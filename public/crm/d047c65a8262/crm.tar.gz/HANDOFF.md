# High Life CRM — передача кода

Снимок ветки `main` на 2026-10-16. CRM для посуточной аренды апартаментов: клиенты, воронки и сделки,
единый inbox (Telegram, WhatsApp), брони и шахматка, интеграция с RealtyCalendar, отчёты.

## С чего начать

| Файл | Что там |
|---|---|
| `README.md` | Структура, локальный запуск, проверки |
| `docs/DEPLOY.md` | Сервер с нуля: Docker + Caddy (HTTPS), настройки, бэкапы, обновление, неполадки |
| `docs/PLAN.md` | Что сделано по этапам, устройство модулей, решения |
| `CLAUDE.md` | Рабочие заметки: локальная разработка без Docker, миграции, известные проблемы |

Стек: монорепо pnpm 11 + Turborepo, Node.js 22+. `apps/api` — NestJS + Prisma 7 (PostgreSQL),
`apps/web` — Next.js 16, `packages/shared` — zod-схемы, общие для API и интерфейса.

## Чего в архиве нет (и это нормально)

- **`.env` с секретами.** Для нового сервера секреты генерируются заново командами `openssl` из
  `deploy/.env.production.example`. Ключи внешних сервисов (Telegram `api_id`/`api_hash`, инстанс
  Green-API) — у владельца; их не пересылают в мессенджерах.
- **База данных и файлы переписки.** Живут на сервере, ежедневный бэкап — `/var/backups/crm`
  (`docs/DEPLOY.md`, §7). Переносить данные — отдельно, по согласованию с владельцем.
- **Выгрузки RealtyCalendar (`imports/`)** — в них персональные данные гостей.
- **История git** — только текущее состояние кода.

## Развёртывание из архива

`docs/DEPLOY.md` §3 описывает выкладку из git (`git archive`). Из архива то же самое:

```bash
scp high-life-crm-2026-10-16.zip ПОЛЬЗОВАТЕЛЬ@IP_СЕРВЕРА:/tmp/
ssh ПОЛЬЗОВАТЕЛЬ@IP_СЕРВЕРА 'sudo apt install -y unzip && sudo install -d -m 750 /opt/crm \
  && cd /tmp && unzip -q high-life-crm-2026-10-16.zip && sudo cp -a high-life-crm/. /opt/crm/ \
  && rm -rf /tmp/high-life-crm /tmp/high-life-crm-2026-10-16.zip'
```

Дальше — `docs/DEPLOY.md` с §4. Файл `deploy/.env.production.example` положен в архив отдельно
(в репозитории его скрывает правило `.env.*` из `.gitignore`).

В документации указаны текущий домен `crm.high-life-apartments.uz`, IP и пользователь рабочего сервера.
Для другого сервера или домена поменяйте в `.env`: `DOMAIN`, `WEB_ORIGIN`, `PUBLIC_API_URL`,
`SEED_ADMIN_EMAIL`. DNS-запись **A** домена должна указывать на новый сервер до запуска Caddy.

## Проверка после сборки

```bash
pnpm install
pnpm lint && pnpm build && pnpm test
curl https://ВАШ_ДОМЕН/api/health
```
