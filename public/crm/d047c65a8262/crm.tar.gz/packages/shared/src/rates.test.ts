import { describe, expect, it } from 'vitest';
import { MAX_RATE_CELLS, nightsOfRateUpdate, rateRangeQuerySchema, rateUpdateSchema } from './rates.js';

const A = '3f1c2a4e-8b7d-4c6e-9a1b-2d3e4f5a6b7c';
const B = '9a8b7c6d-5e4f-4a3b-8c2d-1e0f9a8b7c6d';
const base = { propertyIds: [A], from: '2026-11-01', to: '2026-11-30' };

describe('rateUpdateSchema', () => {
  it('keeps unset fields undefined so they are not changed, and defaults weekdays to every day', () => {
    const result = rateUpdateSchema.parse({ ...base, price: 85 });

    expect(result).toEqual({ ...base, weekdays: [], price: 85 });
  });

  it('accepts null to remove a price or a minimum stay', () => {
    const result = rateUpdateSchema.parse({ ...base, price: null, minStay: null });

    expect(result.price).toBeNull();
    expect(result.minStay).toBeNull();
  });

  it('drops repeated apartments and weekdays', () => {
    const result = rateUpdateSchema.parse({ ...base, propertyIds: [A, B, A], weekdays: [5, 6, 5], closed: true });

    expect(result.propertyIds).toEqual([A, B]);
    expect(result.weekdays).toEqual([5, 6]);
  });

  it('rejects a request that changes nothing', () => {
    expect(rateUpdateSchema.safeParse(base).success).toBe(false);
  });

  it('rejects the end before the start', () => {
    expect(rateUpdateSchema.safeParse({ ...base, from: '2026-11-30', to: '2026-11-01', price: 85 }).success).toBe(false);
  });

  it('rejects a period longer than two years', () => {
    expect(rateUpdateSchema.safeParse({ ...base, from: '2026-01-01', to: '2028-06-01', price: 85 }).success).toBe(false);
  });

  it('rejects a zero or negative price and a minimum stay below one night', () => {
    expect(rateUpdateSchema.safeParse({ ...base, price: 0 }).success).toBe(false);
    expect(rateUpdateSchema.safeParse({ ...base, price: -5 }).success).toBe(false);
    expect(rateUpdateSchema.safeParse({ ...base, minStay: 0 }).success).toBe(false);
  });

  it('rejects a price that would round to zero cents', () => {
    expect(rateUpdateSchema.safeParse({ ...base, price: 0.001 }).success).toBe(false);
  });

  it('accepts a night price in sums', () => {
    expect(rateUpdateSchema.safeParse({ ...base, price: 1_200_000 }).success).toBe(true);
  });

  it('rejects weekdays outside Sunday (0) to Saturday (6)', () => {
    expect(rateUpdateSchema.safeParse({ ...base, weekdays: [7], price: 85 }).success).toBe(false);
  });

  it('rejects more apartment-nights than one request may change', () => {
    const propertyIds = Array.from({ length: 40 }, (_, i) => `3f1c2a4e-8b7d-4c6e-9a1b-${String(i).padStart(12, '0')}`);
    const result = rateUpdateSchema.safeParse({ propertyIds, from: '2026-01-01', to: '2027-12-31', price: 85 });

    expect(40 * 730).toBeGreaterThan(MAX_RATE_CELLS);
    expect(result.success).toBe(false);
  });
});

describe('nightsOfRateUpdate', () => {
  it('counts every night of the period when no weekdays are chosen', () => {
    expect(nightsOfRateUpdate({ from: '2026-11-01', to: '2026-11-30', weekdays: [] })).toHaveLength(30);
  });

  it('keeps only the chosen weekdays (Friday and Saturday)', () => {
    // 2026-11-06 — пятница.
    expect(nightsOfRateUpdate({ from: '2026-11-01', to: '2026-11-14', weekdays: [5, 6] })).toEqual([
      '2026-11-06',
      '2026-11-07',
      '2026-11-13',
      '2026-11-14',
    ]);
  });
});

describe('rateRangeQuerySchema', () => {
  it('accepts the chessboard window and rejects a too long one', () => {
    expect(rateRangeQuerySchema.safeParse({ from: '2026-11-01', to: '2027-02-20' }).success).toBe(true);
    expect(rateRangeQuerySchema.safeParse({ from: '2026-01-01', to: '2026-12-31' }).success).toBe(false);
  });

  it('rejects dates the database cannot compare (a typo in the year)', () => {
    expect(rateRangeQuerySchema.safeParse({ from: '0000-01-01', to: '0000-02-01' }).success).toBe(false);
  });
});
