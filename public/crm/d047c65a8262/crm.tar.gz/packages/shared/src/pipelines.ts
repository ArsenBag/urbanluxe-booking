import { z } from 'zod';
import { nonEmptyPatch, uuidSchema } from './common.js';

export const STAGE_KINDS = ['OPEN', 'WON', 'LOST'] as const;

export type StageKind = (typeof STAGE_KINDS)[number];

export const STAGE_KIND_LABELS: Record<StageKind, string> = {
  OPEN: 'В работе',
  WON: 'Успешно закрыта',
  LOST: 'Отказ',
};

const nameSchema = z.string().trim().min(1, 'Введите название').max(60, 'Не длиннее 60 символов');

export const createPipelineSchema = z.object({ name: nameSchema });
export const updatePipelineSchema = createPipelineSchema;

const stageFields = z.object({
  name: nameSchema,
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Цвет в формате #RRGGBB'),
  kind: z.enum(STAGE_KINDS),
});

export const createStageSchema = stageFields.extend({
  color: stageFields.shape.color.default('#94a3b8'),
  kind: stageFields.shape.kind.default('OPEN'),
});
export const updateStageSchema = nonEmptyPatch(stageFields);

export const reorderStagesSchema = z.object({
  stageIds: z.array(uuidSchema).min(1, 'Список этапов пуст'),
});

export type CreatePipelineInput = z.infer<typeof createPipelineSchema>;
export type CreateStageInput = z.infer<typeof createStageSchema>;
export type UpdateStageInput = z.infer<typeof updateStageSchema>;
export type ReorderStagesInput = z.infer<typeof reorderStagesSchema>;

export interface StageDto {
  id: string;
  name: string;
  position: number;
  color: string;
  kind: StageKind;
}

export interface PipelineDto {
  id: string;
  name: string;
  position: number;
  stages: StageDto[];
}
