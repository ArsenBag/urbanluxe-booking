import { z } from 'zod';
import { uuidSchema } from './common.js';

/**
 * Правила автопереноса сделок по датам брони (время ташкентское):
 * CHECK_IN — «Заезд сегодня» в день заезда, CHECK_OUT_SOON — «Выезд завтра» накануне выезда
 * (только из «Заселён»), CHECKED_OUT — «Выехал» в день выезда.
 */
export const STAGE_RULES = ['CHECK_IN', 'CHECK_OUT_SOON', 'CHECKED_OUT'] as const;
export type StageRule = (typeof STAGE_RULES)[number];

const timeSchema = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Время в формате ЧЧ:ММ');
const stageIdSchema = uuidSchema.nullable();

/** Поля этапов в порядке воронки (и блока настройки): каждый следующий этап должен стоять дальше предыдущего. */
export const STAGE_AUTOMATION_STAGE_FIELDS = ['checkInStageId', 'checkedInStageId', 'checkOutSoonStageId', 'checkedOutStageId'] as const;
export type StageAutomationStageField = (typeof STAGE_AUTOMATION_STAGE_FIELDS)[number];

/** Пустой этап выключает правило; «Заселён» сам не ставится — его отмечает менеджер. */
export const stageAutomationSchema = z
  .object({
    enabled: z.boolean(),
    checkInStageId: stageIdSchema,
    checkInTime: timeSchema,
    checkedInStageId: stageIdSchema,
    checkOutSoonStageId: stageIdSchema,
    checkOutSoonTime: timeSchema,
    checkedOutStageId: stageIdSchema,
    checkedOutTime: timeSchema,
  })
  .superRefine((value, ctx) => {
    if (value.checkOutSoonStageId && !value.checkedInStageId) {
      ctx.addIssue({
        code: 'custom',
        path: ['checkedInStageId'],
        message: 'Выберите этап, из которого сделка уходит в «Выезд завтра»',
      });
    }
    // Повтор этапа отмечается у нижнего из двух полей.
    const seen = new Set<string>();
    for (const field of STAGE_AUTOMATION_STAGE_FIELDS) {
      const stageId = value[field];
      if (!stageId) continue;
      if (seen.has(stageId)) ctx.addIssue({ code: 'custom', path: [field], message: 'Этот этап уже выбран выше' });
      seen.add(stageId);
    }
  });

export type StageAutomationInput = z.infer<typeof stageAutomationSchema>;
export type StageAutomationDto = StageAutomationInput;
