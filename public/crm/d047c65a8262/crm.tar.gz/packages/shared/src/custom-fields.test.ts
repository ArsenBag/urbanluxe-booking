import { describe, expect, it } from 'vitest';
import {
  checkCustomFieldValue,
  createCustomFieldSchema,
  customFieldValuesSchema,
  formatCustomFieldValue,
  updateCustomFieldSchema,
} from './custom-fields.js';

describe('createCustomFieldSchema', () => {
  it('requires options for a list and dedupes them', () => {
    expect(createCustomFieldSchema.safeParse({ entity: 'CONTACT', label: 'Гражданство', type: 'SELECT', options: [] }).success).toBe(false);
    expect(
      createCustomFieldSchema.parse({ entity: 'DEAL', label: 'Оплата', type: 'SELECT', options: [' Наличные ', 'Карта', 'Наличные'] })
        .options,
    ).toEqual(['Наличные', 'Карта']);
  });

  it('drops options for non-list types', () => {
    expect(createCustomFieldSchema.parse({ entity: 'CONTACT', label: 'Паспорт', type: 'TEXT', options: ['x'] }).options).toEqual([]);
  });

  it('does not allow changing the type later', () => {
    expect(updateCustomFieldSchema.parse({ label: 'Новое', type: 'NUMBER' })).toEqual({ label: 'Новое' });
    expect(updateCustomFieldSchema.safeParse({}).success).toBe(false);
  });
});

describe('customFieldValuesSchema', () => {
  it('accepts values keyed by field id and rejects other keys', () => {
    const id = '00000000-0000-4000-8000-000000000001';
    expect(customFieldValuesSchema.safeParse({ values: { [id]: 'x' } }).success).toBe(true);
    expect(customFieldValuesSchema.safeParse({ values: { name: 'x' } }).success).toBe(false);
    expect(customFieldValuesSchema.safeParse({ values: { [id]: { nested: true } } }).success).toBe(false);
  });
});

describe('checkCustomFieldValue', () => {
  const field = (type: 'TEXT' | 'NUMBER' | 'DATE' | 'BOOLEAN' | 'SELECT', options: string[] = []) => ({ type, options });

  it('treats empty input as clearing the value', () => {
    expect(checkCustomFieldValue(field('NUMBER'), '  ')).toEqual({ ok: true, value: null });
    expect(checkCustomFieldValue(field('SELECT', ['A']), null)).toEqual({ ok: true, value: null });
  });

  it('normalizes numbers typed with a comma or spaces', () => {
    expect(checkCustomFieldValue(field('NUMBER'), '1 500,5')).toEqual({ ok: true, value: 1500.5 });
    expect(checkCustomFieldValue(field('NUMBER'), 'abc').ok).toBe(false);
    expect(checkCustomFieldValue(field('NUMBER'), Number.POSITIVE_INFINITY).ok).toBe(false);
  });

  it('validates dates, booleans and list options', () => {
    expect(checkCustomFieldValue(field('DATE'), '2026-02-30').ok).toBe(false);
    expect(checkCustomFieldValue(field('DATE'), '2026-10-20')).toEqual({ ok: true, value: '2026-10-20' });
    expect(checkCustomFieldValue(field('BOOLEAN'), false)).toEqual({ ok: true, value: false });
    expect(checkCustomFieldValue(field('BOOLEAN'), 'да').ok).toBe(false);
    expect(checkCustomFieldValue(field('SELECT', ['Карта']), 'Наличные').ok).toBe(false);
    expect(checkCustomFieldValue(field('TEXT'), 42).ok).toBe(false);
    expect(checkCustomFieldValue(field('TEXT'), 'a'.repeat(1001)).ok).toBe(false);
  });
});

describe('formatCustomFieldValue', () => {
  it('formats values for the card', () => {
    // Intl разделяет разряды неразрывным пробелом.
    expect(formatCustomFieldValue({ type: 'NUMBER' }, 1500).replace(/\s/g, ' ')).toBe('1 500');
    expect(formatCustomFieldValue({ type: 'DATE' }, '2026-10-20')).toBe('20.10.2026');
    expect(formatCustomFieldValue({ type: 'BOOLEAN' }, false)).toBe('Нет');
    expect(formatCustomFieldValue({ type: 'TEXT' }, undefined)).toBe('—');
  });
});

describe('checkCustomFieldValue edge cases', () => {
  it('accepts only plain decimal numbers', () => {
    for (const value of ['0x1F', '1e5', '0b11', '1.2.3', '--1']) {
      expect(checkCustomFieldValue({ type: 'NUMBER', options: [] }, value).ok).toBe(false);
    }
    expect(checkCustomFieldValue({ type: 'NUMBER', options: [] }, '-2,5')).toEqual({ ok: true, value: -2.5 });
  });

  it('rejects the NUL character that PostgreSQL cannot store', () => {
    const nul = String.fromCharCode(0);
    expect(checkCustomFieldValue({ type: 'TEXT', options: [] }, `a${nul}b`).ok).toBe(false);
    expect(createCustomFieldSchema.safeParse({ entity: 'DEAL', label: 'x', type: 'SELECT', options: [`a${nul}`] }).success).toBe(false);
  });
});
