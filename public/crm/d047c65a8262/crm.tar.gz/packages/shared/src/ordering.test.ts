import { describe, expect, it } from 'vitest';
import { POSITION_STEP, positionBetween } from './ordering.js';

describe('positionBetween', () => {
  it('starts an empty column at one step', () => {
    expect(positionBetween(null, null)).toBe(POSITION_STEP);
  });

  it('appends after the last card', () => {
    expect(positionBetween(3000, null)).toBe(3000 + POSITION_STEP);
  });

  it('prepends before the first card', () => {
    expect(positionBetween(null, 1000)).toBe(500);
  });

  it('puts a card between two neighbours', () => {
    expect(positionBetween(1000, 2000)).toBe(1500);
  });

  it('returns null when neighbours are too close and the column needs rebalancing', () => {
    expect(positionBetween(1, 1 + 1e-10)).toBeNull();
  });

  it('returns null when repeated prepends have squeezed the first card to zero', () => {
    expect(positionBetween(null, 1e-9)).toBeNull();
  });

  it('returns null when neighbours are out of order', () => {
    expect(positionBetween(2000, 1000)).toBeNull();
  });
});
