import { describe, expect, it } from 'vitest';
import { firstName, renderTemplate, templateFileBodyError } from './templates.js';

describe('templateFileBodyError', () => {
  it('lets a template with a file keep a text that fits a caption', () => {
    expect(templateFileBodyError('Видео входа в U-Tower')).toBeNull();
    expect(templateFileBodyError(`${'a'.repeat(1024)}  `)).toBeNull();
  });

  it('explains the caption limit for a longer text', () => {
    expect(templateFileBodyError('a'.repeat(1025))).toBe('С файлом текст становится подписью — не длиннее 1024 символов');
  });
});

describe('renderTemplate', () => {
  it('substitutes known variables', () => {
    expect(renderTemplate('Здравствуйте, {имя}!', { имя: 'Азиз' })).toBe('Здравствуйте, Азиз!');
  });

  it('leaves unknown variables visible so the manager notices them', () => {
    expect(renderTemplate('Код: {код}', { имя: 'Азиз' })).toBe('Код: {код}');
  });

  it('drops the variable with its leading separator when the value is empty', () => {
    expect(renderTemplate('Здравствуйте, {имя}!', { имя: '' })).toBe('Здравствуйте!');
  });
});

describe('firstName', () => {
  it('takes the first word of a full name', () => {
    expect(firstName('Дилноза Каримова')).toBe('Дилноза');
  });

  it('ignores names that are phone numbers or usernames', () => {
    expect(firstName('+998901234567')).toBe('');
    expect(firstName('@guest_2026')).toBe('');
  });
});

describe('renderTemplate with booking variables', () => {
  it('fills booking details and keeps unknown ones visible', () => {
    const text = renderTemplate('{имя}, ждём вас {заезд} в {объект}. Код: {код}', { имя: 'Азиз', заезд: '20 окт.', объект: 'U-Tower' });

    expect(text).toBe('Азиз, ждём вас 20 окт. в U-Tower. Код: {код}');
  });

  it('leaves booking variables visible when inserted manually without booking data', () => {
    expect(renderTemplate('Заезд {заезд}', { имя: 'Азиз' })).toBe('Заезд {заезд}');
  });
});
