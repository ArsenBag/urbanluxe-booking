import { describe, expect, it } from 'vitest';
import { listParam } from './common.js';
import { dealBoardQuerySchema } from './deals.js';
import { conversationListQuerySchema } from './inbox.js';
import { z } from 'zod';

const PIPELINE = '1b4e28ba-2fa1-41d2-883f-0016d3cca427';
const USER = '6ec0bd7f-11c0-43da-975e-2a8ad9ebae0b';

describe('listParam', () => {
  const schema = listParam(z.enum(['A', 'B']));

  it('splits a comma-separated query value and drops blanks', () => {
    expect(schema.parse('A, B,,')).toEqual(['A', 'B']);
  });

  it('rejects unknown items and overlong lists', () => {
    expect(schema.safeParse('A,C').success).toBe(false);
    expect(listParam(z.string(), 2).safeParse('a,b,c').success).toBe(false);
  });
});

describe('dealBoardQuerySchema', () => {
  it('needs only the pipeline', () => {
    expect(dealBoardQuerySchema.parse({ pipelineId: PIPELINE })).toEqual({ pipelineId: PIPELINE });
  });

  it('parses date ranges, owners including "nobody" and client sources', () => {
    const parsed = dealBoardQuerySchema.parse({
      pipelineId: PIPELINE,
      createdFrom: '2026-10-01',
      createdTo: '2026-10-31',
      closedFrom: '2026-09-01',
      ownerIds: `${USER},none`,
      sources: 'TELEGRAM,BOOKING',
    });
    expect(parsed.ownerIds).toEqual([USER, 'none']);
    expect(parsed.sources).toEqual(['TELEGRAM', 'BOOKING']);
    expect(parsed.closedFrom).toBe('2026-09-01');
  });

  it('parses the check-in range and a trimmed name search', () => {
    const parsed = dealBoardQuerySchema.parse({ pipelineId: PIPELINE, checkInFrom: '2026-10-10', checkInTo: '2026-10-20', search: '  Анна ' });
    expect(parsed).toMatchObject({ checkInFrom: '2026-10-10', checkInTo: '2026-10-20', search: 'Анна' });
    expect(dealBoardQuerySchema.safeParse({ pipelineId: PIPELINE, checkInFrom: '2026-10-20', checkInTo: '2026-10-10' }).success).toBe(false);
    expect(dealBoardQuerySchema.safeParse({ pipelineId: PIPELINE, search: 'x'.repeat(101) }).success).toBe(false);
  });

  it('rejects inverted ranges, ancient dates and unknown values', () => {
    expect(dealBoardQuerySchema.safeParse({ pipelineId: PIPELINE, createdFrom: '2026-10-02', createdTo: '2026-10-01' }).success).toBe(false);
    expect(dealBoardQuerySchema.safeParse({ pipelineId: PIPELINE, closedFrom: '2026-10-02', closedTo: '2026-10-01' }).success).toBe(false);
    expect(dealBoardQuerySchema.safeParse({ pipelineId: PIPELINE, closedFrom: '0001-01-01' }).success).toBe(false);
    expect(dealBoardQuerySchema.safeParse({ pipelineId: PIPELINE, ownerIds: 'someone' }).success).toBe(false);
    expect(dealBoardQuerySchema.safeParse({ pipelineId: PIPELINE, sources: 'PIGEON' }).success).toBe(false);
  });
});

describe('conversationListQuerySchema', () => {
  it('keeps the old defaults', () => {
    expect(conversationListQuerySchema.parse({})).toMatchObject({ filter: 'all', status: 'OPEN', unanswered: false });
  });

  it('filters by messenger, employee and unanswered', () => {
    expect(conversationListQuerySchema.parse({ channelType: 'WHATSAPP', assigneeId: USER, unanswered: 'true' })).toMatchObject({
      channelType: 'WHATSAPP',
      assigneeId: USER,
      unanswered: true,
    });
    expect(conversationListQuerySchema.parse({ unanswered: 'false' }).unanswered).toBe(false);
  });

  it('rejects unknown messengers and malformed employees', () => {
    expect(conversationListQuerySchema.safeParse({ channelType: 'SMS' }).success).toBe(false);
    expect(conversationListQuerySchema.safeParse({ assigneeId: 'me' }).success).toBe(false);
  });
});
