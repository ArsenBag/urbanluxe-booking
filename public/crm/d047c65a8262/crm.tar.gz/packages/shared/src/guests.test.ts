import { describe, expect, it } from 'vitest';
import { createContactSchema, updateContactSchema } from './contacts.js';
import { blacklistInputSchema, completedStays } from './guests.js';

const stay = (status: 'BOOKED' | 'REQUEST' | 'CANCELED' | 'DELETED', checkOut: string) => ({ status, checkOut });

describe('completedStays', () => {
  const today = '2026-10-14';

  it('counts confirmed bookings whose check-out has passed or is today', () => {
    const bookings = [stay('BOOKED', '2025-05-02'), stay('BOOKED', '2026-10-14')];

    expect(completedStays(bookings, today)).toBe(2);
  });

  it('does not count the current or a future stay: the guest is still a first-timer', () => {
    expect(completedStays([stay('BOOKED', '2026-10-15'), stay('BOOKED', '2027-01-03')], today)).toBe(0);
  });

  it('ignores requests, canceled and deleted bookings', () => {
    const bookings = [stay('REQUEST', '2026-01-01'), stay('CANCELED', '2026-01-01'), stay('DELETED', '2026-01-01')];

    expect(completedStays(bookings, today)).toBe(0);
  });

  it('returns 0 for a guest without bookings', () => {
    expect(completedStays([], today)).toBe(0);
  });
});

describe('blacklistInputSchema', () => {
  it('trims the reason', () => {
    expect(blacklistInputSchema.parse({ reason: '  Испортил мебель ' })).toEqual({ reason: 'Испортил мебель' });
  });

  it('requires a reason so colleagues know why the guest is listed', () => {
    expect(blacklistInputSchema.safeParse({ reason: '   ' }).success).toBe(false);
    expect(blacklistInputSchema.safeParse({}).success).toBe(false);
  });

  it('keeps line breaks but rejects invisible control and direction characters', () => {
    expect(blacklistInputSchema.safeParse({ reason: 'Шумел\nночью' }).success).toBe(true);
    expect(blacklistInputSchema.safeParse({ reason: 'a\u0000b' }).success).toBe(false);
    expect(blacklistInputSchema.safeParse({ reason: 'a\u202Eb' }).success).toBe(false);
  });

  it('rejects an overly long reason', () => {
    expect(blacklistInputSchema.safeParse({ reason: 'а'.repeat(501) }).success).toBe(false);
  });
});

describe('contact VIP flag', () => {
  it('defaults to a regular guest on create', () => {
    expect(createContactSchema.parse({ name: 'Гость' }).vip).toBe(false);
  });

  it('can be toggled alone with a patch', () => {
    expect(updateContactSchema.parse({ vip: true })).toEqual({ vip: true });
  });
});
