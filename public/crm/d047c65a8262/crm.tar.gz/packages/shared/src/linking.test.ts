import { describe, expect, it } from 'vitest';
import { linkConversationSchema, linkSearchQuerySchema, linkTargetSchema } from './linking.js';

const BOOKING_ID = '0b5f3f4e-8c1a-4d2b-9a6e-1f2e3d4c5b6a';
const DEAL_ID = '1c6a4a5f-9d2b-4e3c-8b7f-2a3b4c5d6e7f';

describe('linkTargetSchema', () => {
  it('accepts exactly one of a booking or a deal', () => {
    expect(linkTargetSchema.safeParse({ bookingId: BOOKING_ID }).success).toBe(true);
    expect(linkTargetSchema.safeParse({ dealId: DEAL_ID }).success).toBe(true);
  });

  it('rejects both or neither', () => {
    expect(linkTargetSchema.safeParse({ bookingId: BOOKING_ID, dealId: DEAL_ID }).success).toBe(false);
    expect(linkTargetSchema.safeParse({}).success).toBe(false);
  });
});

describe('linkConversationSchema', () => {
  it('keeps the conversation name and merges no deals or other cards by default', () => {
    const parsed = linkConversationSchema.parse({ bookingId: BOOKING_ID });

    expect(parsed).toEqual({ bookingId: BOOKING_ID, useOtherName: false, mergeDealId: null, mergeContactId: null });
  });

  it('rejects a request without a booking or a deal', () => {
    expect(linkConversationSchema.safeParse({ useOtherName: true }).success).toBe(false);
  });

  it('rejects a deal merged with itself', () => {
    expect(linkConversationSchema.safeParse({ dealId: DEAL_ID, mergeDealId: DEAL_ID }).success).toBe(false);
  });
});

describe('linkSearchQuerySchema', () => {
  it('trims the query and treats a missing one as empty', () => {
    expect(linkSearchQuerySchema.parse({ q: '  U-51 ' }).q).toBe('U-51');
    expect(linkSearchQuerySchema.parse({}).q).toBe('');
  });

  it('rejects overly long queries', () => {
    expect(linkSearchQuerySchema.safeParse({ q: 'x'.repeat(101) }).success).toBe(false);
  });
});
