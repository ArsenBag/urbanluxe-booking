import { z } from 'zod';
import { nonEmptyPatch, optionalText, paginationSchema, uuidSchema, type EntityRef } from './common.js';
import type { CustomFieldValues } from './custom-fields.js';
import type { GuestBlacklistDto } from './guests.js';
import { normalizePhone } from './phone.js';

export const CONTACT_SOURCES = [
  'WEBSITE',
  'TELEGRAM',
  'WHATSAPP',
  'INSTAGRAM',
  'PHONE',
  'BOOKING',
  'AIRBNB',
  'REFERRAL',
  'REPEAT',
  'OTHER',
] as const;

export type ContactSource = (typeof CONTACT_SOURCES)[number];

export const CONTACT_SOURCE_LABELS: Record<ContactSource, string> = {
  WEBSITE: 'Сайт',
  TELEGRAM: 'Telegram',
  WHATSAPP: 'WhatsApp',
  INSTAGRAM: 'Instagram',
  PHONE: 'Звонок',
  BOOKING: 'Booking.com',
  AIRBNB: 'Airbnb',
  REFERRAL: 'По рекомендации',
  REPEAT: 'Повторный гость',
  OTHER: 'Другое',
};

const MAX_PHONES = 5;
const MAX_TAGS = 10;
const MAX_TAG_LENGTH = 30;

const phoneSchema = z.string().transform((value, context) => {
  const normalized = normalizePhone(value);
  if (!normalized) {
    context.addIssue({ code: 'custom', message: `Некорректный телефон: ${value}` });
    return z.NEVER;
  }
  return normalized;
});

const contactFields = z.object({
  name: z.string().trim().min(1, 'Введите имя').max(120, 'Не длиннее 120 символов'),
  phones: z
    .array(phoneSchema)
    .max(MAX_PHONES, `Не больше ${MAX_PHONES} телефонов`)
    .transform((phones) => [...new Set(phones)]),
  email: z
    .string()
    .trim()
    .toLowerCase()
    .transform((value) => (value === '' ? null : value))
    .pipe(z.email('Некорректный email').nullable())
    .nullable(),
  source: z.enum(CONTACT_SOURCES),
  tags: z
    .array(z.string().trim().min(1).max(MAX_TAG_LENGTH, `Тег не длиннее ${MAX_TAG_LENGTH} символов`))
    .max(MAX_TAGS, `Не больше ${MAX_TAGS} тегов`)
    .transform((tags) => [...new Set(tags)]),
  notes: optionalText(5000),
  ownerId: uuidSchema.nullable(),
  vip: z.boolean(),
});

export const createContactSchema = contactFields.extend({
  phones: contactFields.shape.phones.default([]),
  email: contactFields.shape.email.default(null),
  source: contactFields.shape.source.default('OTHER'),
  tags: contactFields.shape.tags.default([]),
  notes: contactFields.shape.notes.default(null),
  vip: contactFields.shape.vip.default(false),
  /** Если не указан — создатель карточки. */
  ownerId: contactFields.shape.ownerId.optional(),
});

export const updateContactSchema = nonEmptyPatch(contactFields);

export const contactListQuerySchema = paginationSchema.extend({
  search: z.string().trim().max(100).optional(),
});

export type CreateContactInput = z.infer<typeof createContactSchema>;
export type UpdateContactInput = z.infer<typeof updateContactSchema>;
export type ContactListQuery = z.infer<typeof contactListQuerySchema>;

export interface ContactDto {
  id: string;
  name: string;
  phones: string[];
  email: string | null;
  source: ContactSource;
  tags: string[];
  notes: string | null;
  owner: EntityRef | null;
  /** Значения полей, настроенных администратором: id поля → значение. */
  customFields: CustomFieldValues;
  vip: boolean;
  /** null — гость не в чёрном списке. */
  blacklist: GuestBlacklistDto | null;
  createdAt: string;
  updatedAt: string;
}

export interface ContactListItemDto extends ContactDto {
  openDealsCount: number;
}
