import { z } from 'zod';
import { emailSchema, passwordSchema } from './auth.js';
import { ROLES, type Role } from './roles.js';

const NAME_MAX_LENGTH = 100;

const nameSchema = z
  .string()
  .trim()
  .min(1, 'Введите имя')
  .max(NAME_MAX_LENGTH, `Имя должно быть не длиннее ${NAME_MAX_LENGTH} символов`);

export const createUserSchema = z.object({
  email: emailSchema,
  name: nameSchema,
  password: passwordSchema,
  role: z.enum(ROLES),
});

export const updateUserSchema = z
  .object({
    name: nameSchema,
    role: z.enum(ROLES),
    isActive: z.boolean(),
    password: passwordSchema,
  })
  .partial()
  .refine((value) => Object.keys(value).length > 0, 'Нет полей для обновления');

export type CreateUserInput = z.infer<typeof createUserSchema>;
export type UpdateUserInput = z.infer<typeof updateUserSchema>;

export interface UserDto {
  id: string;
  email: string;
  name: string;
  role: Role;
  isActive: boolean;
  createdAt: string;
}

/** Пользователь для выпадающих списков (ответственный, исполнитель). */
export interface UserOptionDto {
  id: string;
  name: string;
}
