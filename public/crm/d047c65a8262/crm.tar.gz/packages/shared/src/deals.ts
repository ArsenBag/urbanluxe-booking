import { z } from 'zod';
import { filterDateSchema, isoDateSchema, listParam, nonEmptyPatch, optionalText, uuidSchema, type EntityRef } from './common.js';
import { CONTACT_SOURCES } from './contacts.js';
import type { CustomFieldValues } from './custom-fields.js';
import type { StageKind } from './pipelines.js';

export const CURRENCIES = ['USD', 'UZS'] as const;
export type Currency = (typeof CURRENCIES)[number];

const MAX_GUESTS = 50;
const MAX_AMOUNT = 1_000_000_000;

const dealFields = z.object({
  title: z.string().trim().min(1, 'Введите название').max(200, 'Не длиннее 200 символов'),
  ownerId: uuidSchema.nullable(),
  amount: z.number().min(0, 'Сумма не может быть отрицательной').max(MAX_AMOUNT).nullable(),
  currency: z.enum(CURRENCIES),
  checkIn: isoDateSchema.nullable(),
  checkOut: isoDateSchema.nullable(),
  guests: z.number().int().min(1, 'Минимум 1 гость').max(MAX_GUESTS, `Не больше ${MAX_GUESTS} гостей`).nullable(),
  notes: optionalText(5000),
});

/** Выезд строго после заезда, если обе даты указаны. Даты в ISO сравниваются как строки. */
function checkOutAfterCheckIn(value: { checkIn?: string | null; checkOut?: string | null }): boolean {
  return !value.checkIn || !value.checkOut || value.checkOut > value.checkIn;
}

const DATES_ERROR = { message: 'Дата выезда должна быть позже даты заезда', path: ['checkOut'] };

export const createDealSchema = dealFields
  .extend({
    pipelineId: uuidSchema,
    /** Если не указан — первый этап воронки. */
    stageId: uuidSchema.optional(),
    contactId: uuidSchema,
    /** Если не указано — имя клиента. */
    title: dealFields.shape.title.optional(),
    /** Если не указан — создатель сделки. */
    ownerId: dealFields.shape.ownerId.optional(),
    amount: dealFields.shape.amount.default(null),
    currency: dealFields.shape.currency.default('USD'),
    checkIn: dealFields.shape.checkIn.default(null),
    checkOut: dealFields.shape.checkOut.default(null),
    guests: dealFields.shape.guests.default(null),
    notes: dealFields.shape.notes.default(null),
  })
  .refine(checkOutAfterCheckIn, DATES_ERROR);

export const updateDealSchema = nonEmptyPatch(dealFields).refine(checkOutAfterCheckIn, DATES_ERROR);

/** Перемещение карточки: новый этап и соседи сверху и снизу (null — край колонки). */
export const moveDealSchema = z
  .object({
    stageId: uuidSchema,
    prevDealId: uuidSchema.nullable().default(null),
    nextDealId: uuidSchema.nullable().default(null),
    lostReason: optionalText(500).optional(),
  })
  .refine((value) => !value.prevDealId || value.prevDealId !== value.nextDealId, {
    message: 'Соседние карточки сверху и снизу не могут совпадать',
    path: ['nextDealId'],
  });

/** Значение «без ответственного» в фильтре по ответственным. */
export const NO_OWNER_FILTER = 'none';

/** Поиск по сделкам — не длиннее этого. */
export const MAX_DEAL_SEARCH_LENGTH = 100;

/** Потолок карточек на канбане: защита от случайно огромных выборок (например, закрытые за год). */
export const MAX_BOARD_DEALS = 1000;

const RANGE_ERROR = 'Конец периода раньше начала';
const rangeIsOrdered = (from: string | undefined, to: string | undefined) => !from || !to || to >= from;

/**
 * Канбан воронки с фильтрами. Даты — дни по Ташкенту, обе включительно. Фильтр по дате закрытия
 * показывает только закрытые в этот период сделки, в том числе старше 30 дней.
 * Источник — откуда пришёл клиент (Telegram, WhatsApp, Booking…), поле карточки клиента.
 */
export const dealBoardQuerySchema = z
  .object({
    pipelineId: uuidSchema,
    createdFrom: filterDateSchema.optional(),
    createdTo: filterDateSchema.optional(),
    closedFrom: filterDateSchema.optional(),
    closedTo: filterDateSchema.optional(),
    /** Дата заезда в карточке сделки; сделки без даты заезда под этот фильтр не попадают. */
    checkInFrom: filterDateSchema.optional(),
    checkInTo: filterDateSchema.optional(),
    /** Имя клиента, название сделки или цифры телефона. */
    search: z.string().trim().max(MAX_DEAL_SEARCH_LENGTH, `Не длиннее ${MAX_DEAL_SEARCH_LENGTH} символов`).optional(),
    ownerIds: listParam(z.union([uuidSchema, z.literal(NO_OWNER_FILTER)])).optional(),
    sources: listParam(z.enum(CONTACT_SOURCES)).optional(),
  })
  .refine((value) => rangeIsOrdered(value.createdFrom, value.createdTo), { message: RANGE_ERROR, path: ['createdTo'] })
  .refine((value) => rangeIsOrdered(value.closedFrom, value.closedTo), { message: RANGE_ERROR, path: ['closedTo'] })
  .refine((value) => rangeIsOrdered(value.checkInFrom, value.checkInTo), { message: RANGE_ERROR, path: ['checkInTo'] });

export type DealBoardQuery = z.infer<typeof dealBoardQuerySchema>;

export type CreateDealInput = z.infer<typeof createDealSchema>;
export type UpdateDealInput = z.infer<typeof updateDealSchema>;
export type MoveDealInput = z.infer<typeof moveDealSchema>;

export interface DealContactRef extends EntityRef {
  phones: string[];
}

export interface DealDto {
  id: string;
  title: string;
  pipelineId: string;
  stageId: string;
  stageKind: StageKind;
  contact: DealContactRef;
  owner: EntityRef | null;
  /** Decimal строкой, чтобы не терять точность. */
  amount: string | null;
  currency: Currency;
  checkIn: string | null;
  checkOut: string | null;
  guests: number | null;
  notes: string | null;
  position: number;
  closedAt: string | null;
  lostReason: string | null;
  openTasksCount: number;
  /** Значения полей, настроенных администратором: id поля → значение. */
  customFields: CustomFieldValues;
  createdAt: string;
  updatedAt: string;
}

/** Количество ночей между датами заезда и выезда. */
export function nightsBetween(checkIn: string, checkOut: string): number {
  const MS_PER_DAY = 86_400_000;
  return Math.round((Date.parse(checkOut) - Date.parse(checkIn)) / MS_PER_DAY);
}
