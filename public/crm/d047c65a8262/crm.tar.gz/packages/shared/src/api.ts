/** Единый формат ответа API. */
export type ApiResponse<T> =
  | { success: true; data: T; error: null }
  | { success: false; data: null; error: ApiError };

export interface ApiError {
  message: string;
  /** Ошибки по полям формы: имя поля → сообщение. */
  fields?: Record<string, string>;
}
