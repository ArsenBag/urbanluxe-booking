import { z } from 'zod';
import type { ChannelType } from './inbox.js';

/** Лента событий для уведомлений сотрудника: новые входящие сообщения и новые брони. */
export const notificationFeedQuerySchema = z.object({
  /** Курсор из прошлого ответа. Без него сервер вернёт только курсор — без старых событий. */
  after: z.iso.datetime({ offset: true }).optional(),
});
export type NotificationFeedQuery = z.infer<typeof notificationFeedQuerySchema>;

export interface MessageNotification {
  kind: 'message';
  /** id сообщения. */
  id: string;
  at: string;
  conversationId: string;
  contactName: string;
  channelType: ChannelType;
  preview: string;
  /** Пишет гость из чёрного списка — карточка мигает. */
  blacklisted: boolean;
}

export interface BookingNotification {
  kind: 'booking';
  /** id брони. */
  id: string;
  at: string;
  status: 'BOOKED' | 'REQUEST';
  propertyTitle: string | null;
  guestName: string | null;
  checkIn: string;
  checkOut: string;
  origin: string | null;
  /** Бронь на гостя из чёрного списка — карточка мигает. */
  blacklisted: boolean;
}

export type NotificationEvent = MessageNotification | BookingNotification;

export interface NotificationFeedDto {
  /** Передать в after следующего запроса. */
  cursor: string;
  events: NotificationEvent[];
}
