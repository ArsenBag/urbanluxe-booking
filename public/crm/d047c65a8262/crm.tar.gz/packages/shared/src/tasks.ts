import { z } from 'zod';
import { nonEmptyPatch, uuidSchema, type EntityRef } from './common.js';

const taskFields = z.object({
  title: z.string().trim().min(1, 'Введите задачу').max(300, 'Не длиннее 300 символов'),
  dueAt: z.iso.datetime({ offset: true, message: 'Некорректная дата' }).nullable(),
  assigneeId: uuidSchema.nullable(),
});

export const createTaskSchema = taskFields
  .extend({
    dueAt: taskFields.shape.dueAt.default(null),
    /** Если не указан — создатель задачи. */
    assigneeId: taskFields.shape.assigneeId.optional(),
    dealId: uuidSchema.nullable().default(null),
    contactId: uuidSchema.nullable().default(null),
  });

export const updateTaskSchema = nonEmptyPatch(taskFields.extend({ isDone: z.boolean() }));

export const TASK_SCOPES = ['mine', 'all'] as const;
export const TASK_STATUSES = ['open', 'done', 'all'] as const;

export const taskListQuerySchema = z.object({
  scope: z.enum(TASK_SCOPES).default('mine'),
  status: z.enum(TASK_STATUSES).default('open'),
  dealId: uuidSchema.optional(),
  contactId: uuidSchema.optional(),
});

export type CreateTaskInput = z.infer<typeof createTaskSchema>;
export type UpdateTaskInput = z.infer<typeof updateTaskSchema>;
export type TaskListQuery = z.infer<typeof taskListQuerySchema>;

export interface TaskDto {
  id: string;
  title: string;
  dueAt: string | null;
  isDone: boolean;
  doneAt: string | null;
  assignee: EntityRef | null;
  deal: { id: string; title: string } | null;
  contact: EntityRef | null;
  createdAt: string;
}
