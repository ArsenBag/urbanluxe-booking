import { describe, expect, it } from 'vitest';
import {
  attachmentKindForMime,
  canFetchAttachment,
  formatFileSize,
  messagePreview,
  sendFileSchema,
  sendTemplateFileSchema,
} from './inbox.js';

describe('canFetchAttachment', () => {
  it('offers to load photos, videos, voice messages and documents that have no saved file', () => {
    expect(canFetchAttachment({ kind: 'photo' })).toBe(true);
    expect(canFetchAttachment({ kind: 'voice' })).toBe(true);
    expect(canFetchAttachment({ kind: 'document', fileName: 'бронь.pdf' })).toBe(true);
  });

  it('does not offer it when the file is already saved or there is no file at all', () => {
    expect(canFetchAttachment({ kind: 'photo', fileId: 'f1' })).toBe(false);
    expect(canFetchAttachment({ kind: 'sticker' })).toBe(false);
    expect(canFetchAttachment({ kind: 'location' })).toBe(false);
    expect(canFetchAttachment({ kind: 'call', call: { outcome: 'missed' } })).toBe(false);
    expect(canFetchAttachment(null)).toBe(false);
  });
});

describe('attachmentKindForMime', () => {
  it('sends common images as photos and other files as documents', () => {
    expect(attachmentKindForMime('image/jpeg')).toBe('photo');
    expect(attachmentKindForMime('image/svg+xml')).toBe('document');
    expect(attachmentKindForMime('video/mp4')).toBe('video');
    expect(attachmentKindForMime('audio/mpeg')).toBe('audio');
    expect(attachmentKindForMime('application/pdf')).toBe('document');
  });
});

describe('formatFileSize', () => {
  it('formats bytes, kilobytes and megabytes', () => {
    expect(formatFileSize(512)).toBe('512 Б');
    expect(formatFileSize(34 * 1024)).toBe('34 КБ');
    expect(formatFileSize(2.5 * 1024 * 1024)).toBe('2,5 МБ');
  });
});

describe('sendFileSchema', () => {
  it('trims the caption and turns an empty one into null', () => {
    expect(sendFileSchema.parse({ caption: '  Чек  ' })).toEqual({ caption: 'Чек' });
    expect(sendFileSchema.parse({ caption: '   ' })).toEqual({ caption: null });
    expect(sendFileSchema.parse({})).toEqual({ caption: null });
  });

  it('limits the caption length', () => {
    expect(sendFileSchema.safeParse({ caption: 'a'.repeat(1025) }).success).toBe(false);
  });
});

describe('sendTemplateFileSchema', () => {
  const templateId = '0f8fad5b-d9cb-469f-a165-70867728950e';
  const fileId = '7c9e6679-7425-40de-944b-e07fc1f90ae7';

  it('needs the template and the file the manager saw, and keeps the caption rules of an uploaded file', () => {
    expect(sendTemplateFileSchema.parse({ templateId, fileId, caption: '  Вход  ' })).toEqual({ templateId, fileId, caption: 'Вход' });
    expect(sendTemplateFileSchema.parse({ templateId, fileId })).toEqual({ templateId, fileId, caption: null });
    expect(sendTemplateFileSchema.safeParse({ templateId }).success).toBe(false);
    expect(sendTemplateFileSchema.safeParse({ templateId: 'abc', fileId }).success).toBe(false);
    expect(sendTemplateFileSchema.safeParse({ templateId, fileId, caption: 'a'.repeat(1025) }).success).toBe(false);
  });
});

describe('messagePreview with a file', () => {
  it('uses the attachment label when there is no caption', () => {
    expect(messagePreview(null, { kind: 'photo', fileId: 'x' })).toBe('[Фото]');
  });
});
