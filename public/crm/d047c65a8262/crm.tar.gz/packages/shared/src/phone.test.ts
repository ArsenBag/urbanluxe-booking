import { describe, expect, it } from 'vitest';
import { formatPhone, normalizePhone } from './phone.js';

describe('normalizePhone', () => {
  it.each([
    ['+998 93 206 28 91', '+998932062891'],
    ['998932062891', '+998932062891'],
    ['93 206-28-91', '+998932062891'],
    ['(93) 206 28 91', '+998932062891'],
    ['+7 916 123-45-67', '+79161234567'],
    ['8 916 123 45 67', '+79161234567'],
    ['89161234567', '+79161234567'],
    ['+44 20 7946 0958', '+442079460958'],
  ])('normalizes %s to %s', (input, expected) => {
    expect(normalizePhone(input)).toBe(expected);
  });

  it.each(['', 'abc', '12345', '+1234567890123456'])('rejects %s', (input) => {
    expect(normalizePhone(input)).toBeNull();
  });
});

describe('formatPhone', () => {
  it('formats Uzbek numbers for reading', () => {
    expect(formatPhone('+998932062891')).toBe('+998 93 206 28 91');
  });

  it('leaves other countries as is', () => {
    expect(formatPhone('+79161234567')).toBe('+79161234567');
  });
});
