import { z } from 'zod';
import { optionalText, uuidSchema } from './common.js';
import { MAX_MIN_STAY } from './rates.js';

/** Площадки менеджера каналов. Ostrovok — Emerging Travel Group (Ostrovok, RateHawk, ZenHotels). */
export const SALES_CHANNELS = ['AIRBNB', 'BOOKING', 'OSTROVOK', 'WEBSITE'] as const;
export type SalesChannel = (typeof SALES_CHANNELS)[number];

export const SALES_CHANNEL_LABELS: Record<SalesChannel, string> = {
  AIRBNB: 'Airbnb',
  BOOKING: 'Booking.com',
  OSTROVOK: 'Ostrovok',
  WEBSITE: 'Сайт',
};

/** Наценка тарифа: процент или сумма в базовой валюте (как «%» и «$» в RealtyCalendar). */
export const MARKUP_KINDS = ['PERCENT', 'AMOUNT'] as const;
export type MarkupKind = (typeof MARKUP_KINDS)[number];

/** Тарифов у площадки — с большим запасом (в RealtyCalendar обычно 1–3). */
export const MAX_RATE_PLANS = 20;
const MAX_PERCENT = 1000;
const MAX_AMOUNT = 1_000_000_000;

interface Markup {
  markupKind: MarkupKind;
  markupValue: number;
}

/** Цена с наценкой, до цента. Отрицательная наценка — скидка. */
export function applyMarkup(price: number, kind: MarkupKind, value: number): number {
  const raw = kind === 'PERCENT' ? price * (1 + value / 100) : price + value;
  return Math.round(raw * 100) / 100;
}

/**
 * Цена ночи на площадке по тарифу: от базовой цены ночи, а у дочернего тарифа — от цены родительского
 * (так в RealtyCalendar «Невозвратный −5%» считается от «Стандартного +25%», а «std+$» — сумма сверху).
 * Скидка суммой больше цены даёт 0, а не отрицательную цену: такую ночь на площадку не отправляем.
 */
export function ratePlanPrice(base: number, plan: Markup, parent: Markup | null): number {
  const from = parent ? applyMarkup(base, parent.markupKind, parent.markupValue) : base;
  return Math.max(0, applyMarkup(from, plan.markupKind, plan.markupValue));
}

const nightsSchema = z.number().int().min(1, 'Хотя бы одна ночь').max(MAX_MIN_STAY, `Не больше ${MAX_MIN_STAY} ночей`);

export const ratePlanInputSchema = z
  .object({
    /** Есть — тариф уже сохранён (его id связан с тарифом на площадке); нет — новый. */
    id: uuidSchema.optional(),
    name: z.string().trim().min(1, 'Укажите название тарифа').max(100, 'Не длиннее 100 символов'),
    /** Номер родительского тарифа в этом же списке (выше этого); null — от базовой цены. */
    parentIndex: z.number().int().min(0).nullable().default(null),
    markupKind: z.enum(MARKUP_KINDS).default('PERCENT'),
    markupValue: z.number().min(-MAX_AMOUNT).max(MAX_AMOUNT).default(0),
    minNights: nightsSchema.default(1),
    maxNights: nightsSchema.default(MAX_MIN_STAY),
    closed: z.boolean().default(false),
  })
  .refine((plan) => plan.minNights <= plan.maxNights, { message: '«Ночей до» меньше, чем «от»', path: ['maxNights'] })
  .refine((plan) => plan.markupKind !== 'PERCENT' || (plan.markupValue > -100 && plan.markupValue <= MAX_PERCENT), {
    message: 'Скидка меньше 100%, наценка — не больше 1000%',
    path: ['markupValue'],
  });

export type RatePlanInput = z.infer<typeof ratePlanInputSchema>;

/**
 * Площадка у квартиры целиком, как её сохраняет окно менеджера каналов: подключение и список тарифов.
 * Тарифов, которых нет в списке, больше нет; дочерний тариф — только от тарифа выше него и только один уровень.
 */
export const channelListingInputSchema = z
  .object({
    propertyId: uuidSchema,
    channel: z.enum(SALES_CHANNELS),
    enabled: z.boolean().default(true),
    externalHotelId: optionalText(100).default(null),
    externalRoomId: optionalText(100).default(null),
    commissionPercent: z.number().min(0).max(100, 'Комиссия — не больше 100%').nullable().default(null),
    ratePlans: z.array(ratePlanInputSchema).max(MAX_RATE_PLANS, `Не больше ${MAX_RATE_PLANS} тарифов`).default([]),
  })
  .superRefine((listing, context) => {
    listing.ratePlans.forEach((plan, index) => {
      if (plan.parentIndex === null) return;
      const parent = listing.ratePlans[plan.parentIndex];
      if (plan.parentIndex >= index || !parent || parent.parentIndex !== null) {
        context.addIssue({
          code: 'custom',
          message: 'Дочерний тариф считается от основного тарифа выше него',
          path: ['ratePlans', index, 'parentIndex'],
        });
      }
    });
  });

export type ChannelListingInput = z.infer<typeof channelListingInputSchema>;
export type ChannelListingRequest = z.input<typeof channelListingInputSchema>;

export interface ChannelRatePlanDto {
  id: string;
  name: string;
  parentId: string | null;
  markupKind: MarkupKind;
  /** Decimal строкой: процент или сумма в базовой валюте. */
  markupValue: string;
  minNights: number;
  maxNights: number;
  closed: boolean;
}

export interface ChannelListingDto {
  id: string;
  propertyId: string;
  channel: SalesChannel;
  enabled: boolean;
  externalHotelId: string | null;
  externalRoomId: string | null;
  /** Decimal строкой, %; null — не указана. */
  commissionPercent: string | null;
  /** В порядке, как в окне: родительский тариф всегда выше дочернего. */
  ratePlans: ChannelRatePlanDto[];
  updatedAt: string;
}
