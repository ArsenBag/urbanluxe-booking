import { z } from 'zod';
import { isoDateSchema, MIN_FILTER_DATE, uuidSchema } from './common.js';

/** Дальше двух лет вперёд цены не задают — такой период почти всегда опечатка в годе. */
export const MAX_RATE_RANGE_DAYS = 731;
/** Сколько квартиро-ночей меняет один запрос: все квартиры на год вперёд с запасом. */
export const MAX_RATE_CELLS = 25_000;
/** Цены читаются окном шахматки — как и брони, не длиннее этого. */
export const MAX_RATE_QUERY_DAYS = 120;
export const MAX_MIN_STAY = 365;
const MAX_RATE_PROPERTIES = 200;
/** Цена ночи и в сумах помещается с запасом (колонка DECIMAL(12,2)). */
const MAX_NIGHT_PRICE = 1_000_000_000;
/** Меньше цента база округлит до нуля — ночь ушла бы на площадки бесплатной. */
const MIN_NIGHT_PRICE = 0.01;
const MAX_RATE_DATE = '2100-12-31';
const MS_PER_DAY = 86_400_000;

const toUtc = (date: string) => Date.parse(`${date}T00:00:00Z`);
const daysBetween = (from: string, to: string) => Math.round((toUtc(to) - toUtc(from)) / MS_PER_DAY);
const unique = <T>(values: T[]) => [...new Set(values)];

/**
 * Ночи периода [from, to] включительно, оставив только выбранные дни недели (0 — воскресенье … 6 — суббота).
 * Пустой список дней — все ночи периода.
 */
export function nightsOfRateUpdate(input: { from: string; to: string; weekdays: readonly number[] }): string[] {
  const nights: string[] = [];
  for (let time = toUtc(input.from); time <= toUtc(input.to); time += MS_PER_DAY) {
    const date = new Date(time);
    if (input.weekdays.length === 0 || input.weekdays.includes(date.getUTCDay())) nights.push(date.toISOString().slice(0, 10));
  }
  return nights;
}

/**
 * Изменение цен и ограничений на шахматке: квартиры, ночи с from по to включительно (ночь — дата заезда,
 * как ячейка шахматки), по желанию только некоторые дни недели. Поле, которого нет в запросе, не меняется;
 * null у цены или минимума ночей — убрать значение.
 */
export const rateUpdateSchema = z
  .object({
    propertyIds: z.array(uuidSchema).min(1, 'Выберите квартиры').max(MAX_RATE_PROPERTIES).transform(unique),
    from: isoDateSchema,
    to: isoDateSchema,
    weekdays: z.array(z.number().int().min(0).max(6)).max(7).default([]).transform(unique),
    price: z.number().min(MIN_NIGHT_PRICE, 'Цена больше нуля').max(MAX_NIGHT_PRICE, 'Слишком большая цена').nullable().optional(),
    minStay: z.number().int().min(1, 'Хотя бы одна ночь').max(MAX_MIN_STAY, `Не больше ${MAX_MIN_STAY} ночей`).nullable().optional(),
    closed: z.boolean().optional(),
    closedToArrival: z.boolean().optional(),
    closedToDeparture: z.boolean().optional(),
  })
  .refine((value) => value.to >= value.from, { message: 'Конец периода раньше начала', path: ['to'] })
  .refine((value) => value.from >= MIN_FILTER_DATE && value.to <= MAX_RATE_DATE, {
    message: 'Даты — между 2000 и 2100 годом',
    path: ['from'],
  })
  .refine((value) => daysBetween(value.from, value.to) < MAX_RATE_RANGE_DAYS, {
    message: 'Период не длиннее двух лет',
    path: ['to'],
  })
  .refine(
    (value) =>
      [value.price, value.minStay, value.closed, value.closedToArrival, value.closedToDeparture].some((field) => field !== undefined),
    { message: 'Укажите, что изменить: цену, минимум ночей или закрытие', path: ['price'] },
  )
  .refine((value) => value.propertyIds.length * (daysBetween(value.from, value.to) + 1) <= MAX_RATE_CELLS, {
    message: 'Слишком много ночей за раз — разбейте период или выберите меньше квартир',
    path: ['to'],
  });

export type RateUpdateInput = z.infer<typeof rateUpdateSchema>;
export type RateUpdateRequest = z.input<typeof rateUpdateSchema>;

export const rateRangeQuerySchema = z
  .object({ from: isoDateSchema, to: isoDateSchema })
  .refine((value) => value.to >= value.from, { message: 'Конец периода раньше начала', path: ['to'] })
  .refine((value) => value.from >= MIN_FILTER_DATE && value.to <= MAX_RATE_DATE, {
    message: 'Даты — между 2000 и 2100 годом',
    path: ['from'],
  })
  .refine((value) => daysBetween(value.from, value.to) <= MAX_RATE_QUERY_DAYS, {
    message: `Период не длиннее ${MAX_RATE_QUERY_DAYS} дней`,
    path: ['to'],
  });

export type RateRangeQuery = z.infer<typeof rateRangeQuerySchema>;

/** Цена и ограничения квартиры на ночь. Ночи, на которые ничего не задано, не приходят. */
export interface RateDayDto {
  propertyId: string;
  date: string;
  /** Decimal строкой в базовой валюте; null — цена не задана. */
  price: string | null;
  /** Минимум ночей для заезда в эту ночь; null — без ограничения. */
  minStay: number | null;
  /** Продажи закрыты. */
  closed: boolean;
  closedToArrival: boolean;
  closedToDeparture: boolean;
}

export interface RatesDto {
  /** Базовая валюта цен (та же, что у сумм броней). */
  currency: string;
  days: RateDayDto[];
}

export interface RateUpdateResultDto {
  /** Сколько квартиро-ночей записано. */
  nights: number;
}
