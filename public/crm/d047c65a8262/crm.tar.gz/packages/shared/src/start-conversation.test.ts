import { describe, expect, it } from 'vitest';
import { startConversationSchema } from './inbox.js';

const parse = (value: Record<string, unknown>) => startConversationSchema.safeParse({ text: 'Здравствуйте', ...value });

describe('startConversationSchema', () => {
  it('needs a phone for WhatsApp', () => {
    expect(parse({ channel: 'WHATSAPP', phone: '+998901234567' }).success).toBe(true);
    expect(parse({ channel: 'WHATSAPP', username: '@guest_name' }).success).toBe(false);
  });

  it('accepts a phone or a real @username for Telegram', () => {
    expect(parse({ channel: 'TELEGRAM', phone: '+998901234567' }).success).toBe(true);
    expect(parse({ channel: 'TELEGRAM', username: '@guest_name' }).success).toBe(true);
    expect(parse({ channel: 'TELEGRAM', username: 'Guest2025' }).success).toBe(true);
  });

  it('rejects strings Telegram would treat as an id or that cannot be a username', () => {
    expect(parse({ channel: 'TELEGRAM', username: '123456789' }).success).toBe(false);
    expect(parse({ channel: 'TELEGRAM', username: '_guest' }).success).toBe(false);
    expect(parse({ channel: 'TELEGRAM', username: 'guest_' }).success).toBe(false);
    expect(parse({ channel: 'TELEGRAM', username: 'abc' }).success).toBe(false);
    expect(parse({ channel: 'TELEGRAM', username: 't.me/joinchat' }).success).toBe(false);
  });

  it('needs a message', () => {
    expect(parse({ channel: 'WHATSAPP', phone: '+998901234567', text: '   ' }).success).toBe(false);
  });
});
