import { describe, expect, it } from 'vitest';
import { MAX_REPORT_DAYS, funnelReportQuerySchema, listPeriodDates, reportPeriodDays, reportPeriodSchema } from './reports.js';

describe('reportPeriodDays', () => {
  it('counts both ends of the period', () => {
    expect(reportPeriodDays('2026-10-01', '2026-10-01')).toBe(1);
    expect(reportPeriodDays('2026-10-01', '2026-10-31')).toBe(31);
    expect(reportPeriodDays('2026-12-31', '2027-01-01')).toBe(2);
  });
});

describe('listPeriodDates', () => {
  it('lists every day of the period in order', () => {
    expect(listPeriodDates('2026-02-27', '2026-03-02')).toEqual(['2026-02-27', '2026-02-28', '2026-03-01', '2026-03-02']);
  });
});

describe('reportPeriodSchema', () => {
  it('accepts a period up to a year long', () => {
    expect(reportPeriodSchema.safeParse({ from: '2026-01-01', to: '2026-01-01' }).success).toBe(true);
    expect(reportPeriodSchema.safeParse({ from: '2024-01-01', to: '2024-12-31' }).success).toBe(true);
  });

  it('rejects an inverted or overlong period', () => {
    expect(reportPeriodSchema.safeParse({ from: '2026-10-02', to: '2026-10-01' }).success).toBe(false);
    const tooLong = reportPeriodDays('2025-01-01', '2026-01-02');
    expect(tooLong).toBeGreaterThan(MAX_REPORT_DAYS);
    expect(reportPeriodSchema.safeParse({ from: '2025-01-01', to: '2026-01-02' }).success).toBe(false);
  });

  it('rejects periods before the CRM era that the database cannot represent', () => {
    expect(reportPeriodSchema.safeParse({ from: '0001-01-01', to: '0001-01-31' }).success).toBe(false);
    expect(reportPeriodSchema.safeParse({ from: '2000-01-01', to: '2000-01-31' }).success).toBe(true);
  });

  it('rejects malformed dates', () => {
    expect(reportPeriodSchema.safeParse({ from: '01.10.2026', to: '2026-10-31' }).success).toBe(false);
    expect(reportPeriodSchema.safeParse({ from: '2026-10-01' }).success).toBe(false);
  });
});

describe('funnelReportQuerySchema', () => {
  it('takes an optional pipeline and the same period rules', () => {
    expect(funnelReportQuerySchema.safeParse({ from: '2026-10-01', to: '2026-10-31' }).success).toBe(true);
    expect(
      funnelReportQuerySchema.safeParse({ from: '2026-10-01', to: '2026-10-31', pipelineId: '1b4e28ba-2fa1-41d2-883f-0016d3cca427' }).success,
    ).toBe(true);
    expect(funnelReportQuerySchema.safeParse({ from: '2026-10-01', to: '2026-10-31', pipelineId: 'nope' }).success).toBe(false);
    expect(funnelReportQuerySchema.safeParse({ from: '2026-10-31', to: '2026-10-01' }).success).toBe(false);
  });
});
