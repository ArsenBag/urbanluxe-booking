import { z } from 'zod';
import { uuidSchema, type EntityRef } from './common.js';

const MAX_SEARCH_LENGTH = 100;

/** Поиск брони или сделки для связи с диалогом. Пустой запрос — ближайшие заезды или открытые сделки. */
export const linkSearchQuerySchema = z.object({
  q: z.string().trim().max(MAX_SEARCH_LENGTH, `Не длиннее ${MAX_SEARCH_LENGTH} символов`).default(''),
});

export type LinkSearchQuery = z.infer<typeof linkSearchQuerySchema>;

/** Потолок результатов поиска брони или сделки: в окне выбора больше не нужно. */
export const MAX_LINK_SEARCH_RESULTS = 20;

const targetShape = {
  bookingId: uuidSchema.optional(),
  dealId: uuidSchema.optional(),
};

const hasExactlyOneTarget = (value: { bookingId?: string; dealId?: string }) =>
  Boolean(value.bookingId) !== Boolean(value.dealId);

const TARGET_ERROR = { message: 'Выберите бронь или сделку' };

/** С чем связываем диалог: ровно одна бронь или одна сделка. */
export const linkTargetSchema = z.object(targetShape).refine(hasExactlyOneTarget, TARGET_ERROR);

export type LinkTarget = z.infer<typeof linkTargetSchema>;

/**
 * Связать диалог с бронью или сделкой. Карточка клиента брони (сделки) вливается в клиента диалога.
 * useOtherName — взять имя из той карточки (например, настоящее имя из брони вместо ника в мессенджере).
 * mergeDealId — открытая сделка диалога, которая объединится со сделкой брони (чтобы не было двух сделок).
 * mergeContactId — карточка, которую человек видел в окне подтверждения (mergeContact): если к моменту
 * «Связать» бронь уже у другого клиента, сервер откажет, а не вольёт чужую карточку.
 */
export const linkConversationSchema = z
  .object({
    ...targetShape,
    useOtherName: z.boolean().default(false),
    mergeDealId: uuidSchema.nullable().default(null),
    mergeContactId: uuidSchema.nullable().default(null),
  })
  .refine(hasExactlyOneTarget, TARGET_ERROR)
  .refine((value) => !value.mergeDealId || value.mergeDealId !== value.dealId, {
    message: 'Сделку нельзя объединить саму с собой',
    path: ['mergeDealId'],
  });

export type LinkConversationInput = z.infer<typeof linkConversationSchema>;

export interface LinkDealRef {
  id: string;
  title: string;
  stageId: string;
}

/** Другая карточка клиента, которая вольётся в клиента диалога, и что вместе с ней переедет. */
export interface LinkMergeContactDto extends EntityRef {
  bookings: number;
  deals: number;
  conversations: number;
}

/** Что произойдёт при связывании — показывается перед подтверждением. */
export interface LinkPreviewDto {
  /** Клиент диалога: его карточка остаётся. */
  contact: EntityRef;
  /** Бронь или сделка уже у клиента диалога. */
  alreadyLinked: boolean;
  /** null — объединять карточки не нужно. */
  mergeContact: LinkMergeContactDto | null;
  /** Сделка брони или выбранная сделка. */
  targetDeal: LinkDealRef | null;
  /** Открытая сделка клиента диалога без броней: её можно объединить с targetDeal. */
  dealMergeCandidate: LinkDealRef | null;
}

export interface LinkResultDto {
  contactId: string;
  /** Сделка, с которой теперь связан диалог (после объединения сделок — оставшаяся). */
  dealId: string | null;
}
