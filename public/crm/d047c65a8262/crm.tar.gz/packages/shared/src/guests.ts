import { z } from 'zod';
import type { BookingDto } from './bookings.js';
import type { EntityRef } from './common.js';

export const MAX_BLACKLIST_REASON = 500;

const ALLOWED_CONTROL = new Set(['\n', '\r', '\t']);

/** Невидимые символы: управляющие (кроме переноса строки и табуляции) и смены направления текста. */
function hasInvisibleCharacters(value: string): boolean {
  return [...value].some((char) => {
    const code = char.codePointAt(0) ?? 0;
    const isControl = (code < 0x20 && !ALLOWED_CONTROL.has(char)) || code === 0x7f;
    const isDirection = (code >= 0x202a && code <= 0x202e) || (code >= 0x2066 && code <= 0x2069);
    return isControl || isDirection;
  });
}

/** Добавление в чёрный список: причину видят все, кто откроет диалог или карточку гостя. */
export const blacklistInputSchema = z.object({
  reason: z
    .string()
    .trim()
    .min(1, 'Укажите причину')
    .max(MAX_BLACKLIST_REASON, `Не длиннее ${MAX_BLACKLIST_REASON} символов`)
    .refine((value) => !hasInvisibleCharacters(value), 'Уберите из причины невидимые служебные символы'),
});

export type BlacklistInput = z.infer<typeof blacklistInputSchema>;

/** Отметка «в чёрном списке» у клиента: за что, когда и кто добавил. */
export interface GuestBlacklistDto {
  reason: string;
  at: string;
  by: EntityRef | null;
}

/** Строка раздела «Чёрный список». */
export interface BlacklistEntryDto {
  contact: EntityRef & { phones: string[] };
  blacklist: GuestBlacklistDto;
}

/**
 * Сколько раз гость у нас жил: подтверждённые брони с наступившим днём выезда (today — день по Ташкенту, YYYY-MM-DD).
 * Текущее и будущие проживания не считаются: гость в первом проживании — «впервые».
 */
export function completedStays(bookings: readonly Pick<BookingDto, 'status' | 'checkOut'>[], today: string): number {
  return bookings.filter((booking) => booking.status === 'BOOKED' && booking.checkOut <= today).length;
}
