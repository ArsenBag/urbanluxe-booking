import { z } from 'zod';

/** Для новых и изменённых паролей; вход со старыми паролями продолжает работать. */
export const PASSWORD_MIN_LENGTH = 12;
export const PASSWORD_MAX_LENGTH = 128;

export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .pipe(z.email('Некорректный email'));

export const passwordSchema = z
  .string()
  .min(PASSWORD_MIN_LENGTH, `Пароль должен быть не короче ${PASSWORD_MIN_LENGTH} символов`)
  .max(PASSWORD_MAX_LENGTH, `Пароль должен быть не длиннее ${PASSWORD_MAX_LENGTH} символов`);

export const loginSchema = z.object({
  email: emailSchema,
  // На входе не проверяем сложность: только что поле не пустое и не гигантское.
  password: z.string().min(1, 'Введите пароль').max(PASSWORD_MAX_LENGTH),
});

export type LoginInput = z.infer<typeof loginSchema>;
