/** Шаг между карточками на канбане: оставляет место для вставок без перенумерации. */
export const POSITION_STEP = 1000;

/** Минимальный зазор между соседями, ниже которого колонку пора перенумеровать. */
const MIN_GAP = 1e-6;

/**
 * Позиция для карточки между соседями (null — края колонки).
 * Возвращает null, если между соседями не осталось места: колонку нужно перенумеровать.
 */
export function positionBetween(before: number | null, after: number | null): number | null {
  if (before === null && after === null) {
    return POSITION_STEP;
  }
  if (after === null) {
    return (before as number) + POSITION_STEP;
  }
  const lower = before ?? 0;
  if (after - lower < MIN_GAP) {
    return null;
  }
  return (lower + after) / 2;
}
