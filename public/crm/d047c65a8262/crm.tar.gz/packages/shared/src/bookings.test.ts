import { describe, expect, it } from 'vitest';
import { isCrmOnlyBooking, manualBookingSchema } from './bookings.js';

const PROPERTY_ID = '3f1c2a4e-8b7d-4c6e-9a1b-2d3e4f5a6b7c';
const base = { propertyId: PROPERTY_ID, checkIn: '2026-10-12', checkOut: '2026-10-13', guestName: 'Азиз' };

describe('manualBookingSchema', () => {
  it('applies defaults and normalizes the guest phone', () => {
    const result = manualBookingSchema.parse({ ...base, guestPhone: '93 206 28 91' });

    expect(result).toMatchObject({
      status: 'BOOKED',
      guestPhone: '+998932062891',
      contactId: null,
      arrivalTime: null,
      amount: null,
      notes: null,
    });
  });

  it('treats empty text fields as absent', () => {
    const result = manualBookingSchema.parse({ ...base, guestPhone: '  ', notes: '' });

    expect(result.guestPhone).toBeNull();
    expect(result.notes).toBeNull();
  });

  it('rejects an unreadable phone', () => {
    const result = manualBookingSchema.safeParse({ ...base, guestPhone: '123' });

    expect(result.success).toBe(false);
    expect(result.error?.issues[0].path).toEqual(['guestPhone']);
  });

  it('needs at least one night', () => {
    const result = manualBookingSchema.safeParse({ ...base, checkOut: '2026-10-12' });

    expect(result.success).toBe(false);
    expect(result.error?.issues[0].path).toEqual(['checkOut']);
  });

  it('rejects a stay longer than a year, a likely typo in the year', () => {
    expect(manualBookingSchema.safeParse({ ...base, checkOut: '2027-10-12' }).success).toBe(true);
    expect(manualBookingSchema.safeParse({ ...base, checkOut: '2027-10-13' }).success).toBe(false);
  });

  it('rejects dates outside 2000–2100, which are always typos', () => {
    const result = manualBookingSchema.safeParse({ ...base, checkIn: '0001-01-01', checkOut: '0001-01-02' });

    expect(result.success).toBe(false);
    expect(result.error?.issues[0].path).toEqual(['checkIn']);
    expect(manualBookingSchema.safeParse({ ...base, checkIn: '9999-01-01', checkOut: '9999-01-02' }).success).toBe(false);
  });

  it('needs a guest: a CRM client, a name or a phone', () => {
    const result = manualBookingSchema.safeParse({ ...base, guestName: '' });

    expect(result.success).toBe(false);
    expect(result.error?.issues[0].path).toEqual(['guestName']);
    expect(manualBookingSchema.safeParse({ ...base, guestName: null, contactId: PROPERTY_ID }).success).toBe(true);
  });

  it('accepts only HH:MM times and never a canceled status', () => {
    expect(manualBookingSchema.safeParse({ ...base, arrivalTime: '14:30' }).success).toBe(true);
    expect(manualBookingSchema.safeParse({ ...base, arrivalTime: '25:00' }).success).toBe(false);
    expect(manualBookingSchema.safeParse({ ...base, status: 'CANCELED' }).success).toBe(false);
  });

  it('rejects negative money', () => {
    expect(manualBookingSchema.safeParse({ ...base, prepayment: -1 }).success).toBe(false);
  });
});

describe('isCrmOnlyBooking', () => {
  it('is true only for a CRM booking that RealtyCalendar has not sent yet', () => {
    expect(isCrmOnlyBooking({ source: 'CRM', rcId: null })).toBe(true);
    expect(isCrmOnlyBooking({ source: 'CRM', rcId: 42 })).toBe(false);
    expect(isCrmOnlyBooking({ source: 'REALTYCALENDAR', rcId: null })).toBe(false);
  });
});
