import { z } from 'zod';
import { paginationSchema, uuidSchema, type EntityRef } from './common.js';
import type { GuestBlacklistDto } from './guests.js';

export const CHANNEL_TYPES = ['TELEGRAM', 'WHATSAPP', 'INSTAGRAM'] as const;
export type ChannelType = (typeof CHANNEL_TYPES)[number];

export const CHANNEL_TYPE_LABELS: Record<ChannelType, string> = {
  TELEGRAM: 'Telegram',
  WHATSAPP: 'WhatsApp',
  INSTAGRAM: 'Instagram',
};

export const CHANNEL_STATUSES = ['DISCONNECTED', 'AWAITING_CODE', 'AWAITING_PASSWORD', 'CONNECTED', 'ERROR'] as const;
export type ChannelStatus = (typeof CHANNEL_STATUSES)[number];

export const CHANNEL_STATUS_LABELS: Record<ChannelStatus, string> = {
  DISCONNECTED: 'Не подключён',
  AWAITING_CODE: 'Ожидает код из Telegram',
  AWAITING_PASSWORD: 'Ожидает облачный пароль',
  CONNECTED: 'Подключён',
  ERROR: 'Ошибка',
};

export const startTelegramLoginSchema = z.object({
  phone: z.string().trim().min(5, 'Введите номер телефона').max(20),
});
export const telegramCodeSchema = z.object({
  code: z
    .string()
    .trim()
    .regex(/^\d{4,8}$/, 'Код — от 4 до 8 цифр'),
});
export const telegramPasswordSchema = z.object({
  password: z.string().min(1, 'Введите пароль').max(256),
});

export interface ChannelDto {
  id: string;
  type: ChannelType;
  name: string;
  status: ChannelStatus;
  phone: string | null;
  username: string | null;
  lastError: string | null;
  historyImportedAt: string | null;
}

/** Состояние интеграций: настроены ли ключи на сервере. */
export interface ChannelsOverviewDto {
  telegramConfigured: boolean;
  whatsappConfigured: boolean;
  /** Адрес для настройки вебхука в Green-API; null — не задан PUBLIC_API_URL. */
  whatsappWebhookUrl: string | null;
  channels: ChannelDto[];
}

export const CONVERSATION_FILTERS = ['all', 'mine', 'unassigned'] as const;
export const CONVERSATION_STATUSES = ['OPEN', 'CLOSED'] as const;
export type ConversationFilter = (typeof CONVERSATION_FILTERS)[number];
export type ConversationStatus = (typeof CONVERSATION_STATUSES)[number];

export const conversationListQuerySchema = paginationSchema.extend({
  filter: z.enum(CONVERSATION_FILTERS).default('all'),
  status: z.enum(CONVERSATION_STATUSES).default('OPEN'),
  /** Имя, @username или цифры телефона. */
  search: z.string().trim().max(100).optional(),
  channelType: z.enum(CHANNEL_TYPES).optional(),
  /** Диалоги конкретного сотрудника; если задан, filter не учитывается. */
  assigneeId: uuidSchema.optional(),
  /** Только диалоги, где последнее слово за гостем: ему ещё не ответили. */
  unanswered: z.stringbool().default(false),
});

export const updateConversationSchema = z
  .object({
    assigneeId: uuidSchema.nullable(),
    status: z.enum(CONVERSATION_STATUSES),
  })
  .partial()
  .refine((value) => Object.keys(value).length > 0, 'Нет полей для обновления');

export const messageListQuerySchema = z.object({
  /** Загрузить сообщения старше этого момента (прокрутка вверх). */
  before: z.iso.datetime({ offset: true }).optional(),
  /** id первого уже загруженного сообщения: различает сообщения с одинаковым временем. */
  beforeId: uuidSchema.optional(),
  limit: z.coerce.number().int().min(1).max(100).default(50),
});

/** Ограничение Telegram на длину одного сообщения. */
export const MAX_MESSAGE_LENGTH = 4096;

export const sendMessageSchema = z.object({
  text: z
    .string()
    .trim()
    .min(1, 'Сообщение пустое')
    .max(MAX_MESSAGE_LENGTH, `Не длиннее ${MAX_MESSAGE_LENGTH} символов`),
});

/** Мессенджеры, в которых CRM может написать клиенту первой. */
export const STARTABLE_CHANNELS = ['WHATSAPP', 'TELEGRAM'] as const;
export type StartableChannel = (typeof STARTABLE_CHANNELS)[number];

/** Имя в Telegram: 5–32 символа, начинается с буквы, без «_» в конце. Только цифры — не имя. */
export const TELEGRAM_USERNAME_PATTERN = /^@?[A-Za-z][A-Za-z0-9_]{3,30}[A-Za-z0-9]$/;

/** Первое сообщение клиенту из его карточки: по телефону (WhatsApp, Telegram) или @username (Telegram). */
export const startConversationSchema = z
  .object({
    channel: z.enum(STARTABLE_CHANNELS),
    phone: z.string().trim().min(1).max(32).optional(),
    username: z
      .string()
      .trim()
      .regex(TELEGRAM_USERNAME_PATTERN, 'Имя в Telegram — 5–32 латинские буквы, цифры или _, начинается с буквы')
      .optional(),
    text: sendMessageSchema.shape.text,
  })
  .refine((value) => value.phone || (value.channel === 'TELEGRAM' && value.username), {
    message: 'Выберите телефон клиента',
    path: ['phone'],
  });

export type StartConversationInput = z.infer<typeof startConversationSchema>;

export interface StartConversationResult {
  conversationId: string;
  message: MessageDto;
}

export type ConversationListQuery = z.infer<typeof conversationListQuerySchema>;
export type UpdateConversationInput = z.infer<typeof updateConversationSchema>;
export type MessageListQuery = z.infer<typeof messageListQuerySchema>;
export type SendMessageInput = z.infer<typeof sendMessageSchema>;

export interface ConversationDto {
  id: string;
  channel: { id: string; type: ChannelType; name: string };
  /** avatarFileId — фото профиля из мессенджера (fileUrl), null — показываем инициалы. */
  contact: EntityRef & {
    phones: string[];
    avatarFileId: string | null;
    vip: boolean;
    /** null — гость не в чёрном списке. */
    blacklist: GuestBlacklistDto | null;
  };
  /** @username клиента в мессенджере, если есть. */
  handle: string | null;
  assignee: EntityRef | null;
  status: ConversationStatus;
  unreadCount: number;
  lastMessageAt: string | null;
  lastMessagePreview: string | null;
}

export const ATTACHMENT_KINDS = ['photo', 'video', 'voice', 'audio', 'document', 'sticker', 'location', 'contact', 'call', 'other'] as const;
export type AttachmentKind = (typeof ATTACHMENT_KINDS)[number];

export const ATTACHMENT_LABELS: Record<AttachmentKind, string> = {
  photo: 'Фото',
  video: 'Видео',
  voice: 'Голосовое сообщение',
  audio: 'Аудио',
  document: 'Файл',
  sticker: 'Стикер',
  location: 'Геолокация',
  contact: 'Контакт',
  call: 'Звонок',
  other: 'Вложение',
};

export type MessageDirection = 'IN' | 'OUT';

/** Чем закончился звонок: поговорили, никто не взял трубку, звонок сбросили. */
export const CALL_OUTCOMES = ['answered', 'missed', 'declined'] as const;
export type CallOutcome = (typeof CALL_OUTCOMES)[number];

/**
 * Звонок в мессенджере. Разговор идёт на телефоне, CRM только отмечает его в переписке.
 * type, а не interface: вложение целиком пишется в JSON-колонку, а интерфейс Prisma туда не пускает.
 */
export type CallInfo = {
  outcome: CallOutcome;
  /** Длительность разговора, если мессенджер её сообщает (Telegram). */
  durationSec?: number;
  video?: boolean;
};

export interface MessageAttachment {
  kind: AttachmentKind;
  fileName?: string;
  /** Файл сохранён в CRM: скачивается по fileUrl(fileId). Нет — только отметка о вложении. */
  fileId?: string;
  mimeType?: string;
  size?: number;
  /** Только у kind: 'call'. */
  call?: CallInfo;
}

const CALL_TITLES: Record<MessageDirection, Record<CallOutcome, (noun: string) => string>> = {
  IN: {
    answered: (noun) => `Входящий ${noun}`,
    missed: (noun) => `Пропущенный ${noun}`,
    declined: (noun) => `Отклонённый ${noun}`,
  },
  OUT: {
    answered: (noun) => `Исходящий ${noun}`,
    missed: (noun) => `Исходящий ${noun} без ответа`,
    declined: (noun) => `Исходящий ${noun} отклонён`,
  },
};

const SECONDS_PER_MINUTE = 60;

/** Длительность разговора: 0:45, 12:05. */
export function formatCallDuration(seconds: number): string {
  const minutes = Math.floor(seconds / SECONDS_PER_MINUTE);
  const rest = String(seconds % SECONDS_PER_MINUTE).padStart(2, '0');
  return `${minutes}:${rest}`;
}

/** Подпись звонка: «Пропущенный звонок», «Исходящий видеозвонок · 2:15». */
export function callTitle(direction: MessageDirection, call: CallInfo | undefined): string {
  const noun = call?.video ? 'видеозвонок' : 'звонок';
  // Значение из JSON в базе: неизвестный итог показываем как пропущенный, а не падаем.
  const outcome = CALL_OUTCOMES.find((value) => value === call?.outcome) ?? 'missed';
  const title = CALL_TITLES[direction][outcome](noun);
  return call?.durationSec ? `${title} · ${formatCallDuration(call.durationSec)}` : title;
}

/** Звонок, в котором поговорили: внимания сотрудника не требует. */
export function isAnsweredCall(attachment: MessageAttachment | null | undefined): boolean {
  return attachment?.kind === 'call' && attachment.call?.outcome === 'answered';
}

/** Входящий звонок без разговора — клиенту нужно перезвонить. */
export function isMissedCall(direction: MessageDirection, attachment: MessageAttachment | null | undefined): boolean {
  return direction === 'IN' && attachment?.kind === 'call' && attachment.call?.outcome !== 'answered';
}

/** Предел размера файла в переписке (и входящего, и отправляемого). */
export const MAX_FILE_BYTES = 20 * 1024 * 1024;
/** Ограничение Telegram на подпись к файлу. */
export const MAX_CAPTION_LENGTH = 1024;

const captionSchema = z
  .string()
  .trim()
  .max(MAX_CAPTION_LENGTH, `Подпись не длиннее ${MAX_CAPTION_LENGTH} символов`)
  .optional()
  .transform((value) => value || null);

export const sendFileSchema = z.object({ caption: captionSchema });
export type SendFileInput = z.infer<typeof sendFileSchema>;

/**
 * Отправка файла, прикреплённого к шаблону. fileId — файл, который менеджер видел при выборе шаблона:
 * если файл шаблона успели заменить, отправка отклоняется, а не уходит другой файл.
 */
export const sendTemplateFileSchema = z.object({ templateId: uuidSchema, fileId: uuidSchema, caption: captionSchema });
export type SendTemplateFileInput = z.infer<typeof sendTemplateFileSchema>;

/** Вложения с файлом, который CRM сохраняет. Стикеры, геолокацию и контакты — нет. */
export const FILE_ATTACHMENT_KINDS: readonly AttachmentKind[] = ['photo', 'video', 'voice', 'audio', 'document'];

/**
 * Файл вложения не сохранён (не скачался сразу или пропущен при импорте истории), но его можно
 * загрузить из мессенджера по запросу сотрудника.
 */
export function canFetchAttachment(attachment: MessageAttachment | null | undefined): boolean {
  return Boolean(attachment && !attachment.fileId && FILE_ATTACHMENT_KINDS.includes(attachment.kind));
}

/** Адрес файла для браузера (через тот же /api, с cookie сессии). */
export function fileUrl(fileId: string): string {
  return `/api/files/${fileId}`;
}

/** Вид вложения по MIME-типу отправляемого файла. */
export function attachmentKindForMime(mimeType: string): AttachmentKind {
  if (/^image\/(jpeg|png|webp|gif)$/.test(mimeType)) return 'photo';
  if (mimeType.startsWith('video/')) return 'video';
  if (mimeType.startsWith('audio/')) return 'audio';
  return 'document';
}

/** Размер файла для людей: 512 Б, 34 КБ, 2,5 МБ. */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} КБ`;
  return `${(bytes / (1024 * 1024)).toFixed(1).replace('.', ',')} МБ`;
}

export interface MessageDto {
  id: string;
  direction: MessageDirection;
  status: 'RECEIVED' | 'PENDING' | 'SENT' | 'FAILED';
  text: string | null;
  attachment: MessageAttachment | null;
  sender: EntityRef | null;
  error: string | null;
  sentAt: string;
}

interface PreviewOptions {
  /** Нужно для звонков: «Пропущенный» или «Исходящий». */
  direction?: MessageDirection;
  maxLength?: number;
}

function attachmentPreview(attachment: MessageAttachment | null, direction: MessageDirection): string {
  if (!attachment) return '';
  if (attachment.kind === 'call') return `📞 ${callTitle(direction, attachment.call)}`;
  return `[${ATTACHMENT_LABELS[attachment.kind]}]`;
}

/** Короткий текст для списка диалогов. */
export function messagePreview(
  text: string | null,
  attachment: MessageAttachment | null,
  { direction = 'IN', maxLength = 120 }: PreviewOptions = {},
): string {
  const base = text?.trim() || attachmentPreview(attachment, direction);
  return base.length > maxLength ? `${base.slice(0, maxLength - 1)}…` : base;
}
