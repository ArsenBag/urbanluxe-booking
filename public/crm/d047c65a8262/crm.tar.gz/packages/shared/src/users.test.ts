import { describe, expect, it } from 'vitest';
import { loginSchema } from './auth.js';
import { createUserSchema, updateUserSchema } from './users.js';

describe('loginSchema', () => {
  it('normalizes email to trimmed lowercase', () => {
    const result = loginSchema.parse({ email: '  Admin@Example.COM ', password: 'x' });

    expect(result.email).toBe('admin@example.com');
  });

  it('rejects empty password', () => {
    const result = loginSchema.safeParse({ email: 'a@b.uz', password: '' });

    expect(result.success).toBe(false);
  });
});

describe('createUserSchema', () => {
  const valid = { email: 'm@b.uz', name: 'Азиз', password: 'longpassword', role: 'MANAGER' };

  it('accepts a valid manager', () => {
    expect(createUserSchema.safeParse(valid).success).toBe(true);
  });

  it('rejects short password', () => {
    expect(createUserSchema.safeParse({ ...valid, password: 'short' }).success).toBe(false);
  });

  it('rejects unknown role', () => {
    expect(createUserSchema.safeParse({ ...valid, role: 'OWNER' }).success).toBe(false);
  });
});

describe('updateUserSchema', () => {
  it('rejects empty update', () => {
    expect(updateUserSchema.safeParse({}).success).toBe(false);
  });

  it('accepts partial update', () => {
    expect(updateUserSchema.safeParse({ isActive: false }).success).toBe(true);
  });
});

describe('password length', () => {
  it('requires at least 12 characters for a new password', () => {
    const base = { email: 'm@b.uz', name: 'Азиз', role: 'ADMIN' as const };
    expect(createUserSchema.safeParse({ ...base, password: 'elevenchars' }).success).toBe(false);
    expect(createUserSchema.safeParse({ ...base, password: 'twelve-chars' }).success).toBe(true);
  });
});
