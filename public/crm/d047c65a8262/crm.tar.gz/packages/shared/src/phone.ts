const UZ_COUNTRY_CODE = '998';
const UZ_LOCAL_LENGTH = 9;
const UZ_FULL_LENGTH = UZ_COUNTRY_CODE.length + UZ_LOCAL_LENGTH;
/** Российский формат 8 9xx xxx-xx-xx: 11 цифр, восьмёрка вместо +7. */
const RU_TRUNK_LENGTH = 11;
const MIN_INTERNATIONAL_LENGTH = 10;
const MAX_INTERNATIONAL_LENGTH = 15;

/**
 * Приводит телефон к виду +<код страны><номер>.
 * Без кода страны считаем номер узбекским (9 цифр), 8XXXXXXXXXX — российским.
 * Возвращает null, если строка не похожа на телефон.
 */
export function normalizePhone(raw: string): string | null {
  const trimmed = raw.trim();
  const digits = trimmed.replace(/\D/g, '');

  if (trimmed.startsWith('+')) {
    return isInternationalLength(digits) ? `+${digits}` : null;
  }
  if (digits.length === UZ_LOCAL_LENGTH) {
    return `+${UZ_COUNTRY_CODE}${digits}`;
  }
  if (digits.length === UZ_FULL_LENGTH && digits.startsWith(UZ_COUNTRY_CODE)) {
    return `+${digits}`;
  }
  if (digits.length === RU_TRUNK_LENGTH && (digits.startsWith('8') || digits.startsWith('7'))) {
    return `+7${digits.slice(1)}`;
  }
  return isInternationalLength(digits) ? `+${digits}` : null;
}

function isInternationalLength(digits: string): boolean {
  return digits.length >= MIN_INTERNATIONAL_LENGTH && digits.length <= MAX_INTERNATIONAL_LENGTH;
}

/** +998932062891 → +998 93 206 28 91. Остальные страны показываем как есть. */
export function formatPhone(normalized: string): string {
  const match = /^\+998(\d{2})(\d{3})(\d{2})(\d{2})$/.exec(normalized);
  return match ? `+998 ${match.slice(1).join(' ')}` : normalized;
}
