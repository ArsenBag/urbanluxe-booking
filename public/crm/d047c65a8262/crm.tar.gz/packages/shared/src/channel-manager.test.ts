import { describe, expect, it } from 'vitest';
import { applyMarkup, channelListingInputSchema, ratePlanPrice } from './channel-manager.js';

const PROPERTY_ID = '3f1c2a4e-8b7d-4c6e-9a1b-2d3e4f5a6b7c';
const standard = { name: 'Standard Rate', markupKind: 'PERCENT', markupValue: 20 } as const;
const base = { propertyId: PROPERTY_ID, channel: 'BOOKING' };

describe('applyMarkup', () => {
  it('adds a percentage and rounds to cents', () => {
    expect(applyMarkup(85, 'PERCENT', 20)).toBe(102);
    expect(applyMarkup(85, 'PERCENT', 25)).toBe(106.25);
  });

  it('adds or subtracts a fixed amount', () => {
    expect(applyMarkup(85, 'AMOUNT', 10)).toBe(95);
    expect(applyMarkup(85, 'AMOUNT', -5)).toBe(80);
  });
});

describe('ratePlanPrice', () => {
  it('applies the markup to the base price of the night', () => {
    expect(ratePlanPrice(100, standard, null)).toBe(120);
  });

  it('applies a child plan on top of its parent (non-refundable −5% of standard)', () => {
    const nonRefundable = { markupKind: 'PERCENT', markupValue: -5 } as const;

    expect(ratePlanPrice(100, nonRefundable, { markupKind: 'PERCENT', markupValue: 25 })).toBe(118.75);
  });

  it('supports «standard + amount» as a fixed amount on top of the parent', () => {
    expect(ratePlanPrice(100, { markupKind: 'AMOUNT', markupValue: 15 }, standard)).toBe(135);
  });

  it('never goes below zero when a fixed discount is larger than the price', () => {
    expect(ratePlanPrice(80, { markupKind: 'AMOUNT', markupValue: -100 }, null)).toBe(0);
  });
});

describe('channelListingInputSchema', () => {
  it('fills defaults for a new listing and its plans', () => {
    const result = channelListingInputSchema.parse({ ...base, ratePlans: [{ name: 'Standard Rate' }] });

    expect(result).toMatchObject({
      enabled: true,
      externalHotelId: null,
      externalRoomId: null,
      commissionPercent: null,
      ratePlans: [{ name: 'Standard Rate', parentIndex: null, markupKind: 'PERCENT', markupValue: 0, minNights: 1, maxNights: 365, closed: false }],
    });
  });

  it('accepts a child plan that points to an earlier top-level plan', () => {
    const result = channelListingInputSchema.safeParse({
      ...base,
      ratePlans: [standard, { name: 'Non-refundable', parentIndex: 0, markupValue: -5 }],
    });

    expect(result.success).toBe(true);
  });

  it('rejects a parent that is the plan itself, comes later or is itself a child', () => {
    const plans = (parentIndexes: Array<number | null>) =>
      channelListingInputSchema.safeParse({ ...base, ratePlans: parentIndexes.map((parentIndex, i) => ({ name: `P${i}`, parentIndex })) });

    expect(plans([0]).success).toBe(false);
    expect(plans([1, null]).success).toBe(false);
    expect(plans([null, 0, 1]).success).toBe(false);
  });

  it('rejects a discount of 100% or more and a stay range that ends before it starts', () => {
    expect(channelListingInputSchema.safeParse({ ...base, ratePlans: [{ name: 'X', markupValue: -100 }] }).success).toBe(false);
    expect(channelListingInputSchema.safeParse({ ...base, ratePlans: [{ name: 'X', minNights: 7, maxNights: 3 }] }).success).toBe(false);
  });

  it('rejects an empty plan name, a commission over 100% and an unknown channel', () => {
    expect(channelListingInputSchema.safeParse({ ...base, ratePlans: [{ name: '  ' }] }).success).toBe(false);
    expect(channelListingInputSchema.safeParse({ ...base, commissionPercent: 120 }).success).toBe(false);
    expect(channelListingInputSchema.safeParse({ ...base, channel: 'URBANLUXE' }).success).toBe(false);
  });
});
