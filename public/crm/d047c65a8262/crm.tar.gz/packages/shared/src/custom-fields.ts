import { z } from 'zod';
import { uuidSchema } from './common.js';

/** Карточки, для которых администратор настраивает свои поля. */
export const CUSTOM_FIELD_ENTITIES = ['CONTACT', 'DEAL'] as const;
export type CustomFieldEntity = (typeof CUSTOM_FIELD_ENTITIES)[number];

export const CUSTOM_FIELD_ENTITY_LABELS: Record<CustomFieldEntity, string> = {
  CONTACT: 'Клиенты',
  DEAL: 'Сделки',
};

export const CUSTOM_FIELD_TYPES = ['TEXT', 'NUMBER', 'DATE', 'BOOLEAN', 'SELECT'] as const;
export type CustomFieldType = (typeof CUSTOM_FIELD_TYPES)[number];

export const CUSTOM_FIELD_TYPE_LABELS: Record<CustomFieldType, string> = {
  TEXT: 'Текст',
  NUMBER: 'Число',
  DATE: 'Дата',
  BOOLEAN: 'Да / нет',
  SELECT: 'Список вариантов',
};

export const MAX_CUSTOM_FIELDS_PER_ENTITY = 50;
export const MAX_SELECT_OPTIONS = 50;
const MAX_LABEL_LENGTH = 60;
const MAX_OPTION_LENGTH = 60;
const MAX_TEXT_VALUE_LENGTH = 1000;
const MAX_NUMBER_VALUE = 1e12;

/** Значение поля в карточке. null — очистить. */
export type CustomFieldValue = string | number | boolean;
export type CustomFieldValues = Record<string, CustomFieldValue>;

const labelSchema = z
  .string()
  .trim()
  .min(1, 'Введите название')
  .max(MAX_LABEL_LENGTH, `Не длиннее ${MAX_LABEL_LENGTH} символов`)
  .refine((value) => noNul(value), 'Недопустимый символ');

/** Нулевой символ PostgreSQL не хранит в тексте и JSON — такой ввод отклоняем сразу. */
const NUL = String.fromCharCode(0);
const noNul = (value: string) => !value.includes(NUL);

const optionsSchema = z
  .array(
    z
      .string()
      .trim()
      .min(1)
      .max(MAX_OPTION_LENGTH, `Вариант не длиннее ${MAX_OPTION_LENGTH} символов`)
      .refine(noNul, 'Недопустимый символ'),
  )
  .max(MAX_SELECT_OPTIONS, `Не больше ${MAX_SELECT_OPTIONS} вариантов`)
  .transform((options) => [...new Set(options)]);

export const createCustomFieldSchema = z
  .object({
    entity: z.enum(CUSTOM_FIELD_ENTITIES),
    label: labelSchema,
    type: z.enum(CUSTOM_FIELD_TYPES),
    options: optionsSchema.default([]),
  })
  .refine((field) => field.type !== 'SELECT' || field.options.length > 0, {
    message: 'Добавьте хотя бы один вариант',
    path: ['options'],
  })
  .transform((field) => (field.type === 'SELECT' ? field : { ...field, options: [] }));

/** Тип поля после создания не меняется: иначе сохранённые значения станут некорректными. */
export const updateCustomFieldSchema = z
  .object({ label: labelSchema, options: optionsSchema })
  .partial()
  .refine((value) => Object.keys(value).length > 0, 'Нет полей для обновления');

export const reorderCustomFieldsSchema = z.object({
  entity: z.enum(CUSTOM_FIELD_ENTITIES),
  ids: z.array(uuidSchema).min(1).max(MAX_CUSTOM_FIELDS_PER_ENTITY),
});

export const customFieldValuesSchema = z.object({
  values: z
    .record(uuidSchema, z.union([z.string(), z.number(), z.boolean(), z.null()]))
    .refine((values) => Object.keys(values).length <= MAX_CUSTOM_FIELDS_PER_ENTITY, 'Слишком много полей'),
});

export type CreateCustomFieldInput = z.infer<typeof createCustomFieldSchema>;
export type UpdateCustomFieldInput = z.infer<typeof updateCustomFieldSchema>;
export type ReorderCustomFieldsInput = z.infer<typeof reorderCustomFieldsSchema>;
export type CustomFieldValuesInput = z.infer<typeof customFieldValuesSchema>;

export interface CustomFieldDto {
  id: string;
  entity: CustomFieldEntity;
  label: string;
  type: CustomFieldType;
  options: string[];
  position: number;
}

export type CustomFieldCheck = { ok: true; value: CustomFieldValue | null } | { ok: false; error: string };

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
/** Обычная десятичная запись: «1500», «-2,5», «1 500.75». Без 0x…, 1e5 и прочих форм Number(). */
const DECIMAL = /^[+-]?\d+(\.\d+)?$/;

function parseDecimal(value: string): number | null {
  const normalized = value.replace(/\s/g, '').replace(',', '.');
  return DECIMAL.test(normalized) ? Number(normalized) : null;
}

function isRealDate(value: string): boolean {
  if (!ISO_DATE.test(value)) return false;
  const date = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().startsWith(value);
}

/**
 * Проверка и нормализация значения по типу поля. Пустое значение (null, пустая строка) — очистка.
 * Общая для сервера (граница системы) и формы (подсказка до отправки).
 */
export function checkCustomFieldValue(field: Pick<CustomFieldDto, 'type' | 'options'>, raw: unknown): CustomFieldCheck {
  if (raw === null || raw === undefined || (typeof raw === 'string' && raw.trim() === '')) {
    return { ok: true, value: null };
  }
  switch (field.type) {
    case 'TEXT':
      if (typeof raw !== 'string') return { ok: false, error: 'Ожидается текст' };
      if (!noNul(raw)) return { ok: false, error: 'Недопустимый символ' };
      return raw.trim().length > MAX_TEXT_VALUE_LENGTH
        ? { ok: false, error: `Не длиннее ${MAX_TEXT_VALUE_LENGTH} символов` }
        : { ok: true, value: raw.trim() };
    case 'NUMBER': {
      const number = typeof raw === 'string' ? parseDecimal(raw) : raw;
      return typeof number === 'number' && Number.isFinite(number) && Math.abs(number) <= MAX_NUMBER_VALUE
        ? { ok: true, value: number }
        : { ok: false, error: 'Введите число' };
    }
    case 'DATE':
      return typeof raw === 'string' && isRealDate(raw) ? { ok: true, value: raw } : { ok: false, error: 'Некорректная дата' };
    case 'BOOLEAN':
      return typeof raw === 'boolean' ? { ok: true, value: raw } : { ok: false, error: 'Ожидается да или нет' };
    case 'SELECT':
      return typeof raw === 'string' && field.options.includes(raw)
        ? { ok: true, value: raw }
        : { ok: false, error: 'Выберите вариант из списка' };
  }
}

const numberFormatter = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 });

/** Значение для показа в карточке: «1 500», «20.10.2026», «Да». */
export function formatCustomFieldValue(field: Pick<CustomFieldDto, 'type'>, value: CustomFieldValue | undefined): string {
  if (value === undefined || value === '') return '—';
  if (field.type === 'BOOLEAN') return value === true ? 'Да' : 'Нет';
  if (field.type === 'NUMBER' && typeof value === 'number') return numberFormatter.format(value);
  if (field.type === 'DATE' && typeof value === 'string' && ISO_DATE.test(value)) {
    const [year, month, day] = value.split('-');
    return `${day}.${month}.${year}`;
  }
  return String(value);
}
