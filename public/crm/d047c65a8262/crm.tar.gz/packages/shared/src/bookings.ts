import { z } from 'zod';
import { isoDateSchema, MIN_FILTER_DATE, optionalText, uuidSchema, type EntityRef } from './common.js';
import { nightsBetween } from './deals.js';
import { normalizePhone } from './phone.js';

export const BOOKING_STATUSES = ['BOOKED', 'REQUEST', 'CANCELED', 'DELETED'] as const;
export type BookingStatus = (typeof BOOKING_STATUSES)[number];

/** Где бронь заведена: в RealtyCalendar (вебхук или выгрузка Excel), сотрудником в CRM или в PMS Urban Luxe (площадки, сайт, шахматка PMS). */
export const BOOKING_SOURCES = ['REALTYCALENDAR', 'CRM', 'PMS'] as const;
export type BookingSource = (typeof BOOKING_SOURCES)[number];

/** Статусы, которые сотрудник выбирает для брони, внесённой в CRM. Отмена — отдельным действием. */
export const MANUAL_BOOKING_STATUSES = ['BOOKED', 'REQUEST'] as const;
export type ManualBookingStatus = (typeof MANUAL_BOOKING_STATUSES)[number];

/** Самая длинная бронь, которую можно внести вручную: защита от опечатки в годе. */
export const MAX_MANUAL_BOOKING_NIGHTS = 365;
const MAX_BOOKING_AMOUNT = 1_000_000_000;
/** Как у вебхука RealtyCalendar: даты вроде 0001 или 9999 года база не сравнит, а это всегда опечатка. */
const MAX_BOOKING_DATE = '2100-12-31';
const MAX_PHONE_INPUT_LENGTH = 50;

const timeSchema = z
  .string()
  .regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Время в формате ЧЧ:ММ')
  .nullable();

const moneySchema = z
  .number()
  .min(0, 'Сумма не может быть отрицательной')
  .max(MAX_BOOKING_AMOUNT, 'Слишком большая сумма')
  .nullable();

/** Пустая строка — телефона нет; иначе приводим к виду +998… */
const guestPhoneSchema = z
  .string()
  .trim()
  .max(MAX_PHONE_INPUT_LENGTH, 'Некорректный телефон')
  .transform((value, context) => {
    if (value === '') return null;
    const normalized = normalizePhone(value);
    if (!normalized) {
      context.addIssue({ code: 'custom', message: 'Некорректный телефон' });
      return z.NEVER;
    }
    return normalized;
  })
  .nullable();

/**
 * Бронь, которую сотрудник вносит или правит в CRM. Гость — клиент CRM (contactId) или имя и телефон:
 * по телефону CRM найдёт клиента сама, а если такого нет — заведёт нового.
 */
export const manualBookingSchema = z
  .object({
    propertyId: uuidSchema,
    status: z.enum(MANUAL_BOOKING_STATUSES).default('BOOKED'),
    checkIn: isoDateSchema,
    checkOut: isoDateSchema,
    arrivalTime: timeSchema.default(null),
    departureTime: timeSchema.default(null),
    contactId: uuidSchema.nullable().default(null),
    guestName: optionalText(200).default(null),
    guestPhone: guestPhoneSchema.default(null),
    amount: moneySchema.default(null),
    prepayment: moneySchema.default(null),
    deposit: moneySchema.default(null),
    notes: optionalText(2000).default(null),
  })
  .refine((value) => value.checkOut > value.checkIn, {
    message: 'Дата выезда должна быть позже даты заезда',
    path: ['checkOut'],
  })
  .refine((value) => value.checkIn >= MIN_FILTER_DATE && value.checkOut <= MAX_BOOKING_DATE, {
    message: 'Даты брони — между 2000 и 2100 годом',
    path: ['checkIn'],
  })
  .refine((value) => nightsBetween(value.checkIn, value.checkOut) <= MAX_MANUAL_BOOKING_NIGHTS, {
    message: `Не больше ${MAX_MANUAL_BOOKING_NIGHTS} ночей`,
    path: ['checkOut'],
  })
  .refine((value) => value.contactId !== null || value.guestName !== null || value.guestPhone !== null, {
    message: 'Укажите гостя: клиента CRM, имя или телефон',
    path: ['guestName'],
  });

export type ManualBookingInput = z.infer<typeof manualBookingSchema>;
/** Тело запроса из формы: незаполненные поля можно не передавать. */
export type ManualBookingRequest = z.input<typeof manualBookingSchema>;

/** Бронь внесена в CRM и ещё не пришла из RealtyCalendar: её ведут здесь, в RealtyCalendar её нет. */
export function isCrmOnlyBooking(booking: { source: BookingSource; rcId: number | null }): boolean {
  return booking.source === 'CRM' && booking.rcId === null;
}

export const BOOKING_STATUS_LABELS: Record<BookingStatus, string> = {
  BOOKED: 'Забронировано',
  REQUEST: 'Запрос',
  CANCELED: 'Отменена',
  DELETED: 'Удалена',
};

/** Максимальный период выборки броней, чтобы шахматка не тянула годы данных. */
export const MAX_BOOKING_RANGE_DAYS = 120;

export const bookingRangeQuerySchema = z
  .object({
    from: isoDateSchema,
    to: isoDateSchema,
    propertyId: uuidSchema.optional(),
  })
  .refine((value) => value.to >= value.from, { message: 'Конец периода раньше начала', path: ['to'] })
  .refine(
    (value) => (Date.parse(value.to) - Date.parse(value.from)) / 86_400_000 <= MAX_BOOKING_RANGE_DAYS,
    { message: `Период не длиннее ${MAX_BOOKING_RANGE_DAYS} дней`, path: ['to'] },
  );

export type BookingRangeQuery = z.infer<typeof bookingRangeQuerySchema>;

export interface PropertyDto {
  id: string;
  title: string;
  address: string | null;
  /** Квартира из RealtyCalendar (код вроде U-51). null — ЖК из выгрузки Excel, квартира не определена. */
  rcId: number | null;
  /** ЖК квартиры (U-Tower, Modera Towers…); null — не узнан по адресу и коду. */
  complex: string | null;
}

export interface BookingDto {
  id: string;
  /** null — бронь из выгрузки Excel или внесённая в CRM, по ней ещё не было вебхука. */
  rcId: number | null;
  source: BookingSource;
  status: BookingStatus;
  property: PropertyDto | null;
  contact: EntityRef | null;
  /** Клиент брони в чёрном списке — бронь выделена красным. */
  guestBlacklisted: boolean;
  deal: { id: string; title: string } | null;
  checkIn: string;
  checkOut: string;
  nights: number;
  arrivalTime: string | null;
  departureTime: string | null;
  /** Decimal строкой. Валюта — настройка RealtyCalendar (RC_CURRENCY на сервере). */
  amount: string | null;
  prepayment: string | null;
  deposit: string | null;
  currency: string;
  origin: string | null;
  guestName: string | null;
  guestPhone: string | null;
  notes: string | null;
  rcUrl: string | null;
  /** Бронь в PMS Urban Luxe: id и ссылка на шахматку PMS; null — бронь в PMS ещё не отправлена или мост не настроен. */
  pmsId: string | null;
  pmsUrl: string | null;
  /** Последняя ошибка отправки брони CRM в PMS; null — отправлена или не требуется. */
  pmsError: string | null;
}

/** Сводка дня для администратора: кто заезжает, кто выезжает, кто живёт. */
export interface BookingDayDto {
  date: string;
  arrivals: BookingDto[];
  departures: BookingDto[];
  staying: BookingDto[];
}

/** Состояние интеграции с RealtyCalendar для страницы настроек. */
export interface RealtyCalendarStatusDto {
  /** Адрес для поля «URL Webhook» в RealtyCalendar; null — не задан PUBLIC_API_URL или секрет. */
  webhookUrl: string | null;
  lastEventAt: string | null;
  bookingsCount: number;
  propertiesCount: number;
}

/** Состояние моста с PMS Urban Luxe («Настройки → Интеграции → PMS»). */
export interface PmsStatusDto {
  enabled: boolean;
  apiUrl: string;
  webUrl: string;
  /** Адрес вебхука для раздела «Интеграции» PMS; null — не задан PUBLIC_API_URL. */
  webhookUrl: string | null;
  webhookSecretSet: boolean;
  organization: string | null;
  keyName: string | null;
  connectionError: string | null;
  lastWebhookAt: string | null;
  lastWebhookEvent: string | null;
  lastPropertiesSyncAt: string | null;
  propertiesLinked: number;
  propertiesTotal: number;
  /** Брони CRM, ещё не отправленные в PMS или с ошибкой отправки. */
  bookingsPending: number;
  bookingsFromPms: number;
}

export interface PmsPropertiesSyncResultDto {
  total: number;
  created: number;
  linked: number;
  updated: number;
  skipped: { id: string; title: string; reason: string }[];
}
