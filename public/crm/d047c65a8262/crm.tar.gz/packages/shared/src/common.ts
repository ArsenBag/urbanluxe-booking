import { z } from 'zod';

export const DEFAULT_PAGE_SIZE = 25;
export const MAX_PAGE_SIZE = 100;

export const paginationSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(MAX_PAGE_SIZE).default(DEFAULT_PAGE_SIZE),
});

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
}

/** Ссылка на связанную сущность для отображения: id и подпись. */
export interface EntityRef {
  id: string;
  name: string;
}

export const uuidSchema = z.uuid('Некорректный идентификатор');

/** Необязательный текст: пустая строка превращается в null. */
export function optionalText(max: number) {
  return z
    .string()
    .trim()
    .max(max, `Не длиннее ${max} символов`)
    .transform((value) => (value === '' ? null : value))
    .nullable();
}

/** Дата без времени в формате YYYY-MM-DD (даты заезда и выезда). */
export const isoDateSchema = z.iso.date('Дата в формате ГГГГ-ММ-ДД');

/** Раньше данных нет, а даты вроде 0001 года база не может сравнить со временем записей. */
export const MIN_FILTER_DATE = '2000-01-01';

/** Дата фильтра или отчёта: YYYY-MM-DD не раньше 2000 года. */
export const filterDateSchema = isoDateSchema.refine((value) => value >= MIN_FILTER_DATE, 'Дата не раньше 2000 года');

const MAX_LIST_PARAM_ITEMS = 50;
/** Запас длины на один элемент списка (UUID — 36 символов): длинную строку отбрасываем до разбора. */
const MAX_LIST_ITEM_CHARS = 40;

/** Список в строке запроса: «a,b,c». Пустые элементы отбрасываются, каждый проверяется схемой item. */
export function listParam<T extends z.ZodType<unknown, string>>(item: T, max = MAX_LIST_PARAM_ITEMS) {
  return z
    .string()
    .max(max * MAX_LIST_ITEM_CHARS, `Не больше ${max} значений`)
    .transform((value) =>
      value
        .split(',')
        .map((part) => part.trim())
        .filter(Boolean),
    )
    .pipe(z.array(item).max(max, `Не больше ${max} значений`));
}

/**
 * Делает схему частичной для PATCH и требует хотя бы одно поле.
 * Используется для всех запросов на обновление.
 */
export function nonEmptyPatch<T extends z.ZodRawShape>(schema: z.ZodObject<T>) {
  return schema
    .partial()
    .refine((value) => Object.values(value).some((field) => field !== undefined), 'Нет полей для обновления');
}

/** Запись истории изменений (журнал действий) для карточек клиента и сделки. */
export interface ActivityDto {
  id: string;
  action: string;
  entityType: string;
  entityId: string | null;
  actor: EntityRef | null;
  payload: Record<string, unknown> | null;
  createdAt: string;
}
