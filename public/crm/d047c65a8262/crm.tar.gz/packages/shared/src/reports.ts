import { z } from 'zod';
import { filterDateSchema, uuidSchema, type EntityRef } from './common.js';
import type { ChannelType } from './inbox.js';
import type { StageKind } from './pipelines.js';

/** Отчёт строится не больше чем за год: дольше — тяжёлые запросы и нечитаемые графики. */
export const MAX_REPORT_DAYS = 366;

const MS_PER_DAY = 86_400_000;

/** Число дней в периоде, обе даты (YYYY-MM-DD) включительно. */
export function reportPeriodDays(from: string, to: string): number {
  return Math.round((Date.parse(to) - Date.parse(from)) / MS_PER_DAY) + 1;
}

/** Все дни периода по порядку — оси графиков «по дням». */
export function listPeriodDates(from: string, to: string): string[] {
  const start = Date.parse(from);
  return Array.from({ length: reportPeriodDays(from, to) }, (_, index) =>
    new Date(start + index * MS_PER_DAY).toISOString().slice(0, 10),
  );
}

const periodFields = z.object({ from: filterDateSchema, to: filterDateSchema });

function withPeriodRules<T extends typeof periodFields>(schema: T) {
  return schema
    .refine((value) => value.to >= value.from, { message: 'Конец периода раньше начала', path: ['to'] })
    .refine((value) => reportPeriodDays(value.from, value.to) <= MAX_REPORT_DAYS, {
      message: `Период не длиннее ${MAX_REPORT_DAYS} дней`,
      path: ['to'],
    });
}

/** Период отчёта: даты по Ташкенту, обе включительно. */
export const reportPeriodSchema = withPeriodRules(periodFields);
export type ReportPeriod = z.infer<typeof reportPeriodSchema>;

/** Без воронки — первая по порядку. */
export const funnelReportQuerySchema = withPeriodRules(periodFields.extend({ pipelineId: uuidSchema.optional() }));
export type FunnelReportQuery = z.infer<typeof funnelReportQuerySchema>;

export type ChannelCounts = Record<ChannelType, number>;

/** Обращения: новые диалоги и объём переписки за период. */
export interface InquiriesReportDto {
  /** Диалоги, первое сообщение которых пришло в периоде. */
  newConversations: {
    /** Первым написал гость. */
    fromGuests: ChannelCounts;
    /** Первыми написали мы (из CRM или с телефона). */
    fromUs: ChannelCounts;
  };
  /** Диалоги, начатые гостями, по дням периода. */
  byDay: Array<{ date: string; counts: ChannelCounts }>;
  messages: {
    incoming: number;
    /** Отправлено сотрудниками из CRM. */
    fromCrm: number;
    /** Отправлено с телефона компании мимо CRM. */
    fromPhone: number;
    /** Автосообщения перед заездом и после выезда. */
    automated: number;
  };
  /** Пропущенные и сброшенные входящие звонки. */
  missedCalls: number;
}

export interface FunnelStageRow {
  id: string;
  name: string;
  color: string;
  kind: StageKind;
  deals: number;
}

export interface FunnelTotals {
  deals: number;
  /** Дошли до брони: этап «Бронь создана» и дальше, успешный этап или бронь потом отменили. */
  booked: number;
  /** Из дошедших до брони — бронь отменили в RealtyCalendar. */
  cancelled: number;
  /** Отказ до брони. */
  lost: number;
  open: number;
}

export interface FunnelOwnerRow extends Omit<FunnelTotals, 'open'> {
  /** null — сделки без ответственного. */
  owner: EntityRef | null;
}

/** Воронка: сделки, созданные в периоде, по текущему этапу. */
export interface FunnelReportDto {
  pipeline: { id: string; name: string } | null;
  pipelines: Array<{ id: string; name: string }>;
  totals: FunnelTotals;
  stages: FunnelStageRow[];
  /** Самые частые причины отказа до брони (без учёта регистра). */
  lostReasons: Array<{ reason: string; deals: number }>;
  owners: FunnelOwnerRow[];
}

export interface OccupancyRow {
  nights: number;
  /** Доля занятых ночей 0…1; null — нет квартир, чтобы считать загрузку. */
  occupancy: number | null;
  revenue: number;
}

/** Брони и загрузка: ночи, выручка и источники за период (по датам проживания). */
export interface BookingsReportDto {
  currency: string;
  /** Квартир в RealtyCalendar — знаменатель загрузки. */
  apartments: number;
  days: number;
  totals: OccupancyRow & {
    /** Брони с заездом в периоде. */
    arrivals: number;
    /** Средняя цена ночи по броням с известной суммой; null — сумм нет. */
    averageNightPrice: number | null;
    /** Отменённые брони с заездом в периоде (по данным RealtyCalendar). */
    cancellations: number;
  };
  /** Занятые квартиры на каждую ночь периода. */
  byDay: Array<{ date: string; occupied: number }>;
  byComplex: Array<OccupancyRow & { title: string; apartments: number }>;
  byApartment: Array<OccupancyRow & { id: string; title: string; complex: string | null }>;
  /** Площадка брони; origin null — бронь внесена вручную или пришла с сайта. */
  byOrigin: Array<{ origin: string | null; bookings: number; nights: number; revenue: number }>;
}

/** Время первого ответа на сообщение гостя. */
export interface ResponseStats {
  /** Сколько раз гостю ответили (ожидание закрыто ответом). */
  answered: number;
  medianMinutes: number | null;
  within15Minutes: number;
  withinHour: number;
}

export interface TeamMemberRow {
  user: EntityRef;
  isActive: boolean;
  messagesSent: number;
  response: ResponseStats;
  tasksDone: number;
  /** Открытые задачи с прошедшим сроком на текущий момент. */
  tasksOverdue: number;
}

/** Команда: скорость ответов и работа сотрудников за период. */
export interface TeamReportDto {
  overall: ResponseStats;
  /** Сообщения гостей, оставшиеся без ответа (кроме самых свежих, моложе 15 минут). */
  unanswered: number;
  members: TeamMemberRow[];
  /** Ответы с телефона компании мимо CRM — сотрудника не определить. */
  phone: { messagesSent: number; response: ResponseStats };
}
