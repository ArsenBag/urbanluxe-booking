import { z } from 'zod';
import { MAX_CAPTION_LENGTH } from './inbox.js';

/** Когда шаблон отправляется гостю автоматически. */
export const TEMPLATE_AUTOMATIONS = ['BEFORE_CHECK_IN', 'AFTER_CHECK_OUT'] as const;
export type TemplateAutomation = (typeof TEMPLATE_AUTOMATIONS)[number];

export const TEMPLATE_AUTOMATION_LABELS: Record<TemplateAutomation, string> = {
  BEFORE_CHECK_IN: 'Накануне заезда в 18:00',
  AFTER_CHECK_OUT: 'После выезда в 14:00',
};

export const MAX_SHORTCUT_LENGTH = 30;
/** Символы команды после «/»: буквы любого алфавита, цифры, дефис и подчёркивание. */
const SHORTCUT_CHARS = /^[\p{L}\p{N}_-]*$/u;

/** Команда быстрого ответа: «/wifi» → «wifi». Пустая строка — без команды. */
const shortcutSchema = z
  .preprocess(
    (value) => (typeof value === 'string' ? value.trim().replace(/^\/+/, '') : value),
    z
      .string()
      .max(MAX_SHORTCUT_LENGTH, `Команда не длиннее ${MAX_SHORTCUT_LENGTH} символов`)
      .regex(SHORTCUT_CHARS, 'Команда — одно слово: буквы, цифры, «-» и «_»')
      .transform((value) => value.toLowerCase() || null)
      .nullable()
      .optional(),
  )
  .transform((value) => value ?? null);

export const replyTemplateSchema = z.object({
  title: z.string().trim().min(1, 'Введите название').max(60, 'Не длиннее 60 символов'),
  body: z.string().trim().min(1, 'Введите текст').max(4096, 'Не длиннее 4096 символов'),
  /** Быстрая команда в поле сообщения: «/wifi». Уникальна; null — только из списка. */
  shortcut: shortcutSchema,
  /** null — только вручную. У каждого вида автоотправки может быть один шаблон. */
  automation: z.enum(TEMPLATE_AUTOMATIONS).nullable().default(null),
});

export type ReplyTemplateInput = z.infer<typeof replyTemplateSchema>;

/** Файл шаблона (фото, видео, документ): уходит клиенту вместе с текстом. */
export interface TemplateFileDto {
  id: string;
  fileName: string;
  mimeType: string;
  size: number;
}

export interface ReplyTemplateDto {
  id: string;
  title: string;
  body: string;
  shortcut: string | null;
  automation: TemplateAutomation | null;
  file: TemplateFileDto | null;
}

/** С файлом текст шаблона уходит подписью к нему, а у подписи лимит Telegram. null — длина подходит. */
export function templateFileBodyError(body: string): string | null {
  return body.trim().length > MAX_CAPTION_LENGTH
    ? `С файлом текст становится подписью — не длиннее ${MAX_CAPTION_LENGTH} символов`
    : null;
}

/** Переменные шаблонов. Данные брони есть только в автоматических сообщениях. */
export interface TemplateVariables {
  имя: string;
  объект?: string;
  заезд?: string;
  выезд?: string;
}

/**
 * Подставляет {переменные}. Неизвестные оставляет как есть, чтобы менеджер их заметил.
 * Пустое значение убирается вместе с запятой перед ним: «Здравствуйте, {имя}!» → «Здравствуйте!».
 */
export function renderTemplate(body: string, variables: TemplateVariables): string {
  return body.replace(/(,\s*)?\{([^{}]+)\}/g, (match, separator: string | undefined, name: string) => {
    const value = variables[name as keyof TemplateVariables];
    if (value === undefined) return match;
    return value ? `${separator ?? ''}${value}` : '';
  });
}

/** Имя для обращения: первое слово, если это похоже на имя, а не телефон или @username. */
export function firstName(fullName: string): string {
  const first = fullName.trim().split(/\s+/)[0] ?? '';
  return /^[\p{L}-]+$/u.test(first) ? first : '';
}

const templateDateFormatter = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long', timeZone: 'UTC' });

/** Дата брони для текста шаблона: «2026-10-20» → «20 октября». */
export function templateDate(isoDate: string): string {
  return templateDateFormatter.format(new Date(`${isoDate}T00:00:00Z`));
}

interface BookingLike {
  status: string;
  property: { title: string } | null;
  checkIn: string;
  checkOut: string;
}

/** Переменные брони для шаблона: {объект}, {заезд}, {выезд}. */
export function bookingTemplateVariables(booking: BookingLike): Pick<TemplateVariables, 'объект' | 'заезд' | 'выезд'> {
  return {
    объект: booking.property?.title ?? '',
    заезд: templateDate(booking.checkIn),
    выезд: templateDate(booking.checkOut),
  };
}

/**
 * Бронь, о которой скорее всего идёт речь в переписке: текущее проживание (включая день выезда),
 * иначе ближайший будущий заезд. Отменённые и запросы не берём. today — YYYY-MM-DD.
 */
export function pickBookingForTemplate<T extends BookingLike>(bookings: readonly T[], today: string): T | null {
  const booked = bookings.filter((booking) => booking.status === 'BOOKED');
  // В день пересменки у клиента может быть и выезд, и новый заезд — важнее тот, где он остаётся.
  const current = booked
    .filter((booking) => booking.checkIn <= today && today <= booking.checkOut)
    .sort((a, b) => b.checkIn.localeCompare(a.checkIn))[0];
  if (current) return current;
  const upcoming = booked.filter((booking) => booking.checkIn > today).sort((a, b) => a.checkIn.localeCompare(b.checkIn));
  return upcoming[0] ?? null;
}

/**
 * «/команда» прямо перед курсором (в начале текста или после пробела).
 * start — позиция «/», query — набранное после неё (в нижнем регистре).
 */
export function slashCommandAt(text: string, caret: number): { start: number; query: string } | null {
  const match = /(^|\s)\/([\p{L}\p{N}_-]*)$/u.exec(text.slice(0, caret));
  if (!match) return null;
  const query = match[2] ?? '';
  return { start: caret - query.length - 1, query: query.toLowerCase() };
}

/**
 * Шаблоны для «/запрос»: сначала точное совпадение команды, затем команды и названия,
 * начинающиеся с запроса, затем содержащие его. Пустой запрос — все шаблоны.
 */
export function matchTemplates<T extends { title: string; shortcut: string | null }>(templates: readonly T[], query: string): T[] {
  const needle = query.toLowerCase();
  const rank = (template: T): number => {
    const shortcut = template.shortcut ?? '';
    const title = template.title.toLowerCase();
    if (!needle) return 0;
    if (shortcut === needle) return 0;
    if (shortcut.startsWith(needle)) return 1;
    if (title.startsWith(needle)) return 2;
    if (shortcut.includes(needle) || title.includes(needle)) return 3;
    return -1;
  };
  return templates
    .map((template, index) => ({ template, index, score: rank(template) }))
    .filter((entry) => entry.score >= 0)
    .sort((a, b) => a.score - b.score || a.index - b.index)
    .map((entry) => entry.template);
}
