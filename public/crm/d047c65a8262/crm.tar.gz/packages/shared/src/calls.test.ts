import { describe, expect, it } from 'vitest';
import { callTitle, formatCallDuration, isMissedCall, messagePreview } from './inbox.js';

describe('callTitle', () => {
  it('names incoming calls by outcome', () => {
    expect(callTitle('IN', { outcome: 'missed' })).toBe('Пропущенный звонок');
    expect(callTitle('IN', { outcome: 'declined' })).toBe('Отклонённый звонок');
    expect(callTitle('IN', { outcome: 'answered', durationSec: 135 })).toBe('Входящий звонок · 2:15');
  });

  it('names outgoing and video calls', () => {
    expect(callTitle('OUT', { outcome: 'missed' })).toBe('Исходящий звонок без ответа');
    expect(callTitle('OUT', { outcome: 'answered', video: true, durationSec: 45 })).toBe('Исходящий видеозвонок · 0:45');
  });

  it('treats a call without details or with an unknown outcome as missed', () => {
    expect(callTitle('IN', undefined)).toBe('Пропущенный звонок');
    expect(callTitle('IN', { outcome: 'constructor' as never })).toBe('Пропущенный звонок');
  });
});

describe('formatCallDuration', () => {
  it('pads seconds', () => {
    expect(formatCallDuration(5)).toBe('0:05');
    expect(formatCallDuration(725)).toBe('12:05');
  });
});

describe('isMissedCall', () => {
  it('is true only for incoming calls without a conversation', () => {
    expect(isMissedCall('IN', { kind: 'call', call: { outcome: 'missed' } })).toBe(true);
    expect(isMissedCall('IN', { kind: 'call', call: { outcome: 'declined' } })).toBe(true);
    expect(isMissedCall('IN', { kind: 'call', call: { outcome: 'answered' } })).toBe(false);
    expect(isMissedCall('OUT', { kind: 'call', call: { outcome: 'missed' } })).toBe(false);
    expect(isMissedCall('IN', { kind: 'photo' })).toBe(false);
    expect(isMissedCall('IN', null)).toBe(false);
  });
});

describe('messagePreview for calls', () => {
  it('shows the call title with its direction', () => {
    expect(messagePreview(null, { kind: 'call', call: { outcome: 'missed' } })).toBe('📞 Пропущенный звонок');
    expect(messagePreview(null, { kind: 'call', call: { outcome: 'answered' } }, { direction: 'OUT' })).toBe('📞 Исходящий звонок');
  });
});
