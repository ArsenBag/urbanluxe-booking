import { describe, expect, it } from 'vitest';
import { createContactSchema, updateContactSchema } from './contacts.js';
import { createDealSchema, moveDealSchema, nightsBetween, updateDealSchema } from './deals.js';
import { createStageSchema } from './pipelines.js';
import { createTaskSchema, taskListQuerySchema } from './tasks.js';

const ID = '3f1c2a4e-8b7d-4c6e-9a1b-2d3e4f5a6b7c';

describe('createContactSchema', () => {
  it('normalizes and de-duplicates phones, applies defaults', () => {
    const result = createContactSchema.parse({ name: ' Азиз ', phones: ['93 206 28 91', '+998932062891'] });

    expect(result).toMatchObject({
      name: 'Азиз',
      phones: ['+998932062891'],
      source: 'OTHER',
      tags: [],
      email: null,
      notes: null,
    });
  });

  it('reports an invalid phone with the original value', () => {
    const result = createContactSchema.safeParse({ name: 'Азиз', phones: ['123'] });

    expect(result.success).toBe(false);
    expect(result.error?.issues[0].message).toContain('123');
  });

  it('treats an empty email as absent', () => {
    expect(createContactSchema.parse({ name: 'Азиз', email: '' }).email).toBeNull();
  });

  it('rejects an empty patch', () => {
    expect(updateContactSchema.safeParse({}).success).toBe(false);
  });
});

describe('createDealSchema', () => {
  const base = { pipelineId: ID, contactId: ID };

  it('defaults currency to USD and leaves title for the server', () => {
    const result = createDealSchema.parse(base);

    expect(result.currency).toBe('USD');
    expect(result.title).toBeUndefined();
  });

  it('requires check-out after check-in', () => {
    const result = createDealSchema.safeParse({ ...base, checkIn: '2026-10-10', checkOut: '2026-10-10' });

    expect(result.success).toBe(false);
    expect(result.error?.issues[0].path).toEqual(['checkOut']);
  });

  it('accepts a valid stay', () => {
    expect(createDealSchema.safeParse({ ...base, checkIn: '2026-10-10', checkOut: '2026-10-13', guests: 2 }).success).toBe(true);
  });
});

describe('updateDealSchema', () => {
  it('validates dates when both are present in a patch', () => {
    expect(updateDealSchema.safeParse({ checkIn: '2026-10-12', checkOut: '2026-10-11' }).success).toBe(false);
  });

  it('allows clearing the amount', () => {
    expect(updateDealSchema.parse({ amount: null })).toEqual({ amount: null });
  });
});

describe('moveDealSchema', () => {
  it('rejects identical neighbours above and below', () => {
    expect(moveDealSchema.safeParse({ stageId: ID, prevDealId: ID, nextDealId: ID }).success).toBe(false);
  });

  it('defaults neighbours to column edges', () => {
    expect(moveDealSchema.parse({ stageId: ID })).toMatchObject({ prevDealId: null, nextDealId: null });
  });
});

describe('createStageSchema', () => {
  it('rejects a malformed color', () => {
    expect(createStageSchema.safeParse({ name: 'Новый', color: 'red' }).success).toBe(false);
  });
});

describe('tasks', () => {
  it('requires an ISO datetime with offset for due date', () => {
    expect(createTaskSchema.safeParse({ title: 'Позвонить', dueAt: '2026-10-05T10:00:00+05:00' }).success).toBe(true);
    expect(createTaskSchema.safeParse({ title: 'Позвонить', dueAt: 'завтра' }).success).toBe(false);
  });

  it('defaults list query to my open tasks', () => {
    expect(taskListQuerySchema.parse({})).toEqual({ scope: 'mine', status: 'open' });
  });
});

describe('nightsBetween', () => {
  it('counts nights between dates', () => {
    expect(nightsBetween('2026-10-10', '2026-10-13')).toBe(3);
  });
});

describe('inbox', () => {
  it('builds a preview from text or attachment', async () => {
    const { messagePreview } = await import('./inbox.js');

    expect(messagePreview('  Добрый день  ', null)).toBe('Добрый день');
    expect(messagePreview(null, { kind: 'photo' })).toBe('[Фото]');
    expect(messagePreview('x'.repeat(200), null, { maxLength: 10 })).toHaveLength(10);
  });

  it('accepts only numeric Telegram codes', async () => {
    const { telegramCodeSchema } = await import('./inbox.js');

    expect(telegramCodeSchema.safeParse({ code: '12345' }).success).toBe(true);
    expect(telegramCodeSchema.safeParse({ code: '12a45' }).success).toBe(false);
  });
});

describe('bookingRangeQuerySchema', () => {
  it('accepts a month range and rejects inverted or too long ranges', async () => {
    const { bookingRangeQuerySchema } = await import('./bookings.js');

    expect(bookingRangeQuerySchema.safeParse({ from: '2026-10-01', to: '2026-10-31' }).success).toBe(true);
    expect(bookingRangeQuerySchema.safeParse({ from: '2026-10-31', to: '2026-10-01' }).success).toBe(false);
    expect(bookingRangeQuerySchema.safeParse({ from: '2026-01-01', to: '2026-12-31' }).success).toBe(false);
  });
});
