import { describe, expect, it } from 'vitest';
import {
  bookingTemplateVariables,
  matchTemplates,
  pickBookingForTemplate,
  replyTemplateSchema,
  slashCommandAt,
  templateDate,
} from './templates.js';

describe('replyTemplateSchema shortcut', () => {
  const base = { title: 'Wi-Fi', body: 'Пароль: 12345' };

  it('normalizes the command: no slash, lowercase, empty means none', () => {
    expect(replyTemplateSchema.parse({ ...base, shortcut: ' /WiFi ' }).shortcut).toBe('wifi');
    expect(replyTemplateSchema.parse({ ...base, shortcut: 'доступ-ут12' }).shortcut).toBe('доступ-ут12');
    expect(replyTemplateSchema.parse({ ...base, shortcut: '' }).shortcut).toBeNull();
    expect(replyTemplateSchema.parse({ ...base, shortcut: null }).shortcut).toBeNull();
    expect(replyTemplateSchema.parse(base).shortcut).toBeNull();
  });

  it('rejects spaces and punctuation', () => {
    expect(replyTemplateSchema.safeParse({ ...base, shortcut: 'wi fi' }).success).toBe(false);
    expect(replyTemplateSchema.safeParse({ ...base, shortcut: 'wifi!' }).success).toBe(false);
    expect(replyTemplateSchema.safeParse({ ...base, shortcut: 'a'.repeat(31) }).success).toBe(false);
  });
});

describe('slashCommandAt', () => {
  it('finds a command at the start or after a space', () => {
    expect(slashCommandAt('/wi', 3)).toEqual({ start: 0, query: 'wi' });
    expect(slashCommandAt('Добрый день! /Доступ', 20)).toEqual({ start: 13, query: 'доступ' });
    expect(slashCommandAt('/', 1)).toEqual({ start: 0, query: '' });
  });

  it('ignores slashes inside words and links, and text after a space', () => {
    expect(slashCommandAt('https://site.uz/wi', 18)).toBeNull();
    expect(slashCommandAt('1/2', 3)).toBeNull();
    expect(slashCommandAt('/wifi пароль', 12)).toBeNull();
  });

  it('looks only at the text before the caret', () => {
    expect(slashCommandAt('/wi текст', 3)).toEqual({ start: 0, query: 'wi' });
  });
});

describe('matchTemplates', () => {
  const templates = [
    { title: 'Адрес и как добраться', shortcut: 'адрес' },
    { title: 'Wi-Fi', shortcut: 'wifi' },
    { title: 'Доступ в квартиру', shortcut: 'доступ' },
    { title: 'Оплата картой', shortcut: null },
    { title: 'Доступы U-Tower', shortcut: 'ут' },
  ];

  it('returns everything for an empty query', () => {
    expect(matchTemplates(templates, '')).toHaveLength(5);
  });

  it('puts the exact command first, then prefixes, then substrings', () => {
    expect(matchTemplates(templates, 'доступ').map((t) => t.title)).toEqual(['Доступ в квартиру', 'Доступы U-Tower']);
    expect(matchTemplates(templates, 'ут').map((t) => t.title)).toEqual(['Доступы U-Tower']);
    expect(matchTemplates(templates, 'карт').map((t) => t.title)).toEqual(['Оплата картой']);
  });

  it('is case-insensitive and returns nothing when nothing matches', () => {
    expect(matchTemplates(templates, 'WIFI')[0]?.title).toBe('Wi-Fi');
    expect(matchTemplates(templates, 'парковка')).toEqual([]);
  });
});

describe('booking variables', () => {
  const booking = (status: string, checkIn: string, checkOut: string, title = 'U-Tower 12') => ({
    status,
    property: { title },
    checkIn,
    checkOut,
  });

  it('formats dates in Russian', () => {
    expect(templateDate('2026-10-20')).toBe('20 октября');
    expect(bookingTemplateVariables(booking('BOOKED', '2026-10-20', '2026-10-23'))).toEqual({
      объект: 'U-Tower 12',
      заезд: '20 октября',
      выезд: '23 октября',
    });
  });

  it('prefers the current stay, including the check-out day', () => {
    const current = booking('BOOKED', '2026-10-01', '2026-10-05', 'Current');
    const next = booking('BOOKED', '2026-11-01', '2026-11-03', 'Next');
    expect(pickBookingForTemplate([next, current], '2026-10-05')?.property.title).toBe('Current');
  });

  it('falls back to the nearest upcoming booking and skips canceled ones', () => {
    const canceled = booking('CANCELED', '2026-10-10', '2026-10-12', 'Canceled');
    const later = booking('BOOKED', '2026-12-01', '2026-12-03', 'Later');
    const sooner = booking('BOOKED', '2026-11-01', '2026-11-03', 'Sooner');
    const past = booking('BOOKED', '2026-09-01', '2026-09-03', 'Past');
    expect(pickBookingForTemplate([canceled, later, past, sooner], '2026-10-05')?.property.title).toBe('Sooner');
    expect(pickBookingForTemplate([past, canceled], '2026-10-05')).toBeNull();
  });
});

describe('pickBookingForTemplate on a turnover day', () => {
  it('prefers the stay that starts today over the one ending today, regardless of order', () => {
    const leaving = { status: 'BOOKED', property: { title: 'Leaving' }, checkIn: '2026-10-01', checkOut: '2026-10-05' };
    const arriving = { status: 'BOOKED', property: { title: 'Arriving' }, checkIn: '2026-10-05', checkOut: '2026-10-08' };
    expect(pickBookingForTemplate([leaving, arriving], '2026-10-05')?.property.title).toBe('Arriving');
    expect(pickBookingForTemplate([arriving, leaving], '2026-10-05')?.property.title).toBe('Arriving');
  });
});
