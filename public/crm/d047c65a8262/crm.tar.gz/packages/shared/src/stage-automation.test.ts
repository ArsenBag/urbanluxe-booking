import { describe, expect, it } from 'vitest';
import { stageAutomationSchema, type StageAutomationInput } from './stage-automation.js';

const CHECK_IN = '11111111-1111-4111-8111-111111111111';
const CHECKED_IN = '22222222-2222-4222-8222-222222222222';
const CHECK_OUT_SOON = '33333333-3333-4333-8333-333333333333';
const CHECKED_OUT = '44444444-4444-4444-8444-444444444444';

const valid: StageAutomationInput = {
  enabled: true,
  checkInStageId: CHECK_IN,
  checkInTime: '08:00',
  checkedInStageId: CHECKED_IN,
  checkOutSoonStageId: CHECK_OUT_SOON,
  checkOutSoonTime: '19:00',
  checkedOutStageId: CHECKED_OUT,
  checkedOutTime: '12:00',
};

const fieldErrors = (input: unknown) => {
  const result = stageAutomationSchema.safeParse(input);
  return result.success ? {} : Object.fromEntries(result.error.issues.map((issue) => [issue.path.join('.'), issue.message]));
};

describe('stageAutomationSchema', () => {
  it('accepts the full set of rules', () => {
    expect(stageAutomationSchema.parse(valid)).toEqual(valid);
  });

  it('accepts rules switched off by an empty stage', () => {
    const off = { ...valid, checkInStageId: null, checkedInStageId: null, checkOutSoonStageId: null, checkedOutStageId: null };

    expect(stageAutomationSchema.parse(off)).toEqual(off);
  });

  it('rejects a time outside HH:MM', () => {
    expect(fieldErrors({ ...valid, checkInTime: '8:00' })).toEqual({ checkInTime: 'Время в формате ЧЧ:ММ' });
    expect(fieldErrors({ ...valid, checkedOutTime: '24:00' })).toEqual({ checkedOutTime: 'Время в формате ЧЧ:ММ' });
  });

  it('requires «Заселён» when «Выезд завтра» is on: only from it the deal moves on', () => {
    expect(fieldErrors({ ...valid, checkedInStageId: null })).toEqual({
      checkedInStageId: 'Выберите этап, из которого сделка уходит в «Выезд завтра»',
    });
  });

  it('rejects one stage chosen for two rules', () => {
    expect(fieldErrors({ ...valid, checkOutSoonStageId: CHECKED_OUT })).toEqual({
      checkedOutStageId: 'Этот этап уже выбран выше',
    });
  });
});
