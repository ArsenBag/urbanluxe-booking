# Мост CRM ↔ PMS Urban Luxe (2026-10-16)

PMS Urban Luxe (urbanluxe.cc/pms) — менеджер каналов: Airbnb, Booking.com, Ostrovok и другие площадки через Channex,
цены и наценки, шахматка. CRM остаётся местом клиентов, сделок, чатов и задач. Мост делает две вещи:

1. **PMS → CRM.** Любая бронь по квартирам High Life в PMS (с площадки, с сайта, из шахматки PMS) приходит вебхуком
   в CRM: появляется бронь (`source = PMS`), клиент, сделка в нужном этапе, задачи заезда/выезда — как у броней
   RealtyCalendar. Такие брони в CRM не редактируются (ссылка «PMS ↗» в карточке ведёт в шахматку PMS).
2. **CRM → PMS.** Бронь, внесённая в CRM на шахматке или из сделки, сначала создаётся в PMS (она знает занятость всех
   площадок: пересечение → «Даты заняты в PMS»), потом записывается в CRM. Изменение и отмена тоже уходят в PMS.
   Если PMS недоступна, бронь сохраняется с пометкой «не отправлено в PMS» и уходит повтором раз в минуту.

Цены, наценки на площадки и закрытия дат ведутся в PMS (решение владельцев 16.10.2026).

## Что менялось в коде

- `apps/api/src/pms/` — новый модуль: `pms-client.ts` (HTTP к Public API PMS), `pms-webhook.controller.ts`
  (`POST /api/webhooks/urbanluxe`, подпись HMAC-SHA256 заголовком `X-UL-Signature`), `pms-sync.service.ts` (бронь PMS →
  бронь CRM), `pms-outbound.service.ts` (бронь CRM → PMS, повторы), `pms-properties.service.ts` (квартиры → PMS),
  `pms.controller.ts` (`GET /api/integrations/pms`, `POST …/sync-properties`, `POST …/retry`, только ADMIN).
- `realtycalendar/manual-bookings.service.ts` — создание/изменение/отмена брони CRM зовут PMS.
- Prisma: `bookings.pmsId/pmsSyncedAt/pmsError`, `properties.pmsId/pmsSyncedAt`, `BookingSource.PMS`
  (миграция `20261016100000_pms_bridge`).
- `.env`: `PMS_API_URL` (по умолчанию `https://urbanluxe.cc/api/v1`), `PMS_API_KEY`, `PMS_WEBHOOK_SECRET`,
  `PMS_WEB_URL` (по умолчанию `https://urbanluxe.cc/pms`). Пока `PMS_API_KEY` пуст, модуль молчит.
- Веб: «Настройки → Интеграции → PMS Urban Luxe» (статус, «Синхронизировать объекты», «Отправить невыгруженные»),
  ссылка «PMS ↗» и пометка «не отправлено в PMS» в карточке брони.

## Выкладка (владелец High Life, по DEPLOY.md §8)

1. Получить от Urban Luxe (Арсен): **секретный API-ключ** организации High Life (`sk_live_…`, права read/book/cancel/manage)
   и **секрет вебхука** (`whsec_…`). Ключ показывается в PMS один раз — хранить только в `.env`.
2. На сервере в `/opt/crm/.env` добавить:
   ```
   PMS_API_KEY=sk_live_…
   PMS_WEBHOOK_SECRET=whsec_…
   ```
3. Выложить код (архив или `git archive`), затем:
   ```bash
   sudo sh -c 'cd /opt/crm && docker compose -f docker-compose.prod.yml up -d --build'
   curl https://crm.high-life-apartments.uz/api/health
   ```
   Миграцию `20261016100000_pms_bridge` применит сервис `migrate` из docker-compose при старте.
4. В CRM: «Настройки → Интеграции → PMS Urban Luxe» → убедиться, что подключение показывает организацию «High Life»,
   нажать **«Синхронизировать объекты»** (56 квартир появятся в PMS в организации High Life; 11 общих с Urban Luxe
   привяжутся к уже существующим).
5. В PMS (urbanluxe.cc/pms, вход High Life → «Интеграции» → «+ Вебхук») указать адрес
   `https://crm.high-life-apartments.uz/api/webhooks/urbanluxe`, события `booking.created / updated / cancelled`.
   Секрет этого вебхука и есть `PMS_WEBHOOK_SECRET` (если вебхук создал Арсен заранее — секрет уже у вас). Кнопка
   «Проверить» в PMS должна показать 200.

## Проверка

1. В CRM создать бронь на квартиру → в PMS она появилась (источник «API», автор «api:High Life CRM»); в карточке CRM — «PMS ↗».
2. Изменить даты в CRM → в PMS изменились. Поставить даты поверх брони площадки → CRM: «Даты заняты в PMS».
3. В PMS создать бронь на квартиру High Life → через ≤1 мин в CRM бронь, клиент, сделка, задачи.
4. Отменить в PMS → в CRM «Отменена», сделка в «Отказ». Отменить в CRM → в PMS `cancelled`.
5. Выключить PMS_API_URL (неверный адрес) → бронь в CRM создаётся с пометкой; вернуть адрес → ушла повтором.

## Переходный период с RealtyCalendar

Пока в CRM включён вебхук RealtyCalendar, брони с `source = rc` из PMS пропускаются (иначе дубли). Когда площадки
High Life переключены на Channex в PMS и вебхук RC в CRM выключен — убрать условие `data.source === 'rc'` в
`pms-webhook.controller.ts`.
