# Развёртывание High Life CRM на сервер

Итог: CRM открывается по адресу `https://crm.high-life-apartments.uz`, принимает вебхуки
RealtyCalendar и держит постоянное подключение к Telegram.

Состав: PostgreSQL, API (NestJS), веб-интерфейс (Next.js) и Caddy (HTTPS) в Docker на одном сервере.

**Текущий прод (с 2026-10-05):** Hostmaster VDS 5485, IP `138.249.248.114`, Ubuntu 22.04, код в `/opt/crm`.
Hostmaster не пускает root по SSH: вход под выданным пользователем по ключу, команды через `sudo`:
`ssh -i ~/.ssh/id_ed25519_highlife lvkim91@138.249.248.114`. Вход по паролю на сервере отключён.

## 1. Что нужно заранее

| Что | Где взять |
|---|---|
| VPS в Узбекистане: 2 vCPU, 4 ГБ RAM, 40 ГБ SSD, Ubuntu 24.04 | Uzcloud, Ahost.uz и т.п. Сервер в РУз нужен по закону о персональных данных |
| Доступ по SSH (логин и IP) | Пришлёт хостинг после покупки |
| Поддомен `crm.high-life-apartments.uz` | В панели DNS домена: запись **A** → IP сервера |
| Код CRM на сервере | Удобнее всего — приватный репозиторий на GitHub (п. 3) |

## 2. Подготовка сервера (один раз)

Сначала с Mac положить ключ на сервер (пароль — из письма хостинга) и разрешить `sudo` без пароля:

```bash
ssh-copy-id -i ~/.ssh/id_ed25519_highlife.pub ПОЛЬЗОВАТЕЛЬ@IP_СЕРВЕРА
ssh -t ПОЛЬЗОВАТЕЛЬ@IP_СЕРВЕРА 'echo "ПОЛЬЗОВАТЕЛЬ ALL=(ALL) NOPASSWD:ALL" | sudo tee /etc/sudoers.d/90-ПОЛЬЗОВАТЕЛЬ && sudo chmod 440 /etc/sudoers.d/90-ПОЛЬЗОВАТЕЛЬ'
```

Затем на сервере (`sudo -i`):

```bash
timedatectl set-timezone Asia/Tashkent
apt update && apt upgrade -y
apt install -y ufw unattended-upgrades docker.io docker-compose-v2 git
# Подкачка 2 ГБ: без неё сборка на 4 ГБ RAM может не хватить памяти
fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
echo '/swapfile none swap sw 0 0' >> /etc/fstab
# Файрвол: только SSH и веб
ufw allow OpenSSH && ufw allow 80/tcp && ufw allow 443/tcp && ufw allow 443/udp && ufw --force enable
# Вход только по ключу (файл с номером 10 важнее 50-cloud-init.conf)
printf 'PasswordAuthentication no\nKbdInteractiveAuthentication no\nPermitRootLogin no\n' > /etc/ssh/sshd_config.d/10-keys-only.conf
sshd -t && systemctl reload ssh
reboot
```

## 3. Код на сервер

Выгружаем ровно то, что закоммичено (без `.env`, выгрузок с данными гостей и локальных файлов).
На Mac, из папки проекта:

```bash
git archive HEAD | ssh -i ~/.ssh/id_ed25519_highlife lvkim91@138.249.248.114 \
  'sudo install -d -m 750 /opt/crm && sudo tar -x -C /opt/crm'
```

## 4. Настройки

```bash
sudo -i
cd /opt/crm
cp deploy/.env.production.example .env
nano .env    # заполнить по комментариям; секреты сгенерировать командами openssl из файла
chmod 600 .env
```

Пустые значения (`TELEGRAM_API_ID=` и т.п.) допустимы: такой канал просто выключен.

## 5. Запуск

```bash
cd /opt/crm
docker compose -f docker-compose.prod.yml up -d --build
docker compose -f docker-compose.prod.yml ps        # все сервисы Up, migrate — Exited (0)
```

Первая сборка занимает 5–10 минут. Caddy сам получит HTTPS-сертификат, если DNS уже указывает на сервер.

Создать первого администратора (данные — `SEED_ADMIN_*` из `.env`):

```bash
docker compose -f docker-compose.prod.yml run --rm migrate pnpm db:seed
```

Откройте `https://crm.high-life-apartments.uz` и войдите.

## 6. Подключения

- **RealtyCalendar.** В CRM: «Интеграции» → скопировать адрес вебхука. В RealtyCalendar: «Настройки» →
  «Интеграции с CRM» → «Webhook» → вставить адрес → «Запустить».
- **Сверка броней с RealtyCalendar по выгрузке Excel** (брони до подключения вебхука и всё, что вебхук
  мог потерять — например, с Booking.com). Пробный запуск (`--dry-run`) ничего не пишет и показывает:
  сколько броней выгрузки уже есть в CRM (пришли вебхуком или прежней выгрузкой), сколько нет — по
  площадкам, и какие брони CRM в выгрузке не нашлись (номер в RealtyCalendar, даты, ЖК — без данных
  гостей), а недостающие текущие и будущие брони — списком (даты, ЖК, площадка), чтобы сверить их с
  шахматкой RealtyCalendar. Загрузка добавляет недостающие брони и не трогает брони из вебхуков и
  отменённые. **В выгрузке нет статуса брони: отменённые в ней выглядят действующими.** Поэтому строка,
  совпавшая с отменённой в CRM бронью, не загружается, а сверять стоит с даты подключения вебхука
  (2026-10-05): более ранние брони CRM не видела и не знает, какие из них отменены. `--since=ГГГГ-ММ-ДД` —
  с какой даты выезда сверять (по умолчанию сегодня); у прошедших проживаний задачи заезда/выезда и сделки
  не создаются. В выгрузке нет квартиры, только адрес дома: недостающие брони встают в строку ЖК, а при
  следующем вебхуке по брони переезжают в свою квартиру.
  ```bash
  # скопировать файл на сервер (с Mac; вход root закрыт — через lvkim91 и sudo). Файл читает только
  # пользователь node контейнера (uid 1000) и root: скрипт в контейнере работает не от root.
  scp -i ~/.ssh/id_ed25519_highlife -o IdentitiesOnly=yes imports/bookings.xls lvkim91@138.249.248.114:/tmp/rc-bookings.xls
  ssh -i ~/.ssh/id_ed25519_highlife -o IdentitiesOnly=yes lvkim91@138.249.248.114 "sudo sh -c 'mkdir -p /opt/crm-imports && mv /tmp/rc-bookings.xls /opt/crm-imports/bookings.xls && chown -R 1000:1000 /opt/crm-imports && chmod 700 /opt/crm-imports && chmod 600 /opt/crm-imports/bookings.xls'"
  # на сервере (cd /opt/crm, под sudo): пробный запуск, затем загрузка — лучше в тихое время
  docker compose -f docker-compose.prod.yml run --rm -v /opt/crm-imports:/imports migrate pnpm import:rc-excel /imports/bookings.xls --dry-run --since=2026-10-05
  docker compose -f docker-compose.prod.yml run --rm -v /opt/crm-imports:/imports migrate pnpm import:rc-excel /imports/bookings.xls --since=2026-10-05
  ```
  После загрузки удалите файл с данными гостей с сервера: `/opt/crm-imports/bookings.xls`.
- **Перенос цен и площадок из RealtyCalendar** (переезд на свой менеджер каналов, 2026-10-15). Файл
  `imports/rc-rates.json` собирает агент в браузере владельца (только чтение RC): цены по ночам на год вперёд,
  посчитанные как в шахматке RC (базовая цена, дни недели, сезоны, ручные цены), ограничения (минимум ночей,
  закрыто, нет заезда/выезда) и площадки Booking, Ostrovok, Airbnb с ID, комиссией и тарифами. Данных гостей в
  файле нет. Квартиры сопоставляются по id RealtyCalendar; ночи с сегодняшнего дня заменяются целиком, площадки
  из файла — вместе с тарифами (повторный запуск безопасен, но перепишет правки, сделанные в CRM после него).
  ```bash
  scp -i ~/.ssh/id_ed25519_highlife -o IdentitiesOnly=yes imports/rc-rates.json lvkim91@138.249.248.114:/tmp/rc-rates.json
  ssh -i ~/.ssh/id_ed25519_highlife -o IdentitiesOnly=yes lvkim91@138.249.248.114 "sudo sh -c 'mkdir -p /opt/crm-imports && mv /tmp/rc-rates.json /opt/crm-imports/rc-rates.json && chown -R 1000:1000 /opt/crm-imports && chmod 700 /opt/crm-imports && chmod 600 /opt/crm-imports/rc-rates.json'"
  # на сервере (cd /opt/crm, под sudo): пробный запуск, затем загрузка
  docker compose -f docker-compose.prod.yml run --rm -v /opt/crm-imports:/imports migrate pnpm import:rc-rates /imports/rc-rates.json --dry-run
  docker compose -f docker-compose.prod.yml run --rm -v /opt/crm-imports:/imports migrate pnpm import:rc-rates /imports/rc-rates.json
  ```
  После загрузки удалите файл с сервера (в нём ID площадок и комиссии): `/opt/crm-imports/rc-rates.json`.
- **Брони, которые вебхук не смог разобрать**, видны в журнале API (номер брони и поля, без данных
  гостей): `docker compose -f docker-compose.prod.yml logs api | grep "Вебхук RealtyCalendar"`.
- **Telegram.** Получить api_id и api_hash на https://my.telegram.org → «API development tools»
  (платформа Desktop). Записать их на сервер с Mac, из папки проекта: `./deploy/set-telegram-keys.sh`
  (ключи вводятся с клавиатуры и сразу уходят на сервер, API перезапускается). Затем в CRM:
  «Каналы» → номер телефона аккаунта → код из Telegram → облачный пароль, если включён.

- **WhatsApp.** На https://console.green-api.com создать инстанс и отсканировать QR-код телефоном
  с WhatsApp компании («Связанные устройства»). Затем с Mac, из папки проекта: `./deploy/set-whatsapp-keys.sh`
  и ввести idInstance, apiTokenInstance, apiUrl и mediaUrl из карточки инстанса. Скрипт сохранит ключи
  на сервере, сам включит в Green-API вебхук на CRM (с секретным токеном из `.env`) и уведомления
  о входящих, исходящих и состоянии номера, перезапустит API.

## 7. Резервные копии

Ежедневно в 03:00, хранятся 14 дней:

```bash
chmod +x /opt/crm/deploy/backup.sh
(crontab -l 2>/dev/null; echo "0 3 * * * /opt/crm/deploy/backup.sh >> /var/log/crm-backup.log 2>&1") | crontab -
/opt/crm/deploy/backup.sh   # проверить вручную
```

В копию входят база (`crm-ДАТА.sql.gz`) и файлы из переписки (`files-ДАТА.tar.gz`).
Копии лежат в `/var/backups/crm`. Раз в неделю скачивайте свежую копию к себе: если сервер пропадёт,
копии на нём пропадут вместе с ним.

Восстановление из копии:

```bash
gunzip -c /var/backups/crm/crm-ДАТА.sql.gz | docker compose -f docker-compose.prod.yml exec -T postgres psql -U crm crm
gunzip -c /var/backups/crm/files-ДАТА.tar.gz | docker compose -f docker-compose.prod.yml exec -T api tar -C /data/files -xf -
```

## 8. Обновление CRM

На Mac, из папки проекта (ветка `main`, всё закоммичено):

```bash
git archive HEAD | ssh -i ~/.ssh/id_ed25519_highlife lvkim91@138.249.248.114 'sudo tar -x -C /opt/crm'
ssh -i ~/.ssh/id_ed25519_highlife lvkim91@138.249.248.114 \
  "sudo sh -c 'cd /opt/crm && docker compose -f docker-compose.prod.yml up -d --build'"
```

Файл `.env` и данные (база, файлы переписки, сертификаты) лежат отдельно и при обновлении не меняются.
Удалённые из репозитория файлы на сервере остаются — это не мешает сборке.

Миграции БД применяются автоматически перед стартом API (сервис `migrate`).

Пока API перезапускается (миграции и старт, до ~40 с), Caddy держит входящие запросы до минуты и отдаёт
их API, когда тот поднимется, — RealtyCalendar не видит ошибок. Caddy при `up -d --build` не
перезапускается; если менялся `deploy/Caddyfile`, перезапустите его (около секунды простоя). `caddy reload`
не подходит: файл подключён в контейнер отдельно, а `tar` при выкладке заменяет его новым — reload
перечитал бы старый.

```bash
ssh -i ~/.ssh/id_ed25519_highlife lvkim91@138.249.248.114 \
  "sudo sh -c 'cd /opt/crm && docker compose -f docker-compose.prod.yml restart caddy'"
```

**Вебхук RealtyCalendar при ошибках.** RealtyCalendar повторяет неудачную отправку через 5 с, 30 с, 2, 5,
10, 30 мин, 1, 2, 4, 8, 24 и 48 ч; после трёх ошибок подряд пишет владельцу на почту, после 48 часов без
успеха переводит вебхук в «Остановлено» — включать заново кнопкой «Запустить» в «Настройки» → «Интеграции
с CRM». Брони, созданные, пока вебхук был остановлен или не работал у самого RealtyCalendar, сами не
придут: их находит сверка с шахматкой RealtyCalendar (CLAUDE.md, «Сверка с шахматкой RC»), а возвращает
любое изменение брони в RealtyCalendar — после него приходит вебхук.

**Вебхук WhatsApp (Green-API) при ошибках.** Green-API отдаёт уведомления строго по очереди и повторяет
неудачное раз в минуту; следующие ждут за ним, хранятся до суток. Число ждущих видно в личном кабинете
Green-API: «Очередь на получение (вебхуки)» — в норме 0. Если она растёт, а новые сообщения WhatsApp не
появляются в CRM, смотрите журнал API (`logs --since 24h api`, строки `WhatsApp`, `Тело запроса отклонено`,
`Unhandled exception`). Очередь **не очищать** (корзина рядом с числом): её сообщения пропадут навсегда;
после исправления CRM Green-API сам доставит их с исходным временем. До 2026-10-10 уведомления больше
100 КБ (превью картинок в base64) получали ответ 500 и останавливали очередь; теперь лимит тела у
вебхука WhatsApp 5 МБ, у остального API — 100 КБ.

## 9. Если что-то не работает

```bash
docker compose -f docker-compose.prod.yml logs --tail 100 api      # ошибки API
docker compose -f docker-compose.prod.yml logs --tail 100 caddy    # HTTPS / домен
docker compose -f docker-compose.prod.yml logs migrate             # миграции
```

- **Сертификат не выдаётся** — проверьте, что запись A домена указывает на IP сервера и порты 80/443 открыты.
- **API не стартует с «Некорректные переменные окружения»** — в логе указано, какую строку `.env` исправить.
