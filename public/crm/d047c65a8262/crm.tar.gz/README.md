# High Life CRM

CRM для посуточной аренды апартаментов: клиенты, воронки, единый inbox (Telegram, WhatsApp,
Instagram), интеграция с RealtyCalendar. План и этапы: [docs/PLAN.md](docs/PLAN.md).

## Структура

```
apps/api         NestJS + Prisma (PostgreSQL) — REST API, порт 4000
apps/web         Next.js — интерфейс, порт 3000 (проксирует /api на API)
packages/shared  Zod-схемы и типы, общие для API и интерфейса
```

## Первый запуск

Нужны Node.js 22+, pnpm и Docker (Docker Desktop или OrbStack).

```bash
pnpm install
cp .env.example .env        # заполнить JWT_SECRET и SEED_ADMIN_PASSWORD
pnpm db:up                  # PostgreSQL в Docker
pnpm --filter @crm/api db:migrate
pnpm --filter @crm/api db:seed   # создаёт первого администратора
pnpm dev                    # API и интерфейс в режиме разработки
```

**Без Docker** (только для разработки): локальный Postgres из Prisma.

```bash
cd apps/api && npx prisma dev --name crm --detach --db-port 51214
# в .env: DATABASE_URL=postgres://postgres:postgres@localhost:51214/crm?sslmode=disable
#         DATABASE_POOL_MAX=1   # эта БД не выдерживает параллельных соединений
pnpm --filter @crm/api db:deploy   # migrate dev здесь не работает: нет теневой БД
```

Интерфейс: http://localhost:3000, вход под `SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD`.

## Развёртывание на сервер

Docker + Caddy (HTTPS) на VPS: пошаговая инструкция в [docs/DEPLOY.md](docs/DEPLOY.md).

## Подключение Telegram

1. На https://my.telegram.org (вход по номеру рабочего аккаунта) → «API development tools» →
   создать приложение. Скопировать `api_id` и `api_hash` в `.env` (`TELEGRAM_API_ID`, `TELEGRAM_API_HASH`).
2. Убедиться, что в `.env` задан `CHANNEL_SECRET_KEY` (`openssl rand -base64 32`): им шифруется сессия.
3. Перезапустить API, открыть «Каналы» → ввести номер → код из Telegram → облачный пароль (если включён).

CRM подключается как ещё одно устройство (видно в Telegram → Настройки → Устройства), загружает
переписку за 90 дней и дальше принимает сообщения. Отключить: кнопка «Отключить» в «Каналах»
или завершить сеанс в самом Telegram.

## Проверки

```bash
pnpm test                                # unit-тесты
pnpm typecheck
pnpm --filter @crm/api test:e2e          # сквозные тесты API, нужна запущенная БД
```

## Безопасность

- Сессия в httpOnly cookie (JWT), пароли хэшируются argon2id.
- Изменяющие запросы требуют заголовок `x-requested-with: crm-web` (защита от CSRF).
- Вход ограничен 5 попытками в минуту с одного IP.
- Все действия с пользователями пишутся в журнал `activity_logs`.
- Сессии мессенджеров хранятся в БД зашифрованными (AES-256-GCM, ключ `CHANNEL_SECRET_KEY`).
  Коды входа и облачный пароль Telegram передаются в Telegram и нигде не сохраняются.
