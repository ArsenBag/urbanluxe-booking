"use client";

import { TelegramConnect } from "@/components/channels/telegram-connect";
import { WhatsAppStatus } from "@/components/channels/whatsapp-status";
import { ErrorAlert } from "@/components/ui/alert";
import { PageHeader } from "@/components/ui/page-header";
import { Section } from "@/components/ui/section";
import { useChannels } from "@/lib/channels";

function TelegramSetupHint() {
  return (
    <div className="max-w-2xl space-y-2 text-sm">
      <p>Чтобы подключить личный Telegram, на сервере нужны ключи приложения Telegram. Получить их (один раз):</p>
      <ol className="list-decimal space-y-1 pl-5">
        <li>
          Откройте{" "}
          <a href="https://my.telegram.org" target="_blank" rel="noreferrer" className="text-primary hover:underline">
            my.telegram.org
          </a>{" "}
          и войдите по номеру аккаунта @high_life_uz.
        </li>
        <li>Раздел «API development tools» → заполните название (например, High Life CRM) → «Create application».</li>
        <li>
          Скопируйте <b>api_id</b> и <b>api_hash</b> в файл <code>.env</code>: <code>TELEGRAM_API_ID</code> и{" "}
          <code>TELEGRAM_API_HASH</code>, затем перезапустите CRM.
        </li>
      </ol>
      <p className="text-muted">Эти ключи — как пароль: никому не пересылайте их и не публикуйте.</p>
    </div>
  );
}

export default function ChannelsPage() {
  const channels = useChannels();

  return (
    <div className="max-w-3xl">
      <PageHeader title="Каналы" subtitle="Подключение мессенджеров к единому окну сообщений" />
      {channels.isError && <ErrorAlert message={channels.error.message} />}
      <div className="flex flex-col gap-4">
        <Section title="Telegram — личный аккаунт">
          {channels.isPending && <p className="text-sm text-muted">Загрузка…</p>}
          {channels.data && !channels.data.telegramConfigured && <TelegramSetupHint />}
          {channels.data?.telegramConfigured && <TelegramConnect channels={channels.data.channels} />}
        </Section>
        <Section title="WhatsApp (Green-API)">
          {channels.data && <WhatsAppStatus overview={channels.data} />}
        </Section>
        <Section title="Instagram">
          <p className="text-sm text-muted">Появится на этапе 5. Заранее подготовьте профессиональный аккаунт, привязанный к странице Facebook.</p>
        </Section>
      </div>
    </div>
  );
}
