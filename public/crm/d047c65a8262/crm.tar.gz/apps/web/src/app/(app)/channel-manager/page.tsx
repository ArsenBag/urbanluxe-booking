"use client";

import { useState } from "react";
import { apartmentsOf } from "@/components/bookings/chessboard-layout";
import { ApartmentChannelList, listingKey, type ListingSelection } from "@/components/channel-manager/apartment-channel-list";
import { ListingPanel } from "@/components/channel-manager/listing-panel";
import { ErrorAlert } from "@/components/ui/alert";
import { PageHeader } from "@/components/ui/page-header";
import { useProperties } from "@/lib/bookings";
import { useChannelListings } from "@/lib/channel-listings";

/** Менеджер каналов, как в RealtyCalendar: выбираете квартиру и площадку и настраиваете её тарифы. */
export default function ChannelManagerPage() {
  const properties = useProperties();
  const listings = useChannelListings();
  const [selected, setSelected] = useState<ListingSelection | null>(null);
  const apartments = apartmentsOf(properties.data ?? []);
  const apartment = selected ? apartments.find((item) => item.id === selected.propertyId) : undefined;
  const listing = selected
    ? listings.data?.find((item) => listingKey(item.propertyId, item.channel) === listingKey(selected.propertyId, selected.channel))
    : undefined;
  const error = properties.error ?? listings.error;

  return (
    <div className="max-w-7xl">
      <PageHeader
        title="Менеджер каналов"
        subtitle="Площадки квартир и наценки по тарифам. Цены площадок считаются от цены ночи на шахматке."
      />
      {error && <ErrorAlert message={error.message} />}
      <div className="grid gap-4 lg:grid-cols-[20rem_minmax(0,1fr)]">
        <ApartmentChannelList apartments={apartments} listings={listings.data ?? []} selected={selected} onSelect={setSelected} />
        {/* Без загруженного списка площадок окно открылось бы как новое — и сохранение пересоздало бы тарифы. */}
        {selected && apartment && listings.data ? (
          // Ключ с id площадки: только что созданная площадка открывается заново уже с сохранёнными тарифами.
          <ListingPanel
            key={`${listingKey(selected.propertyId, selected.channel)}:${listing?.id ?? "new"}`}
            apartment={apartment}
            channel={selected.channel}
            listing={listing}
          />
        ) : (
          <p className="rounded-xl border border-dashed border-border p-6 text-sm text-muted">
            Выберите квартиру и площадку слева: зелёная точка — площадка включена, «+» — ещё не настроена.
          </p>
        )}
      </div>
    </div>
  );
}
