"use client";

import Link from "next/link";
import { TaskList } from "@/components/tasks/task-list";
import { PageHeader } from "@/components/ui/page-header";
import { Section } from "@/components/ui/section";
import { useSession } from "@/lib/session";

export default function HomePage() {
  const session = useSession();

  return (
    <div className="max-w-3xl">
      <PageHeader title={`Здравствуйте, ${session.data?.name ?? ""}`} subtitle="Ваши открытые задачи" />
      <Section
        title="Мои задачи"
        action={
          <Link href="/tasks" className="text-sm text-primary hover:underline">
            Все задачи
          </Link>
        }
      >
        <TaskList filters={{ scope: "mine", status: "open" }} showContext emptyText="Открытых задач нет 🎉" />
      </Section>
    </div>
  );
}
