"use client";

import type { BlacklistEntryDto } from "@crm/shared";
import Link from "next/link";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { formatDateTime, formatPhones, pluralize } from "@/lib/format";
import { useBlacklist, useRemoveFromBlacklist } from "@/lib/guests";
import { useSession } from "@/lib/session";

const COLUMNS = 5;

function BlacklistRow({ entry, canRemove }: { entry: BlacklistEntryDto; canRemove: boolean }) {
  const remove = useRemoveFromBlacklist();
  const { contact, blacklist } = entry;

  function unlist() {
    if (window.confirm(`Убрать «${contact.name}» из чёрного списка?`)) remove.mutate(contact.id);
  }

  return (
    <tr className="border-b border-border align-top last:border-0">
      <td className="px-4 py-3 font-medium">
        <Link href={`/contacts/${contact.id}`} className="hover:text-primary">
          {contact.name}
        </Link>
      </td>
      <td className="px-4 py-3 whitespace-nowrap">{formatPhones(contact.phones) || "—"}</td>
      <td className="px-4 py-3 break-words whitespace-pre-wrap">{blacklist.reason}</td>
      <td className="px-4 py-3 whitespace-nowrap text-muted">
        {formatDateTime(blacklist.at)}
        {blacklist.by && <div className="text-xs">{blacklist.by.name}</div>}
      </td>
      <td className="px-4 py-3 text-right">
        {canRemove && (
          <Button variant="ghost" className="h-8 px-2 text-xs" onClick={unlist} disabled={remove.isPending}>
            Убрать
          </Button>
        )}
        {remove.isError && <p className="mt-1 text-xs text-danger">{remove.error.message}</p>}
      </td>
    </tr>
  );
}

/** Раздел «Чёрный список»: кто в нём, за что, когда и кем внесён. Убрать может только администратор. */
export default function BlacklistPage() {
  const session = useSession();
  const blacklist = useBlacklist();
  const total = blacklist.data?.length ?? 0;
  const isAdmin = session.data?.role === "ADMIN";

  return (
    <div className="max-w-6xl">
      <PageHeader
        title="Чёрный список"
        subtitle={
          blacklist.data &&
          `${total} ${pluralize(total, ["гость", "гостя", "гостей"])} · внести гостя — кнопка «В чёрный список» в диалоге или карточке клиента`
        }
      />

      {blacklist.isError && <ErrorAlert message={blacklist.error.message} />}

      <div className="overflow-x-auto rounded-xl border border-border bg-surface">
        <table className="w-full text-sm">
          <thead className="border-b border-border text-left text-muted">
            <tr>
              <th className="px-4 py-3 font-medium">Гость</th>
              <th className="px-4 py-3 font-medium">Телефон</th>
              <th className="px-4 py-3 font-medium">Причина</th>
              <th className="px-4 py-3 font-medium">Внесён</th>
              <th className="px-4 py-3" aria-label="Действия" />
            </tr>
          </thead>
          <tbody>
            {blacklist.isPending && (
              <tr>
                <td colSpan={COLUMNS} className="px-4 py-6 text-center text-muted">
                  Загрузка…
                </td>
              </tr>
            )}
            {blacklist.data?.length === 0 && (
              <tr>
                <td colSpan={COLUMNS} className="px-4 py-6 text-center text-muted">
                  Список пуст
                </td>
              </tr>
            )}
            {blacklist.data?.map((entry) => (
              <BlacklistRow key={entry.contact.id} entry={entry} canRemove={isAdmin} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
