"use client";

import { MutationCache, QueryCache, QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState, type ReactNode } from "react";
import { isUnauthorized } from "@/lib/api";
import { SESSION_KEY } from "@/lib/session";
import { shouldRecheckSession } from "@/lib/session-recheck";

const STALE_TIME_MS = 30_000;

function createQueryClient(): QueryClient {
  // 401 на любой запрос (сессия истекла, пользователя заблокировали) перепроверяет сессию,
  // а layout при её отсутствии отправляет на страницу входа.
  const recheckSession = (error: unknown, queryKey?: readonly unknown[]) => {
    if (shouldRecheckSession(error, queryKey)) {
      void queryClient.invalidateQueries({ queryKey: SESSION_KEY });
    }
  };
  const queryClient = new QueryClient({
    queryCache: new QueryCache({ onError: (error, query) => recheckSession(error, query.queryKey) }),
    mutationCache: new MutationCache({ onError: (error) => recheckSession(error) }),
    defaultOptions: {
      queries: {
        staleTime: STALE_TIME_MS,
        retry: (failureCount, error) => !isUnauthorized(error) && failureCount < 1,
      },
    },
  });
  return queryClient;
}

export function Providers({ children }: { children: ReactNode }) {
  const [queryClient] = useState(createQueryClient);
  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>;
}
