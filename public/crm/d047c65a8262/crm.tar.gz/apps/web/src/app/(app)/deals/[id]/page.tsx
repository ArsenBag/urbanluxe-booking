"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useState } from "react";
import { ActivityFeed } from "@/components/activity/activity-feed";
import { CustomFieldsSection } from "@/components/custom-fields/custom-fields-section";
import { DealDetailsForm } from "@/components/deals/deal-details-form";
import { LostReasonModal } from "@/components/deals/lost-reason-modal";
import { TaskForm } from "@/components/tasks/task-form";
import { TaskList } from "@/components/tasks/task-list";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { Section } from "@/components/ui/section";
import { BookingsSection } from "@/components/bookings/bookings-section";
import { ContactConversationsSection } from "@/components/inbox/contact-conversations-section";
import { useDealBookings } from "@/lib/bookings";
import { useDeal, useDealActivity, useDeleteDeal, useMoveDeal } from "@/lib/deals";
import { formatDateTime, formatPhones } from "@/lib/format";
import { usePipelines } from "@/lib/pipelines";
import { useSession } from "@/lib/session";

export default function DealPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const session = useSession();
  const deal = useDeal(id);
  const activity = useDealActivity(id);
  const bookings = useDealBookings(id);
  const pipelines = usePipelines();
  const moveDeal = useMoveDeal();
  const deleteDeal = useDeleteDeal();
  const [pendingLostStageId, setPendingLostStageId] = useState<string | null>(null);

  if (deal.isError) return <ErrorAlert message={deal.error.message} />;
  if (deal.isPending) return <p className="text-sm text-muted">Загрузка…</p>;

  const data = deal.data;
  const pipeline = pipelines.data?.find((p) => p.id === data.pipelineId);
  const stage = pipeline?.stages.find((s) => s.id === data.stageId);

  function changeStage(stageId: string) {
    const target = pipeline?.stages.find((s) => s.id === stageId);
    if (target?.kind === "LOST") {
      setPendingLostStageId(stageId);
      return;
    }
    moveDeal.mutate({ id: data.id, input: { stageId } });
  }

  function handleDelete() {
    if (window.confirm(`Удалить сделку «${data.title}»? Задачи по ней тоже удалятся.`)) {
      deleteDeal.mutate(data.id, { onSuccess: () => router.replace("/deals") });
    }
  }

  return (
    <div className="max-w-6xl">
      <PageHeader
        title={data.title}
        subtitle={
          <>
            <Link href={`/contacts/${data.contact.id}`} className="text-primary hover:underline">
              {data.contact.name}
            </Link>
            {data.contact.phones.length > 0 && ` · ${formatPhones(data.contact.phones)}`}
            {` · создана ${formatDateTime(data.createdAt)}`}
          </>
        }
        actions={
          <>
            <select
              className="h-9 rounded-md border border-border bg-surface px-3 text-sm font-medium"
              style={stage ? { color: stage.color } : undefined}
              value={data.stageId}
              onChange={(e) => changeStage(e.target.value)}
              disabled={moveDeal.isPending}
              aria-label="Этап сделки"
            >
              {pipeline?.stages.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
            {session.data?.role === "ADMIN" && (
              <Button variant="ghost" onClick={handleDelete} disabled={deleteDeal.isPending}>
                Удалить
              </Button>
            )}
          </>
        }
      />
      {(moveDeal.error ?? deleteDeal.error) && <ErrorAlert message={(moveDeal.error ?? deleteDeal.error)!.message} />}
      {data.stageKind === "LOST" && data.lostReason && (
        <p className="mb-4 text-sm text-danger">Причина отказа: {data.lostReason}</p>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="flex flex-col gap-4 lg:col-span-2">
          <Section title="Параметры">
            {/* key по id: смена этапа или чужое обновление не стирают несохранённый ввод */}
            <DealDetailsForm key={data.id} deal={data} />
          </Section>
          <CustomFieldsSection entity="DEAL" recordId={data.id} values={data.customFields} />
          <ContactConversationsSection contactId={data.contact.id} />
          <BookingsSection bookings={bookings.data} />
          <Section title="Задачи">
            <TaskList filters={{ dealId: id, scope: "all", status: "all" }} />
            <div className="mt-3 border-t border-border pt-3">
              <TaskForm dealId={id} contactId={data.contact.id} />
            </div>
          </Section>
        </div>
        <Section title="История">
          <ActivityFeed entries={activity.data} isPending={activity.isPending} error={activity.error} />
        </Section>
      </div>

      {pendingLostStageId && (
        <LostReasonModal
          onConfirm={(lostReason) => {
            moveDeal.mutate({ id: data.id, input: { stageId: pendingLostStageId, lostReason } });
            setPendingLostStageId(null);
          }}
          onCancel={() => setPendingLostStageId(null)}
        />
      )}
    </div>
  );
}
