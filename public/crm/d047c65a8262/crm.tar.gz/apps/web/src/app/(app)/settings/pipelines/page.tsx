"use client";

import { PipelineEditor } from "@/components/pipelines/pipeline-editor";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { useCreatePipeline, usePipelines } from "@/lib/pipelines";

export default function PipelinesSettingsPage() {
  const pipelines = usePipelines();
  const createPipeline = useCreatePipeline();

  return (
    <div className="max-w-3xl">
      <PageHeader
        title="Воронки"
        subtitle="Этапы с типом «Успешно закрыта» или «Отказ» закрывают сделку"
        actions={
          <Button onClick={() => createPipeline.mutate("Новая воронка")} disabled={createPipeline.isPending}>
            Новая воронка
          </Button>
        }
      />
      {(pipelines.error ?? createPipeline.error) && <ErrorAlert message={(pipelines.error ?? createPipeline.error)!.message} />}
      <div className="flex flex-col gap-4">
        {pipelines.data?.map((pipeline) => (
          // key с этапами: после переименования/перестановки редактор берёт свежие данные
          <PipelineEditor key={`${pipeline.id}:${pipeline.name}:${pipeline.stages.map((s) => s.id).join()}`} pipeline={pipeline} />
        ))}
      </div>
    </div>
  );
}
