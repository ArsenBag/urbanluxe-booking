"use client";

import { CONTACT_SOURCE_LABELS } from "@crm/shared";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { ContactFormModal } from "@/components/contacts/contact-form-modal";
import { GuestBadges } from "@/components/guests/guest-badges";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { useContacts } from "@/lib/contacts";
import { formatPhones, pluralize } from "@/lib/format";
import { useDebouncedValue } from "@/lib/use-debounced-value";

const SEARCH_DELAY_MS = 300;

export default function ContactsPage() {
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [isCreating, setIsCreating] = useState(false);
  const debouncedSearch = useDebouncedValue(search.trim(), SEARCH_DELAY_MS);
  const contacts = useContacts(debouncedSearch, page);

  const total = contacts.data?.total ?? 0;
  const pageCount = contacts.data ? Math.max(1, Math.ceil(total / contacts.data.limit)) : 1;

  return (
    <div className="max-w-6xl">
      <PageHeader
        title="Клиенты"
        subtitle={contacts.data && `${total} ${pluralize(total, ["клиент", "клиента", "клиентов"])}`}
        actions={<Button onClick={() => setIsCreating(true)}>Новый клиент</Button>}
      />

      <input
        type="search"
        className="mb-4 h-10 w-full max-w-md rounded-md border border-border bg-surface px-3 text-sm outline-none focus:border-primary"
        placeholder="Поиск по имени, телефону или email"
        value={search}
        onChange={(e) => {
          setSearch(e.target.value);
          setPage(1);
        }}
        aria-label="Поиск клиентов"
      />

      {contacts.isError && <ErrorAlert message={contacts.error.message} />}

      <div className="overflow-x-auto rounded-xl border border-border bg-surface">
        <table className="w-full text-sm">
          <thead className="border-b border-border text-left text-muted">
            <tr>
              <th className="px-4 py-3 font-medium">Имя</th>
              <th className="px-4 py-3 font-medium">Телефон</th>
              <th className="px-4 py-3 font-medium">Источник</th>
              <th className="px-4 py-3 font-medium">Открытые сделки</th>
              <th className="px-4 py-3 font-medium">Ответственный</th>
            </tr>
          </thead>
          <tbody>
            {contacts.isPending && (
              <tr>
                <td colSpan={5} className="px-4 py-6 text-center text-muted">
                  Загрузка…
                </td>
              </tr>
            )}
            {contacts.data?.items.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-6 text-center text-muted">
                  {debouncedSearch ? "Никого не нашли" : "Клиентов пока нет"}
                </td>
              </tr>
            )}
            {contacts.data?.items.map((contact) => (
              <tr key={contact.id} className="border-b border-border last:border-0 hover:bg-background">
                <td className="px-4 py-3 font-medium">
                  <span className="inline-flex flex-wrap items-center gap-1.5">
                    <Link href={`/contacts/${contact.id}`} className="hover:text-primary">
                      {contact.name}
                    </Link>
                    <GuestBadges vip={contact.vip} blacklisted={contact.blacklist !== null} compact />
                  </span>
                  {contact.tags.length > 0 && <span className="ml-2 text-xs text-muted">{contact.tags.join(", ")}</span>}
                </td>
                <td className="px-4 py-3 whitespace-nowrap">{formatPhones(contact.phones) || "—"}</td>
                <td className="px-4 py-3">{CONTACT_SOURCE_LABELS[contact.source]}</td>
                <td className="px-4 py-3">{contact.openDealsCount || "—"}</td>
                <td className="px-4 py-3">{contact.owner?.name ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {pageCount > 1 && (
        <div className="mt-4 flex items-center gap-3 text-sm">
          <Button variant="secondary" disabled={page <= 1} onClick={() => setPage(page - 1)}>
            Назад
          </Button>
          <span className="text-muted">
            Страница {page} из {pageCount}
          </span>
          <Button variant="secondary" disabled={page >= pageCount} onClick={() => setPage(page + 1)}>
            Вперёд
          </Button>
        </div>
      )}

      {isCreating && (
        <ContactFormModal onClose={() => setIsCreating(false)} onSaved={(contact) => router.push(`/contacts/${contact.id}`)} />
      )}
    </div>
  );
}
