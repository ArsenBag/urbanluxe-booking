"use client";

import { useState } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { Section } from "@/components/ui/section";
import { usePmsStatus, useRealtyCalendarStatus, useRetryPms, useSyncPmsProperties } from "@/lib/bookings";
import { formatDateTime } from "@/lib/format";

const COPIED_FEEDBACK_MS = 2000;

function WebhookUrl({ url }: { url: string }) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), COPIED_FEEDBACK_MS);
    } catch {
      // Буфер обмена недоступен (например, без HTTPS) — адрес можно выделить вручную.
      setCopied(false);
    }
  }

  return (
    <div className="flex gap-2">
      <input readOnly value={url} className="h-9 flex-1 rounded-md border border-border bg-background px-3 font-mono text-xs" onFocus={(e) => e.target.select()} aria-label="Адрес вебхука" />
      <Button variant="secondary" onClick={copy}>
        {copied ? "Скопировано" : "Копировать"}
      </Button>
    </div>
  );
}

function PmsSection() {
  const status = usePmsStatus();
  const sync = useSyncPmsProperties();
  const retry = useRetryPms();
  const data = status.data;

  return (
    <Section title="PMS Urban Luxe (менеджер каналов)">
      {status.isError && <ErrorAlert message={status.error.message} />}
      {data && !data.enabled && (
        <p className="text-sm">
          Мост не настроен: на сервере нужны <code>PMS_API_KEY</code> (секретный ключ организации High Life из PMS → «Интеграции») и{" "}
          <code>PMS_WEBHOOK_SECRET</code> (секрет вебхука PMS). Пока они не заданы, CRM работает как прежде.
        </p>
      )}
      {data?.enabled && (
        <div className="flex flex-col gap-4 text-sm">
          <dl className="grid grid-cols-3 gap-2">
            <dt className="text-muted">Подключение</dt>
            <dd className="col-span-2">
              {data.connectionError ? <span className="text-red-600">{data.connectionError}</span> : `${data.organization ?? "—"} · ключ «${data.keyName ?? "—"}»`}
            </dd>
            <dt className="text-muted">Вебхук из PMS</dt>
            <dd className="col-span-2">
              {data.webhookUrl ? <WebhookUrl url={data.webhookUrl} /> : <span>задайте PUBLIC_API_URL</span>}
              <div className="mt-1 text-xs text-muted">
                Этот адрес укажите в PMS → «Интеграции» → «+ Вебхук» (события booking.created / updated / cancelled), секрет оттуда — в PMS_WEBHOOK_SECRET.
                {data.webhookSecretSet ? " Секрет задан." : " Секрет не задан — вебхуки отклоняются."}
              </div>
            </dd>
            <dt className="text-muted">Последний вебхук</dt>
            <dd className="col-span-2">{data.lastWebhookAt ? `${formatDateTime(data.lastWebhookAt)} · ${data.lastWebhookEvent ?? ""}` : "ещё не было"}</dd>
            <dt className="text-muted">Квартиры в PMS</dt>
            <dd className="col-span-2">
              {data.propertiesLinked} из {data.propertiesTotal}
              {data.lastPropertiesSyncAt && <span className="text-muted"> · синхронизация {formatDateTime(data.lastPropertiesSyncAt)}</span>}
            </dd>
            <dt className="text-muted">Броней из PMS</dt>
            <dd className="col-span-2">{data.bookingsFromPms}</dd>
            <dt className="text-muted">Не отправлено в PMS</dt>
            <dd className="col-span-2">{data.bookingsPending}</dd>
          </dl>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => sync.mutate()} disabled={sync.isPending}>
              {sync.isPending ? "Синхронизирую…" : "Синхронизировать объекты"}
            </Button>
            <Button variant="secondary" onClick={() => retry.mutate()} disabled={retry.isPending || data.bookingsPending === 0}>
              {retry.isPending ? "Отправляю…" : "Отправить невыгруженные брони"}
            </Button>
          </div>
          {sync.data && (
            <div className="rounded-md border border-border p-3 text-xs">
              Объектов {sync.data.total}: создано в PMS {sync.data.created}, привязано к существующим {sync.data.linked}, обновлено {sync.data.updated}, пропущено{" "}
              {sync.data.skipped.length}
              {sync.data.skipped.length > 0 && (
                <ul className="mt-1 list-disc pl-5">
                  {sync.data.skipped.map((item) => (
                    <li key={item.id}>
                      {item.title}: {item.reason}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
          {retry.data && <p className="text-xs text-muted">Отправлено броней: {retry.data.sent}</p>}
          {(sync.isError || retry.isError) && <ErrorAlert message={(sync.error ?? retry.error)?.message ?? "Ошибка"} />}
          <p className="text-xs text-muted">
            Цены, наценки на площадки и закрытия дат ведутся в PMS. Брони из PMS в CRM не редактируются (ссылка «PMS ↗» в карточке брони).
          </p>
        </div>
      )}
    </Section>
  );
}

export default function IntegrationsPage() {
  const status = useRealtyCalendarStatus();

  return (
    <div className="max-w-3xl">
      <PageHeader title="Интеграции" />
      {status.isError && <ErrorAlert message={status.error.message} />}
      <Section title="RealtyCalendar">
        {status.data && (
          <div className="flex flex-col gap-4 text-sm">
            {status.data.webhookUrl ? (
              <>
                <ol className="list-decimal space-y-1 pl-5">
                  <li>В RealtyCalendar откройте «Настройки» → «Интеграции с CRM» → «Webhook».</li>
                  <li>Вставьте адрес ниже в поле «Введите URL нового Webhook» и нажмите «Запустить».</li>
                  <li>Создайте или измените любую бронь — через несколько секунд она появится в CRM.</li>
                </ol>
                <WebhookUrl url={status.data.webhookUrl} />
                <p className="text-xs text-muted">Адрес содержит секретный ключ: не публикуйте его. Новые брони и изменения приходят автоматически; брони, созданные до подключения, можно загрузить из выгрузки Excel.</p>
              </>
            ) : (
              <p>
                Адрес вебхука появится, когда CRM будет доступна из интернета: на сервере нужно задать <code>PUBLIC_API_URL</code> и{" "}
                <code>RC_WEBHOOK_SECRET</code> (это сделаем при развёртывании).
              </p>
            )}
            <dl className="grid grid-cols-3 gap-2 border-t border-border pt-3">
              <dt className="text-muted">Последнее событие</dt>
              <dd className="col-span-2">{status.data.lastEventAt ? formatDateTime(status.data.lastEventAt) : "ещё не было"}</dd>
              <dt className="text-muted">Броней в CRM</dt>
              <dd className="col-span-2">{status.data.bookingsCount}</dd>
              <dt className="text-muted">Объектов</dt>
              <dd className="col-span-2">{status.data.propertiesCount}</dd>
            </dl>
          </div>
        )}
      </Section>
      <PmsSection />
    </div>
  );
}
