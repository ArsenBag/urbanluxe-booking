"use client";

import type { ReportPeriod } from "@crm/shared";
import { useState } from "react";
import { FunnelSection } from "@/components/reports/funnel-section";
import { InquiriesSection } from "@/components/reports/inquiries-section";
import { OccupancySection } from "@/components/reports/occupancy-section";
import { PeriodFilter } from "@/components/reports/period-filter";
import { TeamSection } from "@/components/reports/team-section";
import { PageHeader } from "@/components/ui/page-header";
import { tashkentDayKey } from "@/lib/format";
import { presetPeriod } from "@/lib/report-period";

export default function ReportsPage() {
  const [period, setPeriod] = useState<ReportPeriod>(() => presetPeriod("last30", tashkentDayKey(new Date())));

  return (
    <div className="max-w-6xl">
      <PageHeader title="Отчёты" subtitle="Даты — по времени Ташкента. Брони — из RealtyCalendar, только подтверждённые." />
      <PeriodFilter period={period} onChange={setPeriod} />
      <div className="space-y-6">
        <OccupancySection period={period} />
        <InquiriesSection period={period} />
        <FunnelSection period={period} />
        <TeamSection period={period} />
      </div>
    </div>
  );
}
