"use client";

import { ROLE_LABELS, type UserDto } from "@crm/shared";
import { useState } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { CreateUserModal } from "@/components/users/create-user-modal";
import { EditUserModal } from "@/components/users/edit-user-modal";
import { useSession } from "@/lib/session";
import { useUpdateUser, useUsers } from "@/lib/users";

export default function UsersPage() {
  const users = useUsers();
  const session = useSession();
  const updateUser = useUpdateUser();
  const [isCreating, setIsCreating] = useState(false);
  const [editing, setEditing] = useState<UserDto | null>(null);

  const currentUserId = session.data?.id;

  return (
    <div className="max-w-4xl">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Пользователи</h1>
        <Button onClick={() => setIsCreating(true)}>Добавить</Button>
      </div>

      {users.isError && <ErrorAlert message={users.error.message} />}
      {updateUser.isError && <ErrorAlert message={updateUser.error.message} />}

      <div className="overflow-hidden rounded-xl border border-border bg-surface">
        <table className="w-full text-sm">
          <thead className="border-b border-border text-left text-muted">
            <tr>
              <th className="px-4 py-3 font-medium">Имя</th>
              <th className="px-4 py-3 font-medium">Email</th>
              <th className="px-4 py-3 font-medium">Роль</th>
              <th className="px-4 py-3 font-medium">Статус</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {users.isPending && (
              <tr>
                <td colSpan={5} className="px-4 py-6 text-center text-muted">
                  Загрузка…
                </td>
              </tr>
            )}
            {users.data?.map((user) => {
              const isSelf = user.id === currentUserId;
              return (
                <tr key={user.id} className="border-b border-border last:border-0">
                  <td className="px-4 py-3 font-medium">{user.name}</td>
                  <td className="px-4 py-3">{user.email}</td>
                  <td className="px-4 py-3">{ROLE_LABELS[user.role]}</td>
                  <td className="px-4 py-3">
                    <span className={user.isActive ? "text-green-600" : "text-muted"}>
                      {user.isActive ? "Активен" : "Заблокирован"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <Button variant="ghost" onClick={() => setEditing(user)}>
                      Изменить
                    </Button>
                    {!isSelf && (
                      <Button
                        variant="ghost"
                        disabled={updateUser.isPending}
                        onClick={() => {
                          updateUser.reset();
                          updateUser.mutate({ id: user.id, input: { isActive: !user.isActive } });
                        }}
                      >
                        {user.isActive ? "Заблокировать" : "Разблокировать"}
                      </Button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <CreateUserModal open={isCreating} onClose={() => setIsCreating(false)} />
      {editing && (
        <EditUserModal user={editing} isSelf={editing.id === currentUserId} onClose={() => setEditing(null)} />
      )}
    </div>
  );
}
