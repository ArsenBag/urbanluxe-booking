"use client";

import { useState } from "react";
import { TaskForm } from "@/components/tasks/task-form";
import { TaskList } from "@/components/tasks/task-list";
import { PageHeader } from "@/components/ui/page-header";
import { Section } from "@/components/ui/section";
import type { TaskFilters } from "@/lib/tasks";

type Scope = NonNullable<TaskFilters["scope"]>;
type Status = NonNullable<TaskFilters["status"]>;

const SCOPES: Array<{ value: Scope; label: string }> = [
  { value: "mine", label: "Мои" },
  { value: "all", label: "Все" },
];
const STATUSES: Array<{ value: Status; label: string }> = [
  { value: "open", label: "Открытые" },
  { value: "done", label: "Выполненные" },
];

function Toggle<T extends string>({ options, value, onChange }: { options: Array<{ value: T; label: string }>; value: T; onChange: (value: T) => void }) {
  return (
    <div className="inline-flex rounded-md border border-border bg-surface p-0.5" role="group">
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          aria-pressed={value === option.value}
          className={`rounded px-3 py-1 text-sm ${value === option.value ? "bg-primary text-primary-foreground" : "text-muted hover:text-foreground"}`}
          onClick={() => onChange(option.value)}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export default function TasksPage() {
  const [scope, setScope] = useState<Scope>("mine");
  const [status, setStatus] = useState<Status>("open");

  return (
    <div className="max-w-3xl">
      <PageHeader title="Задачи" />
      <div className="mb-4 flex flex-wrap gap-3">
        <Toggle options={SCOPES} value={scope} onChange={setScope} />
        <Toggle options={STATUSES} value={status} onChange={setStatus} />
      </div>
      <div className="flex flex-col gap-4">
        <Section title="Новая задача">
          <TaskForm />
        </Section>
        <Section title={status === "open" ? "В работе" : "Выполнено"}>
          <TaskList
            filters={{ scope, status }}
            showContext
            emptyText={status === "open" ? "Открытых задач нет" : "Выполненных задач нет"}
          />
        </Section>
      </div>
    </div>
  );
}
