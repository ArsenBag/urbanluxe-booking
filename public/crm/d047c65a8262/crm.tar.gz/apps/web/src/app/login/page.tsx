"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { TextField } from "@/components/ui/field";
import { ApiRequestError, formLevelError } from "@/lib/api";
import { safeRedirectTarget } from "@/lib/safe-redirect";
import { useLogin } from "@/lib/session";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const login = useLogin();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const error = login.error instanceof ApiRequestError ? login.error : null;
  const formMessage = formLevelError(login.error, ["email", "password"]);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    login.mutate(
      { email, password },
      { onSuccess: () => router.replace(safeRedirectTarget(searchParams.get("next"), window.location.origin)) },
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
      {formMessage && <ErrorAlert message={formMessage} />}
      <TextField
        label="Email"
        type="email"
        autoComplete="email"
        required
        value={email}
        onChange={(event) => setEmail(event.target.value)}
        error={error?.fields.email}
      />
      <TextField
        label="Пароль"
        type="password"
        autoComplete="current-password"
        required
        value={password}
        onChange={(event) => setPassword(event.target.value)}
        error={error?.fields.password}
      />
      <Button type="submit" disabled={login.isPending}>
        {login.isPending ? "Входим…" : "Войти"}
      </Button>
    </form>
  );
}

export default function LoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-sm rounded-xl border border-border bg-surface p-6 shadow-sm">
        <h1 className="text-xl font-semibold">High Life CRM</h1>
        <p className="mb-6 mt-1 text-sm text-muted">Войдите, чтобы продолжить</p>
        <Suspense>
          <LoginForm />
        </Suspense>
      </div>
    </main>
  );
}
