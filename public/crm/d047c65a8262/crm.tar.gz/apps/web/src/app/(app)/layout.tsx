"use client";

import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { NotificationCenter } from "@/components/notifications/notification-center";
import { NotificationSettingsButton } from "@/components/notifications/notification-settings-button";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { isUnauthorized as isUnauthorizedError } from "@/lib/api";
import { useLogout, useSession } from "@/lib/session";

export default function AppLayout({ children }: LayoutProps<"/">) {
  const router = useRouter();
  const pathname = usePathname();
  const session = useSession();
  const logout = useLogout();

  const isUnauthorized = isUnauthorizedError(session.error);

  useEffect(() => {
    if (isUnauthorized) {
      router.replace(`/login?next=${encodeURIComponent(pathname)}`);
    }
  }, [isUnauthorized, pathname, router]);

  if (session.isPending || isUnauthorized) {
    return <div className="p-8 text-sm text-muted">Загрузка…</div>;
  }
  if (session.isError) {
    return (
      <div className="p-8">
        <ErrorAlert message={session.error.message} />
      </div>
    );
  }

  const user = session.data;
  return (
    <div className="flex min-h-screen">
      <aside className="flex w-60 shrink-0 flex-col border-r border-border bg-surface p-4">
        <div className="mb-6 px-3 text-base font-semibold">High Life CRM</div>
        <Sidebar role={user.role} />
        <div className="mt-auto border-t border-border px-3 pt-4">
          <div className="truncate text-sm font-medium">{user.name}</div>
          <div className="truncate text-xs text-muted">{user.email}</div>
          <div className="mt-2">
            <NotificationSettingsButton />
          </div>
          <Button variant="ghost" className="-ml-4" onClick={() => logout.mutate()} disabled={logout.isPending}>
            Выйти
          </Button>
        </div>
      </aside>
      {/* min-w-0: широкое содержимое (канбан, шахматка) прокручивается внутри, а не растягивает страницу. */}
      <main className="min-w-0 flex-1 p-8">{children}</main>
      <NotificationCenter />
    </div>
  );
}
