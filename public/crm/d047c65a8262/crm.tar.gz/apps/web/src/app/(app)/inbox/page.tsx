"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { ChatView } from "@/components/inbox/chat-view";
import { ConversationList } from "@/components/inbox/conversation-list";
import { ConversationPanel } from "@/components/inbox/conversation-panel";
import { DEFAULT_CONVERSATION_FILTERS, type ConversationFilters } from "@/lib/inbox";

function Inbox() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  // Открытый диалог хранится в адресе (?c=…): ссылкой можно поделиться, «назад» работает.
  const selectedId = searchParams.get("c");
  const [filters, setFilters] = useState<ConversationFilters>(DEFAULT_CONVERSATION_FILTERS);

  const select = (id: string) => router.replace(`${pathname}?c=${id}`, { scroll: false });

  return (
    <div className="-m-8 grid h-screen grid-cols-[320px_minmax(0,1fr)] xl:grid-cols-[320px_minmax(0,1fr)_300px]">
      <div className="min-h-0 border-r border-border bg-surface">
        <ConversationList filters={filters} onFiltersChange={setFilters} selectedId={selectedId} onSelect={select} />
      </div>
      <div className="min-h-0">
        {selectedId ? (
          <ChatView key={selectedId} conversationId={selectedId} />
        ) : (
          <div className="flex h-full items-center justify-center text-sm text-muted">Выберите диалог слева</div>
        )}
      </div>
      {selectedId && (
        <div className="hidden min-h-0 border-l border-border bg-surface xl:block">
          <ConversationPanel conversationId={selectedId} />
        </div>
      )}
    </div>
  );
}

export default function InboxPage() {
  return (
    <Suspense>
      <Inbox />
    </Suspense>
  );
}
