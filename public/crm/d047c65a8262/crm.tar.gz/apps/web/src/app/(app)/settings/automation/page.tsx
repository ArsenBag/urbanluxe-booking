"use client";

import { StageAutomationEditor } from "@/components/stage-automation/stage-automation-editor";
import { ErrorAlert } from "@/components/ui/alert";
import { PageHeader } from "@/components/ui/page-header";
import { usePipelines } from "@/lib/pipelines";
import { useStageAutomation } from "@/lib/stage-automation";

export default function StageAutomationPage() {
  const settings = useStageAutomation();
  const pipelines = usePipelines();
  const error = settings.error ?? pipelines.error;

  return (
    <div className="max-w-3xl">
      <PageHeader
        title="Автоперенос сделок"
        subtitle="Сделки по броням сами переходят по этапам в нужное время: заезд, выезд завтра, выехал."
      />
      {error && <ErrorAlert message={error.message} />}
      {settings.data && pipelines.data && <StageAutomationEditor settings={settings.data} pipelines={pipelines.data} />}
    </div>
  );
}
