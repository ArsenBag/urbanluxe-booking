"use client";

import { CUSTOM_FIELD_ENTITIES, CUSTOM_FIELD_ENTITY_LABELS } from "@crm/shared";
import { FieldsEditor } from "@/components/custom-fields/fields-editor";
import { PageHeader } from "@/components/ui/page-header";
import { Section } from "@/components/ui/section";

export default function CustomFieldsPage() {
  return (
    <div className="max-w-3xl">
      <PageHeader
        title="Поля карточек"
        subtitle="Свои поля для карточек клиентов и сделок. Они появятся в блоке «Дополнительно», заполнять их могут все сотрудники."
      />
      <div className="flex flex-col gap-4">
        {CUSTOM_FIELD_ENTITIES.map((entity) => (
          <Section key={entity} title={CUSTOM_FIELD_ENTITY_LABELS[entity]}>
            <FieldsEditor entity={entity} />
          </Section>
        ))}
      </div>
    </div>
  );
}
