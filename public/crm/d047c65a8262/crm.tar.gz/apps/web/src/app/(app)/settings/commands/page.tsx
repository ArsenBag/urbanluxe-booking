"use client";

import { CommandList } from "@/components/quick-commands/command-list";
import { ErrorAlert } from "@/components/ui/alert";
import { PageHeader } from "@/components/ui/page-header";
import { Section } from "@/components/ui/section";
import { useTemplates } from "@/lib/channels";
import { useSession } from "@/lib/session";

const VARIABLES: Array<[string, string]> = [
  ["{имя}", "имя клиента из карточки"],
  ["{объект}", "квартира из текущей или ближайшей брони"],
  ["{заезд}", "дата заезда, например «20 октября»"],
  ["{выезд}", "дата выезда"],
];

export default function QuickCommandsPage() {
  const templates = useTemplates();
  const session = useSession();

  return (
    <div className="max-w-5xl">
      <PageHeader
        title="Быстрые команды"
        subtitle="В чате наберите / и начало команды — например /wifi — выберите стрелками и нажмите Enter. Готовый текст подставится в сообщение, а прикреплённый к команде файл — во вложение."
      />
      {templates.isError && <ErrorAlert message={templates.error.message} />}
      <div className="grid gap-4 lg:grid-cols-[1fr_16rem]">
        {templates.data && session.data ? (
          <CommandList templates={templates.data} isAdmin={session.data.role === "ADMIN"} />
        ) : (
          <p className="text-sm text-muted">Загрузка…</p>
        )}
        <Section title="Переменные">
          <p className="mb-2 text-xs text-muted">Пишите их в тексте — при вставке заменятся на данные клиента:</p>
          <dl className="flex flex-col gap-2 text-sm">
            {VARIABLES.map(([name, description]) => (
              <div key={name}>
                <dt className="font-mono text-primary">{name}</dt>
                <dd className="text-xs text-muted">{description}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-3 text-xs text-muted">Если брони нет, переменная останется в тексте — допишите вручную перед отправкой.</p>
        </Section>
      </div>
    </div>
  );
}
