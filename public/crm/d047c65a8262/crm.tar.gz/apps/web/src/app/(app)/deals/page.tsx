"use client";

import { MAX_BOARD_DEALS, type DealDto, type PipelineDto } from "@crm/shared";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { Board } from "@/components/deals/board";
import { DealFiltersBar } from "@/components/deals/deal-filters-bar";
import { DealFormModal } from "@/components/deals/deal-form-modal";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { dealBoardQuery, dealFiltersToParams, parseDealFilters, type DealFilters } from "@/lib/deal-filters";
import { useBoard } from "@/lib/deals";
import { usePipelines } from "@/lib/pipelines";
import { useDebouncedValue } from "@/lib/use-debounced-value";
import { useUserOptions } from "@/lib/users";

const SEARCH_DELAY_MS = 300;

/** Выбранные этапы — колонки доски; если ни один этап этой воронки не выбран, видны все. */
function visibleStagesOf(pipeline: PipelineDto, stageIds: string[]): PipelineDto {
  const stages = pipeline.stages.filter((stage) => stageIds.includes(stage.id));
  return stages.length > 0 ? { ...pipeline, stages } : pipeline;
}

function countOnBoard(pipeline: PipelineDto, deals: DealDto[]): number {
  const stageIds = new Set(pipeline.stages.map((stage) => stage.id));
  return deals.filter((deal) => stageIds.has(deal.stageId)).length;
}

/**
 * Воронка и фильтры — в состоянии страницы и копией в адресе (?pipeline=…&owners=…): переход в сделку и
 * назад их не сбрасывает. Состояние меняется сразу, поэтому быстрые щелчки подряд не теряются.
 */
function DealsView() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [filters, setFiltersState] = useState(() => parseDealFilters(new URLSearchParams(searchParams.toString())));
  const [pipelineId, setPipelineId] = useState(() => searchParams.get("pipeline"));
  const pipelines = usePipelines();
  const users = useUserOptions();
  const [newDealStageId, setNewDealStageId] = useState<string | null>(null);

  const pipeline = pipelines.data?.find((p) => p.id === pipelineId) ?? pipelines.data?.[0];
  // Этапы из адреса, которых нет в этой воронке, не считаются фильтром.
  const shown = { ...filters, stageIds: filters.stageIds.filter((id) => pipeline?.stages.some((stage) => stage.id === id)) };
  // Поиск уходит на сервер после паузы в наборе, остальные фильтры — сразу.
  const debouncedSearch = useDebouncedValue(shown.search, SEARCH_DELAY_MS);
  // Очищенное поле (и «Сбросить фильтры») применяется сразу, без лишнего запроса со старым текстом.
  const search = shown.search.trim() ? debouncedSearch : "";
  const board = useBoard(pipeline?.id, dealBoardQuery({ ...shown, search }));

  const apply = (nextFilters: DealFilters, nextPipelineId: string | null) => {
    setFiltersState(nextFilters);
    setPipelineId(nextPipelineId);
    const params = dealFiltersToParams(nextFilters, new URLSearchParams());
    if (nextPipelineId) params.set("pipeline", nextPipelineId);
    const query = params.toString();
    router.replace(query ? `${pathname}?${query}` : pathname, { scroll: false });
  };

  if (pipelines.isError) return <ErrorAlert message={pipelines.error.message} />;
  if (pipelines.isPending) return <p className="text-sm text-muted">Загрузка…</p>;
  if (!pipeline) return <p className="text-sm text-muted">Воронок нет. Администратор может создать их в настройках.</p>;

  const boardPipeline = visibleStagesOf(pipeline, shown.stageIds);

  return (
    <div className="-m-8 flex h-screen flex-col p-8">
      <DealsHeader
        pipelines={pipelines.data}
        pipelineId={pipeline.id}
        // Этапы другой воронки не подходят — при смене воронки фильтр этапов сбрасывается.
        onPipelineChange={(id) => apply({ ...filters, stageIds: [] }, id)}
        onNewDeal={() => setNewDealStageId(pipeline.stages[0]?.id ?? "")}
      />
      <DealFiltersBar
        filters={shown}
        onChange={(next) => apply(next, pipelineId)}
        stages={pipeline.stages}
        users={users.data ?? []}
        found={board.data && !board.isPlaceholderData ? countOnBoard(boardPipeline, board.data) : undefined}
      />
      <BoardArea board={board} pipeline={boardPipeline} onAddDeal={setNewDealStageId} />
      {newDealStageId !== null && (
        <DealFormModal
          pipelines={pipelines.data}
          defaultPipelineId={pipeline.id}
          defaultStageId={newDealStageId || undefined}
          onClose={() => setNewDealStageId(null)}
        />
      )}
    </div>
  );
}

interface BoardAreaProps {
  board: ReturnType<typeof useBoard>;
  pipeline: PipelineDto;
  onAddDeal: (stageId: string) => void;
}

/** Доска с её состояниями: загрузка, ошибка, предупреждение о потолке карточек, старые данные при смене фильтров. */
function BoardArea({ board, pipeline, onAddDeal }: BoardAreaProps) {
  if (board.isError) return <ErrorAlert message={board.error.message} />;
  if (board.isPending) return <p className="text-sm text-muted">Загрузка…</p>;
  return (
    <>
      {board.data.length >= MAX_BOARD_DEALS && (
        <ErrorAlert message={`Показаны первые ${MAX_BOARD_DEALS} сделок — сузьте фильтр, чтобы увидеть остальные.`} />
      )}
      <div className={`flex min-h-0 flex-1 flex-col ${board.isPlaceholderData ? "opacity-60" : ""}`}>
        <Board pipeline={pipeline} deals={board.data} onAddDeal={onAddDeal} />
      </div>
    </>
  );
}

interface DealsHeaderProps {
  pipelines: PipelineDto[];
  pipelineId: string;
  onPipelineChange: (id: string) => void;
  onNewDeal: () => void;
}

function DealsHeader({ pipelines, pipelineId, onPipelineChange, onNewDeal }: DealsHeaderProps) {
  return (
    <div className="mb-4 flex flex-wrap items-center gap-3">
      <h1 className="text-2xl font-semibold">Сделки</h1>
      {pipelines.length > 1 && (
        <select
          className="h-9 rounded-md border border-border bg-surface px-3 text-sm"
          value={pipelineId}
          onChange={(e) => onPipelineChange(e.target.value)}
          aria-label="Воронка"
        >
          {pipelines.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
      )}
      <Button className="ml-auto" onClick={onNewDeal}>
        Новая сделка
      </Button>
    </div>
  );
}

export default function DealsPage() {
  return (
    <Suspense>
      <DealsView />
    </Suspense>
  );
}
