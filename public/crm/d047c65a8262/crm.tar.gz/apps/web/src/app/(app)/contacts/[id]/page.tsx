"use client";

import { CONTACT_SOURCE_LABELS, formatPhone } from "@crm/shared";
import { useParams, useRouter } from "next/navigation";
import { useState } from "react";
import { ActivityFeed } from "@/components/activity/activity-feed";
import { ContactFormModal } from "@/components/contacts/contact-form-modal";
import { StartConversationModal } from "@/components/contacts/start-conversation-modal";
import { CustomFieldsSection } from "@/components/custom-fields/custom-fields-section";
import { BlacklistBanner } from "@/components/guests/blacklist-banner";
import { GuestActions } from "@/components/guests/guest-actions";
import { GuestBadges } from "@/components/guests/guest-badges";
import { ContactConversationsSection } from "@/components/inbox/contact-conversations-section";
import { DealFormModal } from "@/components/deals/deal-form-modal";
import { DealSummaryRow } from "@/components/deals/deal-summary-row";
import { TaskForm } from "@/components/tasks/task-form";
import { TaskList } from "@/components/tasks/task-list";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { Section } from "@/components/ui/section";
import { useContact, useContactActivity, useDeleteContact } from "@/lib/contacts";
import { BookingsSection } from "@/components/bookings/bookings-section";
import { useContactBookings } from "@/lib/bookings";
import { useContactDeals } from "@/lib/deals";
import { useGuestStays } from "@/lib/guests";
import { formatDateTime } from "@/lib/format";
import { usePipelines } from "@/lib/pipelines";
import { useSession } from "@/lib/session";

function InfoRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-3 gap-2 py-1.5 text-sm">
      <dt className="text-muted">{label}</dt>
      <dd className="col-span-2 break-words">{children}</dd>
    </div>
  );
}

export default function ContactPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const session = useSession();
  const contact = useContact(id);
  const deals = useContactDeals(id);
  const bookings = useContactBookings(id);
  const stays = useGuestStays(id);
  const activity = useContactActivity(id);
  const pipelines = usePipelines();
  const deleteContact = useDeleteContact();
  const [isEditing, setIsEditing] = useState(false);
  const [isCreatingDeal, setIsCreatingDeal] = useState(false);
  const [isWriting, setIsWriting] = useState(false);

  if (contact.isError) return <ErrorAlert message={contact.error.message} />;
  if (contact.isPending) return <p className="text-sm text-muted">Загрузка…</p>;

  const data = contact.data;

  function handleDelete() {
    if (window.confirm(`Удалить клиента «${data.name}»? Это действие нельзя отменить.`)) {
      deleteContact.mutate(data.id, { onSuccess: () => router.replace("/contacts") });
    }
  }

  return (
    <div className="max-w-6xl">
      <PageHeader
        title={data.name}
        subtitle={`${CONTACT_SOURCE_LABELS[data.source]} · добавлен ${formatDateTime(data.createdAt)}`}
        actions={
          <>
            <Button onClick={() => setIsWriting(true)}>Написать</Button>
            <Button variant="secondary" onClick={() => setIsEditing(true)}>
              Изменить
            </Button>
            <Button variant="secondary" onClick={() => setIsCreatingDeal(true)} disabled={!pipelines.data?.length}>
              Новая сделка
            </Button>
            {session.data?.role === "ADMIN" && (
              <Button
                variant="ghost"
                onClick={handleDelete}
                disabled={deleteContact.isPending || data.blacklist !== null}
                title={data.blacklist ? "Гость в чёрном списке — сначала уберите его из списка" : undefined}
              >
                Удалить
              </Button>
            )}
          </>
        }
      />
      {deleteContact.isError && <ErrorAlert message={deleteContact.error.message} />}
      {data.blacklist && (
        <div className="mb-4 overflow-hidden rounded-xl">
          <BlacklistBanner blacklist={data.blacklist} />
        </div>
      )}
      <StartConversationModal contactId={data.id} phones={data.phones} open={isWriting} onClose={() => setIsWriting(false)} />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="flex flex-col gap-4 lg:col-span-2">
          <Section title="Контакты">
            <dl>
              <InfoRow label="Телефоны">
                {data.phones.length
                  ? data.phones.map((phone) => (
                      <a key={phone} href={`tel:${phone}`} className="mr-3 text-primary hover:underline">
                        {formatPhone(phone)}
                      </a>
                    ))
                  : "—"}
              </InfoRow>
              <InfoRow label="Email">{data.email ?? "—"}</InfoRow>
              <InfoRow label="Ответственный">{data.owner?.name ?? "—"}</InfoRow>
              <InfoRow label="Теги">{data.tags.length ? data.tags.join(", ") : "—"}</InfoRow>
              <InfoRow label="Заметки">
                <span className="whitespace-pre-wrap">{data.notes ?? "—"}</span>
              </InfoRow>
            </dl>
          </Section>

          <CustomFieldsSection entity="CONTACT" recordId={data.id} values={data.customFields} />

          <ContactConversationsSection contactId={id} />

          <BookingsSection bookings={bookings.data} />

          <Section title="Сделки">
            {deals.isError && <ErrorAlert message={deals.error.message} />}
            {deals.data?.length === 0 && <p className="text-sm text-muted">Сделок пока нет</p>}
            <ul className="divide-y divide-border">
              {deals.data?.map((deal) => <DealSummaryRow key={deal.id} deal={deal} />)}
            </ul>
          </Section>

          <Section title="Задачи">
            <TaskList filters={{ contactId: id, scope: "all", status: "all" }} />
            <div className="mt-3 border-t border-border pt-3">
              <TaskForm contactId={id} />
            </div>
          </Section>
        </div>

        <div className="flex flex-col gap-4">
          <Section title="Статус гостя">
            <div className="mb-3 flex flex-wrap gap-1.5">
              <GuestBadges vip={data.vip} blacklisted={data.blacklist !== null} stays={stays} />
            </div>
            <GuestActions contactId={data.id} contactName={data.name} vip={data.vip} blacklist={data.blacklist} />
          </Section>

          <Section title="История">
            <ActivityFeed entries={activity.data} isPending={activity.isPending} error={activity.error} />
          </Section>
        </div>
      </div>

      {isEditing && <ContactFormModal contact={data} onClose={() => setIsEditing(false)} />}
      {isCreatingDeal && pipelines.data && (
        <DealFormModal
          pipelines={pipelines.data}
          contact={{ id: data.id, name: data.name }}
          onClose={() => setIsCreatingDeal(false)}
          onCreated={(dealId) => router.push(`/deals/${dealId}`)}
        />
      )}
    </div>
  );
}
