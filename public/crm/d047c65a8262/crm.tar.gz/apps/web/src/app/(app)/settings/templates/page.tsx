import { redirect } from "next/navigation";

/** Раздел переехал: шаблоны ответов теперь — «Быстрые команды». */
export default function TemplatesPage() {
  redirect("/settings/commands");
}
