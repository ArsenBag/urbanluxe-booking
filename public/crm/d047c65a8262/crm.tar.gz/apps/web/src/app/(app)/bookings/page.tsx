"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { addDays } from "@/components/bookings/chessboard-layout";
import { Chessboard } from "@/components/bookings/chessboard";
import { DayOverview } from "@/components/bookings/day-overview";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { formatDayLabel, parseDateKey, tashkentDayKey } from "@/lib/format";

type Tab = "day" | "chessboard";


/** ?date=ГГГГ-ММ-ДД открывает нужный день — так ведёт ссылка из уведомления о новой брони. */
function BookingsFromUrl() {
  const initialDate = parseDateKey(useSearchParams().get("date")) ?? tashkentDayKey(new Date());
  return <BookingsView key={initialDate} initialDate={initialDate} />;
}

export default function BookingsPage() {
  return (
    <Suspense>
      <BookingsFromUrl />
    </Suspense>
  );
}

function BookingsView({ initialDate }: { initialDate: string }) {
  const today = tashkentDayKey(new Date());
  const [tab, setTab] = useState<Tab>("day");
  const [date, setDate] = useState(initialDate);

  return (
    <div className={tab === "day" ? "max-w-6xl" : ""}>
      <PageHeader
        title="Брони"
        subtitle="Брони из RealtyCalendar приходят сами. Внести бронь вручную — на шахматке; её нужно внести и в RealtyCalendar."
      />

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="inline-flex rounded-md border border-border bg-surface p-0.5" role="group">
          {(["day", "chessboard"] as const).map((value) => (
            <button
              key={value}
              type="button"
              aria-pressed={tab === value}
              onClick={() => setTab(value)}
              className={`rounded px-3 py-1 text-sm ${tab === value ? "bg-primary text-primary-foreground" : "text-muted hover:text-foreground"}`}
            >
              {value === "day" ? "День" : "Шахматка"}
            </button>
          ))}
        </div>

        {tab === "day" && (
          <div className="flex items-center gap-2">
            <Button variant="secondary" className="h-8 px-2" onClick={() => setDate(addDays(date, -1))} aria-label="Предыдущий день">
              ←
            </Button>
            <input type="date" className="h-8 rounded-md border border-border bg-surface px-2 text-sm" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} aria-label="Дата" />
            <Button variant="secondary" className="h-8 px-2" onClick={() => setDate(addDays(date, 1))} aria-label="Следующий день">
              →
            </Button>
            <span className="text-sm text-muted">{formatDayLabel(`${date}T07:00:00Z`)}</span>
            {date !== today && (
              <Button variant="secondary" className="h-8" onClick={() => setDate(today)}>
                Сегодня
              </Button>
            )}
          </div>
        )}
      </div>

      {tab === "day" ? <DayOverview date={date} /> : <Chessboard />}
    </div>
  );
}
