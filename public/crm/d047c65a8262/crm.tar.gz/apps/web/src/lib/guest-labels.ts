import { pluralize } from "./format";

/** Метка гостя: «Впервые» или «3 проживания». */
export function staysLabel(stays: number): string {
  if (stays === 0) return "Впервые";
  return `${stays} ${pluralize(stays, ["проживание", "проживания", "проживаний"])}`;
}
