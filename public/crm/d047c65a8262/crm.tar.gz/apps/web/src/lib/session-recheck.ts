import { isUnauthorized } from "./api";
import { SESSION_KEY } from "./session";

/**
 * Нужно ли перепроверить сессию после ошибки запроса.
 * Ответ 401 на любой запрос, кроме самой проверки сессии, означает, что сессия могла закончиться.
 * Ошибку самой проверки не обрабатываем: иначе перепроверка запускает сама себя бесконечно.
 */
export function shouldRecheckSession(error: unknown, queryKey: readonly unknown[] | undefined): boolean {
  return isUnauthorized(error) && queryKey?.[0] !== SESSION_KEY[0];
}
