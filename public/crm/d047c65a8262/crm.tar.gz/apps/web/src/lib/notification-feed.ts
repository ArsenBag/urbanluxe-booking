import { CHANNEL_TYPE_LABELS, type NotificationEvent } from "@crm/shared";
import { formatStay } from "./format";
import type { NotificationSettings } from "./notification-settings";
import type { NotificationSound } from "./notification-sounds";

export interface NotificationContent {
  /** id события: по нему убираются повторы. */
  id: string;
  kind: NotificationEvent["kind"];
  title: string;
  body: string;
  /** Без имён и текста — для системного уведомления на экране, который видят посторонние. */
  summary: string;
  /** Системные уведомления с одним тегом заменяют друг друга: один чат — одно уведомление. */
  tag: string;
  href: string;
  /** Гость из чёрного списка: карточка красная и мигает. */
  blacklisted: boolean;
}

const BLACKLIST_TITLE = "Чёрный список · ";
const BLACKLIST_SUMMARY = " — гость из чёрного списка";

/** Гость из чёрного списка виден сразу: в заголовке и в системном уведомлении без имён. */
function markBlacklisted(content: NotificationContent): NotificationContent {
  if (!content.blacklisted) return content;
  return { ...content, title: BLACKLIST_TITLE + content.title, summary: content.summary + BLACKLIST_SUMMARY };
}

/** Заголовок, текст и ссылка уведомления. */
export function notificationContent(event: NotificationEvent): NotificationContent {
  return markBlacklisted(baseContent(event));
}

function baseContent(event: NotificationEvent): NotificationContent {
  if (event.kind === "message") {
    const channel = CHANNEL_TYPE_LABELS[event.channelType];
    return {
      id: event.id,
      kind: event.kind,
      title: `${event.contactName} · ${channel}`,
      body: event.preview || "Новое сообщение",
      summary: `Новое сообщение в ${channel}`,
      tag: event.conversationId,
      href: `/inbox?c=${event.conversationId}`,
      blacklisted: event.blacklisted,
    };
  }
  const title = event.status === "REQUEST" ? "Новая заявка на бронь" : "Новая бронь";
  const details = [event.propertyTitle, formatStay(event.checkIn, event.checkOut), event.origin, event.guestName];
  return {
    id: event.id,
    kind: event.kind,
    title,
    body: details.filter(Boolean).join(" · "),
    summary: title,
    tag: event.id,
    href: `/bookings?date=${event.checkIn}`,
    blacklisted: event.blacklisted,
  };
}

/** Порядок вытеснения: обычные сообщения, затем брони, в последнюю очередь — гости из чёрного списка. */
const EVICTION_PASSES: ReadonlyArray<(toast: NotificationContent) => boolean> = [
  (toast) => !toast.blacklisted && toast.kind === "message",
  (toast) => !toast.blacklisted && toast.kind === "booking",
  (toast) => toast.blacklisted,
];

/**
 * Новые карточки в стопку не больше max. Лишние уходят от старых к новым, но сначала
 * обычные сообщения: карточка брони или гостя из чёрного списка не должна исчезнуть из-за потока сообщений.
 */
export function pushToasts(current: readonly NotificationContent[], incoming: readonly NotificationContent[], max: number): NotificationContent[] {
  const all = [...current, ...incoming];
  const evicted = new Set<string>();
  for (const isEvictable of EVICTION_PASSES) {
    for (const toast of all) {
      if (all.length - evicted.size <= max) break;
      if (isEvictable(toast)) evicted.add(toast.id);
    }
  }
  return all.filter((toast) => !evicted.has(toast.id));
}

/**
 * Один звук на пачку событий за опрос, а не по сигналу на каждое сообщение.
 * Бронь важнее сообщения; выключенный в настройках звук пропускаем. null — молчим.
 */
export function batchSound(
  contents: readonly Pick<NotificationContent, "kind">[],
  settings: Pick<NotificationSettings, "messageSound" | "bookingSound">,
): NotificationSound | null {
  const has = (kind: NotificationContent["kind"]) => contents.some((content) => content.kind === kind);
  if (settings.bookingSound && has("booking")) return "booking";
  if (settings.messageSound && has("message")) return "message";
  return null;
}

const CLAIMS_KEY = "crm:notified";
/** Помним последние id: этого хватает на запас ленты и несколько открытых вкладок. */
const MAX_CLAIMS = 200;

type ClaimStorage = Pick<Storage, "getItem" | "setItem">;

/**
 * Отмечает событие показанным. false — его уже показали: повтор из запаса ленты или
 * другая вкладка CRM успела раньше (общий localStorage), чтобы звук не играл дважды.
 */
export function createNotificationClaims(storage: ClaimStorage | null) {
  const seen = new Set<string>();
  return function claim(id: string): boolean {
    if (seen.has(id)) return false;
    seen.add(id);
    // Вкладка может быть открыта днями: самый старый id выкидываем (Set хранит порядок вставки).
    if (seen.size > MAX_CLAIMS) seen.delete(seen.values().next().value as string);
    if (!storage) return true;
    try {
      const parsed: unknown = JSON.parse(storage.getItem(CLAIMS_KEY) ?? "[]");
      const claimed = Array.isArray(parsed) ? parsed.filter((value): value is string => typeof value === "string") : [];
      if (claimed.includes(id)) return false;
      storage.setItem(CLAIMS_KEY, JSON.stringify([...claimed, id].slice(-MAX_CLAIMS)));
    } catch {
      // Хранилище недоступно — повторы отсекает seen этой вкладки.
    }
    return true;
  };
}
