import { describe, expect, it } from "vitest";
import { ApiRequestError } from "./api";
import { shouldRecheckSession } from "./session-recheck";

const unauthorized = new ApiRequestError("Требуется вход в систему", 401);

describe("shouldRecheckSession", () => {
  it("rechecks the session when another request gets 401", () => {
    expect(shouldRecheckSession(unauthorized, ["contacts"])).toBe(true);
  });

  it("never rechecks because of the session request itself (that would loop forever)", () => {
    expect(shouldRecheckSession(unauthorized, ["session"])).toBe(false);
  });

  it("ignores other errors", () => {
    expect(shouldRecheckSession(new ApiRequestError("Нет прав", 403), ["contacts"])).toBe(false);
    expect(shouldRecheckSession(new Error("сеть"), ["contacts"])).toBe(false);
  });

  it("rechecks after a failed mutation, which has no query key", () => {
    expect(shouldRecheckSession(unauthorized, undefined)).toBe(true);
  });
});
