import { describe, expect, it } from "vitest";
import { movedSummary } from "./link-summary";

describe("movedSummary", () => {
  it("lists what moves with the merged card in Russian plural forms", () => {
    expect(movedSummary({ bookings: 1, deals: 2, conversations: 5 })).toBe("1 бронь, 2 сделки, 5 чатов");
  });

  it("skips empty kinds", () => {
    expect(movedSummary({ bookings: 3, deals: 0, conversations: 1 })).toBe("3 брони, 1 чат");
  });

  it("returns null when nothing moves", () => {
    expect(movedSummary({ bookings: 0, deals: 0, conversations: 0 })).toBeNull();
  });
});
