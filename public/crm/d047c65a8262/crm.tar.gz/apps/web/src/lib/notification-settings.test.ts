import { describe, expect, it } from "vitest";
import { DEFAULT_NOTIFICATION_SETTINGS, parseNotificationSettings } from "./notification-settings";

describe("parseNotificationSettings", () => {
  it("uses defaults when nothing is saved or the value is broken", () => {
    expect(parseNotificationSettings(null)).toEqual(DEFAULT_NOTIFICATION_SETTINGS);
    expect(parseNotificationSettings("{oops")).toEqual(DEFAULT_NOTIFICATION_SETTINGS);
    expect(parseNotificationSettings("42")).toEqual(DEFAULT_NOTIFICATION_SETTINGS);
  });

  it("reads saved values and keeps defaults for missing ones", () => {
    expect(parseNotificationSettings(JSON.stringify({ volume: 0.3, bookingSound: false }))).toEqual({
      ...DEFAULT_NOTIFICATION_SETTINGS,
      volume: 0.3,
      bookingSound: false,
    });
  });

  it("keeps the volume between 0 and 1", () => {
    expect(parseNotificationSettings(JSON.stringify({ volume: 5 })).volume).toBe(1);
    expect(parseNotificationSettings(JSON.stringify({ volume: -1 })).volume).toBe(0);
    expect(parseNotificationSettings(JSON.stringify({ volume: "громко" })).volume).toBe(DEFAULT_NOTIFICATION_SETTINGS.volume);
  });
});
