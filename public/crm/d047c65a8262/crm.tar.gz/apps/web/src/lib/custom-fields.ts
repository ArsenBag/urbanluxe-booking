"use client";

import type {
  CreateCustomFieldInput,
  CustomFieldDto,
  CustomFieldEntity,
  CustomFieldValues,
  UpdateCustomFieldInput,
} from "@crm/shared";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

/** Все поля всех карточек: их немного, один запрос на всё приложение. */
export function useCustomFields(entity: CustomFieldEntity) {
  return useQuery({
    queryKey: queryKeys.customFields,
    queryFn: () => apiRequest<CustomFieldDto[]>("/custom-fields"),
    select: (fields) => fields.filter((field) => field.entity === entity),
  });
}

function useInvalidateFields() {
  const queryClient = useQueryClient();
  return () => queryClient.invalidateQueries({ queryKey: queryKeys.customFields });
}

export function useCreateCustomField() {
  const invalidate = useInvalidateFields();
  return useMutation({
    mutationFn: (input: CreateCustomFieldInput) => apiRequest<CustomFieldDto>("/custom-fields", { method: "POST", body: input }),
    onSuccess: invalidate,
  });
}

export function useUpdateCustomField() {
  const invalidate = useInvalidateFields();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: UpdateCustomFieldInput }) =>
      apiRequest<CustomFieldDto>(`/custom-fields/${id}`, { method: "PATCH", body: input }),
    onSuccess: invalidate,
  });
}

export function useDeleteCustomField() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => apiRequest<null>(`/custom-fields/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      // Значения удалённого поля стёрты и в карточках.
      void queryClient.invalidateQueries({ queryKey: queryKeys.customFields });
      void queryClient.invalidateQueries({ queryKey: queryKeys.contacts });
      void queryClient.invalidateQueries({ queryKey: queryKeys.deals });
    },
  });
}

export function useReorderCustomFields() {
  const invalidate = useInvalidateFields();
  return useMutation({
    mutationFn: (input: { entity: CustomFieldEntity; ids: string[] }) =>
      apiRequest<CustomFieldDto[]>("/custom-fields/reorder", { method: "POST", body: input }),
    onSettled: invalidate,
  });
}

const RECORD_PATHS: Record<CustomFieldEntity, string> = { CONTACT: "contacts", DEAL: "deals" };

/** Значения полей в карточке клиента или сделки. null — очистить поле. */
export function useUpdateCustomValues(entity: CustomFieldEntity, recordId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (values: Record<string, string | number | boolean | null>) =>
      apiRequest<CustomFieldValues>(`/${RECORD_PATHS[entity]}/${recordId}/custom-fields`, { method: "PATCH", body: { values } }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: entity === "CONTACT" ? queryKeys.contact(recordId) : queryKeys.deal(recordId) });
      void queryClient.invalidateQueries({ queryKey: entity === "CONTACT" ? queryKeys.contactActivity(recordId) : queryKeys.dealActivity(recordId) });
    },
  });
}
