import { describe, expect, it } from "vitest";
import {
  formatDayLabel,
  formatListTime,
  formatStay,
  parseDateKey,
  initials,
  isoToLocalDateTime,
  isOverdue,
  localDateTimeToIso,
  pluralize,
  tashkentDayKey,
} from "./format";

describe("pluralize", () => {
  it.each([
    [1, "ночь"],
    [2, "ночи"],
    [5, "ночей"],
    [11, "ночей"],
    [21, "ночь"],
    [22, "ночи"],
  ])("%i → %s", (count, expected) => {
    expect(pluralize(count, ["ночь", "ночи", "ночей"])).toBe(expected);
  });
});

describe("formatStay", () => {
  it("shows dates and nights", () => {
    expect(formatStay("2026-11-01", "2026-11-04")).toMatch(/3 ночи$/);
  });

  it("returns null when a date is missing", () => {
    expect(formatStay("2026-11-01", null)).toBeNull();
  });
});

describe("Tashkent datetime conversion", () => {
  it("round-trips a local datetime", () => {
    const iso = localDateTimeToIso("2026-10-31T10:00") as string;

    expect(iso).toBe("2026-10-31T10:00:00+05:00");
    expect(isoToLocalDateTime(new Date(iso).toISOString())).toBe("2026-10-31T10:00");
  });
});

describe("isOverdue", () => {
  it("flags past due dates only", () => {
    const now = new Date("2026-10-04T12:00:00Z");

    expect(isOverdue("2026-10-04T11:00:00Z", now)).toBe(true);
    expect(isOverdue("2026-10-04T13:00:00Z", now)).toBe(false);
    expect(isOverdue(null, now)).toBe(false);
  });
});

describe("chat time helpers", () => {
  // 4 октября 2026, 14:00 по Ташкенту.
  const now = new Date("2026-10-04T09:00:00Z");

  it("groups by Tashkent day, not UTC", () => {
    // 20:30 UTC 3 октября — это уже 01:30 4 октября в Ташкенте.
    expect(tashkentDayKey("2026-10-03T20:30:00Z")).toBe("2026-10-04");
  });

  it("labels today and yesterday", () => {
    expect(formatDayLabel("2026-10-04T03:00:00Z", now)).toBe("Сегодня");
    expect(formatDayLabel("2026-10-03T08:00:00Z", now)).toBe("Вчера");
    expect(formatDayLabel("2026-09-20T08:00:00Z", now)).toMatch(/20 сентября/);
  });

  it("shows time for today and date for older items in the list", () => {
    expect(formatListTime("2026-10-04T05:15:00Z", now)).toBe("10:15");
    expect(formatListTime("2026-10-01T05:15:00Z", now)).toMatch(/1 окт/);
  });

  it("builds initials", () => {
    expect(initials("Дилноза Каримова")).toBe("ДК");
    expect(initials("@guest")).toBe("G");
    expect(initials("")).toBe("?");
  });
});

describe("parseDateKey", () => {
  it("accepts real calendar dates", () => {
    expect(parseDateKey("2026-10-12")).toBe("2026-10-12");
    expect(parseDateKey("2028-02-29")).toBe("2028-02-29");
  });

  it("rejects impossible or malformed dates", () => {
    expect(parseDateKey("2026-02-30")).toBeNull();
    expect(parseDateKey("2026-99-99")).toBeNull();
    expect(parseDateKey("12.10.2026")).toBeNull();
    expect(parseDateKey(null)).toBeNull();
  });
});
