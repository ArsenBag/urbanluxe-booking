import { describe, expect, it } from "vitest";
import { ApiRequestError, apiRequest, formLevelError, isUnauthorized } from "./api";

describe("formLevelError", () => {
  it("hides the message when a shown field carries the error", () => {
    const error = new ApiRequestError("Проверьте данные", 400, { email: "Email уже занят" });

    expect(formLevelError(error, ["email"])).toBeNull();
  });

  it("shows the message when the error belongs to a field the form does not display", () => {
    const error = new ApiRequestError("Проверьте данные", 400, { role: "Неизвестная роль" });

    expect(formLevelError(error, ["email"])).toBe("Проверьте данные");
  });

  it("returns null without an error", () => {
    expect(formLevelError(null, ["email"])).toBeNull();
  });
});

describe("isUnauthorized", () => {
  it("detects 401 API errors only", () => {
    expect(isUnauthorized(new ApiRequestError("x", 401))).toBe(true);
    expect(isUnauthorized(new ApiRequestError("x", 403))).toBe(false);
    expect(isUnauthorized(new Error("x"))).toBe(false);
  });
});

describe("apiRequest with a file", () => {
  it("sends FormData as is, with the CSRF header and without a JSON content type", async () => {
    const calls: RequestInit[] = [];
    const originalFetch = globalThis.fetch;
    globalThis.fetch = async (_url: RequestInfo | URL, init?: RequestInit) => {
      calls.push(init ?? {});
      return new Response(JSON.stringify({ success: true, data: { id: "m1" }, error: null }));
    };
    try {
      const form = new FormData();
      form.append("caption", "Чек");

      await apiRequest("/conversations/c1/files", { method: "POST", body: form });

      expect(calls[0]?.body).toBe(form);
      expect(calls[0]?.headers).toEqual({ "x-requested-with": "crm-web" });
    } finally {
      globalThis.fetch = originalFetch;
    }
  });
});
