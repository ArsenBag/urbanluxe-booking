"use client";

import type { ActivityDto, CreateDealInput, DealDto, MoveDealInput, UpdateDealInput } from "@crm/shared";
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

/** Автоперенос по датам брони (08:00, 19:00, 12:00) двигает карточки сам — доска перечитывается без перезагрузки. */
const BOARD_POLL_MS = 60_000;

/** Канбан воронки; filters — серверные фильтры (dealBoardQuery). При смене фильтров старая доска видна до ответа. */
export function useBoard(pipelineId: string | undefined, filters: Record<string, string> = {}) {
  return useQuery({
    queryKey: queryKeys.board(pipelineId ?? "", filters),
    queryFn: () => apiRequest<DealDto[]>("/deals", { query: { pipelineId, ...filters } }),
    enabled: Boolean(pipelineId),
    placeholderData: keepPreviousData,
    refetchInterval: BOARD_POLL_MS,
  });
}

export function useDeal(id: string) {
  return useQuery({ queryKey: queryKeys.deal(id), queryFn: () => apiRequest<DealDto>(`/deals/${id}`) });
}

export function useContactDeals(contactId: string) {
  return useQuery({
    queryKey: queryKeys.contactDeals(contactId),
    queryFn: () => apiRequest<DealDto[]>(`/contacts/${contactId}/deals`),
    // В панели диалога id клиента пуст, пока диалог загружается.
    enabled: Boolean(contactId),
  });
}

export function useDealActivity(id: string) {
  return useQuery({ queryKey: queryKeys.dealActivity(id), queryFn: () => apiRequest<ActivityDto[]>(`/deals/${id}/activity`) });
}

/** Возвращает промис: мутация завершится только после перечитывания данных, без мигания старого состояния. */
function useInvalidateDeals() {
  const queryClient = useQueryClient();
  return () =>
    Promise.all([
      queryClient.invalidateQueries({ queryKey: queryKeys.deals }),
      queryClient.invalidateQueries({ queryKey: queryKeys.contacts }),
    ]);
}

export type DealFormInput = Partial<Omit<CreateDealInput, "pipelineId" | "contactId">>;

export function useCreateDeal() {
  const invalidate = useInvalidateDeals();
  return useMutation({
    mutationFn: (input: DealFormInput & { pipelineId: string; contactId: string }) =>
      apiRequest<DealDto>("/deals", { method: "POST", body: input }),
    onSuccess: invalidate,
  });
}

export function useUpdateDeal(id: string) {
  const invalidate = useInvalidateDeals();
  return useMutation({
    mutationFn: (input: UpdateDealInput) => apiRequest<DealDto>(`/deals/${id}`, { method: "PATCH", body: input }),
    onSuccess: invalidate,
  });
}

export function useMoveDeal() {
  const invalidate = useInvalidateDeals();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: Partial<MoveDealInput> & { stageId: string } }) =>
      apiRequest<DealDto>(`/deals/${id}/move`, { method: "POST", body: input }),
    // И при успехе, и при ошибке перечитываем доску: при ошибке это откатывает карточку на место.
    onSettled: invalidate,
  });
}

export function useDeleteDeal() {
  const invalidate = useInvalidateDeals();
  return useMutation({
    mutationFn: (id: string) => apiRequest<null>(`/deals/${id}`, { method: "DELETE" }),
    onSuccess: invalidate,
  });
}
