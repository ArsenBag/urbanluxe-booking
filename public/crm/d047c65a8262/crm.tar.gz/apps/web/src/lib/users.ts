"use client";

import type { CreateUserInput, UpdateUserInput, UserDto, UserOptionDto } from "@crm/shared";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

const USERS_KEY = ["users"] as const;

export function useUsers() {
  return useQuery({ queryKey: USERS_KEY, queryFn: () => apiRequest<UserDto[]>("/users") });
}

export function useCreateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: CreateUserInput) => apiRequest<UserDto>("/users", { method: "POST", body: input }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: USERS_KEY }),
  });
}

export function useUpdateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: UpdateUserInput }) =>
      apiRequest<UserDto>(`/users/${id}`, { method: "PATCH", body: input }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: USERS_KEY }),
  });
}

/** Активные сотрудники для выпадающих списков «ответственный», «исполнитель». */
export function useUserOptions() {
  return useQuery({
    queryKey: queryKeys.userOptions,
    queryFn: () => apiRequest<UserOptionDto[]>("/users/options"),
    staleTime: 5 * 60_000,
  });
}
