"use client";

import type { BookingsReportDto, FunnelReportDto, InquiriesReportDto, ReportPeriod, TeamReportDto } from "@crm/shared";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { apiRequest } from "./api";

/** Отчёт — не живая лента: перечитываем при смене периода, а не по таймеру. */
const REPORT_STALE_MS = 60_000;

function useReport<T>(name: string, period: ReportPeriod, extra: Record<string, string | undefined> = {}) {
  return useQuery({
    queryKey: ["reports", name, period.from, period.to, extra],
    queryFn: () => apiRequest<T>(`/reports/${name}`, { query: { ...period, ...extra } }),
    // При смене периода старые цифры остаются на экране, пока грузятся новые.
    placeholderData: keepPreviousData,
    staleTime: REPORT_STALE_MS,
  });
}

export const useInquiriesReport = (period: ReportPeriod) => useReport<InquiriesReportDto>("inquiries", period);
export const useBookingsReport = (period: ReportPeriod) => useReport<BookingsReportDto>("bookings", period);
export const useTeamReport = (period: ReportPeriod) => useReport<TeamReportDto>("team", period);
export const useFunnelReport = (period: ReportPeriod, pipelineId: string | undefined) =>
  useReport<FunnelReportDto>("funnel", period, { pipelineId });
