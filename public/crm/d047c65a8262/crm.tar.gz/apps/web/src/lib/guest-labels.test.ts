import { describe, expect, it } from "vitest";
import { staysLabel } from "./guest-labels";

describe("staysLabel", () => {
  it("marks a guest without past stays as a first-timer", () => {
    expect(staysLabel(0)).toBe("Впервые");
  });

  it.each([
    [1, "1 проживание"],
    [3, "3 проживания"],
    [5, "5 проживаний"],
    [21, "21 проживание"],
  ])("counts %i stays in Russian", (stays, expected) => {
    expect(staysLabel(stays)).toBe(expected);
  });
});
