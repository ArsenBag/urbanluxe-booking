import { describe, expect, it } from "vitest";
import { airbnbReservation, bookingChannel, bookingGuestName, paidShare } from "./booking-channels";

const AIRBNB_NOTES =
  "Reservation URL: https://www.airbnb.com/hosting/reservations/details/HMJAK9FFXD Phone Number (Last 4 Digits): 0509Reserved";

type BookingFields = Parameters<typeof bookingGuestName>[0] & Parameters<typeof paidShare>[0];

const booking = (patch: Partial<BookingFields> = {}): BookingFields => ({
  origin: null,
  notes: null,
  amount: null,
  prepayment: null,
  contact: null,
  guestName: null,
  ...patch,
});

describe("bookingChannel", () => {
  it.each([
    ["Booking.com", "BOOKING"],
    ["booking.com", "BOOKING"],
    ["Airbnb", "AIRBNB"],
    ["YandexTravel", "YANDEX"],
    ["Яндекс Путешествия", "YANDEX"],
    ["EmergingTravel", "EMERGING"],
    ["emergingtravel.com", "EMERGING"],
    ["Sutochno.ru", "SUTOCHNO"],
    ["Bronevik.com", "BRONEVIK"],
    ["Корзина", "BASKET"],
    ["basket", "BASKET"],
  ])("recognizes %s as %s", (origin, key) => {
    expect(bookingChannel(booking({ origin }))?.key).toBe(key);
  });

  it("finds Airbnb by the reservation link in the notes when RealtyCalendar sent no platform", () => {
    expect(bookingChannel(booking({ notes: AIRBNB_NOTES }))?.key).toBe("AIRBNB");
  });

  it("shows an unknown platform by its first letter and a manual booking without a badge", () => {
    expect(bookingChannel(booking({ origin: "Островок Партнёр" }))?.key).toBe("EMERGING");
    expect(bookingChannel(booking({ origin: "Telegram" }))).toMatchObject({ key: "OTHER", letter: "T", label: "Telegram" });
    expect(bookingChannel(booking({ origin: "Direct booking" }))?.key).toBe("OTHER");
    expect(bookingChannel(booking({ origin: "Корзина", notes: AIRBNB_NOTES }))?.key).toBe("AIRBNB");
    expect(bookingChannel(booking())).toBeNull();
  });
});

describe("airbnbReservation", () => {
  it("reads the reservation code, link and last phone digits from the iCal note", () => {
    expect(airbnbReservation(AIRBNB_NOTES)).toEqual({
      code: "HMJAK9FFXD",
      url: "https://www.airbnb.com/hosting/reservations/details/HMJAK9FFXD",
      phoneLast4: "0509",
      rest: "",
    });
  });

  it("keeps what staff wrote next to the Airbnb text", () => {
    expect(airbnbReservation(`${AIRBNB_NOTES} Поздний заезд`)?.rest).toBe("Поздний заезд");
  });

  it("ignores notes without an Airbnb reservation link, including lookalike hosts", () => {
    for (const host of ["evil.example", "airbnb.com.evil.org", "www.airbnb.com@evil.org", "evil-airbnb.com", "airbnb.tk"]) {
      expect(airbnbReservation(`https://${host}/hosting/reservations/details/HMJAK9FFXD`)).toBeNull();
    }
    expect(airbnbReservation(null)).toBeNull();
  });

  it("cleans the iCal text wherever it stands and does not swallow a word glued to the code", () => {
    const glued = "Reservation URL: https://www.airbnb.com/hosting/reservations/details/HMJAK9FFXDPhone Number (Last 4 Digits): ****Reserved";
    expect(airbnbReservation(glued)).toMatchObject({ code: "HMJAK9FFXD", phoneLast4: null, rest: "" });
    expect(airbnbReservation(`Поздний заезд. ${AIRBNB_NOTES}`)?.rest).toBe("Поздний заезд.");
  });
});

describe("bookingGuestName", () => {
  it("prefers the client, then the guest, then the Airbnb code, then the platform", () => {
    expect(bookingGuestName(booking({ contact: { id: "c", name: "Азиз" }, guestName: "Aziz" }))).toBe("Азиз");
    expect(bookingGuestName(booking({ guestName: "Aziz" }))).toBe("Aziz");
    expect(bookingGuestName(booking({ notes: AIRBNB_NOTES }))).toBe("Airbnb HMJAK9FFXD");
    expect(bookingGuestName(booking({ origin: "Booking.com" }))).toBe("Booking.com");
    expect(bookingGuestName(booking())).toBeNull();
  });
});

describe("paidShare", () => {
  it("reads payment like RealtyCalendar: prepayment of the amount", () => {
    expect(paidShare(booking({ amount: "200", prepayment: "50" }))).toBe(0.25);
    expect(paidShare(booking({ amount: "200", prepayment: "300" }))).toBe(1);
    expect(paidShare(booking({ amount: "200" }))).toBe(0);
  });

  it("counts Airbnb as paid: Airbnb collects the money itself", () => {
    expect(paidShare(booking({ origin: "Airbnb", amount: "310" }))).toBe(1);
    expect(paidShare(booking({ notes: AIRBNB_NOTES }))).toBe(1);
  });

  it("draws no payment strip without an amount or with unreadable money", () => {
    expect(paidShare(booking({ prepayment: "50" }))).toBeNull();
    expect(paidShare(booking({ amount: "0" }))).toBeNull();
    expect(paidShare(booking({ amount: "200", prepayment: "abc" }))).toBeNull();
  });
});
