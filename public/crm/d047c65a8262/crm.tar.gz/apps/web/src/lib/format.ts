import { formatPhone, nightsBetween } from "@crm/shared";

const LOCALE = "ru-RU";
/** Время показываем по Ташкенту независимо от часового пояса компьютера. */
export const TIME_ZONE = "Asia/Tashkent";

const dateFormatter = new Intl.DateTimeFormat(LOCALE, { day: "numeric", month: "short", timeZone: "UTC" });
const dateTimeFormatter = new Intl.DateTimeFormat(LOCALE, {
  day: "numeric",
  month: "short",
  hour: "2-digit",
  minute: "2-digit",
  timeZone: TIME_ZONE,
});

const DATE_KEY = /^\d{4}-\d{2}-\d{2}$/;

/** Дата YYYY-MM-DD из адреса или null: 2026-02-30 и 2026-99-99 не пройдут. */
export function parseDateKey(value: string | null): string | null {
  if (!value || !DATE_KEY.test(value)) return null;
  const date = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().startsWith(value) ? value : null;
}

/** Дата без времени (YYYY-MM-DD): «12 окт.». */
export function formatDate(value: string): string {
  return dateFormatter.format(new Date(`${value}T00:00:00Z`));
}

export function formatDateTime(value: string): string {
  return dateTimeFormatter.format(new Date(value));
}

export function formatStay(checkIn: string | null, checkOut: string | null): string | null {
  if (!checkIn || !checkOut) return null;
  const nights = nightsBetween(checkIn, checkOut);
  return `${formatDate(checkIn)} – ${formatDate(checkOut)} · ${nights} ${pluralize(nights, ["ночь", "ночи", "ночей"])}`;
}

export function formatMoney(amount: string | null, currency: string): string | null {
  if (amount === null) return null;
  return new Intl.NumberFormat(LOCALE, { style: "currency", currency, maximumFractionDigits: 2 }).format(Number(amount));
}

export function formatPhones(phones: string[]): string {
  return phones.map(formatPhone).join(", ");
}

export function isOverdue(dueAt: string | null, now = new Date()): boolean {
  return dueAt !== null && new Date(dueAt) < now;
}

/** Русское склонение: 1 ночь, 2 ночи, 5 ночей. */
export function pluralize(count: number, [one, few, many]: [string, string, string]): string {
  const mod10 = count % 10;
  const mod100 = count % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return few;
  return many;
}

/** Значение для <input type="datetime-local"> в часовом поясе Ташкента → ISO со смещением +05:00. */
export function localDateTimeToIso(value: string): string | null {
  return value ? `${value}:00+05:00` : null;
}

export function isoToLocalDateTime(value: string | null): string {
  if (!value) return "";
  // Ташкент живёт в UTC+5 без перехода на летнее время.
  const TASHKENT_OFFSET_MS = 5 * 3_600_000;
  return new Date(new Date(value).getTime() + TASHKENT_OFFSET_MS).toISOString().slice(0, 16);
}

const timeFormatter = new Intl.DateTimeFormat(LOCALE, { hour: "2-digit", minute: "2-digit", timeZone: TIME_ZONE });
const dayFormatter = new Intl.DateTimeFormat(LOCALE, { day: "numeric", month: "long", timeZone: TIME_ZONE });
const shortDayFormatter = new Intl.DateTimeFormat(LOCALE, { day: "numeric", month: "short", timeZone: TIME_ZONE });
const dayKeyFormatter = new Intl.DateTimeFormat("en-CA", { timeZone: TIME_ZONE });

/** Календарный день по Ташкенту (YYYY-MM-DD) — для группировки сообщений. */
export function tashkentDayKey(value: string | Date): string {
  return dayKeyFormatter.format(new Date(value));
}

export function formatTime(value: string): string {
  return timeFormatter.format(new Date(value));
}

/** Разделитель дней в чате: «Сегодня», «Вчера» или «12 октября». */
export function formatDayLabel(value: string, now = new Date()): string {
  const day = tashkentDayKey(value);
  if (day === tashkentDayKey(now)) return "Сегодня";
  const yesterday = new Date(now.getTime() - 86_400_000);
  if (day === tashkentDayKey(yesterday)) return "Вчера";
  return dayFormatter.format(new Date(value));
}

/** Время в списке диалогов: сегодня — часы, раньше — дата. */
export function formatListTime(value: string, now = new Date()): string {
  return tashkentDayKey(value) === tashkentDayKey(now) ? formatTime(value) : shortDayFormatter.format(new Date(value));
}

/** Инициалы для аватара: «Дилноза Каримова» → «ДК». */
export function initials(name: string): string {
  const letters = name
    .replace(/^[@+]/, "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0]?.toUpperCase() ?? "");
  return letters.join("") || "?";
}
