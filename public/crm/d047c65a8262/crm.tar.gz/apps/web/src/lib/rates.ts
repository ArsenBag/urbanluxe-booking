"use client";

import type { RatesDto, RateUpdateRequest, RateUpdateResultDto } from "@crm/shared";
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

/** Цены окна шахматки. Как и брони, при прокрутке прежние видны, пока не придут новые. */
export function useRates(from: string, to: string) {
  return useQuery({
    queryKey: [...queryKeys.rates, from, to],
    queryFn: () => apiRequest<RatesDto>("/rates", { query: { from, to } }),
    placeholderData: keepPreviousData,
  });
}

export function useUpdateRates() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: RateUpdateRequest) => apiRequest<RateUpdateResultDto>("/rates", { method: "PUT", body: input }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.rates }),
  });
}
