"use client";

import type { CreateStageInput, PipelineDto, StageDto, UpdateStageInput } from "@crm/shared";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

export function usePipelines() {
  return useQuery({ queryKey: queryKeys.pipelines, queryFn: () => apiRequest<PipelineDto[]>("/pipelines") });
}

/** Изменения настроек воронок перечитывают воронки и доску сделок, которая от них зависит. */
function usePipelineMutation<TInput, TResult>(request: (input: TInput) => Promise<TResult>) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: request,
    onSuccess: () =>
      Promise.all([
        queryClient.invalidateQueries({ queryKey: queryKeys.pipelines }),
        queryClient.invalidateQueries({ queryKey: queryKeys.deals }),
      ]),
  });
}

export const useCreatePipeline = () =>
  usePipelineMutation((name: string) => apiRequest<PipelineDto>("/pipelines", { method: "POST", body: { name } }));

export const useRenamePipeline = () =>
  usePipelineMutation(({ id, name }: { id: string; name: string }) =>
    apiRequest<PipelineDto>(`/pipelines/${id}`, { method: "PATCH", body: { name } }),
  );

export const useDeletePipeline = () =>
  usePipelineMutation((id: string) => apiRequest<null>(`/pipelines/${id}`, { method: "DELETE" }));

export const useAddStage = () =>
  usePipelineMutation(({ pipelineId, input }: { pipelineId: string; input: Partial<CreateStageInput> & { name: string } }) =>
    apiRequest<StageDto>(`/pipelines/${pipelineId}/stages`, { method: "POST", body: input }),
  );

export const useUpdateStage = () =>
  usePipelineMutation(({ id, input }: { id: string; input: UpdateStageInput }) =>
    apiRequest<StageDto>(`/stages/${id}`, { method: "PATCH", body: input }),
  );

export const useDeleteStage = () =>
  usePipelineMutation((id: string) => apiRequest<null>(`/stages/${id}`, { method: "DELETE" }));

export const useReorderStages = () =>
  usePipelineMutation(({ pipelineId, stageIds }: { pipelineId: string; stageIds: string[] }) =>
    apiRequest<PipelineDto>(`/pipelines/${pipelineId}/stages/order`, { method: "PUT", body: { stageIds } }),
  );

/** Поиск этапа по id среди всех воронок (для подписей на карточках сделок). */
export function useStageLookup(): (stageId: string) => StageDto | undefined {
  const pipelines = usePipelines();
  const stages = new Map((pipelines.data ?? []).flatMap((pipeline) => pipeline.stages.map((stage) => [stage.id, stage] as const)));
  return (stageId) => stages.get(stageId);
}
