import { describe, expect, it } from "vitest";
import type { BookingNotification, MessageNotification } from "@crm/shared";
import { batchSound, createNotificationClaims, notificationContent, pushToasts } from "./notification-feed";

const message: MessageNotification = {
  kind: "message",
  id: "m1",
  at: "2026-10-06T10:00:00.000Z",
  conversationId: "c1",
  contactName: "Азиз",
  channelType: "WHATSAPP",
  preview: "Есть студия на выходные?",
  blacklisted: false,
};

const booking: BookingNotification = {
  kind: "booking",
  id: "b1",
  at: "2026-10-06T10:00:00.000Z",
  status: "BOOKED",
  propertyTitle: "U-51",
  guestName: "Гость",
  checkIn: "2026-10-12",
  checkOut: "2026-10-15",
  origin: "Booking.com",
  blacklisted: false,
};

function memoryStorage() {
  const values = new Map<string, string>();
  return {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => void values.set(key, value),
  };
}

describe("notificationContent", () => {
  it("opens the conversation of a new message", () => {
    expect(notificationContent(message)).toEqual({
      id: "m1",
      kind: "message",
      title: "Азиз · WhatsApp",
      body: "Есть студия на выходные?",
      summary: "Новое сообщение в WhatsApp",
      tag: "c1",
      href: "/inbox?c=c1",
      blacklisted: false,
    });
  });

  it("warns that a blacklisted guest is writing, without the name on a system notification", () => {
    const content = notificationContent({ ...message, blacklisted: true });

    expect(content).toMatchObject({
      title: "Чёрный список · Азиз · WhatsApp",
      summary: "Новое сообщение в WhatsApp — гость из чёрного списка",
      blacklisted: true,
    });
  });

  it("warns about a booking by a blacklisted guest", () => {
    expect(notificationContent({ ...booking, blacklisted: true })).toMatchObject({
      title: "Чёрный список · Новая бронь",
      summary: "Новая бронь — гость из чёрного списка",
      blacklisted: true,
    });
  });

  it("describes a new booking and opens its arrival day", () => {
    expect(notificationContent(booking)).toMatchObject({
      title: "Новая бронь",
      body: "U-51 · 12 окт. – 15 окт. · 3 ночи · Booking.com · Гость",
      href: "/bookings?date=2026-10-12",
    });
  });

  it("names a booking request and skips missing details", () => {
    const request = { ...booking, status: "REQUEST" as const, propertyTitle: null, origin: null, guestName: null };
    expect(notificationContent(request)).toMatchObject({
      title: "Новая заявка на бронь",
      body: "12 окт. – 15 окт. · 3 ночи",
    });
  });
});

describe("batchSound", () => {
  const all = { messageSound: true, bookingSound: true };

  it("plays the booking chime when a batch has a booking", () => {
    expect(batchSound([{ kind: "message" }, { kind: "booking" }], all)).toBe("booking");
  });

  it("falls back to the message sound when the booking sound is off", () => {
    expect(batchSound([{ kind: "message" }, { kind: "booking" }], { ...all, bookingSound: false })).toBe("message");
  });

  it("stays silent when the sounds are off", () => {
    expect(batchSound([{ kind: "message" }], { ...all, messageSound: false })).toBeNull();
    expect(batchSound([], all)).toBeNull();
  });
});

describe("createNotificationClaims", () => {
  it("lets an event through once per tab", () => {
    const claim = createNotificationClaims(null);
    expect(claim("e1")).toBe(true);
    expect(claim("e1")).toBe(false);
  });

  it("does not repeat an event another tab already showed", () => {
    const storage = memoryStorage();
    const firstTab = createNotificationClaims(storage);
    const secondTab = createNotificationClaims(storage);
    expect(firstTab("e1")).toBe(true);
    expect(secondTab("e1")).toBe(false);
    expect(secondTab("e2")).toBe(true);
  });

  it("survives corrupted storage", () => {
    const storage = memoryStorage();
    storage.setItem("crm:notified", "{not json");
    expect(createNotificationClaims(storage)("e1")).toBe(true);
  });
});

describe("pushToasts", () => {
  const toast = (id: string, kind: "message" | "booking") => ({ ...notificationContent(kind === "message" ? message : booking), id });

  it("keeps the newest toasts within the limit", () => {
    const result = pushToasts([toast("1", "message"), toast("2", "message")], [toast("3", "message")], 2);
    expect(result.map((item) => item.id)).toEqual(["2", "3"]);
  });

  it("evicts messages before a booking", () => {
    const result = pushToasts([toast("b", "booking"), toast("1", "message")], [toast("2", "message"), toast("3", "message")], 3);
    expect(result.map((item) => item.id)).toEqual(["b", "2", "3"]);
  });

  it("keeps a blacklisted guest's toast longest, even over a booking", () => {
    const listed = { ...toast("x", "message"), blacklisted: true };
    const result = pushToasts([listed, toast("b", "booking")], [toast("c", "booking")], 2);
    expect(result.map((item) => item.id)).toEqual(["x", "c"]);
  });
});
