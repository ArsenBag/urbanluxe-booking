import { describe, expect, it } from "vitest";
import { EMPTY_DEAL_FILTERS, activeDealFilterCount, dealBoardQuery, dealFiltersToParams, parseDealFilters } from "./deal-filters";

const USER = "6ec0bd7f-11c0-43da-975e-2a8ad9ebae0b";
const STAGE = "1b4e28ba-2fa1-41d2-883f-0016d3cca427";

describe("parseDealFilters", () => {
  it("reads filters from the page address", () => {
    const params = new URLSearchParams(
      `createdFrom=2026-10-01&createdTo=2026-10-31&closedFrom=2026-09-01&stages=${STAGE}&owners=${USER},none&sources=TELEGRAM,BOOKING`,
    );
    expect(parseDealFilters(params)).toEqual({
      createdFrom: "2026-10-01",
      createdTo: "2026-10-31",
      closedFrom: "2026-09-01",
      closedTo: "",
      checkInFrom: "",
      checkInTo: "",
      search: "",
      stageIds: [STAGE],
      ownerIds: [USER, "none"],
      sources: ["TELEGRAM", "BOOKING"],
    });
  });

  it("drops broken dates, unknown sources and junk ids", () => {
    const params = new URLSearchParams("createdFrom=2026-02-30&sources=TELEGRAM,PIGEON&owners=<script>&stages=x");
    expect(parseDealFilters(params)).toEqual({ ...EMPTY_DEAL_FILTERS, sources: ["TELEGRAM"] });
  });

  it("follows the server rules: no ancient dates, no inverted range, no duplicates, at most 50 items", () => {
    const owners = Array.from({ length: 60 }, (_, index) => `6ec0bd7f-11c0-43da-975e-${String(index).padStart(12, "0")}`);
    const params = new URLSearchParams(
      `createdFrom=0001-01-01&closedFrom=2026-10-10&closedTo=2026-10-01&sources=PHONE,PHONE&owners=${owners.join(",")}`,
    );
    const filters = parseDealFilters(params);
    expect(filters.createdFrom).toBe("");
    expect(filters.closedFrom).toBe("2026-10-10");
    expect(filters.closedTo).toBe("");
    expect(filters.sources).toEqual(["PHONE"]);
    expect(filters.ownerIds).toHaveLength(50);
  });
});

describe("check-in and name filters", () => {
  it("read the check-in range and the search text from the address", () => {
    const filters = parseDealFilters(new URLSearchParams("checkInFrom=2026-10-10&checkInTo=2026-10-05&q=%20Анна%20"));
    expect(filters.checkInFrom).toBe("2026-10-10");
    expect(filters.checkInTo).toBe("");
    expect(filters.search).toBe("Анна");
  });

  it("send them to the server and count them as filters", () => {
    const filters = { ...EMPTY_DEAL_FILTERS, checkInFrom: "2026-10-10", search: "Анна" };
    expect(dealBoardQuery(filters)).toEqual({ checkInFrom: "2026-10-10", search: "Анна" });
    expect(activeDealFilterCount(filters)).toBe(2);
    expect(dealFiltersToParams(filters, new URLSearchParams()).toString()).toBe("checkInFrom=2026-10-10&q=%D0%90%D0%BD%D0%BD%D0%B0");
  });

  it("cut an overlong search to the server limit", () => {
    expect(parseDealFilters(new URLSearchParams(`q=${"я".repeat(150)}`)).search).toHaveLength(100);
  });
});

describe("dealFiltersToParams", () => {
  it("writes only the filters that are set and keeps other parameters", () => {
    const base = new URLSearchParams("pipeline=abc&createdFrom=2026-01-01");
    const params = dealFiltersToParams({ ...EMPTY_DEAL_FILTERS, ownerIds: [USER, "none"], closedTo: "2026-10-31" }, base);
    expect(params.toString()).toBe(`pipeline=abc&closedTo=2026-10-31&owners=${USER}%2Cnone`);
  });

  it("round-trips through the address", () => {
    const filters = { ...EMPTY_DEAL_FILTERS, createdFrom: "2026-10-01", stageIds: [STAGE], sources: ["WHATSAPP" as const] };
    expect(parseDealFilters(dealFiltersToParams(filters, new URLSearchParams()))).toEqual(filters);
  });
});

describe("dealBoardQuery", () => {
  it("sends server-side filters as comma lists and leaves stages to the board", () => {
    expect(dealBoardQuery({ ...EMPTY_DEAL_FILTERS, stageIds: [STAGE], ownerIds: [USER, "none"], createdTo: "2026-10-31" })).toEqual({
      createdTo: "2026-10-31",
      ownerIds: `${USER},none`,
    });
    expect(dealBoardQuery(EMPTY_DEAL_FILTERS)).toEqual({});
  });
});

describe("activeDealFilterCount", () => {
  it("counts a date range once", () => {
    expect(activeDealFilterCount(EMPTY_DEAL_FILTERS)).toBe(0);
    expect(activeDealFilterCount({ ...EMPTY_DEAL_FILTERS, createdFrom: "2026-10-01", createdTo: "2026-10-31", sources: ["PHONE"] })).toBe(2);
  });
});
