import { describe, expect, it } from "vitest";
import { formatDuration, formatPercent, formatShare, matchPreset, presetPeriod } from "./report-period";

const TODAY = "2026-10-06";

describe("presetPeriod", () => {
  it("counts recent days including today", () => {
    expect(presetPeriod("last7", TODAY)).toEqual({ from: "2026-09-30", to: "2026-10-06" });
    expect(presetPeriod("last30", TODAY)).toEqual({ from: "2026-09-07", to: "2026-10-06" });
  });

  it("takes calendar months", () => {
    expect(presetPeriod("thisMonth", TODAY)).toEqual({ from: "2026-10-01", to: "2026-10-06" });
    expect(presetPeriod("lastMonth", TODAY)).toEqual({ from: "2026-09-01", to: "2026-09-30" });
    expect(presetPeriod("lastMonth", "2026-01-15")).toEqual({ from: "2025-12-01", to: "2025-12-31" });
    expect(presetPeriod("lastMonth", "2028-03-31")).toEqual({ from: "2028-02-01", to: "2028-02-29" });
  });

  it("looks ahead for future occupancy", () => {
    expect(presetPeriod("next30", TODAY)).toEqual({ from: "2026-10-06", to: "2026-11-04" });
  });
});

describe("matchPreset", () => {
  it("recognises a preset period and falls back to custom", () => {
    expect(matchPreset({ from: "2026-10-01", to: "2026-10-06" }, TODAY)).toBe("thisMonth");
    expect(matchPreset({ from: "2026-10-02", to: "2026-10-06" }, TODAY)).toBe("custom");
  });
});

describe("formatPercent", () => {
  it("rounds a share to whole percent", () => {
    expect(formatPercent(0.456)).toBe("46 %");
    expect(formatPercent(0)).toBe("0 %");
    expect(formatPercent(null)).toBe("—");
  });
});

describe("formatShare", () => {
  it("shows a part of a whole as percent, empty whole as a dash", () => {
    expect(formatShare(1, 4)).toBe("25 %");
    expect(formatShare(0, 0)).toBe("—");
  });
});

describe("formatDuration", () => {
  it("reads minutes as minutes, hours or days", () => {
    expect(formatDuration(null)).toBe("—");
    expect(formatDuration(0)).toBe("меньше минуты");
    expect(formatDuration(12)).toBe("12 мин");
    expect(formatDuration(60)).toBe("1 ч");
    expect(formatDuration(95)).toBe("1 ч 35 мин");
    expect(formatDuration(60 * 26)).toBe("1 д 2 ч");
  });
});
