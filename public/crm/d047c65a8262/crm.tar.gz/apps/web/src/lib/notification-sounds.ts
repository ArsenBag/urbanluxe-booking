"use client";

export type NotificationSound = "message" | "booking";

interface Tone {
  frequency: number;
  /** Секунды от начала звука. */
  start: number;
  duration: number;
}

/** Сообщение — короткий двойной сигнал, бронь — мелодичный аккорд до-ми-соль. */
const TONES: Record<NotificationSound, Tone[]> = {
  message: [
    { frequency: 880, start: 0, duration: 0.12 },
    { frequency: 1320, start: 0.1, duration: 0.2 },
  ],
  booking: [
    { frequency: 1046.5, start: 0, duration: 0.4 },
    { frequency: 1318.5, start: 0.14, duration: 0.4 },
    { frequency: 1568, start: 0.28, duration: 0.7 },
  ],
};

/** Пиковая громкость при ползунке на максимуме: синус на полной амплитуде режет слух. */
const PEAK_GAIN = 0.35;
const SILENT_GAIN = 0.0001;
const ATTACK_SECONDS = 0.01;

let context: AudioContext | null = null;

function audioContext(): AudioContext | null {
  if (typeof window === "undefined" || typeof window.AudioContext === "undefined") return null;
  context ??= new window.AudioContext();
  return context;
}

/**
 * Браузер разрешает звук только после действия пользователя на странице.
 * Вызывается при первом клике или нажатии клавиши — дальше звук играет и в фоновой вкладке.
 */
export async function unlockAudio(): Promise<void> {
  await audioContext()?.resume();
}

/** volume — 0–1 из настроек; квадрат даёт ползунок, который на слух меняется равномерно. */
export function playNotificationSound(sound: NotificationSound, volume: number): void {
  const ctx = audioContext();
  // Пока браузер не разрешил звук, сигналы не копим: после первого клика они зазвучали бы разом.
  if (!ctx || ctx.state !== "running" || volume <= 0) return;
  const peak = PEAK_GAIN * volume * volume;
  const startAt = ctx.currentTime;
  for (const tone of TONES[sound]) {
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.type = "sine";
    oscillator.frequency.value = tone.frequency;
    const toneStart = startAt + tone.start;
    gain.gain.setValueAtTime(SILENT_GAIN, toneStart);
    gain.gain.exponentialRampToValueAtTime(peak, toneStart + ATTACK_SECONDS);
    gain.gain.exponentialRampToValueAtTime(SILENT_GAIN, toneStart + tone.duration);
    oscillator.connect(gain).connect(ctx.destination);
    oscillator.start(toneStart);
    oscillator.stop(toneStart + tone.duration);
  }
}
