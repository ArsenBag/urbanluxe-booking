"use client";

import { useSyncExternalStore } from "react";

/** Настройки уведомлений этого компьютера: громкость своя у каждого рабочего места. */
export interface NotificationSettings {
  /** Громкость звука, 0–1. */
  volume: number;
  messageSound: boolean;
  bookingSound: boolean;
  /** Уведомления macOS/Windows, когда вкладка CRM не на экране. */
  systemNotifications: boolean;
  /** Имя и текст в системном уведомлении. Выключают там, где экран видят посторонние. */
  systemNotificationText: boolean;
}

export const DEFAULT_NOTIFICATION_SETTINGS: NotificationSettings = {
  volume: 0.7,
  messageSound: true,
  bookingSound: true,
  systemNotifications: true,
  systemNotificationText: true,
};

const STORAGE_KEY = "crm:notification-settings";

const clampVolume = (value: unknown): number =>
  typeof value === "number" && Number.isFinite(value) ? Math.min(1, Math.max(0, value)) : DEFAULT_NOTIFICATION_SETTINGS.volume;

const flag = (value: unknown, fallback: boolean): boolean => (typeof value === "boolean" ? value : fallback);

/** Сохранённые настройки; повреждённые или старые поля заменяются значениями по умолчанию. */
export function parseNotificationSettings(raw: string | null): NotificationSettings {
  if (!raw) return DEFAULT_NOTIFICATION_SETTINGS;
  let value: Record<string, unknown>;
  try {
    const parsed: unknown = JSON.parse(raw);
    if (typeof parsed !== "object" || parsed === null) return DEFAULT_NOTIFICATION_SETTINGS;
    value = parsed as Record<string, unknown>;
  } catch {
    return DEFAULT_NOTIFICATION_SETTINGS;
  }
  return {
    volume: clampVolume(value.volume),
    messageSound: flag(value.messageSound, DEFAULT_NOTIFICATION_SETTINGS.messageSound),
    bookingSound: flag(value.bookingSound, DEFAULT_NOTIFICATION_SETTINGS.bookingSound),
    systemNotifications: flag(value.systemNotifications, DEFAULT_NOTIFICATION_SETTINGS.systemNotifications),
    systemNotificationText: flag(value.systemNotificationText, DEFAULT_NOTIFICATION_SETTINGS.systemNotificationText),
  };
}

const listeners = new Set<() => void>();
/** Запасное хранение, если браузер не даёт писать в localStorage (приватный режим). */
let memoryRaw: string | null = null;
let cached: { raw: string | null; value: NotificationSettings } | null = null;

function readRaw(): string | null {
  try {
    return window.localStorage.getItem(STORAGE_KEY) ?? memoryRaw;
  } catch {
    return memoryRaw;
  }
}

function readSettings(): NotificationSettings {
  const raw = readRaw();
  if (cached?.raw !== raw) cached = { raw, value: parseNotificationSettings(raw) };
  return cached.value;
}

export function saveNotificationSettings(next: NotificationSettings): void {
  const raw = JSON.stringify(next);
  memoryRaw = raw;
  try {
    window.localStorage.setItem(STORAGE_KEY, raw);
  } catch {
    // Остаётся memoryRaw: настройки действуют до перезагрузки страницы.
  }
  for (const listener of listeners) listener();
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  // Настройки поменяли в другой вкладке CRM.
  const onStorage = (event: StorageEvent) => {
    if (event.key === STORAGE_KEY) listener();
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", onStorage);
  };
}

export function useNotificationSettings(): NotificationSettings {
  return useSyncExternalStore(subscribe, readSettings, () => DEFAULT_NOTIFICATION_SETTINGS);
}
