"use client";

import type { ChannelListingDto, ChannelListingRequest } from "@crm/shared";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

export function useChannelListings() {
  return useQuery({
    queryKey: queryKeys.channelListings,
    queryFn: () => apiRequest<ChannelListingDto[]>("/channel-listings"),
  });
}

export function useSaveChannelListing() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: ChannelListingRequest) => apiRequest<ChannelListingDto>("/channel-listings", { method: "PUT", body: input }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.channelListings }),
  });
}

export function useRemoveChannelListing() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => apiRequest<void>(`/channel-listings/${id}`, { method: "DELETE" }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.channelListings }),
  });
}
