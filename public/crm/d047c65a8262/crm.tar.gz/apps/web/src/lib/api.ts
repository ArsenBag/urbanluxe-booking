import type { ApiResponse } from "@crm/shared";

/** Совпадает с CSRF_HEADER на сервере: без него изменяющие запросы отклоняются. */
const CSRF_HEADERS = { "x-requested-with": "crm-web" };

const NETWORK_ERROR_MESSAGE = "Нет связи с сервером. Проверьте подключение к интернету.";

export class ApiRequestError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly fields: Record<string, string> = {},
  ) {
    super(message);
    this.name = "ApiRequestError";
  }
}

/** Запрос к API через прокси Next.js (/api → сервер API), с cookie сессии. */
type QueryValue = string | number | boolean | null | undefined;

interface RequestOptions {
  method?: string;
  body?: unknown;
  /** Параметры строки запроса; пустые значения пропускаются. */
  query?: Record<string, QueryValue>;
}

function buildUrl(path: string, query: RequestOptions["query"]): string {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(query ?? {})) {
    if (value !== undefined && value !== null && value !== "") {
      params.set(key, String(value));
    }
  }
  const search = params.toString();
  return `/api${path}${search ? `?${search}` : ""}`;
}

export async function apiRequest<T>(path: string, init: RequestOptions = {}): Promise<T> {
  let response: Response;
  try {
    response = await fetch(buildUrl(path, init.query), {
      method: init.method ?? "GET",
      credentials: "same-origin",
      // FormData (загрузка файла) браузер кодирует сам и ставит Content-Type с границей.
      headers: init.body instanceof FormData ? CSRF_HEADERS : { "content-type": "application/json", ...CSRF_HEADERS },
      body: init.body === undefined || init.body instanceof FormData ? init.body : JSON.stringify(init.body),
    });
  } catch {
    throw new ApiRequestError(NETWORK_ERROR_MESSAGE, 0);
  }

  let payload: ApiResponse<T>;
  try {
    payload = (await response.json()) as ApiResponse<T>;
  } catch {
    throw new ApiRequestError(`Сервер вернул некорректный ответ (${response.status})`, response.status);
  }

  if (!payload.success) {
    throw new ApiRequestError(payload.error.message, response.status, payload.error.fields);
  }
  return payload.data;
}

export const UNAUTHORIZED_STATUS = 401;

export function isUnauthorized(error: unknown): boolean {
  return error instanceof ApiRequestError && error.status === UNAUTHORIZED_STATUS;
}

/**
 * Сообщение для показа над формой: если ошибка не привязана ни к одному из полей,
 * которые форма умеет подсвечивать, её нужно показать отдельно, иначе она потеряется.
 */
export function formLevelError(error: unknown, shownFields: readonly string[]): string | null {
  if (!error) return null;
  if (!(error instanceof ApiRequestError)) {
    return error instanceof Error ? error.message : "Неизвестная ошибка";
  }
  const hasShownFieldError = shownFields.some((field) => error.fields[field]);
  return hasShownFieldError ? null : error.message;
}
