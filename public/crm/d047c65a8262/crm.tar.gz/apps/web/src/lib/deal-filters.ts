import { CONTACT_SOURCES, MAX_DEAL_SEARCH_LENGTH, MIN_FILTER_DATE, NO_OWNER_FILTER, type ContactSource } from "@crm/shared";
import { parseDateKey } from "./format";

/** Фильтры канбана сделок. Даты — YYYY-MM-DD или пустая строка; этапы фильтруются на доске, остальное — сервером. */
export interface DealFilters {
  createdFrom: string;
  createdTo: string;
  closedFrom: string;
  closedTo: string;
  checkInFrom: string;
  checkInTo: string;
  /** Имя клиента, название сделки или цифры телефона; пусто — без поиска. */
  search: string;
  stageIds: string[];
  /** id сотрудников и NO_OWNER_FILTER («без ответственного»). */
  ownerIds: string[];
  sources: ContactSource[];
}

export const EMPTY_DEAL_FILTERS: DealFilters = {
  createdFrom: "",
  createdTo: "",
  closedFrom: "",
  closedTo: "",
  checkInFrom: "",
  checkInTo: "",
  search: "",
  stageIds: [],
  ownerIds: [],
  sources: [],
};

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DATE_KEYS = ["createdFrom", "createdTo", "closedFrom", "closedTo", "checkInFrom", "checkInTo"] as const;
/** Параметр поиска в адресе страницы. */
const SEARCH_KEY = "q";
/** Поле фильтра → параметр в адресе страницы. */
const LIST_KEYS = [
  ["stageIds", "stages"],
  ["ownerIds", "owners"],
  ["sources", "sources"],
] as const;

/** Как на сервере: не больше 50 значений в списке. */
const MAX_LIST_ITEMS = 50;

const listOf = (value: string | null) => [
  ...new Set(
    (value ?? "")
      .split(",")
      .map((part) => part.trim())
      .filter(Boolean),
  ),
];
const isSource = (value: string): value is ContactSource => (CONTACT_SOURCES as readonly string[]).includes(value);
/** Дата из адреса по правилам сервера: настоящая дата не раньше 2000 года, иначе пусто. */
const filterDate = (value: string | null) => {
  const date = parseDateKey(value);
  return date && date >= MIN_FILTER_DATE ? date : "";
};
/** Перевёрнутый диапазон сервер отклонит — отбрасываем конец, начало оставляем. */
const rangeEnd = (from: string, to: string) => (from && to && to < from ? "" : to);

/** Фильтры из адреса страницы: неверные даты и значения молча отбрасываются (адрес мог прийти из ссылки). */
export function parseDealFilters(params: URLSearchParams): DealFilters {
  const createdFrom = filterDate(params.get("createdFrom"));
  const closedFrom = filterDate(params.get("closedFrom"));
  const checkInFrom = filterDate(params.get("checkInFrom"));
  return {
    createdFrom,
    createdTo: rangeEnd(createdFrom, filterDate(params.get("createdTo"))),
    closedFrom,
    closedTo: rangeEnd(closedFrom, filterDate(params.get("closedTo"))),
    checkInFrom,
    checkInTo: rangeEnd(checkInFrom, filterDate(params.get("checkInTo"))),
    search: (params.get(SEARCH_KEY) ?? "").trim().slice(0, MAX_DEAL_SEARCH_LENGTH),
    stageIds: listOf(params.get("stages"))
      .filter((id) => UUID.test(id))
      .slice(0, MAX_LIST_ITEMS),
    ownerIds: listOf(params.get("owners"))
      .filter((id) => id === NO_OWNER_FILTER || UUID.test(id))
      .slice(0, MAX_LIST_ITEMS),
    sources: listOf(params.get("sources")).filter(isSource),
  };
}

/** Новый адрес страницы: фильтры заменяются, остальные параметры (воронка) остаются. */
export function dealFiltersToParams(filters: DealFilters, base: URLSearchParams): URLSearchParams {
  const params = new URLSearchParams(base);
  for (const key of DATE_KEYS) {
    params.delete(key);
    if (filters[key]) params.set(key, filters[key]);
  }
  params.delete(SEARCH_KEY);
  if (filters.search.trim()) params.set(SEARCH_KEY, filters.search.trim());
  for (const [field, key] of LIST_KEYS) {
    params.delete(key);
    if (filters[field].length > 0) params.set(key, filters[field].join(","));
  }
  return params;
}

/** Параметры запроса доски: только заданные серверные фильтры. */
export function dealBoardQuery(filters: DealFilters): Record<string, string> {
  return Object.fromEntries(
    [
      ...DATE_KEYS.map((key) => [key, filters[key]] as const),
      ["search", filters.search.trim()] as const,
      ["ownerIds", filters.ownerIds.join(",")] as const,
      ["sources", filters.sources.join(",")] as const,
    ].filter(([, value]) => value !== ""),
  );
}

/** Сколько фильтров включено (диапазон дат — один фильтр). */
export function activeDealFilterCount(filters: DealFilters): number {
  return [
    filters.createdFrom || filters.createdTo,
    filters.closedFrom || filters.closedTo,
    filters.checkInFrom || filters.checkInTo,
    filters.search.trim(),
    filters.stageIds.length,
    filters.ownerIds.length,
    filters.sources.length,
  ].filter(Boolean).length;
}
