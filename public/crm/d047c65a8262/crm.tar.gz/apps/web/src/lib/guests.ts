"use client";

import { completedStays, type BlacklistEntryDto, type BlacklistInput, type ContactDto } from "@crm/shared";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { useContactBookings } from "./bookings";
import { tashkentDayKey } from "./format";
import { queryKeys } from "./query-keys";

/** Сколько раз гость у нас жил; null — брони ещё грузятся или не загрузились. */
export function useGuestStays(contactId: string): number | null {
  const bookings = useContactBookings(contactId);
  if (!bookings.data) return null;
  return completedStays(bookings.data, tashkentDayKey(new Date()));
}

export function useBlacklist() {
  return useQuery({
    queryKey: queryKeys.blacklist,
    queryFn: () => apiRequest<BlacklistEntryDto[]>("/blacklist"),
  });
}

/**
 * Метки гостя видны в карточке, диалогах и разделе «Чёрный список» — перечитываем всё это.
 * Не ждём перечитывания: окно закрывается сразу, метки обновятся следом.
 */
function useInvalidateGuest() {
  const queryClient = useQueryClient();
  return () => {
    for (const queryKey of [queryKeys.contacts, queryKeys.conversations, queryKeys.blacklist]) {
      void queryClient.invalidateQueries({ queryKey });
    }
  };
}

export function useSetVip(contactId: string) {
  const invalidate = useInvalidateGuest();
  return useMutation({
    mutationFn: (vip: boolean) => apiRequest<ContactDto>(`/contacts/${contactId}`, { method: "PATCH", body: { vip } }),
    onSuccess: invalidate,
  });
}

export function useAddToBlacklist(contactId: string) {
  const invalidate = useInvalidateGuest();
  return useMutation({
    mutationFn: (input: BlacklistInput) => apiRequest<ContactDto>(`/blacklist/${contactId}`, { method: "PUT", body: input }),
    onSuccess: invalidate,
  });
}

/** Убрать из списка может только администратор. */
export function useRemoveFromBlacklist() {
  const invalidate = useInvalidateGuest();
  return useMutation({
    mutationFn: (contactId: string) => apiRequest<ContactDto>(`/blacklist/${contactId}`, { method: "DELETE" }),
    onSuccess: invalidate,
  });
}
