import { describe, expect, it } from "vitest";
import { safeRedirectTarget } from "./safe-redirect";

const ORIGIN = "https://crm.example.uz";

describe("safeRedirectTarget", () => {
  it("keeps internal paths with query", () => {
    expect(safeRedirectTarget("/settings/users?tab=1", ORIGIN)).toBe("/settings/users?tab=1");
  });

  it.each([null, "", "https://evil.com", "//evil.com", "/\\evil.com", "\\\\evil.com", "javascript:alert(1)"])(
    "falls back to home for %s",
    (value) => {
      expect(safeRedirectTarget(value, ORIGIN)).toBe("/");
    },
  );
});
