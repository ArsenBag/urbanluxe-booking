"use client";

import type { BookingDto, DealDto, LinkConversationInput, LinkPreviewDto, LinkResultDto, LinkTarget } from "@crm/shared";
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

export type LinkKind = "booking" | "deal";

/** Поиск брони для связи с диалогом; пустой запрос — ближайшие заезды. */
export function useBookingSearch(query: string, enabled: boolean) {
  return useQuery({
    queryKey: queryKeys.linkSearch("booking", query),
    queryFn: () => apiRequest<BookingDto[]>("/bookings/search", { query: { q: query } }),
    enabled,
    placeholderData: keepPreviousData,
  });
}

/** Поиск сделки для связи с диалогом; пустой запрос — недавние открытые сделки. */
export function useDealSearch(query: string, enabled: boolean) {
  return useQuery({
    queryKey: queryKeys.linkSearch("deal", query),
    queryFn: () => apiRequest<DealDto[]>("/deals/search", { query: { q: query } }),
    enabled,
    placeholderData: keepPreviousData,
  });
}

export function useLinkPreview(conversationId: string, target: LinkTarget) {
  return useQuery({
    queryKey: queryKeys.linkPreview(conversationId, target),
    queryFn: () => apiRequest<LinkPreviewDto>(`/conversations/${conversationId}/link-preview`, { query: { ...target } }),
  });
}

/** Связывание объединяет карточки и сделки — обновляем всё, где они видны. */
export function useLinkConversation(conversationId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: LinkConversationInput) =>
      apiRequest<LinkResultDto>(`/conversations/${conversationId}/link`, { method: "POST", body: input }),
    onSuccess: () => {
      for (const queryKey of [queryKeys.conversations, queryKeys.contacts, queryKeys.deals, queryKeys.bookings, queryKeys.linkSearchAll, queryKeys.blacklist]) {
        void queryClient.invalidateQueries({ queryKey });
      }
    },
    // Отказ из-за изменившейся брони: показываем окну подтверждения свежее состояние.
    onError: () => void queryClient.invalidateQueries({ queryKey: queryKeys.linkPreviewAll(conversationId) }),
  });
}
