"use client";

import type { ChannelDto, ChannelsOverviewDto, ReplyTemplateDto, ReplyTemplateInput } from "@crm/shared";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

const CHANNELS_POLL_MS = 5000;

export function useChannels() {
  return useQuery({
    queryKey: queryKeys.channels,
    queryFn: () => apiRequest<ChannelsOverviewDto>("/channels"),
    // Статус импорта истории и ошибки подключения обновляются на сервере в фоне.
    refetchInterval: CHANNELS_POLL_MS,
  });
}

function useChannelMutation<TInput>(request: (input: TInput) => Promise<ChannelDto>) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: request,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.channels }),
  });
}

export const useStartTelegramLogin = () =>
  useChannelMutation((phone: string) => apiRequest<ChannelDto>("/channels/telegram/login", { method: "POST", body: { phone } }));

export const useSubmitTelegramCode = () =>
  useChannelMutation(({ id, code }: { id: string; code: string }) =>
    apiRequest<ChannelDto>(`/channels/${id}/login/code`, { method: "POST", body: { code } }),
  );

export const useSubmitTelegramPassword = () =>
  useChannelMutation(({ id, password }: { id: string; password: string }) =>
    apiRequest<ChannelDto>(`/channels/${id}/login/password`, { method: "POST", body: { password } }),
  );

export const useDisconnectChannel = () =>
  useChannelMutation((id: string) => apiRequest<ChannelDto>(`/channels/${id}/disconnect`, { method: "POST" }));

export function useTemplates() {
  return useQuery({ queryKey: queryKeys.templates, queryFn: () => apiRequest<ReplyTemplateDto[]>("/templates") });
}

function useTemplateMutation<TInput, TResult>(request: (input: TInput) => Promise<TResult>) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: request,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.templates }),
  });
}

export const useCreateTemplate = () =>
  useTemplateMutation((input: ReplyTemplateInput) => apiRequest<ReplyTemplateDto>("/templates", { method: "POST", body: input }));

export const useUpdateTemplate = () =>
  useTemplateMutation(({ id, input }: { id: string; input: ReplyTemplateInput }) =>
    apiRequest<ReplyTemplateDto>(`/templates/${id}`, { method: "PATCH", body: input }),
  );

export const useDeleteTemplate = () =>
  useTemplateMutation((id: string) => apiRequest<null>(`/templates/${id}`, { method: "DELETE" }));

/** Прикрепить или заменить файл шаблона — сохраняется сразу, отдельно от текста. */
export const useAttachTemplateFile = () =>
  useTemplateMutation(({ id, file }: { id: string; file: File }) => {
    const form = new FormData();
    form.append("file", file);
    return apiRequest<ReplyTemplateDto>(`/templates/${id}/file`, { method: "PUT", body: form });
  });

export const useRemoveTemplateFile = () =>
  useTemplateMutation((id: string) => apiRequest<ReplyTemplateDto>(`/templates/${id}/file`, { method: "DELETE" }));
