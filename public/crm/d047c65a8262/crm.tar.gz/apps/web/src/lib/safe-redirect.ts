/**
 * Возвращает путь для перехода после входа, только если он ведёт на этот же сайт.
 * Защищает от ссылок вида /login?next=//evil.com или /login?next=/\evil.com.
 */
export function safeRedirectTarget(value: string | null, origin: string): string {
  if (!value || !value.startsWith("/") || value.includes("\\")) {
    return "/";
  }
  try {
    const url = new URL(value, origin);
    return url.origin === origin ? `${url.pathname}${url.search}${url.hash}` : "/";
  } catch {
    return "/";
  }
}
