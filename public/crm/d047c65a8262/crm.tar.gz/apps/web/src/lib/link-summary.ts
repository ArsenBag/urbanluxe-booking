import type { LinkMergeContactDto } from "@crm/shared";
import { pluralize } from "./format";

type MovedCounts = Pick<LinkMergeContactDto, "bookings" | "deals" | "conversations">;

const FORMS: Array<[keyof MovedCounts, [string, string, string]]> = [
  ["bookings", ["бронь", "брони", "броней"]],
  ["deals", ["сделка", "сделки", "сделок"]],
  ["conversations", ["чат", "чата", "чатов"]],
];

/** Что переедет вместе с влитой карточкой: «1 бронь, 2 сделки». null — ничего. */
export function movedSummary(counts: MovedCounts): string | null {
  const parts = FORMS.filter(([key]) => counts[key] > 0).map(([key, forms]) => `${counts[key]} ${pluralize(counts[key], forms)}`);
  return parts.length > 0 ? parts.join(", ") : null;
}
