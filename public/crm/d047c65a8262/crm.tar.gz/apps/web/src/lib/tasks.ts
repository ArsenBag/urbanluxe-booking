"use client";

import type { CreateTaskInput, TaskDto, UpdateTaskInput } from "@crm/shared";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

export interface TaskFilters {
  scope?: "mine" | "all";
  status?: "open" | "done" | "all";
  dealId?: string;
  contactId?: string;
}

export function useTasks(filters: TaskFilters) {
  return useQuery({
    queryKey: queryKeys.taskList({ ...filters }),
    queryFn: () => apiRequest<TaskDto[]>("/tasks", { query: { ...filters } }),
  });
}

function useInvalidateTasks() {
  const queryClient = useQueryClient();
  return () => {
    void queryClient.invalidateQueries({ queryKey: queryKeys.tasks });
    // Счётчик открытых задач на карточках сделок и история.
    void queryClient.invalidateQueries({ queryKey: queryKeys.deals });
    void queryClient.invalidateQueries({ queryKey: queryKeys.contacts });
  };
}

export function useCreateTask() {
  const invalidate = useInvalidateTasks();
  return useMutation({
    mutationFn: (input: Partial<CreateTaskInput> & { title: string }) =>
      apiRequest<TaskDto>("/tasks", { method: "POST", body: input }),
    onSuccess: invalidate,
  });
}

export function useUpdateTask() {
  const invalidate = useInvalidateTasks();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: UpdateTaskInput }) =>
      apiRequest<TaskDto>(`/tasks/${id}`, { method: "PATCH", body: input }),
    onSuccess: invalidate,
  });
}

export function useDeleteTask() {
  const invalidate = useInvalidateTasks();
  return useMutation({
    mutationFn: (id: string) => apiRequest<null>(`/tasks/${id}`, { method: "DELETE" }),
    onSuccess: invalidate,
  });
}
