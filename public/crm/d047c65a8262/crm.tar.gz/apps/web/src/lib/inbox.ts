"use client";

import type {
  ChannelType,
  ConversationDto,
  ConversationFilter,
  ConversationStatus,
  MessageDto,
  Paginated,
  SendTemplateFileInput,
  StartConversationInput,
  StartConversationResult,
  UpdateConversationInput,
} from "@crm/shared";
import { keepPreviousData, useInfiniteQuery, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

/** Частота опроса сервера: открытый диалог и список. Вне активной вкладки опрос не идёт. */
const MESSAGES_POLL_MS = 3000;
const LIST_POLL_MS = 5000;
const COUNTERS_POLL_MS = 10_000;
const MESSAGES_PAGE_SIZE = 50;

export interface ConversationFilters {
  filter: ConversationFilter;
  status: ConversationStatus;
  search: string;
  /** Пусто — все мессенджеры. */
  channelType: ChannelType | "";
  /** Конкретный сотрудник; пусто — по filter. */
  assigneeId: string;
  /** Только диалоги, где гостю ещё не ответили. */
  unanswered: boolean;
}

export const DEFAULT_CONVERSATION_FILTERS: ConversationFilters = {
  filter: "all",
  status: "OPEN",
  search: "",
  channelType: "",
  assigneeId: "",
  unanswered: false,
};

export function useConversations(filters: ConversationFilters) {
  // Пустые значения apiRequest не отправляет; «без ответа» — только когда включено.
  const query = { ...filters, unanswered: filters.unanswered || undefined, limit: 100 };
  return useQuery({
    queryKey: queryKeys.conversationList({ ...filters, unanswered: String(filters.unanswered) }),
    queryFn: () => apiRequest<Paginated<ConversationDto>>("/conversations", { query }),
    refetchInterval: LIST_POLL_MS,
    placeholderData: keepPreviousData,
  });
}

export function useConversation(id: string | null) {
  return useQuery({
    queryKey: queryKeys.conversation(id ?? ""),
    queryFn: () => apiRequest<ConversationDto>(`/conversations/${id}`),
    enabled: Boolean(id),
    refetchInterval: MESSAGES_POLL_MS,
  });
}

export function useInboxCounters() {
  return useQuery({
    queryKey: queryKeys.inboxCounters,
    queryFn: () => apiRequest<{ unassigned: number; mineUnread: number }>("/conversations/counters"),
    refetchInterval: COUNTERS_POLL_MS,
  });
}

export function useContactConversations(contactId: string) {
  return useQuery({
    queryKey: queryKeys.contactConversations(contactId),
    queryFn: () => apiRequest<ConversationDto[]>(`/contacts/${contactId}/conversations`),
  });
}

/** Сообщения постранично: первая страница — самые свежие, следующие — более старые. */
export function useMessages(conversationId: string | null) {
  return useInfiniteQuery({
    queryKey: queryKeys.messages(conversationId ?? ""),
    queryFn: ({ pageParam }) =>
      apiRequest<MessageDto[]>(`/conversations/${conversationId}/messages`, {
        query: { limit: MESSAGES_PAGE_SIZE, before: pageParam?.before, beforeId: pageParam?.beforeId },
      }),
    initialPageParam: undefined as { before: string; beforeId: string } | undefined,
    // Курсор из времени и id: у сообщений истории время часто совпадает до секунды.
    getNextPageParam: (page) =>
      page.length === MESSAGES_PAGE_SIZE ? { before: page[0].sentAt, beforeId: page[0].id } : undefined,
    enabled: Boolean(conversationId),
    refetchInterval: MESSAGES_POLL_MS,
  });
}

function useInvalidateInbox() {
  const queryClient = useQueryClient();
  return () => queryClient.invalidateQueries({ queryKey: queryKeys.conversations });
}

export function useSendMessage(conversationId: string) {
  const invalidate = useInvalidateInbox();
  return useMutation({
    mutationFn: (text: string) =>
      apiRequest<MessageDto>(`/conversations/${conversationId}/messages`, { method: "POST", body: { text } }),
    onSettled: invalidate,
  });
}

/** Первое сообщение клиенту из его карточки: CRM найдёт его в мессенджере и откроет диалог. */
export function useStartConversation(contactId: string) {
  const queryClient = useQueryClient();
  const invalidateInbox = useInvalidateInbox();
  return useMutation({
    mutationFn: (input: StartConversationInput) =>
      apiRequest<StartConversationResult>(`/contacts/${contactId}/conversations`, { method: "POST", body: input }),
    // Карточка клиента тоже меняется: новый чат в «Переписке» и запись в истории.
    onSuccess: () =>
      Promise.all([invalidateInbox(), queryClient.invalidateQueries({ queryKey: queryKeys.contacts })]),
  });
}

export function useSendFile(conversationId: string) {
  const invalidate = useInvalidateInbox();
  return useMutation({
    mutationFn: ({ file, caption }: { file: File; caption: string }) => {
      const form = new FormData();
      form.append("file", file);
      if (caption) form.append("caption", caption);
      return apiRequest<MessageDto>(`/conversations/${conversationId}/files`, { method: "POST", body: form });
    },
    onSettled: invalidate,
  });
}

/**
 * Файл шаблона: он уже на сервере, браузер его не загружает. fileId — файл, который видел менеджер:
 * если его заменили или убрали, сервер откажет — тогда перечитываем шаблоны, чтобы выбрать заново.
 */
export function useSendTemplateFile(conversationId: string) {
  const invalidate = useInvalidateInbox();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: SendTemplateFileInput) =>
      apiRequest<MessageDto>(`/conversations/${conversationId}/template-file`, { method: "POST", body: input }),
    onError: () => queryClient.invalidateQueries({ queryKey: queryKeys.templates }),
    onSettled: invalidate,
  });
}

export function useRetryMessage() {
  const invalidate = useInvalidateInbox();
  return useMutation({
    mutationFn: (messageId: string) => apiRequest<MessageDto>(`/messages/${messageId}/retry`, { method: "POST" }),
    onSettled: invalidate,
  });
}

/** Загрузить из мессенджера файл вложения, который не сохранился (фото, голосовое, документ). */
export function useFetchAttachment() {
  const invalidate = useInvalidateInbox();
  return useMutation({
    mutationFn: (messageId: string) => apiRequest<MessageDto>(`/messages/${messageId}/attachment`, { method: "POST" }),
    onSuccess: invalidate,
  });
}

export function useUpdateConversation(conversationId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: UpdateConversationInput) =>
      apiRequest<ConversationDto>(`/conversations/${conversationId}`, { method: "PATCH", body: input }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: queryKeys.conversations });
      void queryClient.invalidateQueries({ queryKey: queryKeys.contacts });
    },
  });
}

export function useMarkRead() {
  const invalidate = useInvalidateInbox();
  return useMutation({
    mutationFn: (conversationId: string) => apiRequest<null>(`/conversations/${conversationId}/read`, { method: "POST" }),
    onSuccess: invalidate,
  });
}
