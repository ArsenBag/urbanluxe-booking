"use client";

import type { StageAutomationDto, StageAutomationInput } from "@crm/shared";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

export function useStageAutomation() {
  return useQuery({
    queryKey: queryKeys.stageAutomation,
    queryFn: () => apiRequest<StageAutomationDto>("/stage-automation"),
  });
}

export function useSaveStageAutomation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: StageAutomationInput) => apiRequest<StageAutomationDto>("/stage-automation", { method: "PUT", body: input }),
    onSuccess: (saved) => queryClient.setQueryData(queryKeys.stageAutomation, saved),
  });
}
