"use client";

import type {
  ActivityDto,
  ContactDto,
  ContactListItemDto,
  CreateContactInput,
  Paginated,
  UpdateContactInput,
} from "@crm/shared";
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

export function useContacts(search: string, page: number) {
  return useQuery({
    queryKey: queryKeys.contactList(search, page),
    queryFn: () => apiRequest<Paginated<ContactListItemDto>>("/contacts", { query: { search, page } }),
    placeholderData: keepPreviousData,
  });
}

export function useContact(id: string) {
  return useQuery({ queryKey: queryKeys.contact(id), queryFn: () => apiRequest<ContactDto>(`/contacts/${id}`) });
}

export function useContactActivity(id: string) {
  return useQuery({
    queryKey: queryKeys.contactActivity(id),
    queryFn: () => apiRequest<ActivityDto[]>(`/contacts/${id}/activity`),
  });
}

/** Ввод клиента в формах: поля, которые сервер нормализует сам (телефоны, теги). */
export type ContactFormInput = Partial<CreateContactInput> & { name: string };

export function useCreateContact() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: ContactFormInput) => apiRequest<ContactDto>("/contacts", { method: "POST", body: input }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.contacts }),
  });
}

export function useUpdateContact(id: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: UpdateContactInput | ContactFormInput) =>
      apiRequest<ContactDto>(`/contacts/${id}`, { method: "PATCH", body: input }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: queryKeys.contacts });
      void queryClient.invalidateQueries({ queryKey: queryKeys.deals });
    },
  });
}

export function useDeleteContact() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => apiRequest<null>(`/contacts/${id}`, { method: "DELETE" }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.contacts }),
  });
}
