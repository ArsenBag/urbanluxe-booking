import type { ReportPeriod } from "@crm/shared";
import { addDays } from "../components/bookings/chessboard-layout";

export const REPORT_PRESETS = ["last7", "last30", "thisMonth", "lastMonth", "next30"] as const;
export type ReportPreset = (typeof REPORT_PRESETS)[number];

export const REPORT_PRESET_LABELS: Record<ReportPreset, string> = {
  last7: "7 дней",
  last30: "30 дней",
  thisMonth: "Этот месяц",
  lastMonth: "Прошлый месяц",
  next30: "Следующие 30 дней",
};

const LOCALE = "ru-RU";
const MINUTES_PER_HOUR = 60;
const MINUTES_PER_DAY = 24 * MINUTES_PER_HOUR;

const monthStart = (date: string) => `${date.slice(0, 7)}-01`;

/** Период пресета относительно сегодняшнего дня по Ташкенту (YYYY-MM-DD). */
export function presetPeriod(preset: ReportPreset, today: string): ReportPeriod {
  switch (preset) {
    case "last7":
      return { from: addDays(today, -6), to: today };
    case "last30":
      return { from: addDays(today, -29), to: today };
    case "thisMonth":
      return { from: monthStart(today), to: today };
    case "lastMonth": {
      const lastDay = addDays(monthStart(today), -1);
      return { from: monthStart(lastDay), to: lastDay };
    }
    case "next30":
      return { from: today, to: addDays(today, 29) };
  }
}

/** Какой пресет выбран, чтобы подсветить кнопку; свои даты — custom. */
export function matchPreset(period: ReportPeriod, today: string): ReportPreset | "custom" {
  return (
    REPORT_PRESETS.find((preset) => {
      const candidate = presetPeriod(preset, today);
      return candidate.from === period.from && candidate.to === period.to;
    }) ?? "custom"
  );
}

const percentFormatter = new Intl.NumberFormat(LOCALE, { style: "percent", maximumFractionDigits: 0 });
const countFormatter = new Intl.NumberFormat(LOCALE);

export function formatPercent(share: number | null): string {
  return share === null ? "—" : percentFormatter.format(share);
}

/** Часть от целого в процентах; от пустого целого — прочерк. */
export function formatShare(part: number, whole: number): string {
  return whole > 0 ? formatPercent(part / whole) : "—";
}

export function formatCount(value: number): string {
  return countFormatter.format(value);
}

/** Сумма без копеек: в отчёте важен порядок, а не центы. */
export function formatAmount(value: number, currency: string): string {
  return new Intl.NumberFormat(LOCALE, { style: "currency", currency, maximumFractionDigits: 0 }).format(value);
}

/** Длительность ожидания: «12 мин», «1 ч 35 мин», «1 д 2 ч». */
export function formatDuration(minutes: number | null): string {
  if (minutes === null) return "—";
  if (minutes < 1) return "меньше минуты";
  if (minutes < MINUTES_PER_HOUR) return `${Math.round(minutes)} мин`;
  if (minutes < MINUTES_PER_DAY) {
    const hours = Math.floor(minutes / MINUTES_PER_HOUR);
    const rest = Math.round(minutes % MINUTES_PER_HOUR);
    return rest > 0 ? `${hours} ч ${rest} мин` : `${hours} ч`;
  }
  const days = Math.floor(minutes / MINUTES_PER_DAY);
  const hours = Math.round((minutes % MINUTES_PER_DAY) / MINUTES_PER_HOUR);
  return hours > 0 ? `${days} д ${hours} ч` : `${days} д`;
}
