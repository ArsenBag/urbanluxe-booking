"use client";

import type { LoginInput, Role } from "@crm/shared";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: Role;
}

export const SESSION_KEY = ["session"] as const;

export function useSession() {
  return useQuery({
    queryKey: SESSION_KEY,
    queryFn: () => apiRequest<SessionUser>("/auth/me"),
    retry: false,
  });
}

export function useLogin() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: LoginInput) => apiRequest<SessionUser>("/auth/login", { method: "POST", body: input }),
    onSuccess: (user) => queryClient.setQueryData(SESSION_KEY, user),
  });
}

export function useLogout() {
  return useMutation({
    mutationFn: () => apiRequest<null>("/auth/logout", { method: "POST" }),
    // Полная перезагрузка намеренна: сбрасывает весь кэш данных и не даёт гонки двух редиректов.
    // eslint-disable-next-line @next/next/no-location-assign-relative-destination
    onSuccess: () => window.location.assign("/login"),
  });
}
