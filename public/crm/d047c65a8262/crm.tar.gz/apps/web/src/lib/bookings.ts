"use client";

import type { BookingDayDto, BookingDto, ManualBookingRequest, PmsPropertiesSyncResultDto, PmsStatusDto, PropertyDto, RealtyCalendarStatusDto } from "@crm/shared";
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./api";
import { queryKeys } from "./query-keys";

/** Брони приходят из RealtyCalendar в фоне — периодически перечитываем. */
const BOOKINGS_POLL_MS = 30_000;

export function useBookingDay(date: string) {
  return useQuery({
    queryKey: ["bookings", "day", date],
    queryFn: () => apiRequest<BookingDayDto>("/bookings/day", { query: { date } }),
    refetchInterval: BOOKINGS_POLL_MS,
  });
}

/** При прокрутке шахматки диапазон сдвигается — прежние брони видны, пока не придут новые, без мигания. */
export function useBookingRange(from: string, to: string) {
  return useQuery({
    queryKey: ["bookings", "range", from, to],
    queryFn: () => apiRequest<BookingDto[]>("/bookings", { query: { from, to } }),
    refetchInterval: BOOKINGS_POLL_MS,
    placeholderData: keepPreviousData,
  });
}

export function useProperties() {
  return useQuery({ queryKey: ["properties"], queryFn: () => apiRequest<PropertyDto[]>("/properties") });
}

export function useContactBookings(contactId: string) {
  return useQuery({
    queryKey: ["contacts", contactId, "bookings"],
    queryFn: () => apiRequest<BookingDto[]>(`/contacts/${contactId}/bookings`),
    // В панели диалога id клиента пуст, пока диалог загружается.
    enabled: Boolean(contactId),
  });
}

export function useDealBookings(dealId: string) {
  return useQuery({
    queryKey: ["deals", dealId, "bookings"],
    queryFn: () => apiRequest<BookingDto[]>(`/deals/${dealId}/bookings`),
  });
}

export function useRealtyCalendarStatus() {
  return useQuery({
    queryKey: ["integrations", "realtycalendar"],
    queryFn: () => apiRequest<RealtyCalendarStatusDto>("/integrations/realtycalendar"),
    refetchInterval: BOOKINGS_POLL_MS,
  });
}

export function usePmsStatus() {
  return useQuery({
    queryKey: ["integrations", "pms"],
    queryFn: () => apiRequest<PmsStatusDto>("/integrations/pms"),
    refetchInterval: BOOKINGS_POLL_MS,
  });
}

export function useSyncPmsProperties() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => apiRequest<PmsPropertiesSyncResultDto>("/integrations/pms/sync-properties", { method: "POST" }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["integrations", "pms"] }),
  });
}

export function useImportPmsProperties() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => apiRequest<PmsPropertiesSyncResultDto>("/integrations/pms/import-properties", { method: "POST" }),
    onSuccess: () => Promise.all([queryClient.invalidateQueries({ queryKey: ["integrations", "pms"] }), queryClient.invalidateQueries({ queryKey: queryKeys.bookings })]),
  });
}

export function useRetryPms() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => apiRequest<{ sent: number }>("/integrations/pms/retry", { method: "POST" }),
    onSuccess: () => Promise.all([queryClient.invalidateQueries({ queryKey: ["integrations", "pms"] }), queryClient.invalidateQueries({ queryKey: queryKeys.bookings })]),
  });
}

/** Бронь меняет и шахматку, и сделку, клиента, задачи заезда/выезда — перечитываем всё это. */
function useInvalidateBookings() {
  const queryClient = useQueryClient();
  return () =>
    Promise.all(
      [queryKeys.bookings, queryKeys.deals, queryKeys.contacts, queryKeys.tasks].map((queryKey) =>
        queryClient.invalidateQueries({ queryKey }),
      ),
    );
}

export function useCreateBooking() {
  const invalidate = useInvalidateBookings();
  return useMutation({
    mutationFn: (input: ManualBookingRequest) => apiRequest<BookingDto>("/bookings", { method: "POST", body: input }),
    onSuccess: invalidate,
  });
}

export function useUpdateBooking(id: string) {
  const invalidate = useInvalidateBookings();
  return useMutation({
    mutationFn: (input: ManualBookingRequest) => apiRequest<BookingDto>(`/bookings/${id}`, { method: "PUT", body: input }),
    onSuccess: invalidate,
  });
}

export function useCancelBooking(id: string) {
  const invalidate = useInvalidateBookings();
  return useMutation({
    mutationFn: () => apiRequest<BookingDto>(`/bookings/${id}/cancel`, { method: "POST" }),
    onSuccess: invalidate,
  });
}
