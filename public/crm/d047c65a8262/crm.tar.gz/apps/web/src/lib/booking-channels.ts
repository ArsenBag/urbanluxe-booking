import type { BookingDto } from "@crm/shared";

/** Площадка брони и её значок — маленький цветной квадратик с буквой, как на шахматке RealtyCalendar. */
export interface BookingChannel {
  key: "AIRBNB" | "BOOKING" | "YANDEX" | "EMERGING" | "SUTOCHNO" | "BRONEVIK" | "BASKET" | "WEBSITE" | "OTHER";
  label: string;
  letter: string;
  background: string;
  color: string;
}

const AIRBNB: BookingChannel = { key: "AIRBNB", label: "Airbnb", letter: "A", background: "#FF385C", color: "#FFFFFF" };

/** Названия площадок в RealtyCalendar пишутся по-разному («Booking.com» и «booking.com», «YandexTravel» и «Яндекс Путешествия»). */
const KNOWN_CHANNELS: ReadonlyArray<{ pattern: RegExp; channel: BookingChannel }> = [
  { pattern: /airbnb/i, channel: AIRBNB },
  { pattern: /booking\.com|^booking$/i, channel: { key: "BOOKING", label: "Booking.com", letter: "B", background: "#003580", color: "#FFFFFF" } },
  { pattern: /yandex|яндекс/i, channel: { key: "YANDEX", label: "Яндекс Путешествия", letter: "Я", background: "#7F65FB", color: "#FDDF58" } },
  {
    pattern: /emerging|ostrovok|островок/i,
    channel: { key: "EMERGING", label: "Emerging Travel (Островок)", letter: "E", background: "#0E9384", color: "#FFFFFF" },
  },
  { pattern: /sutochno|суточно/i, channel: { key: "SUTOCHNO", label: "Суточно.ру", letter: "S", background: "#EE204E", color: "#FFFFFF" } },
  { pattern: /bronevik|броневик/i, channel: { key: "BRONEVIK", label: "Броневик", letter: "B", background: "#A51611", color: "#EE7D00" } },
  { pattern: /корзин|basket/i, channel: { key: "BASKET", label: "Корзина RealtyCalendar", letter: "К", background: "#FFE000", color: "#000000" } },
  { pattern: /сайт|виджет|\bsite\b|\bwidget\b/i, channel: { key: "WEBSITE", label: "Сайт", letter: "С", background: "#12B76A", color: "#FFFFFF" } },
];

type ChannelSource = Pick<BookingDto, "origin" | "notes">;

/**
 * Площадка брони; null — бронь внесена вручную (в RealtyCalendar или в CRM), значка нет. Airbnb подключён
 * к RealtyCalendar календарём (iCal): площадки в брони часто нет, но в заметке есть ссылка на бронь Airbnb —
 * она надёжнее поля источника.
 */
export function bookingChannel(booking: ChannelSource): BookingChannel | null {
  if (airbnbReservation(booking.notes)) return AIRBNB;
  const origin = booking.origin?.trim();
  if (!origin) return null;
  const known = KNOWN_CHANNELS.find(({ pattern }) => pattern.test(origin));
  // [...origin] — по символам, а не по половинкам эмодзи.
  return known?.channel ?? { key: "OTHER", label: origin, letter: [...origin][0].toUpperCase(), background: "#E4E7EC", color: "#344054" };
}

export interface AirbnbReservation {
  /** Код брони в Airbnb (HMJAK9FFXD) — по нему бронь ищут в кабинете Airbnb. */
  code: string;
  url: string;
  /** Airbnb отдаёт в календарь только 4 последние цифры телефона гостя. */
  phoneLast4: string | null;
  /** Заметка без служебного текста календаря Airbnb. */
  rest: string;
}

// Только airbnb.com или airbnb.ru перед /hosting: ссылки вида airbnb.com.example.org за Airbnb не принимаем.
// Код брони — заглавные буквы и цифры; строчная буква после него значит, что пробел потерялся («…FFXDPhone»).
const AIRBNB_URL = /https:\/\/(?:www\.)?airbnb\.(?:com|ru)\/hosting\/reservations\/details\/([A-Z0-9]{6,12})(?![a-z0-9])/;
const AIRBNB_URL_LINE = /Reservation URL:\s*/i;
const PHONE_LAST_DIGITS = /Phone Number \(Last 4 Digits\):\s*([\d*]{4})/i;
/** Календарь Airbnb дописывает статус слитно с цифрами телефона: «0509Reserved». */
const ICAL_STATUS = /(?:^|\s)(?:Reserved|Not available)(?=\s|$)/gi;

export function airbnbReservation(notes: string | null): AirbnbReservation | null {
  const link = notes ? AIRBNB_URL.exec(notes) : null;
  if (!notes || !link) return null;
  const phone = PHONE_LAST_DIGITS.exec(notes)?.[1] ?? null;
  const rest = notes
    .replace(link[0], "")
    .replace(AIRBNB_URL_LINE, "")
    .replace(PHONE_LAST_DIGITS, " ")
    .replace(ICAL_STATUS, "")
    .replace(/\s+/g, " ")
    .trim();
  return { code: link[1], url: link[0], phoneLast4: phone && /^\d{4}$/.test(phone) ? phone : null, rest };
}

/** Кого показать на брони вместо безликого «Гость»: клиента, гостя, код брони Airbnb или площадку. */
export function bookingGuestName(booking: ChannelSource & Pick<BookingDto, "contact" | "guestName">): string | null {
  const name = booking.contact?.name ?? booking.guestName;
  if (name) return name;
  const airbnb = airbnbReservation(booking.notes);
  if (airbnb) return `Airbnb ${airbnb.code}`;
  return bookingChannel(booking)?.label ?? null;
}

/**
 * Доля оплаты для полоски под бронью, как в RealtyCalendar: предоплата от суммы. Airbnb берёт деньги с гостя
 * сам — его брони считаем оплаченными. null — суммы нет, полоску не рисуем.
 */
export function paidShare(booking: ChannelSource & Pick<BookingDto, "amount" | "prepayment">): number | null {
  if (bookingChannel(booking)?.key === "AIRBNB") return 1;
  const amount = booking.amount === null ? 0 : Number(booking.amount);
  const share = Number(booking.prepayment ?? 0) / amount;
  if (!(amount > 0) || !Number.isFinite(share)) return null;
  return Math.min(1, Math.max(0, share));
}
