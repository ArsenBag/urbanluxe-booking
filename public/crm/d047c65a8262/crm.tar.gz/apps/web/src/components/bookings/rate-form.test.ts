import { describe, expect, it } from "vitest";
import { formatNightPrice, initialRateForm, rateFormInvalid, rateFormSummary, toRateRequest, type RateForm } from "./rate-form";

const form = (patch: Partial<RateForm> = {}): RateForm => ({
  ...initialRateForm({ propertyId: "p1", from: "2026-11-06", to: "2026-11-08" }),
  ...patch,
});

describe("initialRateForm", () => {
  it("starts with the selected apartment and nights and changes nothing yet", () => {
    expect(form()).toEqual({
      propertyIds: ["p1"],
      from: "2026-11-06",
      to: "2026-11-08",
      weekdays: [],
      price: "",
      clearPrice: false,
      minStay: "",
      closed: "",
      closedToArrival: "",
      closedToDeparture: "",
    });
  });

  it("starts without apartments when opened from the toolbar", () => {
    expect(initialRateForm({ from: "2026-11-06", to: "2026-11-06" }).propertyIds).toEqual([]);
  });
});

describe("toRateRequest", () => {
  it("sends only the fields that were filled in", () => {
    expect(toRateRequest(form({ price: " 85 " }))).toEqual({
      propertyIds: ["p1"],
      from: "2026-11-06",
      to: "2026-11-08",
      weekdays: [],
      price: 85,
    });
  });

  it("turns a minimum stay of one night into no restriction", () => {
    expect(toRateRequest(form({ minStay: "1" })).minStay).toBeNull();
    expect(toRateRequest(form({ minStay: "3" })).minStay).toBe(3);
  });

  it("removes the price when «убрать цену» is ticked, whatever is typed", () => {
    expect(toRateRequest(form({ price: "85", clearPrice: true })).price).toBeNull();
  });

  it("never sends a number that is not finite (it would become null — removal — in JSON)", () => {
    expect(toRateRequest(form({ price: "1e400" }))).not.toHaveProperty("price");
  });

  it("maps close, open and arrival/departure choices to booleans", () => {
    const request = toRateRequest(form({ closed: "on", closedToArrival: "off", closedToDeparture: "on" }));

    expect(request).toMatchObject({ closed: true, closedToArrival: false, closedToDeparture: true });
  });
});

describe("rateFormSummary", () => {
  it("counts apartment-nights of the chosen weekdays", () => {
    // 6 и 7 ноября 2026 — пятница и суббота, 8-е — воскресенье.
    expect(rateFormSummary(form({ propertyIds: ["p1", "p2"], weekdays: [5, 6] }))).toEqual({ nights: 2, apartments: 2, total: 4 });
  });

  it("is empty while the period is not valid yet", () => {
    expect(rateFormSummary(form({ from: "2026-11-08", to: "2026-11-06" })).total).toBe(0);
    expect(rateFormSummary(form({ to: "" })).total).toBe(0);
  });

  it("does not count nights while the year is still being typed (0002 … 2026)", () => {
    expect(rateFormSummary(form({ from: "0002-11-06" })).total).toBe(0);
  });
});

describe("rateFormInvalid", () => {
  it("flags a price or minimum stay that is not a finite number", () => {
    expect(rateFormInvalid(form({ price: "1e400" }))).toBe(true);
    expect(rateFormInvalid(form({ minStay: "1e400" }))).toBe(true);
    expect(rateFormInvalid(form({ price: "85", minStay: "" }))).toBe(false);
  });
});

describe("formatNightPrice", () => {
  it("drops zero cents and keeps real ones", () => {
    expect(formatNightPrice("85.00")).toBe("85");
    expect(formatNightPrice("85.50")).toBe("85.5");
    expect(formatNightPrice("1200.25")).toBe("1200.25");
  });
});
