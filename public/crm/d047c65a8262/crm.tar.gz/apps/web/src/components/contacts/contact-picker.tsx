"use client";

import type { EntityRef } from "@crm/shared";
import { useState } from "react";
import { useContacts } from "@/lib/contacts";
import { formatPhones } from "@/lib/format";
import { useDebouncedValue } from "@/lib/use-debounced-value";

const SEARCH_DELAY_MS = 250;
const MIN_QUERY_LENGTH = 2;

interface ContactPickerProps {
  value: EntityRef | null;
  onChange: (contact: EntityRef | null) => void;
  onCreateNew: (name: string) => void;
  error?: string;
}

/** Поиск клиента по имени или телефону с возможностью создать нового. */
export function ContactPicker({ value, onChange, onCreateNew, error }: ContactPickerProps) {
  const [query, setQuery] = useState("");
  const debounced = useDebouncedValue(query.trim(), SEARCH_DELAY_MS);
  const shouldSearch = debounced.length >= MIN_QUERY_LENGTH;
  const results = useContacts(shouldSearch ? debounced : "", 1);

  if (value) {
    return (
      <div className="flex flex-col gap-1.5">
        <span className="text-sm font-medium">Клиент</span>
        <div className="flex h-9 items-center justify-between rounded-md border border-border bg-background px-3 text-sm">
          <span className="truncate">{value.name}</span>
          <button type="button" className="text-xs text-primary hover:underline" onClick={() => onChange(null)}>
            Изменить
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor="contact-picker" className="text-sm font-medium">
        Клиент
      </label>
      <input
        id="contact-picker"
        className="h-9 w-full rounded-md border border-border bg-surface px-3 text-sm outline-none focus:border-primary aria-invalid:border-danger"
        placeholder="Имя или телефон"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        aria-invalid={Boolean(error)}
        autoComplete="off"
      />
      {error && <p className="text-sm text-danger">{error}</p>}
      {shouldSearch && (
        <ul className="max-h-48 overflow-y-auto rounded-md border border-border">
          {results.data?.items.map((contact) => (
            <li key={contact.id}>
              <button
                type="button"
                className="flex w-full justify-between gap-2 px-3 py-2 text-left text-sm hover:bg-background"
                onClick={() => onChange({ id: contact.id, name: contact.name })}
              >
                <span className="truncate">{contact.name}</span>
                <span className="shrink-0 text-xs text-muted">{formatPhones(contact.phones)}</span>
              </button>
            </li>
          ))}
          <li>
            <button
              type="button"
              className="w-full px-3 py-2 text-left text-sm text-primary hover:bg-background"
              onClick={() => onCreateNew(query.trim())}
            >
              + Новый клиент «{query.trim()}»
            </button>
          </li>
        </ul>
      )}
    </div>
  );
}
