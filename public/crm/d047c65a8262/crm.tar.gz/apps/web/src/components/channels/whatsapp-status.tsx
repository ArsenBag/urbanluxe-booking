"use client";

import { CHANNEL_STATUS_LABELS, type ChannelsOverviewDto } from "@crm/shared";
import { ErrorAlert } from "@/components/ui/alert";

/** Как подключить WhatsApp через Green-API: шаги для администратора. */
function WhatsAppSetupHint({ webhookUrl }: { webhookUrl: string | null }) {
  return (
    <div className="max-w-2xl space-y-2 text-sm">
      <p>WhatsApp подключается через сервис Green-API (номер компании привязывается по QR-коду, как WhatsApp Web):</p>
      <ol className="list-decimal space-y-1 pl-5">
        <li>
          Зарегистрируйтесь на{" "}
          <a href="https://console.green-api.com" target="_blank" rel="noreferrer" className="text-primary hover:underline">
            console.green-api.com
          </a>{" "}
          и создайте инстанс (для проверки подойдёт бесплатный тариф Developer).
        </li>
        <li>В инстансе отсканируйте QR-код телефоном с WhatsApp компании: «Связанные устройства» → «Привязка устройства».</li>
        <li>
          В настройках инстанса укажите адрес вебхука{" "}
          {webhookUrl ? <code className="break-all">{webhookUrl}</code> : <span>(появится после развёртывания на сервер)</span>}, токен
          вебхука и включите уведомления о входящих и исходящих сообщениях и о состоянии инстанса.
        </li>
        <li>
          Впишите в <code>.env</code> сервера <code>GREEN_API_ID_INSTANCE</code>, <code>GREEN_API_TOKEN</code> и тот же токен вебхука в{" "}
          <code>GREEN_API_WEBHOOK_TOKEN</code>, затем перезапустите CRM.
        </li>
      </ol>
      <p className="text-muted">
        Не делайте массовых рассылок с этого номера: WhatsApp может его заблокировать. Отвечать клиентам — безопасно.
      </p>
    </div>
  );
}

export function WhatsAppStatus({ overview }: { overview: ChannelsOverviewDto }) {
  const channel = overview.channels.find((item) => item.type === "WHATSAPP");
  if (!overview.whatsappConfigured) {
    return <WhatsAppSetupHint webhookUrl={overview.whatsappWebhookUrl} />;
  }
  if (!channel) {
    return <p className="text-sm text-muted">Проверяем подключение к Green-API…</p>;
  }
  return (
    <div className="flex flex-col gap-2 text-sm">
      <div className="font-semibold">{channel.name}</div>
      <div className={channel.status === "CONNECTED" ? "text-green-600" : "text-danger"}>{CHANNEL_STATUS_LABELS[channel.status]}</div>
      {channel.lastError && <ErrorAlert message={channel.lastError} />}
      {overview.whatsappWebhookUrl && (
        <p className="text-xs text-muted">
          Адрес вебхука в Green-API: <code className="break-all">{overview.whatsappWebhookUrl}</code>
        </p>
      )}
    </div>
  );
}
