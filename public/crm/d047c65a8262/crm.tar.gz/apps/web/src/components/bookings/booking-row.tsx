"use client";

import { BOOKING_STATUS_LABELS, formatPhone, type BookingDto } from "@crm/shared";
import Link from "next/link";
import { GuestBadges } from "@/components/guests/guest-badges";
import { airbnbReservation, bookingChannel, bookingGuestName } from "@/lib/booking-channels";
import { formatMoney, formatStay } from "@/lib/format";
import { ChannelBadge } from "./channel-badge";

export const BOOKING_STATUS_COLORS: Record<BookingDto["status"], string> = {
  BOOKED: "text-green-600",
  REQUEST: "text-amber-600",
  CANCELED: "text-danger",
  DELETED: "text-muted",
};

/** Строка брони: объект, гость, даты, деньги, ссылки на сделку и в RealtyCalendar. */
export function BookingRow({ booking, showStatus = false }: { booking: BookingDto; showStatus?: boolean }) {
  const channel = bookingChannel(booking);
  const airbnb = airbnbReservation(booking.notes);
  // Airbnb берёт деньги с гостя сам: «к оплате» по его броням не показываем.
  const paidByAirbnb = channel?.key === "AIRBNB";
  const balance =
    !paidByAirbnb && booking.amount !== null && booking.prepayment !== null ? Number(booking.amount) - Number(booking.prepayment) : null;
  const notes = airbnb ? airbnb.rest : booking.notes;
  const hasOwnName = Boolean(booking.contact ?? booking.guestName);

  return (
    <li className="flex flex-wrap items-start justify-between gap-3 py-2.5">
      <div className="min-w-0">
        <div className="text-sm font-medium">
          {booking.property?.title ?? "Объект не указан"}
          {showStatus && <span className={`ml-2 text-xs ${BOOKING_STATUS_COLORS[booking.status]}`}>{BOOKING_STATUS_LABELS[booking.status]}</span>}
        </div>
        <div className="text-xs text-muted">
          {formatStay(booking.checkIn, booking.checkOut)}
          {booking.arrivalTime && ` · заезд ${booking.arrivalTime}`}
          {booking.departureTime && ` · выезд ${booking.departureTime}`}
        </div>
        <div className="text-sm">
          {channel && <ChannelBadge channel={channel} className="mr-1.5 align-[-2px]" />}
          {booking.contact ? (
            <Link href={`/contacts/${booking.contact.id}`} className="text-primary hover:underline">
              {booking.contact.name}
            </Link>
          ) : (
            (bookingGuestName(booking) ?? "Гость")
          )}
          {booking.guestPhone && (
            <a href={`tel:${booking.guestPhone}`} className="ml-2 text-xs text-muted hover:text-primary">
              {formatPhone(booking.guestPhone)}
            </a>
          )}
          {airbnb?.phoneLast4 && <span className="ml-2 text-xs text-muted">телефон …{airbnb.phoneLast4}</span>}
          {channel && hasOwnName && <span className="ml-2 text-xs text-muted">· {channel.label}</span>}
          {booking.guestBlacklisted && (
            <span className="ml-2 inline-flex align-[1px]">
              <GuestBadges vip={false} blacklisted />
            </span>
          )}
        </div>
        {notes && <div className="text-xs text-muted">{notes}</div>}
      </div>
      <div className="shrink-0 text-right text-xs">
        {booking.amount !== null && <div className="text-sm font-medium">{formatMoney(booking.amount, booking.currency)}</div>}
        {paidByAirbnb && <div className="text-green-600">оплачено через Airbnb</div>}
        {balance !== null && balance > 0 && <div className="text-amber-600">к оплате {formatMoney(String(balance), booking.currency)}</div>}
        {booking.deposit !== null && Number(booking.deposit) > 0 && <div className="text-muted">депозит {formatMoney(booking.deposit, booking.currency)}</div>}
        <div className="mt-1 flex justify-end gap-2">
          {booking.deal && (
            <Link href={`/deals/${booking.deal.id}`} className="text-primary hover:underline">
              Сделка
            </Link>
          )}
          {airbnb && (
            <a href={airbnb.url} target="_blank" rel="noreferrer" className="text-primary hover:underline">
              Airbnb ↗
            </a>
          )}
          {booking.rcUrl && /^https?:\/\//.test(booking.rcUrl) && (
            <a href={booking.rcUrl} target="_blank" rel="noreferrer" className="text-primary hover:underline">
              RealtyCalendar ↗
            </a>
          )}
          {booking.pmsUrl && (
            <a href={booking.pmsUrl} target="_blank" rel="noreferrer" className="text-primary hover:underline">
              PMS ↗
            </a>
          )}
          {booking.pmsError && (
            <span className="text-amber-600" title={booking.pmsError}>
              не отправлено в PMS
            </span>
          )}
        </div>
      </div>
    </li>
  );
}
