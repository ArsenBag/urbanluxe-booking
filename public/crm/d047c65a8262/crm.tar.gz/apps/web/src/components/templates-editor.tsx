"use client";

import {
  MAX_SHORTCUT_LENGTH,
  TEMPLATE_AUTOMATION_LABELS,
  TEMPLATE_AUTOMATIONS,
  templateFileBodyError,
  type ReplyTemplateDto,
  type TemplateAutomation,
} from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ApiRequestError } from "@/lib/api";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { SelectField, TextAreaField, TextField } from "@/components/ui/field";
import { TemplateFileField } from "@/components/template-file-field";
import { useCreateTemplate, useDeleteTemplate, useUpdateTemplate } from "@/lib/channels";

const MANUAL = "";
const AUTOMATION_OPTIONS = [
  { value: MANUAL, label: "Нет — только вручную (кнопка ⚡)" },
  ...TEMPLATE_AUTOMATIONS.map((kind) => ({ value: kind, label: TEMPLATE_AUTOMATION_LABELS[kind] })),
];

/** Форма шаблона: создание (без template) или редактирование. */
interface TemplateFormProps {
  template?: ReplyTemplateDto;
  onDone?: () => void;
  /** Есть — показываем «Отмена» (форма раскрыта на месте и её нужно закрыть без сохранения). */
  onCancel?: () => void;
  /** Автоотправку настраивает только администратор — сотруднику поле не показываем. */
  canSetAutomation: boolean;
}

export function TemplateForm({ template, onDone, onCancel, canSetAutomation }: TemplateFormProps) {
  const create = useCreateTemplate();
  const update = useUpdateTemplate();
  const remove = useDeleteTemplate();
  const [title, setTitle] = useState(template?.title ?? "");
  const [body, setBody] = useState(template?.body ?? "");
  const [shortcut, setShortcut] = useState(template?.shortcut ?? "");
  const [automation, setAutomation] = useState<string>(template?.automation ?? MANUAL);
  const error = create.error ?? update.error ?? remove.error;
  const shortcutError = error instanceof ApiRequestError ? error.fields.shortcut : undefined;
  // С файлом текст уходит подписью: лимит видно сразу, не дожидаясь ответа сервера.
  const captionError = template?.file ? templateFileBodyError(body) : null;
  const bodyError = captionError ?? (error instanceof ApiRequestError ? error.fields.body : undefined);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const input = { title, body, shortcut: shortcut || null, automation: (automation || null) as TemplateAutomation | null };
    if (template) {
      update.mutate({ id: template.id, input }, { onSuccess: onDone });
    } else {
      create.mutate(input, {
        onSuccess: () => {
          setTitle("");
          setBody("");
          setShortcut("");
          setAutomation(MANUAL);
          onDone?.();
        },
      });
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      {error && !shortcutError && !bodyError && <ErrorAlert message={error.message} />}
      <div className="grid gap-3 sm:grid-cols-[1fr_12rem]">
        <TextField label="Название" value={title} onChange={(e) => setTitle(e.target.value)} />
        <TextField
          label="Команда (после /)"
          placeholder="wifi"
          value={shortcut}
          error={shortcutError}
          maxLength={MAX_SHORTCUT_LENGTH}
          onChange={(e) => setShortcut(e.target.value.replace(/^\/+/, "").replace(/\s/g, ""))}
        />
      </div>
      <TextAreaField label="Текст" rows={4} value={body} error={bodyError ?? undefined} onChange={(e) => setBody(e.target.value)} />
      {template ? (
        <TemplateFileField template={template} />
      ) : (
        <p className="text-xs text-muted">Фото или видео к команде можно прикрепить после добавления — кнопкой «Изменить».</p>
      )}
      {canSetAutomation && (
        <SelectField
          label="Отправлять автоматически"
          value={automation}
          options={AUTOMATION_OPTIONS}
          onChange={(e) => setAutomation(e.target.value)}
        />
      )}
      <p className="text-xs text-muted">
        {automation && "Уйдёт гостю по броням из RealtyCalendar в тот мессенджер, где он писал последним. "}
        В тексте можно использовать <code>{"{имя}"}</code>, <code>{"{объект}"}</code>, <code>{"{заезд}"}</code>,{" "}
        <code>{"{выезд}"}</code> — данные брони берутся из текущего проживания или ближайшего заезда клиента.
      </p>
      <div className="flex justify-between gap-2">
        {template ? (
          <Button
            variant="ghost"
            className="text-danger"
            onClick={() => window.confirm(`Удалить команду «${template.title}»?`) && remove.mutate(template.id, { onSuccess: onDone })}
          >
            Удалить
          </Button>
        ) : (
          <span />
        )}
        <div className="flex gap-2">
          {onCancel && (
            <Button variant="ghost" onClick={onCancel}>
              Отмена
            </Button>
          )}
          <Button type="submit" disabled={!title.trim() || !body.trim() || captionError !== null || create.isPending || update.isPending}>
            {template ? "Сохранить" : "Добавить"}
          </Button>
        </div>
      </div>
    </form>
  );
}
