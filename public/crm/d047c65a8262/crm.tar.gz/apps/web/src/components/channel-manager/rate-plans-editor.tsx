"use client";

import { MAX_RATE_PLANS, type MarkupKind } from "@crm/shared";
import { Button } from "@/components/ui/button";
import { newPlanRow, removePlan, setPlanParent, type ListingForm, type PlanRow } from "./listing-form";

const CELL = "h-8 rounded-md border border-border bg-surface px-2 text-sm outline-none focus:border-primary aria-invalid:border-danger";

interface RatePlansEditorProps {
  form: ListingForm;
  onChange: (form: ListingForm) => void;
  /** Ошибки сервера по полям: «ratePlans.0.name» и т.п. */
  errors: Record<string, string>;
}

/**
 * Тарифы площадки, как в RealtyCalendar: название, от какой цены считать (базовой или другого тарифа —
 * «Невозвратный» от «Стандартного»), наценка в % или суммой (минус — скидка), сроки проживания, «закрыт».
 */
export function RatePlansEditor({ form, onChange, errors }: RatePlansEditorProps) {
  const update = (key: string, patch: Partial<PlanRow>) =>
    onChange({ ...form, plans: form.plans.map((plan) => (plan.key === key ? { ...plan, ...patch } : plan)) });
  const planErrors = form.plans.map((_, index) =>
    Object.entries(errors).flatMap(([field, message]) => (field.startsWith(`ratePlans.${index}.`) ? [message] : [])),
  );

  return (
    <div className="flex flex-col gap-2">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="text-left text-xs text-muted">
            <tr>
              <th className="pb-1 font-medium">Тариф</th>
              <th className="pb-1 font-medium">Считать от</th>
              <th className="pb-1 font-medium">Наценка</th>
              <th className="pb-1 font-medium">Ночей</th>
              <th className="pb-1 text-center font-medium">Закрыт</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {form.plans.map((plan, index) => {
              // Родителем может быть только основной тариф выше этого.
              const parents = form.plans.slice(0, index).filter((other) => other.parentKey === null);
              return (
                <tr key={plan.key} className="align-top">
                  <td className="py-1 pr-2">
                    <input
                      className={`${CELL} w-full ${plan.parentKey ? "pl-5" : ""}`}
                      value={plan.name}
                      placeholder="Название"
                      aria-label="Название тарифа"
                      aria-invalid={Boolean(errors[`ratePlans.${index}.name`])}
                      onChange={(e) => update(plan.key, { name: e.target.value })}
                    />
                    {planErrors[index].length > 0 && <p className="mt-0.5 text-xs text-danger">{planErrors[index][0]}</p>}
                  </td>
                  <td className="py-1 pr-2">
                    <select
                      className={`${CELL} w-full`}
                      value={plan.parentKey ?? ""}
                      aria-label="Считать от"
                      onChange={(e) => onChange(setPlanParent(form, plan.key, e.target.value || null))}
                    >
                      <option value="">цены ночи</option>
                      {parents.map((parent) => (
                        <option key={parent.key} value={parent.key}>
                          тарифа «{parent.name || "без названия"}»
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="py-1 pr-2">
                    <div className="flex gap-1">
                      <input
                        className={`${CELL} w-20`}
                        type="number"
                        step="0.01"
                        value={plan.markupValue}
                        aria-label="Наценка"
                        onChange={(e) => update(plan.key, { markupValue: e.target.value })}
                      />
                      <select
                        className={CELL}
                        value={plan.markupKind}
                        aria-label="Наценка в процентах или суммой"
                        onChange={(e) => update(plan.key, { markupKind: e.target.value as MarkupKind })}
                      >
                        <option value="PERCENT">%</option>
                        <option value="AMOUNT">$</option>
                      </select>
                    </div>
                  </td>
                  <td className="py-1 pr-2">
                    <div className="flex items-center gap-1 text-xs text-muted">
                      от
                      <input className={`${CELL} w-14`} type="number" min={1} value={plan.minNights} aria-label="Ночей от" onChange={(e) => update(plan.key, { minNights: e.target.value })} />
                      до
                      <input className={`${CELL} w-16`} type="number" min={1} value={plan.maxNights} aria-label="Ночей до" onChange={(e) => update(plan.key, { maxNights: e.target.value })} />
                    </div>
                  </td>
                  <td className="py-1 text-center">
                    <input type="checkbox" className="mt-2" checked={plan.closed} aria-label="Тариф закрыт" onChange={(e) => update(plan.key, { closed: e.target.checked })} />
                  </td>
                  <td className="py-1 pl-2">
                    <button type="button" className="mt-1.5 text-muted hover:text-danger" aria-label="Удалить тариф" onClick={() => onChange(removePlan(form, plan.key))}>
                      ✕
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {errors.ratePlans && <p className="text-sm text-danger">{errors.ratePlans}</p>}
      <div>
        <Button
          variant="secondary"
          className="h-8"
          disabled={form.plans.length >= MAX_RATE_PLANS}
          onClick={() => onChange({ ...form, plans: [...form.plans, newPlanRow()] })}
        >
          + Тариф
        </Button>
      </div>
    </div>
  );
}
