"use client";

import type { ReplyTemplateDto } from "@crm/shared";

interface TemplateMenuProps {
  templates: ReplyTemplateDto[];
  /** Подсвеченный пункт (выбор стрелками в режиме «/»); null — без подсветки. */
  activeIndex: number | null;
  emptyText: string;
  onPick: (template: ReplyTemplateDto) => void;
  onHover?: (index: number) => void;
}

/** Список шаблонов над полем ввода: по кнопке ⚡ и по команде «/». */
export function TemplateMenu({ templates, activeIndex, emptyText, onPick, onHover }: TemplateMenuProps) {
  return (
    <div
      role="listbox"
      aria-label="Шаблоны ответов"
      className="absolute bottom-full left-3 right-3 mb-2 max-h-72 overflow-y-auto rounded-lg border border-border bg-surface shadow-lg"
    >
      {templates.length === 0 && <p className="p-3 text-sm text-muted">{emptyText}</p>}
      {templates.map((template, index) => (
        <button
          key={template.id}
          type="button"
          role="option"
          aria-selected={index === activeIndex}
          className={`block w-full border-b border-border px-3 py-2 text-left last:border-0 hover:bg-background ${
            index === activeIndex ? "bg-background" : ""
          }`}
          // mousedown, а не click: поле ввода не теряет фокус и курсор.
          onMouseDown={(event) => {
            event.preventDefault();
            onPick(template);
          }}
          onMouseEnter={() => onHover?.(index)}
        >
          <span className="flex items-baseline gap-2">
            <span className="text-sm font-medium">{template.title}</span>
            {template.shortcut && <span className="font-mono text-xs text-primary">/{template.shortcut}</span>}
            {template.file && (
              <span className="min-w-0 truncate text-xs text-muted" title="Файл уйдёт вместе с текстом">
                📎 {template.file.fileName}
              </span>
            )}
          </span>
          <span className="block truncate text-xs text-muted">{template.body}</span>
        </button>
      ))}
    </div>
  );
}
