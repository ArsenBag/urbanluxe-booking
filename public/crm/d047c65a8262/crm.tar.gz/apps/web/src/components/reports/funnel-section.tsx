"use client";

import type { FunnelOwnerRow, FunnelReportDto, ReportPeriod } from "@crm/shared";
import { useState } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Section } from "@/components/ui/section";
import { formatCount, formatShare } from "@/lib/report-period";
import { useFunnelReport } from "@/lib/reports";
import { BarList, ReportSubheading, StatGrid, StatTile } from "./report-blocks";

const NO_OWNER = "Без ответственного";

export function FunnelSection({ period }: { period: ReportPeriod }) {
  const [pipelineId, setPipelineId] = useState<string | undefined>(undefined);
  const report = useFunnelReport(period, pipelineId);
  const pipelines = report.data?.pipelines ?? [];

  return (
    <Section
      title="Воронка"
      action={
        pipelines.length > 1 && (
          <select
            className="h-8 rounded-md border border-border bg-surface px-2 text-sm"
            // Пока грузится новая воронка, на экране старые данные — выбор берём из состояния, а не из ответа.
            value={pipelineId ?? report.data?.pipeline?.id ?? ""}
            onChange={(event) => setPipelineId(event.target.value)}
            aria-label="Воронка"
          >
            {pipelines.map((pipeline) => (
              <option key={pipeline.id} value={pipeline.id}>
                {pipeline.name}
              </option>
            ))}
          </select>
        )
      }
    >
      {report.isError && <ErrorAlert message={report.error.message} />}
      {report.isPending && <p className="text-sm text-muted">Загрузка…</p>}
      {report.data && (
        <div className={report.isPlaceholderData ? "opacity-60" : ""}>
          <FunnelReport data={report.data} />
        </div>
      )}
    </Section>
  );
}

function FunnelReport({ data }: { data: FunnelReportDto }) {
  const { totals } = data;
  return (
    <>
      <StatGrid>
        <StatTile label="Новых сделок" value={formatCount(totals.deals)} hint="созданы в периоде" />
        <StatTile
          label="Дошли до брони"
          value={formatCount(totals.booked)}
          hint={`${formatShare(totals.booked, totals.deals)} от новых · бронь отменили: ${formatCount(totals.cancelled)}`}
        />
        <StatTile label="Отказ до брони" value={formatCount(totals.lost)} hint={`${formatShare(totals.lost, totals.deals)} от новых`} />
        <StatTile label="Ещё в работе" value={formatCount(totals.open)} />
      </StatGrid>

      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <ReportSubheading>Где сейчас сделки периода</ReportSubheading>
          <BarList
            emptyText="Сделок в периоде нет"
            rows={data.stages.map((stage) => ({
              key: stage.id,
              label: stage.name,
              value: stage.deals,
              display: `${formatCount(stage.deals)} · ${formatShare(stage.deals, totals.deals)}`,
              swatch: stage.color,
            }))}
          />
        </div>
        <div>
          <ReportSubheading>Причины отказа до брони</ReportSubheading>
          <BarList
            emptyText="Отказов нет"
            rows={data.lostReasons.map((row, index) => ({
              key: `${index}:${row.reason}`,
              label: row.reason,
              value: row.deals,
              display: formatCount(row.deals),
            }))}
          />
        </div>
      </div>

      {data.owners.length > 0 && <OwnersTable owners={data.owners} />}
    </>
  );
}

function OwnersTable({ owners }: { owners: FunnelOwnerRow[] }) {
  const headers = ["Сделок", "До брони", "Бронь отменили", "Отказ", "Конверсия"];
  return (
    <div className="mt-6 overflow-x-auto">
      <ReportSubheading>По ответственным</ReportSubheading>
      <table className="w-full text-sm">
        <thead className="text-left text-muted">
          <tr>
            <th className="pb-2 font-medium">Ответственный</th>
            {headers.map((header) => (
              <th key={header} className="whitespace-nowrap pb-2 pl-3 text-right font-medium">
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="tabular-nums">
          {owners.map((row) => (
            <tr key={row.owner?.id ?? "none"} className="border-t border-border">
              <td className="py-1.5 pr-2">{row.owner?.name ?? NO_OWNER}</td>
              <td className="py-1.5 pl-3 text-right">{formatCount(row.deals)}</td>
              <td className="py-1.5 pl-3 text-right">{formatCount(row.booked)}</td>
              <td className="py-1.5 pl-3 text-right">{formatCount(row.cancelled)}</td>
              <td className="py-1.5 pl-3 text-right">{formatCount(row.lost)}</td>
              <td className="py-1.5 pl-3 text-right">{formatShare(row.booked, row.deals)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
