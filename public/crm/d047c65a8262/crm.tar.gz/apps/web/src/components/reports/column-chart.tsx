"use client";

import { useState, type KeyboardEvent, type PointerEvent } from "react";
import { formatDate } from "@/lib/format";
import { formatCount } from "@/lib/report-period";

export interface ChartSeries {
  key: string;
  label: string;
  /** CSS-цвет метки, например var(--chart-telegram). */
  color: string;
}

export interface ColumnDatum {
  date: string;
  /** Значения в порядке series. */
  values: number[];
}

interface ColumnChartProps {
  /** Подпись для экранного диктора и заголовок таблицы. */
  label: string;
  series: ChartSeries[];
  data: ColumnDatum[];
  /** Верх шкалы (например, все квартиры); по умолчанию — наибольший столбец. */
  max?: number;
  /** Строка-итог в подсказке под значениями серий. */
  describeTotal?: (total: number) => string;
}

const PLOT_HEIGHT_PX = 160;
const TOOLTIP_WIDTH_PX = 176;

const sumOf = (values: number[]) => values.reduce((total, value) => total + value, 0);

/** Узкие столбцы при длинном периоде: зазор 2px съел бы всю ширину. */
function columnGap(count: number): string {
  if (count <= 62) return "2px";
  if (count <= 120) return "1px";
  return "0px";
}

/** Столбцы по дням: серии стопкой, подсказка при наведении и с клавиатуры, таблица для точных чисел. */
export function ColumnChart({ label, series, data, max, describeTotal }: ColumnChartProps) {
  const [active, setActive] = useState<number | null>(null);
  const [showTable, setShowTable] = useState(false);
  const top = Math.max(max ?? 0, ...data.map((datum) => sumOf(datum.values)), 1);
  const activeDatum = active === null ? undefined : data[active];
  const totalText = activeDatum && describeTotal ? describeTotal(sumOf(activeDatum.values)) : "";

  return (
    <div>
      {series.length > 1 && <ChartLegend series={series} data={data} />}
      <div className="flex gap-2">
        <div className="flex w-8 shrink-0 flex-col justify-between text-right text-xs text-muted tabular-nums" style={{ height: PLOT_HEIGHT_PX }} aria-hidden>
          <span>{formatCount(top)}</span>
          <span>0</span>
        </div>
        <div className="relative min-w-0 flex-1">
          <ChartBars label={label} series={series} data={data} top={top} active={active} onActiveChange={setActive} />
          {activeDatum && active !== null && (
            <ChartTooltip series={series} datum={activeDatum} position={(active + 0.5) / data.length} totalText={totalText} />
          )}
          {data.length > 0 && (
            <div className="mt-1 flex justify-between text-xs text-muted" aria-hidden>
              <span>{formatDate(data[0]!.date)}</span>
              {data.length > 2 && <span>{formatDate(data[Math.floor(data.length / 2)]!.date)}</span>}
              <span>{formatDate(data[data.length - 1]!.date)}</span>
            </div>
          )}
        </div>
      </div>

      {/* Область всегда на месте: экранный диктор объявляет только изменения уже существующей области. */}
      <p className="sr-only" aria-live="polite">
        {activeDatum &&
          `${formatDate(activeDatum.date)}: ${series.map((item, index) => `${item.label} ${formatCount(activeDatum.values[index] ?? 0)}`).join(", ")}. ${totalText}`}
      </p>

      <button type="button" aria-expanded={showTable} className="mt-2 text-xs text-primary hover:underline" onClick={() => setShowTable((value) => !value)}>
        {showTable ? "Скрыть таблицу" : "Показать таблицей"}
      </button>
      {showTable && <ChartTable label={label} series={series} data={data} />}
    </div>
  );
}

function ChartLegend({ series, data }: { series: ChartSeries[]; data: ColumnDatum[] }) {
  return (
    <ul className="mb-3 flex flex-wrap gap-x-4 gap-y-1 text-sm">
      {series.map((item, index) => (
        <li key={item.key} className="flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm" style={{ background: item.color }} aria-hidden />
          <span className="text-muted">{item.label}</span>
          <span className="font-medium tabular-nums">{formatCount(sumOf(data.map((datum) => datum.values[index] ?? 0)))}</span>
        </li>
      ))}
    </ul>
  );
}

interface ChartBarsProps {
  label: string;
  series: ChartSeries[];
  data: ColumnDatum[];
  top: number;
  active: number | null;
  onActiveChange: (index: number | null) => void;
}

function ChartBars({ label, series, data, top, active, onActiveChange }: ChartBarsProps) {
  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (data.length === 0) return;
    if (event.key === "ArrowRight" || event.key === "ArrowLeft") {
      event.preventDefault();
      const step = event.key === "ArrowRight" ? 1 : -1;
      const from = active ?? (step > 0 ? -1 : data.length);
      onActiveChange(Math.min(data.length - 1, Math.max(0, from + step)));
    } else if (event.key === "Escape") {
      onActiveChange(null);
    }
  };
  // На сенсорном экране касание сразу даёт «уход» указателя — подсказку там убирает потеря фокуса.
  const onPointerLeave = (event: PointerEvent<HTMLDivElement>) => event.pointerType === "mouse" && onActiveChange(null);

  return (
    <div
      role="group"
      aria-label={`${label}. Стрелки влево и вправо показывают значения по дням.`}
      tabIndex={0}
      onKeyDown={onKeyDown}
      onBlur={() => onActiveChange(null)}
      onPointerLeave={onPointerLeave}
      className="relative flex items-end border-b border-border outline-none focus-visible:ring-2 focus-visible:ring-primary"
      style={{ height: PLOT_HEIGHT_PX, gap: columnGap(data.length) }}
    >
      <div className="pointer-events-none absolute inset-x-0 top-0 border-t border-border" aria-hidden />
      {data.map((datum, index) => (
        <div
          key={datum.date}
          onPointerEnter={() => onActiveChange(index)}
          className={`flex h-full min-w-0 flex-1 justify-center ${active === index ? "bg-foreground/5" : ""}`}
          aria-hidden
        >
          <div className="flex h-full w-full max-w-6 flex-col-reverse gap-[2px]">
            {datum.values.map((value, seriesIndex) => {
              if (value <= 0) return null;
              const isTop = datum.values.slice(seriesIndex + 1).every((rest) => rest <= 0);
              return (
                <div
                  key={series[seriesIndex]?.key ?? seriesIndex}
                  className={isTop ? "rounded-t-[4px]" : ""}
                  style={{ height: `${(value / top) * 100}%`, background: series[seriesIndex]?.color }}
                />
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

interface ChartTooltipProps {
  series: ChartSeries[];
  datum: ColumnDatum;
  /** Середина столбца, доля ширины графика 0…1. */
  position: number;
  totalText: string;
}

function ChartTooltip({ series, datum, position, totalText }: ChartTooltipProps) {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute bottom-full z-10 mb-2 rounded-md border border-border bg-surface px-3 py-2 text-sm shadow-md"
      style={{
        width: TOOLTIP_WIDTH_PX,
        left: `clamp(0px, calc(${position * 100}% - ${TOOLTIP_WIDTH_PX / 2}px), calc(100% - ${TOOLTIP_WIDTH_PX}px))`,
      }}
    >
      <div className="mb-1 text-xs text-muted">{formatDate(datum.date)}</div>
      {series.map((item, index) => (
        <div key={item.key} className="flex items-center gap-2">
          <span className="h-0.5 w-3 shrink-0 rounded-full" style={{ background: item.color }} />
          <span className="font-semibold tabular-nums">{formatCount(datum.values[index] ?? 0)}</span>
          <span className="truncate text-muted">{item.label}</span>
        </div>
      ))}
      {totalText && <div className="mt-1 text-xs text-muted">{totalText}</div>}
    </div>
  );
}

function ChartTable({ label, series, data }: { label: string; series: ChartSeries[]; data: ColumnDatum[] }) {
  return (
    <div className="mt-2 max-h-64 overflow-auto rounded-md border border-border">
      <table className="w-full text-sm">
        <caption className="sr-only">{label}</caption>
        <thead className="sticky top-0 bg-surface text-left text-muted">
          <tr>
            <th className="px-3 py-1.5 font-medium">Дата</th>
            {series.map((item) => (
              <th key={item.key} className="px-3 py-1.5 text-right font-medium">
                {item.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="tabular-nums">
          {data.map((datum) => (
            <tr key={datum.date} className="border-t border-border">
              <td className="px-3 py-1">{formatDate(datum.date)}</td>
              {series.map((item, index) => (
                <td key={item.key} className="px-3 py-1 text-right">
                  {formatCount(datum.values[index] ?? 0)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
