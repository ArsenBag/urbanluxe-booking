"use client";

import { CURRENCIES, type Currency, type DealDto, type UpdateDealInput } from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { SelectField, TextAreaField, TextField } from "@/components/ui/field";
import { ApiRequestError, formLevelError } from "@/lib/api";
import { useUpdateDeal } from "@/lib/deals";
import { useUserOptions } from "@/lib/users";

const SHOWN_FIELDS = ["title", "checkIn", "checkOut", "guests", "amount", "notes"];
const CURRENCY_OPTIONS = CURRENCIES.map((currency) => ({ value: currency, label: currency }));
const NO_OWNER = "";

const toNumberOrNull = (value: string) => (value.trim() === "" ? null : Number(value));

/** Форма параметров сделки. Отправляет только изменённые поля. */
export function DealDetailsForm({ deal }: { deal: DealDto }) {
  const updateDeal = useUpdateDeal(deal.id);
  const users = useUserOptions();
  const [title, setTitle] = useState(deal.title);
  const [checkIn, setCheckIn] = useState(deal.checkIn ?? "");
  const [checkOut, setCheckOut] = useState(deal.checkOut ?? "");
  const [guests, setGuests] = useState(deal.guests?.toString() ?? "");
  const [amount, setAmount] = useState(deal.amount ?? "");
  const [currency, setCurrency] = useState<Currency>(deal.currency);
  const [ownerId, setOwnerId] = useState(deal.owner?.id ?? NO_OWNER);
  const [notes, setNotes] = useState(deal.notes ?? "");
  const [savedAt, setSavedAt] = useState<number | null>(null);

  const error = updateDeal.error instanceof ApiRequestError ? updateDeal.error : null;
  const formMessage = formLevelError(updateDeal.error, SHOWN_FIELDS);

  function changedFields(): UpdateDealInput {
    const next = {
      title,
      checkIn: checkIn || null,
      checkOut: checkOut || null,
      guests: toNumberOrNull(guests),
      amount: toNumberOrNull(amount),
      currency,
      ownerId: ownerId || null,
      notes: notes.trim() || null,
    };
    const current = {
      title: deal.title,
      checkIn: deal.checkIn,
      checkOut: deal.checkOut,
      guests: deal.guests,
      amount: deal.amount === null ? null : Number(deal.amount),
      currency: deal.currency,
      ownerId: deal.owner?.id ?? null,
      notes: deal.notes,
    };
    return Object.fromEntries(
      Object.entries(next).filter(([key, value]) => value !== current[key as keyof typeof current]),
    ) as UpdateDealInput;
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const changes = changedFields();
    if (Object.keys(changes).length === 0) return;
    updateDeal.mutate(changes, { onSuccess: () => setSavedAt(Date.now()) });
  }

  const ownerOptions = [{ value: NO_OWNER, label: "Не назначен" }, ...(users.data ?? []).map((u) => ({ value: u.id, label: u.name }))];

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
      {formMessage && <ErrorAlert message={formMessage} />}
      <TextField label="Название" value={title} onChange={(e) => setTitle(e.target.value)} error={error?.fields.title} />
      <div className="grid grid-cols-3 gap-3">
        <TextField label="Заезд" type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} error={error?.fields.checkIn} />
        <TextField label="Выезд" type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} error={error?.fields.checkOut} />
        <TextField label="Гостей" type="number" min={1} value={guests} onChange={(e) => setGuests(e.target.value)} error={error?.fields.guests} />
      </div>
      <div className="grid grid-cols-3 gap-3">
        <TextField label="Сумма" type="number" min={0} step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} error={error?.fields.amount} />
        <SelectField label="Валюта" value={currency} options={CURRENCY_OPTIONS} onChange={(e) => setCurrency(e.target.value as Currency)} />
        <SelectField label="Ответственный" value={ownerId} options={ownerOptions} onChange={(e) => setOwnerId(e.target.value)} />
      </div>
      <TextAreaField label="Заметки" value={notes} onChange={(e) => setNotes(e.target.value)} error={error?.fields.notes} />
      <div className="flex items-center justify-end gap-3">
        {savedAt && !updateDeal.isPending && !updateDeal.isError && <span className="text-sm text-muted">Сохранено</span>}
        <Button type="submit" disabled={updateDeal.isPending}>
          Сохранить
        </Button>
      </div>
    </form>
  );
}
