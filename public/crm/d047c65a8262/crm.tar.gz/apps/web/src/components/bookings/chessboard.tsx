"use client";

import { isCrmOnlyBooking, type BookingDto } from "@crm/shared";
import { useCallback, useMemo, useState } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { useBookingRange, useProperties } from "@/lib/bookings";
import { tashkentDayKey } from "@/lib/format";
import { useRates } from "@/lib/rates";
import { useSession } from "@/lib/session";
import { BookingDetailsModal } from "./booking-details-modal";
import type { BookingDraft } from "./booking-form";
import { BookingFormModal } from "./booking-form-modal";
import { addDays, apartmentsOf, buildChessboardRows, daysOf, rateCellsByProperty, stayOfCells } from "./chessboard-layout";
import { ChessboardRow, DAY_WIDTH, isWeekend, NAME_WIDTH, type CellHandlers, type ColumnMark } from "./chessboard-row";
import { ChessboardToolbar, type SelectMode } from "./chessboard-toolbar";
import { RANGE_DAYS } from "./chessboard-window";
import type { RateDraft } from "./rate-form";
import { RateFormModal } from "./rate-form-modal";
import { selectionFirst, selectionLast, useCellSelection, type CellSelection } from "./use-cell-selection";
import { useChessboardWindow } from "./use-chessboard-window";

const WEEKDAYS = ["вс", "пн", "вт", "ср", "чт", "пт", "сб"];

type Dialog =
  | { kind: "create"; draft: BookingDraft }
  | { kind: "booking"; booking: BookingDto }
  | { kind: "rates"; draft: RateDraft }
  | null;

/**
 * Шахматка как в RealtyCalendar: ячейка — ночь, открывается с сегодняшнего дня, даты листаются тачпадом.
 * В свободных ячейках — цена ночи. Двойной щелчок по ячейке или протяжка мышью по нескольким — окно новой
 * брони, а в режиме «Цены» (только администратор) — окно цен и ограничений; щелчок по брони — её карточка
 * (брони, внесённые в CRM, там же правятся).
 */
export function Chessboard() {
  const today = tashkentDayKey(new Date());
  const [dialog, setDialog] = useState<Dialog>(null);
  const [mode, setMode] = useState<SelectMode>("booking");
  const isAdmin = useSession().data?.role === "ADMIN";
  const { scroller, rangeStart, visibleStart, handleScroll, goTo } = useChessboardWindow(today, DAY_WIDTH);
  const rangeEnd = addDays(rangeStart, RANGE_DAYS - 1);
  const bookings = useBookingRange(rangeStart, rangeEnd);
  const rates = useRates(rangeStart, rangeEnd);
  const properties = useProperties();
  const ratesMode = isAdmin && mode === "rates";
  const openDraft = useCallback(
    (selection: CellSelection) =>
      setDialog(
        ratesMode
          ? {
              kind: "rates",
              draft: {
                propertyId: selection.propertyId,
                from: addDays(selection.rangeStart, selectionFirst(selection)),
                to: addDays(selection.rangeStart, selectionLast(selection)),
              },
            }
          : {
              kind: "create",
              draft: { propertyId: selection.propertyId, ...stayOfCells(selection.rangeStart, selection.anchor, selection.focus) },
            },
      ),
    [ratesMode],
  );
  const cells = useCellSelection(openDraft);
  const { start, extend, clear } = cells;
  // Выделение, сделанное до сдвига отрисованного диапазона, указывает на другие ячейки — не показываем его.
  const selection = cells.selection?.rangeStart === rangeStart ? cells.selection : null;

  // Шахматка — тысячи ячеек: всё, что получают строки, держим неизменным между перерисовками.
  const dates = useMemo(() => daysOf(rangeStart, RANGE_DAYS), [rangeStart]);
  const marks = useMemo(() => columnMarks(dates, today), [dates, today]);
  const rows = useMemo(() => buildChessboardRows(properties.data ?? [], bookings.data ?? []), [properties.data, bookings.data]);
  // Ячейка считается по дате ночи: цены прошлого окна, пока грузятся новые, ложатся на свои ночи, без мигания.
  const rateCells = useMemo(() => rateCellsByProperty(rates.data?.days ?? [], rangeStart, RANGE_DAYS), [rates.data, rangeStart]);
  const handlers = useMemo<CellHandlers>(
    () => ({
      onCellDown: (propertyId, index) => start(rangeStart, propertyId, index),
      onCellEnter: (propertyId, index) => extend(rangeStart, propertyId, index),
      onCellDoubleClick: (propertyId, index) => openDraft({ rangeStart, propertyId, anchor: index, focus: index }),
      onOpenBooking: (booking) => setDialog({ kind: "booking", booking }),
    }),
    [rangeStart, start, extend, openDraft],
  );
  const apartments = apartmentsOf(properties.data ?? []);
  const isPending = bookings.isPending || properties.isPending;
  // Брони нового диапазона ещё в пути: на только что открытых днях занятые ночи пока выглядят свободными.
  const isStale = bookings.isPlaceholderData;
  const error = bookings.error ?? properties.error ?? rates.error;

  function closeDialog() {
    setDialog(null);
    clear();
  }

  return (
    <div className="flex flex-col gap-3">
      <ChessboardToolbar
        visibleStart={visibleStart}
        today={today}
        onGo={goTo}
        onCreate={() => setDialog({ kind: "create", draft: { checkIn: today, checkOut: addDays(today, 1) } })}
        mode={ratesMode ? "rates" : "booking"}
        onModeChange={setMode}
        onEditRates={isAdmin ? () => setDialog({ kind: "rates", draft: { from: today, to: today } }) : undefined}
      />
      {error && <ErrorAlert message={error.message} />}
      <div
        ref={scroller}
        onScroll={handleScroll}
        className="max-h-[calc(100vh-15rem)] select-none overflow-auto overscroll-x-contain rounded-xl border border-border bg-surface"
      >
        <div className={`transition-opacity ${isStale ? "opacity-60" : ""}`} style={{ width: NAME_WIDTH + DAY_WIDTH * RANGE_DAYS }}>
          <DateHeader dates={dates} today={today} />
          {isPending && <p className="sticky left-0 p-4 text-sm text-muted">Загрузка…</p>}
          {!isPending && rows.length === 0 && (
            <p className="sticky left-0 p-4 text-sm text-muted">Квартир пока нет. Они появятся, когда RealtyCalendar пришлёт брони по вебхуку.</p>
          )}
          {rows.map((row) => (
            <ChessboardRow
              key={row.key}
              row={row}
              from={rangeStart}
              days={RANGE_DAYS}
              marks={marks}
              selection={selection?.propertyId === row.property?.id ? selection : null}
              interactive={!isStale}
              handlers={handlers}
              rates={row.property ? rateCells.get(row.property.id) : undefined}
            />
          ))}
        </div>
      </div>
      {dialog?.kind === "create" && <BookingFormModal apartments={apartments} draft={dialog.draft} onClose={closeDialog} />}
      {dialog?.kind === "rates" && (
        <RateFormModal apartments={apartments} draft={dialog.draft} currency={rates.data?.currency ?? null} onClose={closeDialog} />
      )}
      {dialog?.kind === "booking" &&
        (isCrmOnlyBooking(dialog.booking) ? (
          <BookingFormModal apartments={apartments} booking={dialog.booking} onClose={closeDialog} />
        ) : (
          <BookingDetailsModal booking={dialog.booking} onClose={closeDialog} />
        ))}
    </div>
  );
}

/** Колонки сегодняшнего дня и выходных — подсветка под бронями. */
function columnMarks(dates: readonly string[], today: string): ColumnMark[] {
  return dates.flatMap((date, index) =>
    date === today ? [{ index, className: "bg-primary/10" }] : isWeekend(date) ? [{ index, className: "bg-black/[0.03]" }] : [],
  );
}

/** Строка дат; над первым числом месяца — название месяца, чтобы при прокрутке было видно границу. */
function DateHeader({ dates, today }: { dates: string[]; today: string }) {
  return (
    <div className="sticky top-0 z-20 flex border-b border-border bg-surface text-[11px] text-muted">
      <div className="sticky left-0 z-30 shrink-0 border-r border-border bg-surface px-3 py-2" style={{ width: NAME_WIDTH }}>
        Квартира
      </div>
      {dates.map((date) => (
        <div
          key={date}
          className={`relative shrink-0 border-l border-border pb-1 pt-4 text-center ${date === today ? "bg-primary/10 font-semibold text-primary" : isWeekend(date) ? "bg-black/[0.03]" : ""}`}
          style={{ width: DAY_WIDTH }}
        >
          {date.endsWith("-01") && <span className="absolute left-1 top-0.5 whitespace-nowrap text-[10px] font-medium text-foreground">{monthName(date)}</span>}
          <div>{Number(date.slice(8))}</div>
          <div>{WEEKDAYS[new Date(`${date}T00:00:00Z`).getUTCDay()]}</div>
        </div>
      ))}
    </div>
  );
}

const MONTH_FORMAT = new Intl.DateTimeFormat("ru-RU", { month: "long", timeZone: "UTC" });
const monthName = (date: string) => MONTH_FORMAT.format(new Date(`${date}T00:00:00Z`));
