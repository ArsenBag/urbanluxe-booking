import type { DealDto } from "@crm/shared";

/** Колонки канбана: id этапа → карточки в порядке сверху вниз. */
export type Columns = Record<string, DealDto[]>;

export function groupByStage(deals: DealDto[], stageIds: string[]): Columns {
  const columns: Columns = Object.fromEntries(stageIds.map((id) => [id, []]));
  for (const deal of deals) {
    columns[deal.stageId]?.push(deal);
  }
  for (const id of stageIds) {
    columns[id].sort((a, b) => a.position - b.position);
  }
  return columns;
}

/** Колонка, где лежит карточка; id самой колонки возвращается как есть. */
export function findStageOf(columns: Columns, id: string): string | null {
  if (id in columns) return id;
  return Object.keys(columns).find((stageId) => columns[stageId].some((deal) => deal.id === id)) ?? null;
}

/**
 * Перемещает карточку на место карточки overId (или в конец колонки, если overId — колонка).
 * Возвращает новые колонки, исходные не меняет.
 */
export function moveCard(columns: Columns, activeId: string, overId: string): Columns {
  const from = findStageOf(columns, activeId);
  const to = findStageOf(columns, overId);
  if (!from || !to || activeId === overId) return columns;

  const card = columns[from].find((deal) => deal.id === activeId) as DealDto;
  const source = columns[from].filter((deal) => deal.id !== activeId);
  const target = from === to ? source : [...columns[to]];
  const overIndex = target.findIndex((deal) => deal.id === overId);
  const originalOverIndex = columns[to].findIndex((deal) => deal.id === overId);
  // Внутри колонки при движении вниз карточка встаёт после той, над которой её отпустили.
  const movingDown = from === to && columns[from].findIndex((deal) => deal.id === activeId) < originalOverIndex;
  const insertAt = overIndex === -1 ? target.length : movingDown ? overIndex + 1 : overIndex;
  const updated = [...target.slice(0, insertAt), { ...card, stageId: to }, ...target.slice(insertAt)];

  return from === to ? { ...columns, [to]: updated } : { ...columns, [from]: source, [to]: updated };
}

export function neighboursOf(columns: Columns, stageId: string, dealId: string) {
  const column = columns[stageId];
  const index = column.findIndex((deal) => deal.id === dealId);
  return {
    prevDealId: index > 0 ? column[index - 1].id : null,
    nextDealId: index >= 0 && index < column.length - 1 ? column[index + 1].id : null,
  };
}

/** Сумма сделок колонки по валютам. */
export function columnTotals(deals: DealDto[]): Record<string, number> {
  const totals: Record<string, number> = {};
  for (const deal of deals) {
    if (deal.amount !== null) {
      totals[deal.currency] = (totals[deal.currency] ?? 0) + Number(deal.amount);
    }
  }
  return totals;
}
