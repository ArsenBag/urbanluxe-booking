import { staysLabel } from "@/lib/guest-labels";

const BADGE = "inline-flex shrink-0 items-center rounded-full px-2 py-0.5 text-[11px] leading-4 font-semibold";

interface GuestBadgesProps {
  vip: boolean;
  blacklisted: boolean;
  /** Сколько раз гость жил у нас; undefined или null — метку проживаний не показываем. */
  stays?: number | null;
  /** Короткие подписи — для узкого списка диалогов. */
  compact?: boolean;
}

/** Метки гостя: чёрный список (мигает), VIP, «Впервые» или число проживаний. */
export function GuestBadges({ vip, blacklisted, stays, compact = false }: GuestBadgesProps) {
  return (
    <>
      {blacklisted && (
        <span className={`${BADGE} bg-danger text-background motion-safe:animate-blink`} title="Гость в чёрном списке">
          {compact ? (
            <>
              <span aria-hidden>ЧС</span>
              <span className="sr-only">Чёрный список</span>
            </>
          ) : (
            "Чёрный список"
          )}
        </span>
      )}
      {vip && (
        <span className={`${BADGE} bg-amber-100 text-amber-900 dark:bg-amber-400/15 dark:text-amber-300`} title="VIP-гость">
          ★ VIP
        </span>
      )}
      {stays != null && (
        <span
          className={`${BADGE} ${stays === 0 ? "bg-primary/10 text-primary" : "bg-green-600/10 text-green-700 dark:text-green-400"}`}
          title={
            stays === 0
              ? "Завершённых проживаний в CRM нет. Если гость уже жил у нас, свяжите диалог с его бронью."
              : "Сколько раз гость жил у нас — по броням в CRM"
          }
        >
          {staysLabel(stays)}
        </span>
      )}
    </>
  );
}
