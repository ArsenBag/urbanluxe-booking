"use client";

import { MIN_FILTER_DATE } from "@crm/shared";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { addDays } from "./chessboard-layout";
import { CRM_ONLY_STRIPES, PAID_COLOR } from "./chessboard-row";
import { useVisibleStart, type VisibleStartStore } from "./use-chessboard-window";

const WEEK = 7;
/** Дальше шахматку не листаем: такие даты — опечатка в годе (и addDays на них ломается). */
const MAX_CHESSBOARD_DATE = "2099-12-31";
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

const isReachable = (date: string) => ISO_DATE.test(date) && date >= MIN_FILTER_DATE && date <= MAX_CHESSBOARD_DATE;

/** Что открывает выделение ночей: окно брони или окно цен. */
export type SelectMode = "booking" | "rates";

interface ChessboardToolbarProps {
  visibleStart: VisibleStartStore;
  today: string;
  onGo: (date: string) => void;
  onCreate: () => void;
  mode: SelectMode;
  onModeChange: (mode: SelectMode) => void;
  /** Окно цен без выделения; нет — сотрудник не администратор, цены он только видит. */
  onEditRates?: () => void;
}

/** Даты шахматки (стрелки на неделю, выбор даты, «Сегодня»), легенда, кнопки новой брони и цен. */
export function ChessboardToolbar({ visibleStart, today, onGo, onCreate, mode, onModeChange, onEditRates }: ChessboardToolbarProps) {
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <ChessboardNav visibleStart={visibleStart} today={today} onGo={onGo} />
        <div className="flex flex-wrap items-center gap-2">
          {onEditRates && (
            <>
              <ModeSwitch mode={mode} onChange={onModeChange} />
              <Button variant="secondary" className="h-8" onClick={onEditRates}>
                Цены на период
              </Button>
            </>
          )}
          <Button className="h-8" onClick={onCreate}>
            + Бронь
          </Button>
        </div>
      </div>
      <ChessboardLegend mode={mode} />
    </div>
  );
}

const MODES: Array<{ value: SelectMode; label: string }> = [
  { value: "booking", label: "Бронь" },
  { value: "rates", label: "Цены" },
];

/** Выделение мышью открывает окно брони или окно цен — как переключатель в RealtyCalendar. */
function ModeSwitch({ mode, onChange }: { mode: SelectMode; onChange: (mode: SelectMode) => void }) {
  return (
    <div className="flex items-center gap-1 text-xs text-muted" role="group" aria-label="Что открывает выделение ночей">
      Выделение:
      <div className="flex overflow-hidden rounded-md border border-border">
        {MODES.map((item) => (
          <button
            key={item.value}
            type="button"
            aria-pressed={mode === item.value}
            className={`h-8 px-3 text-sm ${mode === item.value ? "bg-primary text-white" : "bg-surface text-foreground hover:bg-black/5"}`}
            onClick={() => onChange(item.value)}
          >
            {item.label}
          </button>
        ))}
      </div>
    </div>
  );
}

/** Подписан на первый видимый день сам: при прокрутке перерисовывается только он, а не вся шахматка. */
function ChessboardNav({ visibleStart, today, onGo }: Pick<ChessboardToolbarProps, "visibleStart" | "today" | "onGo">) {
  const start = useVisibleStart(visibleStart);
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Button variant="secondary" className="h-8 px-2" onClick={() => onGo(addDays(start, -WEEK))} aria-label="Неделей раньше">
        ←
      </Button>
      <Button variant="secondary" className="h-8 px-2" onClick={() => onGo(addDays(start, WEEK))} aria-label="Неделей позже">
        →
      </Button>
      <DateJump value={start} onGo={onGo} />
      <Button variant="secondary" className="h-8" onClick={() => onGo(today)}>
        Сегодня
      </Button>
      <span className="text-xs text-muted">Даты листаются и тачпадом — влево и вправо</span>
    </div>
  );
}

/**
 * Поле даты со своим черновиком: пока год набирают с клавиатуры, поле отдаёт даты вроде 0002-10-12 —
 * их держим в поле, не переходя к ним, а переходим, когда дата стала настоящей.
 */
function DateJump({ value, onGo }: { value: string; onGo: (date: string) => void }) {
  const [draft, setDraft] = useState<string | null>(null);
  return (
    <input
      type="date"
      className="h-8 rounded-md border border-border bg-surface px-2 text-sm"
      value={draft ?? value}
      min={MIN_FILTER_DATE}
      max={MAX_CHESSBOARD_DATE}
      onChange={(e) => {
        const next = e.target.value;
        if (!isReachable(next)) {
          setDraft(next);
          return;
        }
        setDraft(null);
        onGo(next);
      }}
      onBlur={() => setDraft(null)}
      aria-label="Первый день на шахматке"
    />
  );
}

function LegendSwatch({ className, striped = false }: { className: string; striped?: boolean }) {
  return <span className={`inline-block h-3 w-5 rounded-sm ${className}`} style={striped ? { backgroundImage: CRM_ONLY_STRIPES } : undefined} />;
}

function ChessboardLegend({ mode }: { mode: SelectMode }) {
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted">
      <span className="inline-flex items-center gap-1.5">
        <LegendSwatch className="bg-primary" /> Забронировано
      </span>
      <span className="inline-flex items-center gap-1.5">
        <LegendSwatch className="bg-amber-500" /> Запрос
      </span>
      <span className="inline-flex items-center gap-1.5">
        <LegendSwatch className="bg-danger" /> ⛔ Гость из чёрного списка
      </span>
      <span className="inline-flex items-center gap-1.5">
        <LegendSwatch className="bg-primary" striped /> Только в CRM — внесите в RealtyCalendar
      </span>
      <span className="inline-flex items-center gap-1.5">
        <span className="relative inline-block h-3 w-5 overflow-hidden rounded-sm bg-primary">
          <span className="absolute inset-x-0 bottom-0 h-[3px] bg-white/85" />
          <span className="absolute bottom-0 left-0 h-[3px] w-1/2" style={{ backgroundColor: PAID_COLOR }} />
        </span>
        Полоска снизу — оплата (Airbnb — оплачено)
      </span>
      <span>Число в ячейке — цена ночи, «≥3» — минимум ночей, ✕ — продажи закрыты, красная черта — нет заезда/выезда</span>
      <span>
        Двойной щелчок по свободной ночи или протяжка мышью — {mode === "rates" ? "цены и ограничения" : "новая бронь"}
      </span>
    </div>
  );
}
