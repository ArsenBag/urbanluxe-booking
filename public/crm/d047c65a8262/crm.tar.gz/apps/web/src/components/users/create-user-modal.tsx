"use client";

import type { Role } from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { SelectField, TextField } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { ApiRequestError, formLevelError } from "@/lib/api";
import { useCreateUser } from "@/lib/users";
import { ROLE_OPTIONS } from "./role-options";

const SHOWN_FIELDS = ["name", "email", "password"];

const EMPTY_FORM = { name: "", email: "", password: "", role: "MANAGER" as Role };

export function CreateUserModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const createUser = useCreateUser();
  const [form, setForm] = useState(EMPTY_FORM);
  const error = createUser.error instanceof ApiRequestError ? createUser.error : null;
  const formMessage = formLevelError(createUser.error, SHOWN_FIELDS);

  function close() {
    setForm(EMPTY_FORM);
    createUser.reset();
    onClose();
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    createUser.mutate(form, { onSuccess: close });
  }

  return (
    <Modal title="Новый пользователь" open={open} onClose={close}>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
        {formMessage && <ErrorAlert message={formMessage} />}
        <TextField
          label="Имя"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          error={error?.fields.name}
        />
        <TextField
          label="Email"
          type="email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          error={error?.fields.email}
        />
        <TextField
          label="Пароль"
          type="password"
          autoComplete="new-password"
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          error={error?.fields.password}
        />
        <SelectField
          label="Роль"
          value={form.role}
          options={ROLE_OPTIONS}
          onChange={(e) => setForm({ ...form, role: e.target.value as Role })}
        />
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={close}>
            Отмена
          </Button>
          <Button type="submit" disabled={createUser.isPending}>
            Создать
          </Button>
        </div>
      </form>
    </Modal>
  );
}
