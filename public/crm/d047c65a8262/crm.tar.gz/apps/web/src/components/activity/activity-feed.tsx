import type { ActivityDto } from "@crm/shared";
import { ErrorAlert } from "@/components/ui/alert";
import { formatDateTime } from "@/lib/format";
import { describeActivity } from "./activity-labels";

interface ActivityFeedProps {
  entries: ActivityDto[] | undefined;
  isPending: boolean;
  error: Error | null;
}

export function ActivityFeed({ entries, isPending, error }: ActivityFeedProps) {
  if (error) return <ErrorAlert message={error.message} />;
  if (isPending) return <p className="text-sm text-muted">Загрузка…</p>;
  if (!entries?.length) return <p className="text-sm text-muted">Пока ничего не происходило.</p>;

  return (
    <ol className="flex flex-col gap-3">
      {entries.map((entry) => (
        <li key={entry.id} className="text-sm">
          <div>{describeActivity(entry)}</div>
          <div className="text-xs text-muted">
            {formatDateTime(entry.createdAt)}
            {entry.actor && ` · ${entry.actor.name}`}
          </div>
        </li>
      ))}
    </ol>
  );
}
