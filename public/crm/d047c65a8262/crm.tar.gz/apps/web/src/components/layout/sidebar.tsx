"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { Role } from "@crm/shared";
import { useInboxCounters } from "@/lib/inbox";

interface NavItem {
  href: string;
  label: string;
  /** Раздел появится на указанном этапе плана (docs/PLAN.md). */
  comingAtStage?: number;
  roles?: Role[];
}

const NAV_ITEMS: NavItem[] = [
  { href: "/", label: "Главная" },
  { href: "/inbox", label: "Сообщения" },
  { href: "/deals", label: "Сделки" },
  { href: "/contacts", label: "Клиенты" },
  { href: "/blacklist", label: "Чёрный список" },
  { href: "/tasks", label: "Задачи" },
  { href: "/bookings", label: "Брони" },
  { href: "/reports", label: "Отчёты", roles: ["ADMIN"] },
  { href: "/channel-manager", label: "Менеджер каналов", roles: ["ADMIN"] },
  { href: "/settings/channels", label: "Каналы", roles: ["ADMIN"] },
  { href: "/settings/integrations", label: "Интеграции", roles: ["ADMIN"] },
  { href: "/settings/commands", label: "Быстрые команды" },
  { href: "/settings/fields", label: "Поля карточек", roles: ["ADMIN"] },
  { href: "/settings/pipelines", label: "Воронки", roles: ["ADMIN"] },
  { href: "/settings/automation", label: "Автоперенос сделок", roles: ["ADMIN"] },
  { href: "/settings/users", label: "Пользователи", roles: ["ADMIN"] },
];

export function Sidebar({ role }: { role: Role }) {
  const pathname = usePathname();
  const counters = useInboxCounters();
  // На «Сообщениях»: новые неназначенные диалоги и мои диалоги с непрочитанными.
  const inboxBadge = (counters.data?.unassigned ?? 0) + (counters.data?.mineUnread ?? 0);
  const items = NAV_ITEMS.filter((item) => !item.roles || item.roles.includes(role));

  return (
    <nav aria-label="Основная навигация" className="flex flex-col gap-1">
      {items.map((item) => {
        if (item.comingAtStage) {
          return (
            <span
              key={item.href}
              className="flex items-center justify-between rounded-md px-3 py-2 text-sm text-muted"
              title={`Появится на этапе ${item.comingAtStage}`}
            >
              {item.label}
              <span className="text-xs">скоро</span>
            </span>
          );
        }
        const isActive = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            aria-current={isActive ? "page" : undefined}
            className={`rounded-md px-3 py-2 text-sm font-medium ${isActive ? "bg-primary/10 text-primary" : "hover:bg-background"}`}
          >
            <span className="flex items-center justify-between">
              {item.label}
              {item.href === "/inbox" && inboxBadge > 0 && (
                <span
                  className="rounded-full bg-primary px-1.5 text-xs font-semibold text-primary-foreground"
                  aria-label={`${inboxBadge} требуют внимания`}
                >
                  {inboxBadge}
                </span>
              )}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
