import type { ActivityDto } from "@crm/shared";
import { formatStay } from "@/lib/format";
import { movedSummary } from "@/lib/link-summary";

function bookingLabel(entry: ActivityDto): string {
  const { property, checkIn, checkOut } = entry.payload ?? {};
  const dates = typeof checkIn === "string" && typeof checkOut === "string" ? formatStay(checkIn, checkOut) : null;
  return [typeof property === "string" ? property : null, dates].filter(Boolean).join(", ");
}

/** « (1 бронь, 2 сделки)» — что переехало при объединении карточек. */
function mergedCountsLabel(entry: ActivityDto): string {
  const count = (key: string) => (typeof entry.payload?.[key] === "number" ? (entry.payload[key] as number) : 0);
  const moved = movedSummary({ bookings: count("bookings"), deals: count("deals"), conversations: count("conversations") });
  return moved ? ` (${moved})` : "";
}

/** Изменено одно это поле — например, только отметка VIP. */
function isOnlyField(entry: ActivityDto, field: string): boolean {
  const fields = entry.payload?.fields;
  return Array.isArray(fields) && fields.length === 1 && fields[0] === field;
}

function vipLabel(entry: ActivityDto): string {
  if (entry.payload?.vip === true) return "Клиент отмечен как VIP";
  if (entry.payload?.vip === false) return "Снята отметка VIP";
  return "Изменена отметка VIP";
}

/** Человекочитаемое описание события журнала. */
export function describeActivity(entry: ActivityDto): string {
  const title = typeof entry.payload?.title === "string" ? `«${entry.payload.title}»` : "";
  switch (entry.action) {
    case "contact.created":
      return "Создан клиент";
    case "contact.updated":
      return isOnlyField(entry, "vip") ? vipLabel(entry) : "Изменены данные клиента";
    case "contact.blacklisted":
      return "Клиент внесён в чёрный список";
    case "contact.unblacklisted":
      return "Клиент убран из чёрного списка";
    case "conversation.start":
      return entry.payload?.channel === "TELEGRAM" ? "Написали первыми в Telegram" : "Написали первыми в WhatsApp";
    case "deal.created":
      return `Создана сделка ${title}`;
    case "deal.updated":
      return "Изменена сделка";
    case "deal.moved":
      return `Сделка перенесена на этап «${String(entry.payload?.toStageName ?? "")}»`;
    case "deal.deleted":
      return `Удалена сделка ${title}`;
    case "task.created":
      return `Поставлена задача ${title}`;
    case "task.completed":
      return `Выполнена задача ${title}`;
    case "task.reopened":
      return `Задача снова открыта ${title}`;
    case "task.updated":
      return `Изменена задача ${title}`;
    case "task.deleted":
      return `Удалена задача ${title}`;
    case "booking.created":
      return entry.payload?.via === "CRM"
        ? `Бронь внесена в CRM: ${bookingLabel(entry)}`
        : `Бронь в RealtyCalendar: ${bookingLabel(entry)}`;
    case "booking.updated":
      return `Бронь изменена: ${bookingLabel(entry)}`;
    case "booking.canceled":
      return `Бронь отменена: ${bookingLabel(entry)}`;
    case "automation.sent":
      return entry.payload?.status === "FAILED"
        ? `Автосообщение не отправлено: ${title}`
        : `Отправлено автосообщение ${title}`;
    case "conversation.assigned":
      return entry.payload?.assignee ? `Диалог назначен: ${String(entry.payload.assignee)}` : "Диалог снят с сотрудника";
    case "conversation.closed":
      return "Диалог закрыт";
    case "conversation.reopened":
      return "Диалог открыт снова";
    case "conversation.linked":
      return typeof entry.payload?.checkIn === "string"
        ? `Диалог связан с бронью: ${bookingLabel(entry)}`
        : `Диалог связан со сделкой ${title}`;
    case "contact.merged":
      return `Объединён с другой карточкой клиента${mergedCountsLabel(entry)}`;
    case "deal.merged":
      return `Объединена со сделкой ${title}`;
    default:
      return entry.action;
  }
}
