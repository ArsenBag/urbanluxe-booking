"use client";

import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { TextField } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";

const QUICK_REASONS = ["Дорого", "Нет свободных дат", "Выбрал другой вариант", "Не отвечает"];

interface LostReasonModalProps {
  onConfirm: (reason: string) => void;
  onCancel: () => void;
}

/** Причина отказа при переносе сделки на этап «Отказ». Поле необязательное. */
export function LostReasonModal({ onConfirm, onCancel }: LostReasonModalProps) {
  const [reason, setReason] = useState("");

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    onConfirm(reason.trim());
  }

  return (
    <Modal title="Причина отказа" open onClose={onCancel}>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div className="flex flex-wrap gap-2">
          {QUICK_REASONS.map((quick) => (
            <Button key={quick} variant="secondary" className="h-7 px-2 text-xs" onClick={() => setReason(quick)}>
              {quick}
            </Button>
          ))}
        </div>
        <TextField label="Причина (необязательно)" value={reason} onChange={(e) => setReason(e.target.value)} autoFocus />
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={onCancel}>
            Отмена
          </Button>
          <Button type="submit">Перенести</Button>
        </div>
      </form>
    </Modal>
  );
}
