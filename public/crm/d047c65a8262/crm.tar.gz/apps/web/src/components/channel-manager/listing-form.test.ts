import type { ChannelListingDto } from "@crm/shared";
import { describe, expect, it } from "vitest";
import { initialListingForm, listingFormInvalid, previewPrices, removePlan, setPlanParent, toListingRequest, type ListingForm } from "./listing-form";

const PROPERTY_ID = "3f1c2a4e-8b7d-4c6e-9a1b-2d3e4f5a6b7c";

const saved: ChannelListingDto = {
  id: "l1",
  propertyId: PROPERTY_ID,
  channel: "BOOKING",
  enabled: true,
  externalHotelId: "17060443",
  externalRoomId: null,
  commissionPercent: "15.00",
  ratePlans: [
    { id: "p1", name: "Standard Rate", parentId: null, markupKind: "PERCENT", markupValue: "25.00", minNights: 1, maxNights: 365, closed: false },
    { id: "p2", name: "Non-refundable", parentId: "p1", markupKind: "PERCENT", markupValue: "-5.00", minNights: 1, maxNights: 365, closed: false },
  ],
  updatedAt: "2026-10-15T10:00:00.000Z",
};

describe("initialListingForm", () => {
  it("starts a new listing enabled, with one standard plan without markup", () => {
    const form = initialListingForm();

    expect(form).toMatchObject({ enabled: true, externalHotelId: "", externalRoomId: "", commissionPercent: "" });
    expect(form.plans).toHaveLength(1);
    expect(form.plans[0]).toMatchObject({ name: "Стандартный", parentKey: null, markupKind: "PERCENT", markupValue: "0" });
  });

  it("loads a saved listing with parents linked by plan id", () => {
    const form = initialListingForm(saved);

    expect(form.commissionPercent).toBe("15");
    expect(form.plans.map((plan) => [plan.id, plan.parentKey, plan.markupValue])).toEqual([
      ["p1", null, "25"],
      ["p2", "p1", "-5"],
    ]);
  });
});

describe("toListingRequest", () => {
  it("turns parents into list positions and text fields into numbers", () => {
    const request = toListingRequest(initialListingForm(saved), PROPERTY_ID, "BOOKING");

    expect(request).toMatchObject({
      propertyId: PROPERTY_ID,
      channel: "BOOKING",
      enabled: true,
      externalHotelId: "17060443",
      externalRoomId: "",
      commissionPercent: 15,
    });
    expect(request.ratePlans).toEqual([
      { id: "p1", name: "Standard Rate", parentIndex: null, markupKind: "PERCENT", markupValue: 25, minNights: 1, maxNights: 365, closed: false },
      { id: "p2", name: "Non-refundable", parentIndex: 0, markupKind: "PERCENT", markupValue: -5, minNights: 1, maxNights: 365, closed: false },
    ]);
  });

  it("sends an empty commission as none and empty nights as the defaults", () => {
    const form: ListingForm = {
      ...initialListingForm(),
      commissionPercent: " ",
    };
    form.plans[0] = { ...form.plans[0], markupValue: "", minNights: "", maxNights: "" };

    const request = toListingRequest(form, PROPERTY_ID, "AIRBNB");

    expect(request.commissionPercent).toBeNull();
    expect(request.ratePlans?.[0]).toMatchObject({ markupValue: 0, minNights: 1, maxNights: 365 });
  });
});

describe("removePlan", () => {
  it("removes the plan and turns its children into main plans", () => {
    const form = removePlan(initialListingForm(saved), "p1");

    expect(form.plans.map((plan) => [plan.id, plan.parentKey])).toEqual([["p2", null]]);
  });
});

describe("setPlanParent", () => {
  it("detaches the children of a plan that itself becomes a child (only one level)", () => {
    const form = initialListingForm(saved);
    const withThird: ListingForm = {
      ...form,
      plans: [{ ...form.plans[0], key: "p0", id: undefined, parentKey: null, name: "Weekly" }, ...form.plans],
    };

    const next = setPlanParent(withThird, "p1", "p0");

    expect(next.plans.map((plan) => [plan.key, plan.parentKey])).toEqual([
      ["p0", null],
      ["p1", "p0"],
      ["p2", null],
    ]);
  });
});

describe("listingFormInvalid", () => {
  it("flags numbers that cannot be read", () => {
    const form = initialListingForm(saved);

    expect(listingFormInvalid(form)).toBe(false);
    expect(listingFormInvalid({ ...form, commissionPercent: "1e400" })).toBe(true);
    expect(listingFormInvalid({ ...form, plans: [{ ...form.plans[0], markupValue: "abc" }] })).toBe(true);
  });
});

describe("previewPrices", () => {
  it("computes each plan from the base price, children from their parent", () => {
    expect(previewPrices(100, initialListingForm(saved).plans)).toEqual([125, 118.75]);
  });
});
