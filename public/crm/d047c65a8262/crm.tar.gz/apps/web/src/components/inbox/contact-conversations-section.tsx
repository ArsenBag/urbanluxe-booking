"use client";

import { CHANNEL_TYPE_LABELS } from "@crm/shared";
import Link from "next/link";
import { Section } from "@/components/ui/section";
import { useContactConversations } from "@/lib/inbox";
import { ChannelIcon } from "./channel-icon";

/** Чаты клиента со ссылками во «Входящие» (карточки клиента и сделки). Чатов нет — блок не показываем. */
export function ContactConversationsSection({ contactId }: { contactId: string }) {
  const conversations = useContactConversations(contactId);
  if (!conversations.data?.length) return null;
  return (
    <Section title="Переписка">
      <ul className="divide-y divide-border">
        {conversations.data.map((conversation) => (
          <li key={conversation.id} className="py-2">
            <Link href={`/inbox?c=${conversation.id}`} className="block hover:text-primary">
              <span className="inline-flex items-center gap-1.5 text-sm font-medium">
                <ChannelIcon type={conversation.channel.type} size={16} />
                {CHANNEL_TYPE_LABELS[conversation.channel.type]}
              </span>
              {conversation.handle && <span className="ml-2 text-xs text-muted">{conversation.handle}</span>}
              <span className="block truncate text-xs text-muted">{conversation.lastMessagePreview}</span>
            </Link>
          </li>
        ))}
      </ul>
    </Section>
  );
}
