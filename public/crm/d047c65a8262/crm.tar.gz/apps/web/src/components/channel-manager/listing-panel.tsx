"use client";

import { SALES_CHANNEL_LABELS, type ChannelListingDto, type PropertyDto, type SalesChannel } from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { TextField } from "@/components/ui/field";
import { ApiRequestError, formLevelError } from "@/lib/api";
import { useRemoveChannelListing, useSaveChannelListing } from "@/lib/channel-listings";
import { initialListingForm, listingFormInvalid, toListingRequest, type ListingForm } from "./listing-form";
import { PricePreview } from "./price-preview";
import { RatePlansEditor } from "./rate-plans-editor";

/** Как площадка называет объект и комнату (у сайта своих ID нет, у Airbnb комната — само объявление). */
const EXTERNAL_ID_LABELS: Record<SalesChannel, { hotel?: string; room?: string }> = {
  AIRBNB: { hotel: "ID объявления Airbnb" },
  BOOKING: { hotel: "Hotel ID", room: "Room ID" },
  OSTROVOK: { hotel: "ID отеля", room: "ID комнаты" },
  WEBSITE: {},
};
const SHOWN_FIELDS = ["externalHotelId", "externalRoomId", "commissionPercent"];

interface ListingPanelProps {
  apartment: PropertyDto;
  channel: SalesChannel;
  /** Сохранённая площадка; нет — площадка у квартиры ещё не настроена. */
  listing?: ChannelListingDto;
}

/** Правая колонка: площадка выбранной квартиры — подключение, комиссия, тарифы с наценкой и цены по ним. */
export function ListingPanel({ apartment, channel, listing }: ListingPanelProps) {
  const save = useSaveChannelListing();
  const [form, setForm] = useState<ListingForm>(() => initialListingForm(listing));
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const change = (patch: Partial<ListingForm>) => {
    setSavedAt(null);
    setForm((current) => ({ ...current, ...patch }));
  };
  const labels = EXTERNAL_ID_LABELS[channel];
  const error = save.error instanceof ApiRequestError ? save.error : null;
  const formMessage = formLevelError(save.error, [...SHOWN_FIELDS, ...Object.keys(error?.fields ?? {}).filter((field) => field.startsWith("ratePlans."))]);
  const invalid = listingFormInvalid(form);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    save.mutate(toListingRequest(form, apartment.id, channel), {
      // Новые тарифы получили id — дальше правим уже их, а не создаём заново.
      onSuccess: (saved) => {
        setForm(initialListingForm(saved));
        setSavedAt(Date.now());
      },
    });
  }

  return (
    <form onSubmit={handleSubmit} className="flex min-w-0 flex-col gap-4 rounded-xl border border-border bg-surface p-4" noValidate>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-lg font-semibold">
          {apartment.title} · {SALES_CHANNEL_LABELS[channel]}
        </h2>
        <span className="text-xs text-muted">{!listing ? "Не настроена" : listing.enabled ? "Включена" : "Выключена"}</span>
      </div>
      {formMessage && <ErrorAlert message={formMessage} />}
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={form.enabled} onChange={(e) => change({ enabled: e.target.checked })} />
        Площадка включена — цены и занятость уходят на неё
      </label>
      <div className="grid gap-3 sm:grid-cols-3">
        {labels.hotel && (
          <TextField label={labels.hotel} value={form.externalHotelId} onChange={(e) => change({ externalHotelId: e.target.value })} error={error?.fields.externalHotelId} />
        )}
        {labels.room && (
          <TextField label={labels.room} value={form.externalRoomId} onChange={(e) => change({ externalRoomId: e.target.value })} error={error?.fields.externalRoomId} />
        )}
        {channel !== "WEBSITE" && (
          <TextField
            label="Комиссия площадки, %"
            type="number"
            min={0}
            max={100}
            step="0.01"
            value={form.commissionPercent}
            onChange={(e) => change({ commissionPercent: e.target.value })}
            error={error?.fields.commissionPercent}
          />
        )}
      </div>
      <section className="flex flex-col gap-2">
        <h3 className="text-sm font-semibold">Тарифы</h3>
        <RatePlansEditor form={form} onChange={(next) => change(next)} errors={error?.fields ?? {}} />
      </section>
      <section className="flex flex-col gap-2">
        <h3 className="text-sm font-semibold">Цены на ближайшие ночи</h3>
        <PricePreview propertyId={apartment.id} plans={form.plans} />
      </section>
      <p className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900">
        Пока настройки только сохраняются: подключение к площадке и отправка цен заработают после подключения менеджера
        каналов Channex.
      </p>
      {invalid && <p className="text-sm text-danger">В числовых полях должно быть число.</p>}
      <div className="flex flex-wrap items-center justify-between gap-2">
        {listing ? <RemoveListingButton listingId={listing.id} /> : <span />}
        <div className="flex items-center gap-3">
          {savedAt !== null && <span className="text-sm text-muted">Сохранено</span>}
          <Button type="submit" disabled={save.isPending || invalid}>
            Сохранить
          </Button>
        </div>
      </div>
    </form>
  );
}

/** Убрать площадку у квартиры совсем, с подтверждением: настройки и тарифы удаляются. */
function RemoveListingButton({ listingId }: { listingId: string }) {
  const remove = useRemoveChannelListing();
  const [confirming, setConfirming] = useState(false);

  if (!confirming) {
    return (
      <Button variant="ghost" className="text-danger" onClick={() => setConfirming(true)}>
        Убрать площадку
      </Button>
    );
  }
  return (
    <div className="flex flex-wrap items-center gap-2 text-sm">
      {remove.error && <span className="text-danger">{remove.error.message}</span>}
      <span>Убрать площадку и её тарифы?</span>
      <Button variant="secondary" className="h-8 border-danger text-danger" disabled={remove.isPending} onClick={() => remove.mutate(listingId)}>
        Да, убрать
      </Button>
      <Button variant="ghost" className="h-8" onClick={() => setConfirming(false)}>
        Нет
      </Button>
    </div>
  );
}
