"use client";

import type { PipelineDto, StageAutomationDto } from "@crm/shared";
import { useState, type FormEvent, type ReactNode } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { SelectField, TextField } from "@/components/ui/field";
import { Section } from "@/components/ui/section";
import { ApiRequestError, formLevelError } from "@/lib/api";
import { useSaveStageAutomation } from "@/lib/stage-automation";
import {
  changePipeline,
  initialStageAutomationForm,
  settingsProblem,
  stageOptions,
  toStageAutomationInput,
  type StageAutomationForm,
} from "./stage-automation-form";

const SHOWN_FIELDS = [
  "checkInStageId",
  "checkInTime",
  "checkedInStageId",
  "checkOutSoonStageId",
  "checkOutSoonTime",
  "checkedOutStageId",
  "checkedOutTime",
];
const RULE_OFF = "Не переносить";

function Rule({ title, hint, children }: { title: string; hint: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-3 border-t border-border pt-4 first:border-t-0 first:pt-0">
      <div>
        <h3 className="text-sm font-semibold">{title}</h3>
        <p className="mt-1 text-sm text-muted">{hint}</p>
      </div>
      <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_9rem]">{children}</div>
    </div>
  );
}

/** Блок «Автоперенос сделок»: этапы и время правил по датам брони. */
export function StageAutomationEditor({ settings, pipelines }: { settings: StageAutomationDto; pipelines: PipelineDto[] }) {
  const save = useSaveStageAutomation();
  const [form, setForm] = useState<StageAutomationForm>(() => initialStageAutomationForm(settings, pipelines));
  const [savedForm, setSavedForm] = useState(form);
  const change = (patch: Partial<StageAutomationForm>) => setForm((current) => ({ ...current, ...patch }));
  const options = (emptyLabel: string) => stageOptions(pipelines, form.pipelineId, emptyLabel);
  const error = save.error instanceof ApiRequestError ? save.error : null;
  const formMessage = formLevelError(save.error, SHOWN_FIELDS);
  const dirty = JSON.stringify(form) !== JSON.stringify(savedForm);
  const problem = settingsProblem(form, pipelines);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const submitted = form;
    save.mutate(toStageAutomationInput(submitted), { onSuccess: () => setSavedForm(submitted) });
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
      {formMessage && <ErrorAlert message={formMessage} />}
      {problem && <ErrorAlert message={problem} />}
      <Section title="Общее">
        <div className="flex flex-col gap-3">
          <label className="flex items-start gap-2 text-sm">
            <input type="checkbox" className="mt-0.5" checked={form.enabled} onChange={(event) => change({ enabled: event.target.checked })} />
            <span>
              <span className="font-medium">Переносить сделки по датам брони автоматически</span>
              <span className="block text-muted">
                Каждое правило срабатывает по брони один раз и только вперёд по воронке: карточку, которую менеджер перенёс
                сам (вперёд или назад), автоматика больше не трогает. Время — ташкентское.
              </span>
            </span>
          </label>
          {pipelines.length > 1 && (
            <SelectField
              label="Воронка"
              value={form.pipelineId}
              options={pipelines.map((pipeline) => ({ value: pipeline.id, label: pipeline.name }))}
              onChange={(event) => setForm((current) => changePipeline(current, event.target.value))}
            />
          )}
        </div>
      </Section>
      <Section title="Правила">
        <div className="flex flex-col gap-4">
          <Rule
            title="1. Заезд сегодня"
            hint="В день заезда с указанного времени — к началу смены менеджеров. Бронь, пришедшая позже (днём или вечером), попадает сюда сразу. Бронь, сделанная после полуночи на прошедшую дату (гость заезжает ночью), — тоже сразу, а бронь после полуночи на наступивший день ждёт утра."
          >
            <SelectField label="Этап" value={form.checkInStageId} options={options(RULE_OFF)} onChange={(event) => change({ checkInStageId: event.target.value })} error={error?.fields.checkInStageId} />
            <TextField label="С какого времени" type="time" value={form.checkInTime} onChange={(event) => change({ checkInTime: event.target.value })} error={error?.fields.checkInTime} />
          </Rule>
          <Rule title="2. Гость заселён" hint="Ставит менеджер, когда гость заселился, — автоматически сделка сюда не переходит. Только из этого этапа сделка уходит в «Выезд завтра».">
            <SelectField label="Этап" value={form.checkedInStageId} options={options("Не выбран")} onChange={(event) => change({ checkedInStageId: event.target.value })} error={error?.fields.checkedInStageId} />
          </Rule>
          <Rule
            title="3. Выезд завтра"
            hint="Накануне выезда с указанного времени, только из этапа «Гость заселён». Пока менеджер не отметил заселение, карточка ждёт и переходит сразу после отметки."
          >
            <SelectField label="Этап" value={form.checkOutSoonStageId} options={options(RULE_OFF)} onChange={(event) => change({ checkOutSoonStageId: event.target.value })} error={error?.fields.checkOutSoonStageId} />
            <TextField label="С какого времени" type="time" value={form.checkOutSoonTime} onChange={(event) => change({ checkOutSoonTime: event.target.value })} error={error?.fields.checkOutSoonTime} />
          </Rule>
          <Rule title="4. Выехал" hint="В день выезда с указанного времени, из любого этапа до него.">
            <SelectField label="Этап" value={form.checkedOutStageId} options={options(RULE_OFF)} onChange={(event) => change({ checkedOutStageId: event.target.value })} error={error?.fields.checkedOutStageId} />
            <TextField label="С какого времени" type="time" value={form.checkedOutTime} onChange={(event) => change({ checkedOutTime: event.target.value })} error={error?.fields.checkedOutTime} />
          </Rule>
        </div>
      </Section>
      <div className="flex items-center gap-3">
        <Button type="submit" disabled={!dirty || save.isPending}>
          {save.isPending ? "Сохраняем…" : "Сохранить"}
        </Button>
        {save.isSuccess && !dirty && <span className="text-sm text-muted">Сохранено</span>}
      </div>
    </form>
  );
}
