import { ratePlanPrice, type ChannelListingDto, type ChannelListingRequest, type MarkupKind, type SalesChannel } from "@crm/shared";

/** Строка тарифа в окне: поля как их держат <input>. key — id сохранённого тарифа или временный ключ нового. */
export interface PlanRow {
  key: string;
  id?: string;
  name: string;
  /** Ключ родительского тарифа; null — от базовой цены ночи. */
  parentKey: string | null;
  markupKind: MarkupKind;
  markupValue: string;
  minNights: string;
  maxNights: string;
  closed: boolean;
}

export interface ListingForm {
  enabled: boolean;
  externalHotelId: string;
  externalRoomId: string;
  commissionPercent: string;
  plans: PlanRow[];
}

const DEFAULT_MAX_NIGHTS = 365;

/** Decimal строкой → как набрали бы руками: «25.00» → «25», «-5.50» → «-5.5». */
const decimalText = (value: string) => String(Number(value));

export function newPlanRow(patch: Partial<PlanRow> = {}): PlanRow {
  return {
    key: crypto.randomUUID(),
    name: "",
    parentKey: null,
    markupKind: "PERCENT",
    markupValue: "0",
    minNights: "1",
    maxNights: String(DEFAULT_MAX_NIGHTS),
    closed: false,
    ...patch,
  };
}

/** Окно площадки: сохранённая площадка или новая — включена, с одним тарифом без наценки. */
export function initialListingForm(listing?: ChannelListingDto): ListingForm {
  if (!listing) {
    return { enabled: true, externalHotelId: "", externalRoomId: "", commissionPercent: "", plans: [newPlanRow({ name: "Стандартный" })] };
  }
  return {
    enabled: listing.enabled,
    externalHotelId: listing.externalHotelId ?? "",
    externalRoomId: listing.externalRoomId ?? "",
    commissionPercent: listing.commissionPercent === null ? "" : decimalText(listing.commissionPercent),
    plans: listing.ratePlans.map((plan) => ({
      key: plan.id,
      id: plan.id,
      name: plan.name,
      parentKey: plan.parentId,
      markupKind: plan.markupKind,
      markupValue: decimalText(plan.markupValue),
      minNights: String(plan.minNights),
      maxNights: String(plan.maxNights),
      closed: plan.closed,
    })),
  };
}

/** Число из поля; пустое — fallback, не число — NaN (сервер отклонит, а окно не даст сохранить). */
function numberOr(text: string, fallback: number): number {
  return text.trim() === "" ? fallback : Number(text);
}

const unreadable = (text: string) => text.trim() !== "" && !Number.isFinite(Number(text));

/** В числовых полях то, что не прочитать как число, — сохранять нельзя. */
export function listingFormInvalid(form: ListingForm): boolean {
  return (
    unreadable(form.commissionPercent) ||
    form.plans.some((plan) => unreadable(plan.markupValue) || unreadable(plan.minNights) || unreadable(plan.maxNights))
  );
}

export function toListingRequest(form: ListingForm, propertyId: string, channel: SalesChannel): ChannelListingRequest {
  const indexByKey = new Map(form.plans.map((plan, index) => [plan.key, index]));
  return {
    propertyId,
    channel,
    enabled: form.enabled,
    externalHotelId: form.externalHotelId,
    externalRoomId: form.externalRoomId,
    commissionPercent: form.commissionPercent.trim() === "" ? null : Number(form.commissionPercent),
    ratePlans: form.plans.map((plan) => ({
      ...(plan.id ? { id: plan.id } : {}),
      name: plan.name,
      parentIndex: plan.parentKey === null ? null : (indexByKey.get(plan.parentKey) ?? null),
      markupKind: plan.markupKind,
      markupValue: numberOr(plan.markupValue, 0),
      minNights: numberOr(plan.minNights, 1),
      maxNights: numberOr(plan.maxNights, DEFAULT_MAX_NIGHTS),
      closed: plan.closed,
    })),
  };
}

/**
 * «Считать от» другого тарифа. Уровень один: если тариф сам был родителем, его дочерние становятся основными —
 * иначе сервер отклонит сохранение, а в окне они показывали бы «цены ночи».
 */
export function setPlanParent(form: ListingForm, key: string, parentKey: string | null): ListingForm {
  return {
    ...form,
    plans: form.plans.map((plan) => {
      if (plan.key === key) return { ...plan, parentKey };
      return parentKey !== null && plan.parentKey === key ? { ...plan, parentKey: null } : plan;
    }),
  };
}

/** Убрать тариф; его дочерние тарифы становятся основными (считаются от базовой цены). */
export function removePlan(form: ListingForm, key: string): ListingForm {
  return {
    ...form,
    plans: form.plans
      .filter((plan) => plan.key !== key)
      .map((plan) => (plan.parentKey === key ? { ...plan, parentKey: null } : plan)),
  };
}

/** Цены тарифов при данной базовой цене ночи — для предпросмотра в окне. */
export function previewPrices(base: number, plans: readonly PlanRow[]): number[] {
  const markupOf = (plan: PlanRow) => ({ markupKind: plan.markupKind, markupValue: numberOr(plan.markupValue, 0) });
  const byKey = new Map(plans.map((plan) => [plan.key, plan]));
  return plans.map((plan) => {
    const parent = plan.parentKey === null ? undefined : byKey.get(plan.parentKey);
    return ratePlanPrice(base, markupOf(plan), parent ? markupOf(parent) : null);
  });
}
