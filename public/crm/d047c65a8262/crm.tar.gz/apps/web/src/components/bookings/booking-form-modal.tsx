"use client";

import { BOOKING_STATUS_LABELS, MANUAL_BOOKING_STATUSES, nightsBetween, type BookingDto, type PropertyDto } from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { SelectField, TextAreaField, TextField } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { ApiRequestError, formLevelError } from "@/lib/api";
import { useCancelBooking, useCreateBooking, useUpdateBooking } from "@/lib/bookings";
import { pluralize } from "@/lib/format";
import { initialBookingForm, toBookingRequest, type BookingDraft, type BookingForm } from "./booking-form";
import { BookingGuestFields } from "./booking-guest-fields";
import { addDays } from "./chessboard-layout";

const SHOWN_FIELDS = ["propertyId", "checkIn", "checkOut", "arrivalTime", "departureTime", "contactId", "guestName", "guestPhone", "amount", "prepayment", "deposit", "notes"];
const STATUS_OPTIONS = MANUAL_BOOKING_STATUSES.map((status) => ({ value: status, label: BOOKING_STATUS_LABELS[status] }));

interface BookingFormModalProps {
  /** Квартиры из RealtyCalendar — на строки ЖК бронь не вносится. */
  apartments: PropertyDto[];
  /** Правка брони, внесённой в CRM; без неё — новая бронь из черновика. */
  booking?: BookingDto;
  draft?: BookingDraft;
  onClose: () => void;
}

/** Окно брони на шахматке: новая бронь или правка брони, внесённой в CRM. */
export function BookingFormModal({ apartments, booking, draft, onClose }: BookingFormModalProps) {
  const create = useCreateBooking();
  const update = useUpdateBooking(booking?.id ?? "");
  const save = booking ? update : create;
  const [form, setForm] = useState<BookingForm>(() => initialBookingForm(booking, draft));
  const change = (patch: Partial<BookingForm>) => setForm((current) => ({ ...current, ...patch }));
  const error = save.error instanceof ApiRequestError ? save.error : null;
  const formMessage = formLevelError(save.error, SHOWN_FIELDS);
  const nights = form.checkIn && form.checkOut > form.checkIn ? nightsBetween(form.checkIn, form.checkOut) : null;

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    save.mutate(toBookingRequest(form), { onSuccess: onClose });
  }

  function changeCheckIn(checkIn: string) {
    // Заезд передвинули на дату выезда или позже — выезд сдвигаем на следующий день, как в RealtyCalendar.
    change(checkIn && form.checkOut <= checkIn ? { checkIn, checkOut: addDays(checkIn, 1) } : { checkIn });
  }

  return (
    <Modal title={booking ? "Бронь, внесённая в CRM" : "Новая бронь"} open onClose={onClose} wide>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
        {formMessage && <ErrorAlert message={formMessage} />}
        <div className="grid grid-cols-2 gap-3">
          <SelectField
            label="Квартира"
            value={form.propertyId}
            options={[{ value: "", label: "Выберите квартиру" }, ...apartments.map((p) => ({ value: p.id, label: p.title }))]}
            onChange={(e) => change({ propertyId: e.target.value })}
            error={error?.fields.propertyId}
          />
          <SelectField
            label="Статус"
            value={form.status}
            options={STATUS_OPTIONS}
            onChange={(e) => change({ status: e.target.value as BookingForm["status"] })}
          />
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <TextField label="Заезд" type="date" value={form.checkIn} onChange={(e) => changeCheckIn(e.target.value)} error={error?.fields.checkIn} />
          <TextField label="Выезд" type="date" value={form.checkOut} min={form.checkIn ? addDays(form.checkIn, 1) : undefined} onChange={(e) => change({ checkOut: e.target.value })} error={error?.fields.checkOut} />
          <TextField label="Время заезда" type="time" value={form.arrivalTime} onChange={(e) => change({ arrivalTime: e.target.value })} error={error?.fields.arrivalTime} />
          <TextField label="Время выезда" type="time" value={form.departureTime} onChange={(e) => change({ departureTime: e.target.value })} error={error?.fields.departureTime} />
        </div>
        {nights !== null && (
          <p className="-mt-2 text-xs text-muted">
            {nights} {pluralize(nights, ["ночь", "ночи", "ночей"])}. Без времени — заезд с 15:00, выезд до 12:00.
          </p>
        )}
        <BookingGuestFields form={form} onChange={change} errors={error?.fields ?? {}} />
        <div className="grid grid-cols-3 gap-3">
          <TextField label="Сумма" type="number" min={0} step="0.01" value={form.amount} onChange={(e) => change({ amount: e.target.value })} error={error?.fields.amount} />
          <TextField label="Предоплата" type="number" min={0} step="0.01" value={form.prepayment} onChange={(e) => change({ prepayment: e.target.value })} error={error?.fields.prepayment} />
          <TextField label="Депозит" type="number" min={0} step="0.01" value={form.deposit} onChange={(e) => change({ deposit: e.target.value })} error={error?.fields.deposit} />
        </div>
        <TextAreaField label="Заметки" value={form.notes} onChange={(e) => change({ notes: e.target.value })} error={error?.fields.notes} rows={2} />
        <p className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900">
          Бронь сохранится только в CRM — в RealtyCalendar и на площадках её не будет. Внесите её и в RealtyCalendar, чтобы
          квартиру не продали на эти даты: когда бронь придёт оттуда, CRM свяжет их сама.
        </p>
        <div className="flex flex-wrap items-center justify-between gap-2">
          {booking ? <CancelBookingButton bookingId={booking.id} onCanceled={onClose} /> : <span />}
          <div className="flex gap-2">
            <Button variant="secondary" onClick={onClose}>
              Закрыть
            </Button>
            <Button type="submit" disabled={save.isPending || !form.propertyId}>
              {booking ? "Сохранить" : "Создать бронь"}
            </Button>
          </div>
        </div>
      </form>
    </Modal>
  );
}

/** Отмена с подтверждением: сделка брони уходит в «Отказ», задачи заезда и выезда снимаются. */
function CancelBookingButton({ bookingId, onCanceled }: { bookingId: string; onCanceled: () => void }) {
  const cancel = useCancelBooking(bookingId);
  const [confirming, setConfirming] = useState(false);

  if (!confirming) {
    return (
      <Button variant="ghost" className="text-danger" onClick={() => setConfirming(true)}>
        Отменить бронь
      </Button>
    );
  }
  return (
    <div className="flex flex-wrap items-center gap-2 text-sm">
      {cancel.error && <span className="text-danger">{cancel.error.message}</span>}
      <span>Отменить бронь? Сделка уйдёт в «Отказ».</span>
      <Button variant="secondary" className="h-8 border-danger text-danger" disabled={cancel.isPending} onClick={() => cancel.mutate(undefined, { onSuccess: onCanceled })}>
        Да, отменить
      </Button>
      <Button variant="ghost" className="h-8" onClick={() => setConfirming(false)}>
        Нет
      </Button>
    </div>
  );
}
