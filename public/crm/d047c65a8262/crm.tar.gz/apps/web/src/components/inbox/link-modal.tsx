"use client";

import type { LinkTarget } from "@crm/shared";
import { useState } from "react";
import { Modal } from "@/components/ui/modal";
import { LinkConfirm } from "./link-confirm";
import { LinkSearch } from "./link-search";

interface LinkModalProps {
  conversationId: string;
  open: boolean;
  onClose: () => void;
}

/** «Связать с бронью или сделкой» из диалога: поиск, затем подтверждение. */
export function LinkModal({ conversationId, open, onClose }: LinkModalProps) {
  return (
    <Modal title="Связать диалог с бронью или сделкой" open={open} onClose={onClose} wide>
      {open && <LinkFlow conversationId={conversationId} onClose={onClose} />}
    </Modal>
  );
}

function LinkFlow({ conversationId, onClose }: Omit<LinkModalProps, "open">) {
  const [target, setTarget] = useState<LinkTarget | null>(null);
  return target ? (
    <LinkConfirm conversationId={conversationId} target={target} onBack={() => setTarget(null)} onDone={onClose} />
  ) : (
    <LinkSearch onSelect={setTarget} />
  );
}
