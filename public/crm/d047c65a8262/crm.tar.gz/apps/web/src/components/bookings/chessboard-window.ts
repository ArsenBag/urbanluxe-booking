import { addDays, daysBetween } from "./chessboard-layout";

/** Сколько дней шахматка держит отрисованными: видимые дни и запас по бокам для прокрутки тачпадом (API отдаёт до 120). */
export const RANGE_DAYS = 112;
/** Запас дней слева от первого видимого дня. */
export const BUFFER_DAYS = 28;
/** Ближе к краю отрисованного — сдвигаем диапазон, чтобы прокрутка не упиралась. */
const EDGE_DAYS = 7;

/** Отрисованный диапазон: первый день и прокрутка, при которой на экране нужные дни. */
export interface ChessboardRange {
  rangeStart: string;
  scrollLeft: number;
}

/** Диапазон, в котором date — первый видимый день. */
export function rangeAt(date: string, dayWidth: number): ChessboardRange {
  return { rangeStart: addDays(date, -BUFFER_DAYS), scrollLeft: BUFFER_DAYS * dayWidth };
}

const edgePx = (dayWidth: number) => EDGE_DAYS * dayWidth;

/**
 * Первый видимый день. Полпикселя запаса: при масштабе страницы браузер может вернуть 1119,67 вместо 1120,
 * и тогда первым показался бы вчерашний день.
 */
export function firstVisible(rangeStart: string, scrollLeft: number, dayWidth: number): string {
  return addDays(rangeStart, Math.floor((scrollLeft + 0.5) / dayWidth));
}

/**
 * Первый видимый день после прокрутки; reanchorStart — подошли к краю, пора отрисовать диапазон с этого дня
 * (прокрутку сдвигает хук, чтобы на экране остались те же дни). На очень широком экране запаса не хватает,
 * и диапазон сдвигается только стрелками и выбором даты.
 */
export function afterScroll(
  rangeStart: string,
  scrollLeft: number,
  maxScrollLeft: number,
  dayWidth: number,
): { visibleStart: string; reanchorStart: string | null } {
  const visibleStart = firstVisible(rangeStart, scrollLeft, dayWidth);
  const roomToMove = maxScrollLeft >= 2 * BUFFER_DAYS * dayWidth;
  const nearEdge = scrollLeft < edgePx(dayWidth) || scrollLeft > maxScrollLeft - edgePx(dayWidth);
  return { visibleStart, reanchorStart: roomToMove && nearEdge ? rangeAt(visibleStart, dayWidth).rangeStart : null };
}

/** Переход к дате: прокрутить внутри отрисованного диапазона или отрисовать новый вокруг неё. */
export function jumpTarget(rangeStart: string, date: string, maxScrollLeft: number, dayWidth: number): ChessboardRange {
  const scrollLeft = daysBetween(rangeStart, date) * dayWidth;
  const inside = scrollLeft >= edgePx(dayWidth) && scrollLeft <= maxScrollLeft - edgePx(dayWidth);
  return inside ? { rangeStart, scrollLeft } : rangeAt(date, dayWidth);
}
