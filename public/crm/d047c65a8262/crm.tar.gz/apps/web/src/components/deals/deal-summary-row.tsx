"use client";

import type { DealDto } from "@crm/shared";
import Link from "next/link";
import { formatMoney, formatStay } from "@/lib/format";
import { StageBadge } from "./stage-badge";

export function DealSummaryRow({ deal }: { deal: DealDto }) {
  const details = [formatStay(deal.checkIn, deal.checkOut), formatMoney(deal.amount, deal.currency)].filter(Boolean);

  return (
    <li className="py-2">
      <Link href={`/deals/${deal.id}`} className="flex items-start justify-between gap-3 hover:text-primary">
        <span className="min-w-0">
          <span className="block truncate text-sm font-medium">{deal.title}</span>
          {details.length > 0 && <span className="block text-xs text-muted">{details.join(" · ")}</span>}
        </span>
        <StageBadge stageId={deal.stageId} />
      </Link>
    </li>
  );
}
