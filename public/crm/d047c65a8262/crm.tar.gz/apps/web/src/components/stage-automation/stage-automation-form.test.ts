import type { PipelineDto, StageAutomationDto } from "@crm/shared";
import { describe, expect, it } from "vitest";
import { changePipeline, initialStageAutomationForm, settingsProblem, stageOptions, toStageAutomationInput } from "./stage-automation-form";

const stage = (id: string, position: number, kind: "OPEN" | "WON" | "LOST" = "OPEN") => ({ id, name: `Этап ${id}`, position, color: "#94a3b8", kind });

const PIPELINES: PipelineDto[] = [
  { id: "sales", name: "Продажи", position: 0, stages: [stage("s1", 0)] },
  {
    id: "stays",
    name: "Бронирование",
    position: 1,
    stages: [stage("booked", 0), stage("check-in", 1), stage("checked-in", 2), stage("soon", 3), stage("out", 4), stage("lost", 5, "LOST")],
  },
];

const SAVED: StageAutomationDto = {
  enabled: true,
  checkInStageId: "check-in",
  checkInTime: "08:00",
  checkedInStageId: "checked-in",
  checkOutSoonStageId: null,
  checkOutSoonTime: "19:00",
  checkedOutStageId: "out",
  checkedOutTime: "12:00",
};

describe("initialStageAutomationForm", () => {
  it("shows the pipeline of the chosen stages and empty selects for rules that are off", () => {
    expect(initialStageAutomationForm(SAVED, PIPELINES)).toEqual({
      ...SAVED,
      pipelineId: "stays",
      checkOutSoonStageId: "",
    });
  });

  it("starts from the first pipeline when no stage is chosen", () => {
    const off = { ...SAVED, checkInStageId: null, checkedInStageId: null, checkedOutStageId: null };

    expect(initialStageAutomationForm(off, PIPELINES).pipelineId).toBe("sales");
  });
});

describe("changePipeline", () => {
  it("clears the stages of the previous pipeline and keeps the times", () => {
    const form = initialStageAutomationForm(SAVED, PIPELINES);

    expect(changePipeline(form, "sales")).toEqual({
      ...form,
      pipelineId: "sales",
      checkInStageId: "",
      checkedInStageId: "",
      checkOutSoonStageId: "",
      checkedOutStageId: "",
    });
  });
});

describe("stageOptions", () => {
  it("lists only working stages of the pipeline, after the empty choice", () => {
    expect(stageOptions(PIPELINES, "stays", "Не переносить").map((option) => option.value)).toEqual([
      "",
      "booked",
      "check-in",
      "checked-in",
      "soon",
      "out",
    ]);
  });

  it("is just the empty choice for an unknown pipeline", () => {
    expect(stageOptions(PIPELINES, "gone", "Не переносить")).toEqual([{ value: "", label: "Не переносить" }]);
  });
});

describe("toStageAutomationInput", () => {
  it("turns empty selects into switched-off rules and drops the pipeline", () => {
    expect(toStageAutomationInput(initialStageAutomationForm(SAVED, PIPELINES))).toEqual(SAVED);
  });
});

describe("settingsProblem", () => {
  const form = initialStageAutomationForm(SAVED, PIPELINES);

  it("is empty for stages in the pipeline order", () => {
    expect(settingsProblem(form, PIPELINES)).toBeNull();
  });

  it("explains that rules stopped when the stages were reordered in the pipeline", () => {
    const reordered = PIPELINES.map((pipeline) =>
      pipeline.id === "stays"
        ? { ...pipeline, stages: pipeline.stages.map((s) => (s.id === "check-in" ? { ...s, position: 9 } : s)) }
        : pipeline,
    );

    expect(settingsProblem(form, reordered)).toBe(
      "Этапы выбраны не по порядку воронки (должно быть: заезд сегодня → заселён → выезд завтра → выехал). Пока порядок не исправлен, автоперенос не работает.",
    );
  });

  it("points at a chosen stage that now closes the deal or was removed", () => {
    const closing = PIPELINES.map((pipeline) =>
      pipeline.id === "stays" ? { ...pipeline, stages: pipeline.stages.map((s) => (s.id === "out" ? { ...s, kind: "WON" as const } : s)) } : pipeline,
    );

    expect(settingsProblem(form, closing)).toBe("Один из выбранных этапов удалён или закрывает сделку — выберите другой.");
    expect(settingsProblem({ ...form, checkedOutStageId: "gone" }, PIPELINES)).toBe(
      "Один из выбранных этапов удалён или закрывает сделку — выберите другой.",
    );
  });
});
