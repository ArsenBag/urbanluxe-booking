import { describe, expect, it } from "vitest";
import {
  addDays,
  apartmentsOf,
  assignLanes,
  barFor,
  buildChessboardRows,
  daysBetween,
  daysOf,
  groupApartmentsByComplex,
  rateCellsByProperty,
  stayOfCells,
} from "./chessboard-layout";

describe("rateCellsByProperty", () => {
  const day = (propertyId: string, date: string) => ({ propertyId, date, price: "85.00" });

  it("puts each night into its apartment at the cell index of the window", () => {
    const cells = rateCellsByProperty([day("a", "2026-11-01"), day("a", "2026-11-03"), day("b", "2026-11-02")], "2026-11-01", 5);

    expect(cells.get("a")?.map((cell) => cell.index)).toEqual([0, 2]);
    expect(cells.get("b")?.map((cell) => cell.index)).toEqual([1]);
  });

  it("skips nights outside the window", () => {
    const cells = rateCellsByProperty([day("a", "2026-10-31"), day("a", "2026-11-06")], "2026-11-01", 5);

    expect(cells.get("a")).toBeUndefined();
  });
});

describe("groupApartmentsByComplex", () => {
  it("groups apartments by complex in natural code order, unknown complex last", () => {
    const groups = groupApartmentsByComplex([
      { id: "1", title: "U-100", complex: "U-Tower" },
      { id: "2", title: "Modera-294", complex: "Modera Towers" },
      { id: "3", title: "U-13", complex: "U-Tower" },
      { id: "4", title: "Объект 313432", complex: null },
    ]);

    expect(groups.map((group) => [group.title, group.items.map((item) => item.title)])).toEqual([
      ["Modera Towers", ["Modera-294"]],
      ["U-Tower", ["U-13", "U-100"]],
      ["Без ЖК", ["Объект 313432"]],
    ]);
  });
});

describe("daysOf", () => {
  it("lists consecutive dates", () => {
    expect(daysOf("2026-10-30", 4)).toEqual(["2026-10-30", "2026-10-31", "2026-11-01", "2026-11-02"]);
  });
});

describe("daysBetween", () => {
  it("counts days across months, negative backwards", () => {
    expect(daysBetween("2026-10-30", "2026-11-02")).toBe(3);
    expect(daysBetween("2026-11-02", "2026-10-30")).toBe(-3);
  });
});

describe("addDays", () => {
  it("moves across months", () => {
    expect(addDays("2026-10-31", 1)).toBe("2026-11-01");
    expect(addDays("2026-11-01", -1)).toBe("2026-10-31");
  });
});

describe("barFor", () => {
  const from = "2026-11-01";
  const days = 14;

  it("fills one cell per night, like RealtyCalendar: check-in on the 12th and check-out on the 13th is one cell", () => {
    expect(barFor({ checkIn: "2026-11-12", checkOut: "2026-11-13" }, from, days)).toEqual({
      start: 11,
      length: 1,
      cutStart: false,
      cutEnd: false,
    });
  });

  it("spans from the check-in cell up to the cell before check-out", () => {
    expect(barFor({ checkIn: "2026-11-03", checkOut: "2026-11-06" }, from, days)).toEqual({
      start: 2,
      length: 3,
      cutStart: false,
      cutEnd: false,
    });
  });

  it("clips a booking that started before the window", () => {
    expect(barFor({ checkIn: "2026-10-29", checkOut: "2026-11-02" }, from, days)).toEqual({
      start: 0,
      length: 1,
      cutStart: true,
      cutEnd: false,
    });
  });

  it("clips a booking that ends after the window", () => {
    expect(barFor({ checkIn: "2026-11-13", checkOut: "2026-11-20" }, from, days)).toEqual({
      start: 12,
      length: 2,
      cutStart: false,
      cutEnd: true,
    });
  });

  it("returns null outside the window, including a check-out on the first day", () => {
    expect(barFor({ checkIn: "2026-12-01", checkOut: "2026-12-03" }, from, days)).toBeNull();
    expect(barFor({ checkIn: "2026-10-30", checkOut: "2026-11-01" }, from, days)).toBeNull();
  });
});

describe("stayOfCells", () => {
  it("turns selected night cells into check-in and check-out dates in either drag direction", () => {
    expect(stayOfCells("2026-10-10", 2, 2)).toEqual({ checkIn: "2026-10-12", checkOut: "2026-10-13" });
    expect(stayOfCells("2026-10-10", 4, 2)).toEqual({ checkIn: "2026-10-12", checkOut: "2026-10-15" });
  });
});

describe("apartmentsOf", () => {
  it("keeps only RealtyCalendar apartments in natural code order", () => {
    const list = apartmentsOf([
      { id: "a", title: "U-100", rcId: 100 },
      { id: "c", title: "U-Tower", rcId: null },
      { id: "b", title: "U-13", rcId: 13 },
    ]);
    expect(list.map((property) => property.title)).toEqual(["U-13", "U-100"]);
  });
});

describe("assignLanes", () => {
  it("keeps back-to-back stays in one lane and splits overlapping ones", () => {
    const a = { id: "a", checkIn: "2026-10-01", checkOut: "2026-10-05" };
    const b = { id: "b", checkIn: "2026-10-05", checkOut: "2026-10-07" };
    const c = { id: "c", checkIn: "2026-10-03", checkOut: "2026-10-06" };
    const { items, lanes } = assignLanes([c, b, a]);

    expect(lanes).toBe(2);
    expect(Object.fromEntries(items.map((item) => [item.booking.id, item.lane]))).toEqual({ a: 0, c: 1, b: 0 });
  });

  it("uses one lane when there are no bookings", () => {
    expect(assignLanes([])).toEqual({ items: [], lanes: 1 });
  });
});

describe("buildChessboardRows", () => {
  const apt = (id: string, title: string) => ({ id, title, rcId: Number(id.replace(/\D/g, "")) || 1 });
  const complex = { id: "c1", title: "U-Tower", rcId: null };
  const properties = [apt("p100", "U-100"), apt("p13", "U-13"), apt("p37", "U-37"), complex];

  it("lists every apartment in natural code order, even without bookings", () => {
    const rows = buildChessboardRows(properties, []);
    expect(rows.map((row) => row.property?.title)).toEqual(["U-13", "U-37", "U-100"]);
  });

  it("adds complex and no-property rows below, only when they have bookings", () => {
    const rows = buildChessboardRows(properties, [
      { id: "1", property: complex },
      { id: "2", property: null },
      { id: "3", property: properties[0] },
    ]);

    expect(rows.map((row) => [row.property?.title ?? "none", row.unresolved, row.bookings.length])).toEqual([
      ["U-13", false, 0],
      ["U-37", false, 0],
      ["U-100", false, 1],
      ["U-Tower", true, 1],
      ["none", true, 1],
    ]);
  });

  it("shows an apartment that is missing from the property list but has a booking", () => {
    const fresh = apt("p51", "U-51");
    const rows = buildChessboardRows(properties, [{ id: "1", property: fresh }]);
    expect(rows.map((row) => row.property?.title)).toContain("U-51");
  });
});
