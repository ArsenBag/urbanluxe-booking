import type { ChannelType } from "@crm/shared";

/** Фирменный цвет круга: по нему мессенджер узнаётся с первого взгляда. */
const BACKGROUNDS: Record<ChannelType, string> = {
  TELEGRAM: "#229ED9",
  WHATSAPP: "#25D366",
  INSTAGRAM: "linear-gradient(45deg, #F58529, #DD2A7B 55%, #8134AF)",
};

/** Белый символ на круге, viewBox 24×24: самолётик, телефонная трубка, камера. */
function Glyph({ type }: { type: ChannelType }) {
  if (type === "TELEGRAM") {
    return (
      <path
        fill="currentColor"
        d="M5.2 11.5 17.6 6.6c.6-.2 1.1.2.9.8l-2.1 10c-.2.7-.8.9-1.3.5l-3.2-2.4-1.6 1.5c-.2.2-.5.1-.5-.2l.2-2.5 5.6-5c.2-.2 0-.4-.3-.2l-6.9 4.3-3-.9c-.6-.2-.6-.7.1-1Z"
      />
    );
  }
  if (type === "WHATSAPP") {
    return (
      <path
        fill="currentColor"
        d="M8.4 6.4c.4-.3.9-.2 1.1.2l1.3 2.2c.2.4.1.8-.2 1.1l-.8.8c.6 1.3 1.6 2.4 2.9 3l.8-.8c.3-.3.8-.4 1.1-.2l2.2 1.3c.4.2.5.8.2 1.1l-1 1.1c-.6.6-1.6.9-2.4.6-2.9-1-5.2-3.4-6.2-6.3-.3-.9 0-1.8.6-2.4l.4-.7Z"
      />
    );
  }
  return (
    <g fill="none" stroke="currentColor" strokeWidth="1.8">
      <rect x="6" y="6" width="12" height="12" rx="3.5" />
      <circle cx="12" cy="12" r="2.8" />
      <circle cx="15.6" cy="8.4" r="0.6" fill="currentColor" stroke="none" />
    </g>
  );
}

interface ChannelIconProps {
  type: ChannelType;
  size?: number;
  className?: string;
}

/** Значок мессенджера: круг фирменного цвета с белым символом. Рядом всегда есть подпись — для дикторов скрыт. */
export function ChannelIcon({ type, size = 14, className = "" }: ChannelIconProps) {
  return (
    <span
      className={`inline-flex shrink-0 items-center justify-center rounded-full text-white ${className}`}
      style={{ width: size, height: size, background: BACKGROUNDS[type] }}
      aria-hidden
    >
      <svg viewBox="0 0 24 24" width={size} height={size}>
        <Glyph type={type} />
      </svg>
    </span>
  );
}
