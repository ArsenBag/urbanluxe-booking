import type { ReplyTemplateDto } from "@crm/shared";
import { describe, expect, it } from "vitest";
import { attachmentAfterTemplate, attachmentInfo, type ComposerAttachment } from "./composer-attachment";

const video = { id: "f-1", fileName: "Вход.mp4", mimeType: "video/mp4", size: 1_400_000 };

function template(overrides: Partial<ReplyTemplateDto> = {}): ReplyTemplateDto {
  return { id: "t-1", title: "Вход в U-Tower", body: "Видео входа", shortcut: "вход", automation: null, file: null, ...overrides };
}

describe("attachmentAfterTemplate", () => {
  const upload: ComposerAttachment = { source: "upload", file: new File(["x"], "чек.jpg", { type: "image/jpeg" }) };

  it("attaches the file of the chosen template, replacing a file picked before", () => {
    expect(attachmentAfterTemplate(upload, template({ file: video }))).toEqual({ source: "template", templateId: "t-1", file: video });
    expect(attachmentAfterTemplate(null, template({ file: video }))).toEqual({ source: "template", templateId: "t-1", file: video });
  });

  it("keeps the attached file when the template has only text", () => {
    expect(attachmentAfterTemplate(upload, template())).toBe(upload);
    expect(attachmentAfterTemplate(null, template())).toBeNull();
  });
});

describe("attachmentInfo", () => {
  it("names a picked file and a template file the same way", () => {
    expect(attachmentInfo({ source: "upload", file: new File(["abc"], "чек.jpg") })).toEqual({ name: "чек.jpg", size: 3 });
    expect(attachmentInfo({ source: "template", templateId: "t-1", file: video })).toEqual({ name: "Вход.mp4", size: 1_400_000 });
  });
});
