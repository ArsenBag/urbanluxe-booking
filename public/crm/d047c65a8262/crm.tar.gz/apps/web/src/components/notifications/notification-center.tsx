"use client";

import type { NotificationEvent, NotificationFeedDto } from "@crm/shared";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { apiRequest } from "@/lib/api";
import {
  batchSound,
  createNotificationClaims,
  notificationContent,
  pushToasts,
  type NotificationContent,
} from "@/lib/notification-feed";
import { useNotificationSettings, type NotificationSettings } from "@/lib/notification-settings";
import { playNotificationSound, unlockAudio } from "@/lib/notification-sounds";
import { ToastStack } from "./toast-stack";

/** Как часто спрашиваем сервер о новых сообщениях и бронях. */
const POLL_MS = 10_000;
const MAX_TOASTS = 4;

function browserStorage(): Storage | null {
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

const canUseSystemNotifications = () => typeof Notification !== "undefined";
const isPageVisible = () => document.visibilityState === "visible";

/** Сотрудник уже смотрит этот чат — звенеть и показывать уведомление не нужно. */
function isViewingConversation(event: NotificationEvent): boolean {
  return (
    event.kind === "message" &&
    isPageVisible() &&
    window.location.pathname === "/inbox" &&
    new URLSearchParams(window.location.search).get("c") === event.conversationId
  );
}

function showSystemNotification(content: NotificationContent, showText: boolean, open: (href: string) => void): void {
  if (!canUseSystemNotifications() || Notification.permission !== "granted") return;
  // Звук играем сами, с громкостью из настроек, — системный отключаем.
  const notification = showText
    ? new Notification(content.title, { body: content.body, tag: content.tag, silent: true })
    : new Notification(content.summary, { tag: content.tag, silent: true });
  notification.onclick = () => {
    window.focus();
    open(content.href);
    notification.close();
  };
}

/** Звук и системное уведомление — по возможности: их сбой не должен терять карточки. */
function announce(contents: NotificationContent[], settings: NotificationSettings, open: (href: string) => void): void {
  try {
    const sound = batchSound(contents, settings);
    if (sound) playNotificationSound(sound, settings.volume);
  } catch (error) {
    console.warn("Не удалось проиграть звук уведомления", error);
  }
  if (isPageVisible() || !settings.systemNotifications) return;
  for (const content of contents) {
    try {
      showSystemNotification(content, settings.systemNotificationText, open);
    } catch (error) {
      console.warn("Не удалось показать системное уведомление", error);
    }
  }
}

/**
 * Уведомления о новых входящих (мои и неназначенные чаты) и новых бронях: звук, карточка в углу,
 * а если вкладка CRM не на экране — ещё и системное уведомление. Работает, пока CRM открыта.
 */
export function NotificationCenter() {
  const router = useRouter();
  const settings = useNotificationSettings();
  const settingsRef = useRef(settings);
  const [toasts, setToasts] = useState<NotificationContent[]>([]);

  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  const open = useCallback((href: string) => router.push(href), [router]);
  const dismiss = useCallback((id: string) => setToasts((current) => current.filter((toast) => toast.id !== id)), []);

  const notify = useCallback(
    (contents: NotificationContent[]) => {
      // Карточки добавляем и в свёрнутой вкладке: их таймер ждёт, пока сотрудник вернётся.
      setToasts((shown) => pushToasts(shown, contents, MAX_TOASTS));
      announce(contents, settingsRef.current, open);
    },
    [open],
  );

  // Звук и системные уведомления браузер разрешает только после действия пользователя.
  useEffect(() => {
    const onFirstGesture = () => {
      window.removeEventListener("pointerdown", onFirstGesture);
      window.removeEventListener("keydown", onFirstGesture);
      void unlockAudio();
      if (settingsRef.current.systemNotifications && canUseSystemNotifications() && Notification.permission === "default") {
        void Notification.requestPermission();
      }
    };
    window.addEventListener("pointerdown", onFirstGesture);
    window.addEventListener("keydown", onFirstGesture);
    return () => {
      window.removeEventListener("pointerdown", onFirstGesture);
      window.removeEventListener("keydown", onFirstGesture);
    };
  }, []);

  // Свой цикл вместо refetchInterval: запросы TanStack замирают в фоновой вкладке, а здесь нужен курсор.
  useEffect(() => {
    const claim = createNotificationClaims(browserStorage());
    let cursor: string | undefined;
    /** Время открытия страницы: пришедшее раньше видно в разделах, звенеть о нём поздно. */
    let openedAt: string | undefined;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let isPolling = false;
    let isStopped = false;

    const poll = async () => {
      if (isPolling || isStopped) return;
      isPolling = true;
      clearTimeout(timer);
      try {
        const feed = await apiRequest<NotificationFeedDto>("/notifications", { query: { after: cursor } });
        cursor = feed.cursor;
        openedAt ??= feed.cursor;
        const since = openedAt;
        const fresh = feed.events.filter((event) => event.at >= since && claim(event.id) && !isViewingConversation(event));
        if (fresh.length > 0) notify(fresh.map(notificationContent));
      } catch {
        // Нет сети или истекла сессия: повторим при следующем опросе, выход из CRM обрабатывает layout.
      } finally {
        isPolling = false;
      }
      if (!isStopped) timer = setTimeout(() => void poll(), POLL_MS);
    };

    // Фоновую вкладку браузер будит редко: вернулись на неё или появилась сеть — спрашиваем сразу.
    const pollNow = () => {
      if (isPageVisible()) void poll();
    };
    document.addEventListener("visibilitychange", pollNow);
    window.addEventListener("online", pollNow);
    void poll();
    return () => {
      isStopped = true;
      clearTimeout(timer);
      document.removeEventListener("visibilitychange", pollNow);
      window.removeEventListener("online", pollNow);
    };
  }, [notify]);

  return <ToastStack toasts={toasts} onOpen={open} onDismiss={dismiss} />;
}
