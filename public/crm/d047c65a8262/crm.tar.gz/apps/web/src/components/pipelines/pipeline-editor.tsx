"use client";

import type { PipelineDto } from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Section } from "@/components/ui/section";
import { useAddStage, useDeletePipeline, useRenamePipeline, useReorderStages } from "@/lib/pipelines";
import { StageRow } from "./stage-row";

export function PipelineEditor({ pipeline }: { pipeline: PipelineDto }) {
  const renamePipeline = useRenamePipeline();
  const deletePipeline = useDeletePipeline();
  const addStage = useAddStage();
  const reorderStages = useReorderStages();
  const [name, setName] = useState(pipeline.name);
  const [newStage, setNewStage] = useState("");
  const [error, setError] = useState<string | null>(null);
  const handlers = { onError: (e: Error) => setError(e.message), onSuccess: () => setError(null) };

  function move(index: number, direction: -1 | 1) {
    const ids = pipeline.stages.map((stage) => stage.id);
    const target = index + direction;
    [ids[index], ids[target]] = [ids[target], ids[index]];
    reorderStages.mutate({ pipelineId: pipeline.id, stageIds: ids }, handlers);
  }

  function handleAddStage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    addStage.mutate(
      { pipelineId: pipeline.id, input: { name: newStage.trim() } },
      { ...handlers, onSuccess: () => { setNewStage(""); setError(null); } },
    );
  }

  return (
    <Section
      title="Воронка"
      action={
        <Button
          variant="ghost"
          className="h-8 px-2 text-danger"
          onClick={() => window.confirm(`Удалить воронку «${pipeline.name}»?`) && deletePipeline.mutate(pipeline.id, handlers)}
        >
          Удалить воронку
        </Button>
      }
    >
      {error && <ErrorAlert message={error} />}
      <input
        className="mb-3 h-9 w-full rounded-md border border-border bg-surface px-3 text-base font-semibold"
        value={name}
        onChange={(e) => setName(e.target.value)}
        onBlur={() => name.trim() && name !== pipeline.name && renamePipeline.mutate({ id: pipeline.id, name: name.trim() }, handlers)}
        aria-label="Название воронки"
      />
      <ul className="divide-y divide-border">
        {pipeline.stages.map((stage, index) => (
          <StageRow
            key={stage.id}
            stage={stage}
            isFirst={index === 0}
            isLast={index === pipeline.stages.length - 1}
            onMove={(direction) => move(index, direction)}
            onError={setError}
          />
        ))}
      </ul>
      <form onSubmit={handleAddStage} className="mt-3 flex gap-2">
        <input
          className="h-9 flex-1 rounded-md border border-border bg-surface px-3 text-sm"
          placeholder="Новый этап"
          value={newStage}
          onChange={(e) => setNewStage(e.target.value)}
          aria-label="Название нового этапа"
        />
        <Button type="submit" variant="secondary" disabled={!newStage.trim() || addStage.isPending}>
          Добавить этап
        </Button>
      </form>
    </Section>
  );
}
