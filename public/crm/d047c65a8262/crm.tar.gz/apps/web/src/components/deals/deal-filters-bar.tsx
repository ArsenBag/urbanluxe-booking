"use client";

import {
  CONTACT_SOURCE_LABELS,
  CONTACT_SOURCES,
  MAX_DEAL_SEARCH_LENGTH,
  MIN_FILTER_DATE,
  NO_OWNER_FILTER,
  type ContactSource,
  type StageDto,
  type UserOptionDto,
} from "@crm/shared";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { MultiSelect } from "@/components/ui/multi-select";
import { activeDealFilterCount, EMPTY_DEAL_FILTERS, type DealFilters } from "@/lib/deal-filters";

const SOURCE_OPTIONS = CONTACT_SOURCES.map((source) => ({ value: source, label: CONTACT_SOURCE_LABELS[source] }));

interface DealFiltersBarProps {
  filters: DealFilters;
  onChange: (filters: DealFilters) => void;
  stages: StageDto[];
  users: UserOptionDto[];
  /** Сколько сделок на доске после фильтров; undefined — ещё грузится. */
  found: number | undefined;
}

/** Фильтры над канбаном: поиск, даты заезда, создания и закрытия, этапы, ответственные, откуда пришёл клиент. */
export function DealFiltersBar({ filters, onChange, stages, users, found }: DealFiltersBarProps) {
  const active = activeDealFilterCount(filters);
  return (
    <div className="mb-4 flex flex-wrap items-center gap-2">
      <input
        type="search"
        className={`h-9 w-56 rounded-md border bg-surface px-3 text-sm outline-none focus:border-primary ${filters.search.trim() ? "border-primary" : "border-border"}`}
        placeholder="Имя, сделка или телефон"
        maxLength={MAX_DEAL_SEARCH_LENGTH}
        title="Ищет среди сделок на доске: открытых и закрытых за последние 30 дней. Старые — с фильтром «Закрыта»."
        value={filters.search}
        onChange={(event) => onChange({ ...filters, search: event.target.value })}
        aria-label="Поиск сделок"
      />
      <DateRange
        label="Заезд"
        from={filters.checkInFrom}
        to={filters.checkInTo}
        onChange={(checkInFrom, checkInTo) => onChange({ ...filters, checkInFrom, checkInTo })}
      />
      <DateRange
        label="Создана"
        from={filters.createdFrom}
        to={filters.createdTo}
        onChange={(createdFrom, createdTo) => onChange({ ...filters, createdFrom, createdTo })}
      />
      <DateRange
        label="Закрыта"
        from={filters.closedFrom}
        to={filters.closedTo}
        onChange={(closedFrom, closedTo) => onChange({ ...filters, closedFrom, closedTo })}
      />
      <MultiSelect
        label="Этапы"
        options={stages.map((stage) => ({ value: stage.id, label: stage.name, swatch: stage.color }))}
        selected={filters.stageIds}
        onChange={(stageIds) => onChange({ ...filters, stageIds })}
      />
      <MultiSelect
        label="Ответственный"
        options={[{ value: NO_OWNER_FILTER, label: "Без ответственного" }, ...users.map((user) => ({ value: user.id, label: user.name }))]}
        selected={filters.ownerIds}
        onChange={(ownerIds) => onChange({ ...filters, ownerIds })}
      />
      <MultiSelect
        label="Канал"
        align="right"
        options={SOURCE_OPTIONS}
        selected={filters.sources}
        onChange={(sources) => onChange({ ...filters, sources: sources as ContactSource[] })}
      />
      {active > 0 && (
        <>
          <Button variant="ghost" className="h-9" onClick={() => onChange(EMPTY_DEAL_FILTERS)}>
            Сбросить фильтры
          </Button>
          {found !== undefined && <span className="text-sm text-muted">Найдено: {found}</span>}
        </>
      )}
    </div>
  );
}

interface DateRangeProps {
  label: string;
  from: string;
  to: string;
  onChange: (from: string, to: string) => void;
}

function DateRange({ label, from, to, onChange }: DateRangeProps) {
  const isActive = Boolean(from || to);
  return (
    <div
      role="group"
      aria-label={label}
      className={`flex h-9 items-center gap-1 rounded-md border bg-surface px-2 text-sm ${isActive ? "border-primary" : "border-border"}`}
    >
      <span className={isActive ? "text-primary" : "text-muted"}>{label}</span>
      {/* Перевёрнутый диапазон сервер отклонит: вторая граница подтягивается к выбранной дате. */}
      <DateInput label={`${label} с`} value={from} onCommit={(value) => onChange(value, to && value > to ? value : to)} />
      <span className="text-muted">—</span>
      <DateInput label={`${label} по`} value={to} onCommit={(value) => onChange(from && value && value < from ? value : from, value)} />
    </div>
  );
}

/**
 * Поле даты со своим черновиком: пока год набирают с клавиатуры («0002»…), фильтр не меняется.
 * Сброс фильтров снаружи переписывает черновик.
 */
function DateInput({ label, value, onCommit }: { label: string; value: string; onCommit: (value: string) => void }) {
  const [draft, setDraft] = useState(value);
  const [committed, setCommitted] = useState(value);
  if (value !== committed) {
    setCommitted(value);
    setDraft(value);
  }
  return (
    <input
      type="date"
      aria-label={label}
      className="bg-transparent text-sm"
      value={draft}
      onChange={(event) => {
        const next = event.target.value;
        setDraft(next);
        if (next === "" || next >= MIN_FILTER_DATE) onCommit(next);
      }}
    />
  );
}
