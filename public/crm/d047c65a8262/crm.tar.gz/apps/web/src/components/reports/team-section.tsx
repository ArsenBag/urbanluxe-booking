"use client";

import type { ReportPeriod, ResponseStats, TeamReportDto } from "@crm/shared";
import type { ReactNode } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Section } from "@/components/ui/section";
import { formatCount, formatDuration, formatShare } from "@/lib/report-period";
import { useTeamReport } from "@/lib/reports";
import { StatGrid, StatTile } from "./report-blocks";

const HEADERS = ["Сообщений", "Ответов", "Медиана ответа", "За 15 мин", "Задач сделано", "Просрочено"];

export function TeamSection({ period }: { period: ReportPeriod }) {
  const report = useTeamReport(period);
  return (
    <Section title="Команда">
      {report.isError && <ErrorAlert message={report.error.message} />}
      {report.isPending && <p className="text-sm text-muted">Загрузка…</p>}
      {report.data && (
        <div className={report.isPlaceholderData ? "opacity-60" : ""}>
          <TeamReport data={report.data} />
        </div>
      )}
    </Section>
  );
}

function TeamReport({ data }: { data: TeamReportDto }) {
  const { overall } = data;
  return (
    <>
      <StatGrid>
        <StatTile
          label="Первый ответ, медиана"
          value={formatDuration(overall.medianMinutes)}
          hint={overall.answered > 0 ? `половина из ${formatCount(overall.answered)} ответов — не дольше` : "ответов в периоде нет"}
        />
        <StatTile label="Ответили за 15 минут" value={formatShare(overall.within15Minutes, overall.answered)} hint="из тех, кому ответили" />
        <StatTile label="Ответили за час" value={formatShare(overall.withinHour, overall.answered)} hint="из тех, кому ответили" />
        <StatTile label="Без ответа" value={formatCount(data.unanswered)} hint="сообщения гостей, на которые не ответили" />
      </StatGrid>

      <TeamTable data={data} />

      <p className="mt-3 text-xs text-muted">
        Время ответа — от сообщения гостя до нашего первого ответа, включая ночь и выходные. Звонки и автосообщения не учитываются.
        Просроченные задачи — на текущий момент.
      </p>
    </>
  );
}

function TeamTable({ data }: { data: TeamReportDto }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-left text-muted">
          <tr>
            <th className="pb-2 font-medium">Сотрудник</th>
            {HEADERS.map((header) => (
              <th key={header} className="whitespace-nowrap pb-2 pl-3 text-right font-medium">
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="tabular-nums">
          {data.members.map((row) => (
            <TeamRow
              key={row.user.id}
              name={
                <>
                  {row.user.name}
                  {!row.isActive && <span className="ml-1 text-xs text-muted">(отключён)</span>}
                </>
              }
              messagesSent={row.messagesSent}
              response={row.response}
              tasksDone={formatCount(row.tasksDone)}
              tasksOverdue={formatCount(row.tasksOverdue)}
            />
          ))}
          <TeamRow
            name={<span className="text-muted">С телефона, мимо CRM</span>}
            messagesSent={data.phone.messagesSent}
            response={data.phone.response}
            tasksDone="—"
            tasksOverdue="—"
          />
        </tbody>
      </table>
    </div>
  );
}

interface TeamRowProps {
  name: ReactNode;
  messagesSent: number;
  response: ResponseStats;
  tasksDone: string;
  tasksOverdue: string;
}

function TeamRow({ name, messagesSent, response, tasksDone, tasksOverdue }: TeamRowProps) {
  const cells = [
    formatCount(messagesSent),
    formatCount(response.answered),
    formatDuration(response.medianMinutes),
    formatShare(response.within15Minutes, response.answered),
    tasksDone,
    tasksOverdue,
  ];
  return (
    <tr className="border-t border-border">
      <td className="py-1.5 pr-2">{name}</td>
      {cells.map((cell, index) => (
        <td key={HEADERS[index]} className="py-1.5 pl-3 text-right">
          {cell}
        </td>
      ))}
    </tr>
  );
}
