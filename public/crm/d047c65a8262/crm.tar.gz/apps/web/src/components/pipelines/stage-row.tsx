"use client";

import { STAGE_KIND_LABELS, STAGE_KINDS, type StageDto, type StageKind } from "@crm/shared";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useDeleteStage, useUpdateStage } from "@/lib/pipelines";

interface StageRowProps {
  stage: StageDto;
  isFirst: boolean;
  isLast: boolean;
  onMove: (direction: -1 | 1) => void;
  onError: (message: string) => void;
}

/** Строка этапа в настройках: название, цвет и тип сохраняются при уходе с поля. */
export function StageRow({ stage, isFirst, isLast, onMove, onError }: StageRowProps) {
  const updateStage = useUpdateStage();
  const deleteStage = useDeleteStage();
  const [name, setName] = useState(stage.name);
  const handlers = { onError: (error: Error) => onError(error.message) };

  function save(input: Partial<Pick<StageDto, "name" | "color" | "kind">>) {
    updateStage.mutate({ id: stage.id, input }, handlers);
  }

  return (
    <li className="flex items-center gap-2 py-2">
      <input
        type="color"
        className="h-8 w-8 shrink-0 cursor-pointer rounded border border-border bg-transparent"
        value={stage.color}
        onChange={(e) => save({ color: e.target.value })}
        aria-label={`Цвет этапа «${stage.name}»`}
      />
      <input
        className="h-8 min-w-0 flex-1 rounded-md border border-border bg-surface px-2 text-sm"
        value={name}
        onChange={(e) => setName(e.target.value)}
        onBlur={() => name.trim() && name !== stage.name && save({ name: name.trim() })}
        aria-label="Название этапа"
      />
      <select
        className="h-8 rounded-md border border-border bg-surface px-2 text-sm"
        value={stage.kind}
        onChange={(e) => save({ kind: e.target.value as StageKind })}
        aria-label="Тип этапа"
      >
        {STAGE_KINDS.map((kind) => (
          <option key={kind} value={kind}>
            {STAGE_KIND_LABELS[kind]}
          </option>
        ))}
      </select>
      <Button variant="ghost" className="h-8 px-2" disabled={isFirst} onClick={() => onMove(-1)} aria-label="Выше">
        ↑
      </Button>
      <Button variant="ghost" className="h-8 px-2" disabled={isLast} onClick={() => onMove(1)} aria-label="Ниже">
        ↓
      </Button>
      <Button
        variant="ghost"
        className="h-8 px-2 text-danger"
        disabled={deleteStage.isPending}
        onClick={() => window.confirm(`Удалить этап «${stage.name}»?`) && deleteStage.mutate(stage.id, handlers)}
      >
        Удалить
      </Button>
    </li>
  );
}
