"use client";

import type { BookingDto } from "@crm/shared";
import { ErrorAlert } from "@/components/ui/alert";
import { Section } from "@/components/ui/section";
import { useBookingDay } from "@/lib/bookings";
import { BookingRow } from "./booking-row";

function BookingList({ title, bookings, empty }: { title: string; bookings: BookingDto[]; empty: string }) {
  return (
    <Section title={`${title} · ${bookings.length}`}>
      {bookings.length === 0 ? (
        <p className="text-sm text-muted">{empty}</p>
      ) : (
        <ul className="divide-y divide-border">
          {bookings.map((booking) => (
            <BookingRow key={booking.id} booking={booking} />
          ))}
        </ul>
      )}
    </Section>
  );
}

/** Сводка дня для администратора: заезды, выезды, проживающие. */
export function DayOverview({ date }: { date: string }) {
  const day = useBookingDay(date);

  if (day.isError) return <ErrorAlert message={day.error.message} />;
  if (day.isPending) return <p className="text-sm text-muted">Загрузка…</p>;

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <BookingList title="Заезды" bookings={day.data.arrivals} empty="Заездов нет" />
      <BookingList title="Выезды" bookings={day.data.departures} empty="Выездов нет" />
      <div className="lg:col-span-2">
        <BookingList title="Проживают" bookings={day.data.staying} empty="Никто не проживает" />
      </div>
    </div>
  );
}
