"use client";

import type { TaskDto } from "@crm/shared";
import { ErrorAlert } from "@/components/ui/alert";
import { useDeleteTask, useTasks, useUpdateTask, type TaskFilters } from "@/lib/tasks";
import { TaskItem } from "./task-item";

interface TaskListProps {
  filters: TaskFilters;
  showContext?: boolean;
  emptyText?: string;
}

export function TaskList({ filters, showContext, emptyText = "Задач нет" }: TaskListProps) {
  const tasks = useTasks(filters);
  const updateTask = useUpdateTask();
  const deleteTask = useDeleteTask();
  const mutationError = updateTask.error ?? deleteTask.error;

  function toggle(task: TaskDto) {
    updateTask.mutate({ id: task.id, input: { isDone: !task.isDone } });
  }

  function remove(task: TaskDto) {
    if (window.confirm(`Удалить задачу «${task.title}»?`)) {
      deleteTask.mutate(task.id);
    }
  }

  if (tasks.isError) return <ErrorAlert message={tasks.error.message} />;
  if (tasks.isPending) return <p className="text-sm text-muted">Загрузка…</p>;

  return (
    <div>
      {mutationError && <ErrorAlert message={mutationError.message} />}
      {tasks.data.length === 0 ? (
        <p className="py-2 text-sm text-muted">{emptyText}</p>
      ) : (
        <ul className="divide-y divide-border">
          {tasks.data.map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              showContext={showContext}
              onToggle={toggle}
              onDelete={remove}
              disabled={updateTask.isPending || deleteTask.isPending}
            />
          ))}
        </ul>
      )}
    </div>
  );
}
