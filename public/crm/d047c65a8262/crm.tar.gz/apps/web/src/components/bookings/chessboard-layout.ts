const MS_PER_DAY = 86_400_000;

const toUtc = (date: string) => Date.parse(`${date}T00:00:00Z`);

export function addDays(date: string, days: number): string {
  return new Date(toUtc(date) + days * MS_PER_DAY).toISOString().slice(0, 10);
}

/** Сколько дней от from до to (to раньше — отрицательное число). */
export function daysBetween(from: string, to: string): number {
  return Math.round((toUtc(to) - toUtc(from)) / MS_PER_DAY);
}

export function daysOf(from: string, count: number): string[] {
  return Array.from({ length: count }, (_, index) => addDays(from, index));
}

export interface Bar {
  /** Начало и длина полоски в днях от начала окна. */
  start: number;
  length: number;
  /** Бронь начинается раньше / заканчивается позже видимого окна. */
  cutStart: boolean;
  cutEnd: boolean;
}

/**
 * Положение брони на шахматке окна [from, from + days). Как в RealtyCalendar, ячейка — ночь: заезд 12-го
 * и выезд 13-го закрывают одну ячейку 12-го, а в день выезда квартира свободна для следующего гостя.
 * null — бронь вне окна.
 */
export function barFor(booking: { checkIn: string; checkOut: string }, from: string, days: number): Bar | null {
  const offset = (date: string) => (toUtc(date) - toUtc(from)) / MS_PER_DAY;
  const rawStart = offset(booking.checkIn);
  const rawEnd = offset(booking.checkOut);
  if (rawEnd <= 0 || rawStart >= days) return null;
  const start = Math.max(0, rawStart);
  const end = Math.min(days, rawEnd);
  return { start, length: end - start, cutStart: rawStart < 0, cutEnd: rawEnd > days };
}

interface StayLike {
  checkIn: string;
  checkOut: string;
}

/** Выделенные ячейки строки (тянуть можно в любую сторону) → даты брони: выезд утром после последней ночи. */
export function stayOfCells(from: string, first: number, last: number): { checkIn: string; checkOut: string } {
  return { checkIn: addDays(from, Math.min(first, last)), checkOut: addDays(from, Math.max(first, last) + 1) };
}

/**
 * Раскладка пересекающихся броней по подстрокам: каждая — в первую подстроку, где предыдущая бронь
 * уже выехала. Выезд и заезд в один день не пересекаются. Больше одной подстроки — овербукинг.
 */
export function assignLanes<T extends StayLike>(bookings: readonly T[]): { items: Array<{ booking: T; lane: number }>; lanes: number } {
  const sorted = [...bookings].sort((a, b) => a.checkIn.localeCompare(b.checkIn) || a.checkOut.localeCompare(b.checkOut));
  const laneEnds: string[] = [];
  const items = sorted.map((booking) => {
    const free = laneEnds.findIndex((end) => end <= booking.checkIn);
    const lane = free === -1 ? laneEnds.length : free;
    laneEnds[lane] = booking.checkOut;
    return { booking, lane };
  });
  return { items, lanes: Math.max(1, laneEnds.length) };
}

interface PropertyLike {
  id: string;
  title: string;
  rcId: number | null;
}

export interface ChessboardRow<P extends PropertyLike, B> {
  key: string;
  property: P | null;
  /** ЖК из выгрузки Excel или бронь без объекта: квартира не определена. */
  unresolved: boolean;
  bookings: B[];
}

/** Коды квартир по-человечески: U-13, U-37, U-100, а не U-100, U-13. */
const byTitle = (a: { title: string }, b: { title: string }) => a.title.localeCompare(b.title, "ru", { numeric: true });

/** Цена ночи в ячейке строки: номер ячейки от начала окна и сама цена. */
export interface RateCell<D> {
  index: number;
  day: D;
}

/** Цены окна [from, from + days) по квартирам — каждой строке шахматки свой список ячеек. */
export function rateCellsByProperty<D extends { propertyId: string; date: string }>(
  days: readonly D[],
  from: string,
  count: number,
): Map<string, Array<RateCell<D>>> {
  const cells = new Map<string, Array<RateCell<D>>>();
  for (const day of days) {
    const index = daysBetween(from, day.date);
    if (index < 0 || index >= count) continue;
    cells.set(day.propertyId, [...(cells.get(day.propertyId) ?? []), { index, day }]);
  }
  return cells;
}

const NO_COMPLEX = "Без ЖК";

/** Квартиры по ЖК для выбора в окне цен: ЖК по алфавиту, квартиры в порядке кодов, без ЖК — в конце. */
export function groupApartmentsByComplex<P extends { title: string; complex: string | null }>(
  apartments: readonly P[],
): Array<{ title: string; items: P[] }> {
  const groups = new Map<string, P[]>();
  for (const apartment of apartments) {
    const title = apartment.complex ?? NO_COMPLEX;
    groups.set(title, [...(groups.get(title) ?? []), apartment]);
  }
  return [...groups.entries()]
    .sort(([a], [b]) => (a === NO_COMPLEX ? 1 : b === NO_COMPLEX ? -1 : a.localeCompare(b, "ru")))
    .map(([title, items]) => ({ title, items: [...items].sort(byTitle) }));
}

/** Квартиры из RealtyCalendar (без строк ЖК из старой выгрузки) в порядке кодов — на них вносят брони. */
export function apartmentsOf<P extends PropertyLike>(properties: readonly P[]): P[] {
  return properties.filter((property) => property.rcId !== null).sort(byTitle);
}

/**
 * Строки шахматки: все квартиры из RealtyCalendar (даже без броней) в порядке кодов, а ниже —
 * строки ЖК и «без объекта», только если в окне есть такие брони.
 */
export function buildChessboardRows<P extends PropertyLike, B extends { property: P | null }>(
  properties: readonly P[],
  bookings: readonly B[],
): Array<ChessboardRow<P, B>> {
  const byProperty = new Map<string, B[]>();
  const known = new Map<string, P>(properties.map((property) => [property.id, property]));
  for (const booking of bookings) {
    const key = booking.property?.id ?? "none";
    byProperty.set(key, [...(byProperty.get(key) ?? []), booking]);
    if (booking.property && !known.has(booking.property.id)) known.set(booking.property.id, booking.property);
  }
  const row = (property: P | null): ChessboardRow<P, B> => {
    const key = property?.id ?? "none";
    return { key, property, unresolved: !property || property.rcId === null, bookings: byProperty.get(key) ?? [] };
  };
  const all = [...known.values()];
  const apartments = apartmentsOf(all).map(row);
  const unresolved = all
    .filter((property) => property.rcId === null && byProperty.has(property.id))
    .sort(byTitle)
    .map(row);
  return [...apartments, ...unresolved, ...(byProperty.has("none") ? [row(null)] : [])];
}
