"use client";

import { formatPhone } from "@crm/shared";
import Link from "next/link";
import { useState } from "react";
import { BookingSummary } from "@/components/bookings/booking-summary";
import { GuestActions } from "@/components/guests/guest-actions";
import { GuestBadges } from "@/components/guests/guest-badges";
import { DealFormModal } from "@/components/deals/deal-form-modal";
import { DealSummaryRow } from "@/components/deals/deal-summary-row";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { useContactBookings } from "@/lib/bookings";
import { useContactDeals } from "@/lib/deals";
import { useGuestStays } from "@/lib/guests";
import { useConversation, useUpdateConversation } from "@/lib/inbox";
import { usePipelines } from "@/lib/pipelines";
import { useSession } from "@/lib/session";
import { useUserOptions } from "@/lib/users";

import { LinkModal } from "./link-modal";

const UNASSIGNED = "";
/** В узкой панели — только последние брони, остальные в карточке клиента. */
const MAX_PANEL_BOOKINGS = 5;

/** Правая панель диалога: ответственный, статус, клиент, его брони и сделки, связь с бронью или сделкой. */
export function ConversationPanel({ conversationId }: { conversationId: string }) {
  const conversation = useConversation(conversationId);
  const update = useUpdateConversation(conversationId);
  const session = useSession();
  const users = useUserOptions();
  const pipelines = usePipelines();
  const contactId = conversation.data?.contact.id ?? "";
  const deals = useContactDeals(contactId);
  const bookings = useContactBookings(contactId);
  const stays = useGuestStays(contactId);
  const [isCreatingDeal, setIsCreatingDeal] = useState(false);
  const [isLinking, setIsLinking] = useState(false);

  if (!conversation.data) return null;
  const data = conversation.data;
  const isMine = data.assignee?.id === session.data?.id;

  return (
    <aside className="flex h-full flex-col gap-4 overflow-y-auto p-4">
      {update.isError && <ErrorAlert message={update.error.message} />}

      <section className="flex flex-col gap-2">
        <label htmlFor="assignee" className="text-xs font-semibold uppercase tracking-wide text-muted">
          Ответственный
        </label>
        <select
          id="assignee"
          className="h-9 rounded-md border border-border bg-surface px-2 text-sm"
          value={data.assignee?.id ?? UNASSIGNED}
          onChange={(e) => update.mutate({ assigneeId: e.target.value || null })}
          disabled={update.isPending}
        >
          <option value={UNASSIGNED}>Не назначен</option>
          {users.data?.map((user) => (
            <option key={user.id} value={user.id}>
              {user.name}
            </option>
          ))}
        </select>
        <div className="flex gap-2">
          {!isMine && session.data && (
            <Button variant="secondary" className="flex-1" onClick={() => update.mutate({ assigneeId: session.data!.id })} disabled={update.isPending}>
              Взять себе
            </Button>
          )}
          <Button
            variant="secondary"
            className="flex-1"
            onClick={() => update.mutate({ status: data.status === "OPEN" ? "CLOSED" : "OPEN" })}
            disabled={update.isPending}
          >
            {data.status === "OPEN" ? "Закрыть диалог" : "Открыть снова"}
          </Button>
        </div>
      </section>

      <section>
        <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">Клиент</h3>
        <Link href={`/contacts/${data.contact.id}`} className="font-medium hover:text-primary">
          {data.contact.name}
        </Link>
        {data.contact.phones.map((phone) => (
          <a key={phone} href={`tel:${phone}`} className="block text-sm text-primary hover:underline">
            {formatPhone(phone)}
          </a>
        ))}
        {data.handle && <div className="text-sm text-muted">{data.handle}</div>}
        <div className="mt-2 flex flex-wrap gap-1.5">
          <GuestBadges vip={data.contact.vip} blacklisted={data.contact.blacklist !== null} stays={stays} />
        </div>
        <div className="mt-3 flex flex-col gap-2">
          {/* key: черновик причины и ошибки одного гостя не переезжают к другому при смене диалога. */}
          <GuestActions
            key={data.contact.id}
            contactId={data.contact.id} contactName={data.contact.name} vip={data.contact.vip} blacklist={data.contact.blacklist} />
          <Button variant="secondary" className="w-full" onClick={() => setIsLinking(true)}>
            Связать с бронью или сделкой
          </Button>
        </div>
      </section>

      <section>
        <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">Брони</h3>
        {bookings.data?.length === 0 && <p className="text-sm text-muted">Броней нет</p>}
        <ul className="divide-y divide-border">
          {bookings.data?.slice(0, MAX_PANEL_BOOKINGS).map((booking) => (
            <li key={booking.id} className="py-2">
              <BookingSummary booking={booking} />
              {booking.rcUrl && (
                <a href={booking.rcUrl} target="_blank" rel="noreferrer" className="text-xs text-primary hover:underline">
                  RealtyCalendar ↗
                </a>
              )}
            </li>
          ))}
        </ul>
        {(bookings.data?.length ?? 0) > MAX_PANEL_BOOKINGS && (
          <Link href={`/contacts/${data.contact.id}`} className="text-xs text-primary hover:underline">
            Все брони — в карточке клиента
          </Link>
        )}
      </section>

      <section>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-muted">Сделки</h3>
          <Button variant="ghost" className="h-7 px-2 text-xs" onClick={() => setIsCreatingDeal(true)} disabled={!pipelines.data?.length}>
            + Сделка
          </Button>
        </div>
        {deals.data?.length === 0 && <p className="text-sm text-muted">Сделок нет</p>}
        <ul className="divide-y divide-border">
          {deals.data?.map((deal) => <DealSummaryRow key={deal.id} deal={deal} />)}
        </ul>
      </section>

      <LinkModal conversationId={conversationId} open={isLinking} onClose={() => setIsLinking(false)} />

      {isCreatingDeal && pipelines.data && (
        <DealFormModal
          pipelines={pipelines.data}
          contact={{ id: data.contact.id, name: data.contact.name }}
          onClose={() => setIsCreatingDeal(false)}
        />
      )}
    </aside>
  );
}
