"use client";

import type { BookingsReportDto, ReportPeriod } from "@crm/shared";
import { ErrorAlert } from "@/components/ui/alert";
import { Section } from "@/components/ui/section";
import { pluralize } from "@/lib/format";
import { formatAmount, formatCount, formatPercent } from "@/lib/report-period";
import { useBookingsReport } from "@/lib/reports";
import { ColumnChart } from "./column-chart";
import { BarList, MeterCell, ReportSubheading, StatGrid, StatTile } from "./report-blocks";

const NIGHTS: [string, string, string] = ["ночь", "ночи", "ночей"];
const DIRECT_ORIGIN = "Напрямую / вручную";

const nights = (count: number) => `${formatCount(count)} ${pluralize(count, NIGHTS)}`;

export function OccupancySection({ period }: { period: ReportPeriod }) {
  const report = useBookingsReport(period);
  return (
    <Section title="Брони и загрузка">
      {report.isError && <ErrorAlert message={report.error.message} />}
      {report.isPending && <p className="text-sm text-muted">Загрузка…</p>}
      {report.data && (
        <div className={report.isPlaceholderData ? "opacity-60" : ""}>
          <OccupancyReport data={report.data} />
        </div>
      )}
    </Section>
  );
}

function OccupancyReport({ data }: { data: BookingsReportDto }) {
  const { totals, currency } = data;
  return (
    <>
      <StatGrid>
        <StatTile
          label="Загрузка"
          value={formatPercent(totals.occupancy)}
          hint={`${nights(totals.nights)} из ${formatCount(data.apartments * data.days)} возможных`}
        />
        <StatTile label="Выручка" value={formatAmount(totals.revenue, currency)} hint="за ночи внутри периода" />
        <StatTile
          label="Средняя цена ночи"
          value={totals.averageNightPrice === null ? "—" : formatAmount(totals.averageNightPrice, currency)}
        />
        <StatTile label="Заезды" value={formatCount(totals.arrivals)} hint={`отмен: ${formatCount(totals.cancellations)}`} />
      </StatGrid>

      <ReportSubheading>Занято квартир по ночам</ReportSubheading>
      <ColumnChart
        label="Занято квартир по ночам"
        series={[{ key: "occupied", label: "занято", color: "var(--chart-bar)" }]}
        data={data.byDay.map((day) => ({ date: day.date, values: [day.occupied] }))}
        max={data.apartments}
        describeTotal={(occupied) => `из ${formatCount(data.apartments)} · ${formatPercent(data.apartments > 0 ? occupied / data.apartments : null)}`}
      />

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div>
          <ReportSubheading>По жилым комплексам</ReportSubheading>
          <ComplexTable data={data} />
        </div>
        <div>
          <ReportSubheading>Источники броней</ReportSubheading>
          <BarList
            emptyText="Броней в периоде нет"
            rows={data.byOrigin.map((row) => ({
              key: row.origin === null ? "direct" : `origin:${row.origin}`,
              label: row.origin ?? DIRECT_ORIGIN,
              value: row.nights,
              display: `${nights(row.nights)} · ${formatAmount(row.revenue, currency)}`,
            }))}
          />
        </div>
      </div>

      <details className="mt-6">
        <summary className="cursor-pointer text-sm font-semibold">По квартирам ({formatCount(data.byApartment.length)})</summary>
        <ApartmentTable data={data} />
      </details>
    </>
  );
}

function ComplexTable({ data }: { data: BookingsReportDto }) {
  return (
    <table className="w-full text-sm">
      <thead className="text-left text-muted">
        <tr>
          <th className="pb-2 font-medium">ЖК</th>
          <th className="pb-2 text-right font-medium">Квартир</th>
          <th className="w-1/4 pb-2 pl-3 font-medium">Загрузка</th>
          <th className="pb-2 pl-4 text-right font-medium">Выручка</th>
        </tr>
      </thead>
      <tbody className="tabular-nums">
        {data.byComplex.map((row) => (
          <tr key={row.title} className="border-t border-border">
            <td className="py-1.5 pr-2">{row.title}</td>
            <td className="py-1.5 text-right">{formatCount(row.apartments)}</td>
            <td className="py-1.5 pl-3">
              <MeterCell share={row.occupancy} label={formatPercent(row.occupancy)} />
            </td>
            <td className="py-1.5 pl-4 text-right">{formatAmount(row.revenue, data.currency)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function ApartmentTable({ data }: { data: BookingsReportDto }) {
  return (
    <div className="mt-3 max-h-96 overflow-auto">
      <table className="w-full text-sm">
        <thead className="sticky top-0 bg-surface text-left text-muted">
          <tr>
            <th className="pb-2 font-medium">Квартира</th>
            <th className="pb-2 font-medium">ЖК</th>
            <th className="pb-2 text-right font-medium">Ночей</th>
            <th className="w-1/4 pb-2 pl-3 font-medium">Загрузка</th>
            <th className="pb-2 pl-4 text-right font-medium">Выручка</th>
          </tr>
        </thead>
        <tbody className="tabular-nums">
          {data.byApartment.map((row) => (
            <tr key={row.id} className="border-t border-border">
              <td className="py-1.5 pr-2">{row.title}</td>
              <td className="py-1.5 pr-2 text-muted">{row.complex ?? "—"}</td>
              <td className="py-1.5 text-right">{formatCount(row.nights)}</td>
              <td className="py-1.5 pl-3">
                <MeterCell share={row.occupancy} label={formatPercent(row.occupancy)} />
              </td>
              <td className="py-1.5 pl-4 text-right">{formatAmount(row.revenue, data.currency)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
