"use client";

import { CHANNEL_TYPE_LABELS, CHANNEL_TYPES, type ChannelCounts, type ChannelType, type InquiriesReportDto, type ReportPeriod } from "@crm/shared";
import { ErrorAlert } from "@/components/ui/alert";
import { Section } from "@/components/ui/section";
import { formatCount } from "@/lib/report-period";
import { useInquiriesReport } from "@/lib/reports";
import { ColumnChart, type ChartSeries } from "./column-chart";
import { ReportSubheading, StatGrid, StatTile } from "./report-blocks";

/** Цвет мессенджера на графиках — как его значок в списке диалогов. */
const CHANNEL_COLORS: Record<ChannelType, string> = {
  TELEGRAM: "var(--chart-telegram)",
  WHATSAPP: "var(--chart-whatsapp)",
  INSTAGRAM: "var(--chart-instagram)",
};
/** Instagram ещё не подключён: показываем его, только когда появятся данные. */
const ALWAYS_SHOWN: ChannelType[] = ["TELEGRAM", "WHATSAPP"];

const total = (counts: ChannelCounts) => CHANNEL_TYPES.reduce((sum, channel) => sum + counts[channel], 0);

export function InquiriesSection({ period }: { period: ReportPeriod }) {
  const report = useInquiriesReport(period);
  return (
    <Section title="Обращения">
      {report.isError && <ErrorAlert message={report.error.message} />}
      {report.isPending && <p className="text-sm text-muted">Загрузка…</p>}
      {report.data && (
        <div className={report.isPlaceholderData ? "opacity-60" : ""}>
          <InquiriesReport data={report.data} />
        </div>
      )}
    </Section>
  );
}

function InquiriesReport({ data }: { data: InquiriesReportDto }) {
  const { fromGuests, fromUs } = data.newConversations;
  const channels = CHANNEL_TYPES.filter((channel) => ALWAYS_SHOWN.includes(channel) || fromGuests[channel] > 0 || fromUs[channel] > 0);
  const series: ChartSeries[] = channels.map((channel) => ({ key: channel, label: CHANNEL_TYPE_LABELS[channel], color: CHANNEL_COLORS[channel] }));
  const { messages } = data;

  return (
    <>
      <StatGrid>
        <StatTile label="Новые обращения" value={formatCount(total(fromGuests))} hint="гость написал первым" />
        <StatTile label="Мы написали первыми" value={formatCount(total(fromUs))} hint="новые диалоги по нашей инициативе" />
        <StatTile label="Входящие сообщения" value={formatCount(messages.incoming)} />
        <StatTile label="Пропущенные звонки" value={formatCount(data.missedCalls)} hint="Telegram и WhatsApp" />
      </StatGrid>

      <ReportSubheading>Новые обращения по дням</ReportSubheading>
      <ColumnChart
        label="Новые обращения по дням и мессенджерам"
        series={series}
        data={data.byDay.map((day) => ({ date: day.date, values: channels.map((channel) => day.counts[channel]) }))}
        describeTotal={(sum) => `всего ${formatCount(sum)}`}
      />

      <p className="mt-4 text-sm text-muted">
        Исходящие: из CRM — <span className="font-medium text-foreground">{formatCount(messages.fromCrm)}</span>, с телефона мимо CRM —{" "}
        <span className="font-medium text-foreground">{formatCount(messages.fromPhone)}</span>, автосообщения —{" "}
        <span className="font-medium text-foreground">{formatCount(messages.automated)}</span>.
      </p>
    </>
  );
}
