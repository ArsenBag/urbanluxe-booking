"use client";

import {
  bookingTemplateVariables,
  firstName,
  formatFileSize,
  matchTemplates,
  MAX_CAPTION_LENGTH,
  MAX_FILE_BYTES,
  MAX_MESSAGE_LENGTH,
  pickBookingForTemplate,
  renderTemplate,
  slashCommandAt,
  type ReplyTemplateDto,
  type TemplateVariables,
} from "@crm/shared";
import { useLayoutEffect, useRef, useState, type ChangeEvent, type FormEvent, type KeyboardEvent, type SyntheticEvent } from "react";
import { Button } from "@/components/ui/button";
import { useContactBookings } from "@/lib/bookings";
import { useTemplates } from "@/lib/channels";
import { tashkentDayKey } from "@/lib/format";
import { useSendFile, useSendMessage, useSendTemplateFile } from "@/lib/inbox";
import { attachmentAfterTemplate, attachmentInfo, type ComposerAttachment } from "./composer-attachment";
import { TemplateMenu } from "./template-menu";

/** Показываем счётчик символов, когда до лимита Telegram остаётся немного. */
const LENGTH_WARNING_MARGIN = 300;
const CAPTION_WARNING_MARGIN = 100;
/** Потолок высоты поля ввода (около восьми строк), дальше — прокрутка внутри. */
const MAX_TEXTAREA_HEIGHT_PX = 160;
const MESSAGE_PLACEHOLDER = "Сообщение… / — шаблоны";
const KEYBOARD_HINT = "Enter — отправить, Shift+Enter — новая строка, / — шаблоны";

interface ComposerProps {
  conversationId: string;
  contactId: string;
  contactName: string;
}

export function Composer({ conversationId, contactId, contactName }: ComposerProps) {
  const sendMessage = useSendMessage(conversationId);
  const sendFile = useSendFile(conversationId);
  const sendTemplateFile = useSendTemplateFile(conversationId);
  const templates = useTemplates();
  const bookings = useContactBookings(contactId);
  const textarea = useRef<HTMLTextAreaElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const [text, setText] = useState("");
  const [attachment, setAttachment] = useState<ComposerAttachment | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [showTemplates, setShowTemplates] = useState(false);
  /** Набираемая команда «/…» перед курсором; null — меню команд закрыто. */
  const [slash, setSlash] = useState<{ start: number; query: string } | null>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  // Поле растёт вместе с текстом, в том числе с длинными строками без переносов; выше потолка — прокрутка.
  useLayoutEffect(() => {
    const element = textarea.current;
    if (!element) return;
    element.style.height = "auto";
    // scrollHeight — без рамки, а высота задаётся с рамкой: без поправки появляется лишняя прокрутка.
    const border = element.offsetHeight - element.clientHeight;
    element.style.height = `${Math.min(element.scrollHeight + border, MAX_TEXTAREA_HEIGHT_PX)}px`;
  }, [text]);

  const allTemplates = templates.data ?? [];
  const slashMatches = slash ? matchTemplates(allTemplates, slash.query) : [];
  const activeSlashIndex = Math.min(activeIndex, Math.max(slashMatches.length - 1, 0));

  // С файлом текст становится подписью — у неё свой лимит.
  const maxLength = attachment ? MAX_CAPTION_LENGTH : MAX_MESSAGE_LENGTH;
  const warningAt = maxLength - (attachment ? CAPTION_WARNING_MARGIN : LENGTH_WARNING_MARGIN);
  const trimmed = text.trim();
  const isPending = sendMessage.isPending || sendFile.isPending || sendTemplateFile.isPending;
  const canSend = (attachment !== null || trimmed.length > 0) && trimmed.length <= maxLength && !isPending;
  const attached = attachment ? attachmentInfo(attachment) : null;
  const sendError = [sendFile, sendTemplateFile, sendMessage].find((mutation) => mutation.isError)?.error?.message ?? null;
  const error = fileError ?? sendError;

  function submit() {
    if (!canSend) return;
    const onSuccess = () => {
      setText("");
      setAttachment(null);
    };
    if (attachment?.source === "upload") {
      sendFile.mutate({ file: attachment.file, caption: trimmed }, { onSuccess });
      return;
    }
    if (attachment?.source === "template") {
      sendTemplateFile.mutate(
        { templateId: attachment.templateId, fileId: attachment.file.id, caption: trimmed },
        { onSuccess },
      );
      return;
    }
    sendMessage.mutate(trimmed, { onSuccess: () => setText("") });
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    submit();
  }

  function handleTextChange(event: ChangeEvent<HTMLTextAreaElement>) {
    const { value, selectionStart } = event.target;
    setText(value);
    const command = slashCommandAt(value, selectionStart);
    setSlash(command);
    setActiveIndex(0);
    if (command) setShowTemplates(false);
  }

  /** Курсор сдвинули стрелками или мышью: меню команд следует за ним (или закрывается). */
  function handleSelect(event: SyntheticEvent<HTMLTextAreaElement>) {
    const { value, selectionStart, selectionEnd } = event.currentTarget;
    const command = selectionStart === selectionEnd ? slashCommandAt(value, selectionStart) : null;
    if (command?.start !== slash?.start || command?.query !== slash?.query) {
      setSlash(command);
      setActiveIndex(0);
    }
  }

  /** Стрелки и Enter/Tab управляют меню команд; Enter без меню — отправить, Shift+Enter — новая строка. */
  function handleKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.nativeEvent.isComposing) return;
    if (slash && event.key === "Escape") {
      event.preventDefault();
      setSlash(null);
      return;
    }
    if (slash && slashMatches.length > 0 && handleMenuKey(event)) return;
    // Шаблона с такой командой нет: Enter не отправляет «/опечатку» гостю. Esc закрывает меню.
    if (slash && slashMatches.length === 0 && event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      return;
    }
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      submit();
    }
  }

  function handleMenuKey(event: KeyboardEvent<HTMLTextAreaElement>): boolean {
    const count = slashMatches.length;
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      const step = event.key === "ArrowDown" ? 1 : -1;
      setActiveIndex((activeSlashIndex + step + count) % count);
      return true;
    }
    if ((event.key === "Enter" && !event.shiftKey) || event.key === "Tab") {
      event.preventDefault();
      const template = slashMatches[activeSlashIndex];
      if (template) insertTemplate(template);
      return true;
    }
    return false;
  }

  function handleFileChange(event: ChangeEvent<HTMLInputElement>) {
    const selected = event.target.files?.[0] ?? null;
    // Очищаем input, чтобы тот же файл можно было выбрать снова.
    event.target.value = "";
    if (!selected) return;
    if (selected.size > MAX_FILE_BYTES) {
      setFileError(`Файл больше ${formatFileSize(MAX_FILE_BYTES)}: ${selected.name}`);
      return;
    }
    setFileError(null);
    setAttachment({ source: "upload", file: selected });
  }

  /** {имя} — из карточки клиента, {объект}/{заезд}/{выезд} — из текущей или ближайшей брони. */
  function templateVariables(): TemplateVariables {
    const booking = pickBookingForTemplate(bookings.data ?? [], tashkentDayKey(new Date()));
    return { имя: firstName(contactName), ...(booking && bookingTemplateVariables(booking)) };
  }

  function insertTemplate(template: ReplyTemplateDto) {
    const rendered = renderTemplate(template.body, templateVariables());
    if (slash) {
      // «/команда» заменяется текстом шаблона, остальное сообщение остаётся как было.
      const end = slash.start + 1 + slash.query.length;
      setText(`${text.slice(0, slash.start)}${rendered}${text.slice(end)}`);
      moveCaret(slash.start + rendered.length);
    } else {
      const next = text.trim() ? `${text.trimEnd()}\n${rendered}` : rendered;
      setText(next);
      moveCaret(next.length);
    }
    // Файл шаблона (видео входа, фото дома) прикрепляется вместе с текстом.
    if (template.file) setFileError(null);
    setAttachment((current) => attachmentAfterTemplate(current, template));
    setSlash(null);
    setShowTemplates(false);
  }

  function moveCaret(position: number) {
    requestAnimationFrame(() => {
      textarea.current?.focus();
      textarea.current?.setSelectionRange(position, position);
    });
  }

  return (
    <form onSubmit={handleSubmit} className="relative border-t border-border bg-surface p-3">
      {error && <p className="mb-2 text-sm text-danger">{error}</p>}
      {slash && (
        <TemplateMenu
          templates={slashMatches}
          activeIndex={activeSlashIndex}
          emptyText={slash.query ? `Нет шаблона «/${slash.query}». Esc — закрыть и отправить как текст` : "Шаблонов пока нет"}
          onPick={insertTemplate}
          onHover={setActiveIndex}
        />
      )}
      {showTemplates && !slash && (
        <TemplateMenu templates={allTemplates} activeIndex={null} emptyText="Шаблонов пока нет" onPick={insertTemplate} />
      )}
      {attached && (
        <div className="mb-2 flex items-center gap-2 rounded-md border border-border bg-background px-3 py-1.5 text-sm">
          <span aria-hidden>📎</span>
          <span className="min-w-0 flex-1 truncate">{attached.name}</span>
          <span className="text-xs text-muted">{formatFileSize(attached.size)}</span>
          <button
            type="button"
            className="px-1 text-muted hover:text-danger"
            onClick={() => setAttachment(null)}
            disabled={isPending}
            aria-label="Убрать файл"
          >
            ✕
          </button>
        </div>
      )}
      <div className="flex items-end gap-2">
        <Button
          variant="ghost"
          className="h-10 px-2"
          onClick={() => setShowTemplates((value) => !value)}
          aria-expanded={showTemplates}
          title="Шаблоны ответов (или наберите / в сообщении)"
        >
          ⚡
        </Button>
        <Button
          variant="ghost"
          className="h-10 px-2"
          onClick={() => fileInput.current?.click()}
          disabled={isPending}
          title="Прикрепить фото или файл (до 20 МБ)"
          aria-label="Прикрепить файл"
        >
          📎
        </Button>
        <input ref={fileInput} type="file" className="hidden" onChange={handleFileChange} />
        <textarea
          ref={textarea}
          className="min-h-10 flex-1 resize-none overflow-y-auto rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
          rows={1}
          placeholder={attachment ? "Подпись к файлу (необязательно)" : MESSAGE_PLACEHOLDER}
          title={KEYBOARD_HINT}
          value={text}
          onChange={handleTextChange}
          onKeyDown={handleKeyDown}
          onSelect={handleSelect}
          onBlur={() => setSlash(null)}
          aria-label="Текст сообщения"
          aria-autocomplete="list"
        />
        <Button type="submit" className="h-10" disabled={!canSend}>
          Отправить
        </Button>
      </div>
      {text.length > warningAt && (
        <p className={`mt-1 text-right text-xs ${text.length > maxLength ? "text-danger" : "text-muted"}`}>
          {text.length} / {maxLength}
        </p>
      )}
    </form>
  );
}
