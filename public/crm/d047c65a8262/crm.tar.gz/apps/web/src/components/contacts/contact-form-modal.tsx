"use client";

import { CONTACT_SOURCE_LABELS, CONTACT_SOURCES, formatPhone, type ContactDto, type ContactSource } from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { SelectField, TextAreaField, TextField } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { ApiRequestError, formLevelError } from "@/lib/api";
import { useCreateContact, useUpdateContact, type ContactFormInput } from "@/lib/contacts";
import { useUserOptions } from "@/lib/users";

const SOURCE_OPTIONS = CONTACT_SOURCES.map((source) => ({ value: source, label: CONTACT_SOURCE_LABELS[source] }));
const SHOWN_FIELDS = ["name", "phones", "email", "tags", "notes"];
const NO_OWNER = "";

/** Ошибки по элементам массива (phones.0, tags.1) показываем под полем целиком. */
function fieldError(error: ApiRequestError | null, field: string): string | undefined {
  if (!error) return undefined;
  const key = Object.keys(error.fields).find((name) => name === field || name.startsWith(`${field}.`));
  return key ? error.fields[key] : undefined;
}

function splitList(value: string): string[] {
  return value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

interface ContactFormModalProps {
  /** Нет клиента — создаём нового. */
  contact?: ContactDto;
  /** Имя, уже введённое в поиске клиента. */
  initialName?: string;
  onClose: () => void;
  onSaved?: (contact: ContactDto) => void;
}

export function ContactFormModal({ contact, initialName = "", onClose, onSaved }: ContactFormModalProps) {
  const createContact = useCreateContact();
  const updateContact = useUpdateContact(contact?.id ?? "");
  const mutation = contact ? updateContact : createContact;
  const users = useUserOptions();

  const [name, setName] = useState(contact?.name ?? initialName);
  const [phones, setPhones] = useState(contact?.phones.map(formatPhone).join(", ") ?? "");
  const [email, setEmail] = useState(contact?.email ?? "");
  const [source, setSource] = useState<ContactSource>(contact?.source ?? "TELEGRAM");
  const [tags, setTags] = useState(contact?.tags.join(", ") ?? "");
  const [notes, setNotes] = useState(contact?.notes ?? "");
  const [ownerId, setOwnerId] = useState(contact?.owner?.id ?? NO_OWNER);

  const error = mutation.error instanceof ApiRequestError ? mutation.error : null;
  const formMessage = formLevelError(mutation.error, SHOWN_FIELDS);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const input: ContactFormInput = {
      name,
      phones: splitList(phones),
      email,
      source,
      tags: splitList(tags),
      notes,
      // Новому клиенту без выбора ответственного сервер назначит создателя.
      ...(contact || ownerId ? { ownerId: ownerId || null } : {}),
    };
    mutation.mutate(input, {
      onSuccess: (saved) => {
        onSaved?.(saved);
        onClose();
      },
    });
  }

  const ownerOptions = [{ value: NO_OWNER, label: contact ? "Не назначен" : "Я" }, ...(users.data ?? []).map((u) => ({ value: u.id, label: u.name }))];

  return (
    <Modal title={contact ? "Редактирование клиента" : "Новый клиент"} open onClose={onClose}>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
        {formMessage && <ErrorAlert message={formMessage} />}
        <TextField label="Имя" value={name} onChange={(e) => setName(e.target.value)} error={fieldError(error, "name")} autoFocus />
        <TextField
          label="Телефоны (через запятую)"
          placeholder="+998 90 123 45 67"
          value={phones}
          onChange={(e) => setPhones(e.target.value)}
          error={fieldError(error, "phones")}
        />
        <TextField label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} error={fieldError(error, "email")} />
        <div className="grid grid-cols-2 gap-3">
          <SelectField label="Источник" value={source} options={SOURCE_OPTIONS} onChange={(e) => setSource(e.target.value as ContactSource)} />
          <SelectField label="Ответственный" value={ownerId} options={ownerOptions} onChange={(e) => setOwnerId(e.target.value)} />
        </div>
        <TextField label="Теги (через запятую)" placeholder="VIP, семья, длительно" value={tags} onChange={(e) => setTags(e.target.value)} error={fieldError(error, "tags")} />
        <TextAreaField label="Заметки" value={notes} onChange={(e) => setNotes(e.target.value)} error={fieldError(error, "notes")} />
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={onClose}>
            Отмена
          </Button>
          <Button type="submit" disabled={mutation.isPending}>
            Сохранить
          </Button>
        </div>
      </form>
    </Modal>
  );
}
