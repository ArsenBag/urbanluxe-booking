"use client";

import { fileUrl, formatFileSize, MAX_FILE_BYTES, type ReplyTemplateDto } from "@crm/shared";
import { useId, useRef, useState, type ChangeEvent } from "react";
import { Button } from "@/components/ui/button";
import { useAttachTemplateFile, useRemoveTemplateFile } from "@/lib/channels";

const MAX_FILE_MB = MAX_FILE_BYTES / (1024 * 1024);

/**
 * Файл шаблона (видео входа, фото дома) в форме команды. Сохраняется сразу, отдельно от кнопки «Сохранить»:
 * так видно, загрузился ли файл, ещё до правки текста.
 */
export function TemplateFileField({ template }: { template: ReplyTemplateDto }) {
  const labelId = useId();
  const attach = useAttachTemplateFile();
  const remove = useRemoveTemplateFile();
  const input = useRef<HTMLInputElement>(null);
  const [sizeError, setSizeError] = useState<string | null>(null);
  const isPending = attach.isPending || remove.isPending;
  const error = sizeError ?? attach.error?.message ?? remove.error?.message ?? null;
  const { file } = template;

  function handleChange(event: ChangeEvent<HTMLInputElement>) {
    const selected = event.target.files?.[0] ?? null;
    // Очищаем input, чтобы тот же файл можно было выбрать снова.
    event.target.value = "";
    if (!selected) return;
    if (selected.size > MAX_FILE_BYTES) {
      setSizeError(`Файл больше ${formatFileSize(MAX_FILE_BYTES)}: ${selected.name}`);
      return;
    }
    setSizeError(null);
    remove.reset();
    attach.mutate({ id: template.id, file: selected });
  }

  function handleRemove() {
    setSizeError(null);
    attach.reset();
    remove.mutate(template.id);
  }

  return (
    <div className="flex flex-col gap-1.5" role="group" aria-labelledby={labelId}>
      <span id={labelId} className="text-sm font-medium">
        Файл
      </span>
      <div className="flex flex-wrap items-center gap-2 rounded-md border border-border bg-background px-3 py-1.5 text-sm">
        {file ? (
          <>
            <span aria-hidden>📎</span>
            <a
              href={fileUrl(file.id)}
              target="_blank"
              rel="noreferrer"
              className="min-w-0 flex-1 truncate text-primary hover:underline"
            >
              {file.fileName}
            </a>
            <span className="text-xs text-muted">{formatFileSize(file.size)}</span>
          </>
        ) : (
          <span className="flex-1 text-muted">Нет — только текст</span>
        )}
        <Button variant="ghost" onClick={() => input.current?.click()} disabled={isPending}>
          {attach.isPending ? "Загрузка…" : file ? "Заменить" : "Прикрепить"}
        </Button>
        {file && (
          <Button variant="ghost" className="text-danger" onClick={handleRemove} disabled={isPending}>
            Убрать
          </Button>
        )}
        <input ref={input} type="file" className="hidden" onChange={handleChange} />
      </div>
      {error && <p className="text-sm text-danger">{error}</p>}
      <p className="text-xs text-muted">
        Фото, видео или документ до {MAX_FILE_MB} МБ уходит вместе с текстом, текст становится подписью. Файл
        сохраняется сразу.
      </p>
    </div>
  );
}
