"use client";

import { useState } from "react";
import { ATTACHMENT_LABELS, canFetchAttachment, fileUrl, formatFileSize, type MessageAttachment } from "@crm/shared";
import { useFetchAttachment } from "@/lib/inbox";
import { PhotoViewer } from "./photo-viewer";

interface AttachmentViewProps {
  messageId: string;
  attachment: MessageAttachment;
  /** Цвет подписей: на синем фоне исходящих — светлый, на белом — серый. */
  metaColor: string;
}

/** Вложение сообщения: фото, плеер или ссылка на файл; без сохранённого файла — отметка и «Загрузить». */
export function AttachmentView({ messageId, attachment, metaColor }: AttachmentViewProps) {
  const label = ATTACHMENT_LABELS[attachment.kind];
  if (!attachment.fileId) {
    return <MissingFile messageId={messageId} attachment={attachment} label={label} metaColor={metaColor} />;
  }

  const url = fileUrl(attachment.fileId);
  if (attachment.kind === "photo") {
    return <PhotoAttachment url={url} label={label} fileName={attachment.fileName} />;
  }
  if (attachment.kind === "voice" || attachment.kind === "audio") {
    return <audio controls preload="none" src={url} className="mb-1 h-10 w-64 max-w-full" aria-label={label} />;
  }
  if (attachment.kind === "video") {
    return <video controls preload="metadata" src={url} className="mb-1 max-h-72 max-w-full rounded-lg" aria-label={label} />;
  }
  return (
    <a
      href={url}
      download={attachment.fileName ?? true}
      className="mb-1 flex items-center gap-2 rounded-lg border border-current/20 px-2 py-1.5 hover:bg-black/5"
    >
      <span aria-hidden>📄</span>
      <span className="min-w-0">
        <span className="block truncate font-medium">{attachment.fileName ?? label}</span>
        {attachment.size !== undefined && <span className={`block text-xs ${metaColor}`}>{formatFileSize(attachment.size)}</span>}
      </span>
    </a>
  );
}

/** Фото в переписке; по клику — во весь экран, как в мессенджерах. */
function PhotoAttachment({ url, label, fileName }: { url: string; label: string; fileName?: string }) {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setIsOpen(true)} className="mb-1 block cursor-zoom-in" title="Открыть фото">
        {/* eslint-disable-next-line @next/next/no-img-element -- файл из API за сессией, next/image не нужен */}
        <img src={url} alt={label} loading="lazy" className="max-h-72 max-w-full rounded-lg object-contain" />
      </button>
      {isOpen && <PhotoViewer src={url} alt={label} fileName={fileName} onClose={() => setIsOpen(false)} />}
    </>
  );
}

interface MissingFileProps {
  messageId: string;
  attachment: MessageAttachment;
  label: string;
  metaColor: string;
}

/**
 * Файл не сохранился (не скачался сразу или пришёл с импортом истории): отметка о вложении и
 * кнопка, которая загружает файл из мессенджера. Стикеры, геолокацию и контакты не загружаем.
 */
function MissingFile({ messageId, attachment, label, metaColor }: MissingFileProps) {
  const fetchFile = useFetchAttachment();
  return (
    <div className={`mb-1 text-xs ${metaColor}`}>
      <span className="font-medium">
        📎 {label}
        {attachment.fileName && `: ${attachment.fileName}`}
      </span>
      {canFetchAttachment(attachment) && (
        <button
          type="button"
          className="ml-2 font-semibold underline disabled:opacity-60"
          disabled={fetchFile.isPending}
          onClick={() => fetchFile.mutate(messageId)}
        >
          {fetchFile.isPending ? "Загрузка…" : "Загрузить"}
        </button>
      )}
      {fetchFile.isError && (
        <div role="alert" className="mt-0.5">
          {fetchFile.error.message}
        </div>
      )}
    </div>
  );
}
