import type { BookingDto } from "@crm/shared";
import { describe, expect, it } from "vitest";
import { initialBookingForm, toBookingRequest } from "./booking-form";

const booking = {
  id: "b1",
  rcId: null,
  source: "CRM",
  status: "REQUEST",
  property: { id: "p1", title: "U-51", address: null, rcId: 51, complex: "U-Tower" },
  contact: { id: "c1", name: "Азиз" },
  guestBlacklisted: false,
  deal: null,
  checkIn: "2026-10-12",
  checkOut: "2026-10-14",
  nights: 2,
  arrivalTime: "14:00",
  departureTime: null,
  amount: "120",
  prepayment: null,
  deposit: "50",
  currency: "USD",
  origin: null,
  guestName: "Азиз",
  guestPhone: "+998932062891",
  notes: "Поздний заезд",
  rcUrl: null,
  pmsId: null,
  pmsUrl: null,
  pmsError: null,
} satisfies BookingDto;

const draft = { propertyId: "p1", checkIn: "2026-10-12", checkOut: "2026-10-13" };

describe("initialBookingForm", () => {
  it("starts a new booking from the selected cells as a confirmed stay", () => {
    expect(initialBookingForm(undefined, draft)).toMatchObject({
      propertyId: "p1",
      checkIn: "2026-10-12",
      checkOut: "2026-10-13",
      status: "BOOKED",
      contact: null,
      guestName: "",
      amount: "",
    });
  });

  it("fills the form from a booking being edited", () => {
    expect(initialBookingForm(booking)).toMatchObject({
      propertyId: "p1",
      status: "REQUEST",
      arrivalTime: "14:00",
      departureTime: "",
      contact: { id: "c1", name: "Азиз" },
      amount: "120",
      deposit: "50",
      notes: "Поздний заезд",
    });
  });
});

describe("toBookingRequest", () => {
  it("sends a typed guest and turns empty fields into nulls", () => {
    const form = { ...initialBookingForm(undefined, draft), guestName: " Азиз ", guestPhone: "93 206 28 91", amount: "99.5" };

    expect(toBookingRequest(form)).toEqual({
      propertyId: "p1",
      status: "BOOKED",
      checkIn: "2026-10-12",
      checkOut: "2026-10-13",
      arrivalTime: null,
      departureTime: null,
      contactId: null,
      guestName: " Азиз ",
      guestPhone: "93 206 28 91",
      amount: 99.5,
      prepayment: null,
      deposit: null,
      notes: "",
    });
  });

  it("sends only the CRM client when one is chosen: name and phone come from the client card", () => {
    expect(toBookingRequest(initialBookingForm(booking))).toMatchObject({ contactId: "c1", guestName: null, guestPhone: null });
  });
});
