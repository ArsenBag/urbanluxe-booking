"use client";

import type { Role, UpdateUserInput, UserDto } from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { SelectField, TextField } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { ApiRequestError, formLevelError } from "@/lib/api";
import { useUpdateUser } from "@/lib/users";
import { ROLE_OPTIONS } from "./role-options";

const SHOWN_FIELDS = ["name", "password"];

interface EditUserModalProps {
  user: UserDto;
  isSelf: boolean;
  onClose: () => void;
}

/** Модалка монтируется заново для каждого пользователя, поэтому начальное состояние берём из props. */
export function EditUserModal({ user, isSelf, onClose }: EditUserModalProps) {
  const updateUser = useUpdateUser();
  const [name, setName] = useState(user.name);
  const [role, setRole] = useState<Role>(user.role);
  const [password, setPassword] = useState("");
  const error = updateUser.error instanceof ApiRequestError ? updateUser.error : null;
  const formMessage = formLevelError(updateUser.error, SHOWN_FIELDS);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const input: UpdateUserInput = {
      ...(name !== user.name && { name }),
      ...(role !== user.role && { role }),
      ...(password && { password }),
    };
    if (Object.keys(input).length === 0) {
      onClose();
      return;
    }
    updateUser.mutate({ id: user.id, input }, { onSuccess: onClose });
  }

  return (
    <Modal title={`Редактирование: ${user.name}`} open onClose={onClose}>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
        {formMessage && <ErrorAlert message={formMessage} />}
        <TextField label="Имя" value={name} onChange={(e) => setName(e.target.value)} error={error?.fields.name} />
        <SelectField
          label="Роль"
          value={role}
          options={ROLE_OPTIONS}
          disabled={isSelf}
          onChange={(e) => setRole(e.target.value as Role)}
        />
        <TextField
          label="Новый пароль (оставьте пустым, чтобы не менять)"
          type="password"
          autoComplete="new-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={error?.fields.password}
        />
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={onClose}>
            Отмена
          </Button>
          <Button type="submit" disabled={updateUser.isPending}>
            Сохранить
          </Button>
        </div>
      </form>
    </Modal>
  );
}
