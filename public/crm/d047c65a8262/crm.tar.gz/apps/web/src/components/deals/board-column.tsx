"use client";

import type { DealDto, StageDto } from "@crm/shared";
import { useDroppable } from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { formatMoney } from "@/lib/format";
import { columnTotals } from "./board-state";
import { SortableDealCard } from "./deal-card";

interface BoardColumnProps {
  stage: StageDto;
  deals: DealDto[];
  onAdd: (stageId: string) => void;
}

export function BoardColumn({ stage, deals, onAdd }: BoardColumnProps) {
  const { setNodeRef, isOver } = useDroppable({ id: stage.id });
  const totals = Object.entries(columnTotals(deals))
    .map(([currency, sum]) => formatMoney(String(sum), currency))
    .join(" · ");

  return (
    <div className="flex w-72 shrink-0 flex-col rounded-xl bg-black/[0.03] dark:bg-white/[0.03]">
      <div className="border-t-4 px-3 pb-2 pt-3" style={{ borderTopColor: stage.color }}>
        <div className="flex items-center justify-between gap-2">
          <h2 className="truncate text-sm font-semibold">{stage.name}</h2>
          <span className="text-xs text-muted">{deals.length}</span>
        </div>
        <div className="flex items-center justify-between text-xs text-muted">
          <span>{totals || " "}</span>
          <button
            type="button"
            className="rounded px-1 text-base leading-none hover:bg-background hover:text-foreground"
            onClick={() => onAdd(stage.id)}
            aria-label={`Новая сделка на этапе «${stage.name}»`}
          >
            +
          </button>
        </div>
      </div>
      <SortableContext id={stage.id} items={deals.map((deal) => deal.id)} strategy={verticalListSortingStrategy}>
        <div
          ref={setNodeRef}
          className={`flex min-h-24 flex-1 flex-col gap-2 overflow-y-auto px-2 pb-2 ${isOver ? "bg-primary/5" : ""}`}
        >
          {deals.map((deal) => (
            <SortableDealCard key={deal.id} deal={deal} />
          ))}
        </div>
      </SortableContext>
    </div>
  );
}
