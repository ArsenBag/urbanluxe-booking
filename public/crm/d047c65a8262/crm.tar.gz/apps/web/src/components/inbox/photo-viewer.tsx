"use client";

import { useEffect, useRef } from "react";

interface PhotoViewerProps {
  src: string;
  alt: string;
  fileName?: string;
  onClose: () => void;
}

/**
 * Фото во весь экран поверх CRM, как в мессенджерах: без скачивания и новой вкладки.
 * Закрывается крестиком, Esc или кликом мимо фото. Открыт, пока компонент показан.
 */
export function PhotoViewer({ src, alt, fileName, onClose }: PhotoViewerProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (dialog && !dialog.open) dialog.showModal();
  }, []);

  // Закрываем сам <dialog>: браузер вернёт фокус на миниатюру, а событие close вызовет onClose.
  const close = () => dialogRef.current?.close();

  return (
    <dialog
      ref={dialogRef}
      onClose={onClose}
      aria-label={alt}
      className="m-0 h-dvh max-h-none w-dvw max-w-none bg-transparent p-0 backdrop:bg-black/85"
    >
      {/* Клик по затемнению вокруг фото закрывает просмотр. */}
      <button type="button" tabIndex={-1} aria-hidden className="absolute inset-0 cursor-zoom-out" onClick={close} />
      <div className="pointer-events-none relative flex h-full flex-col">
        <div className="pointer-events-auto flex justify-end gap-2 p-3">
          <a
            href={src}
            download={fileName ?? true}
            className="rounded-lg bg-white/15 px-3 py-1.5 text-sm font-medium text-white hover:bg-white/25"
          >
            Скачать
          </a>
          <button
            type="button"
            onClick={close}
            aria-label="Закрыть"
            className="rounded-lg bg-white/15 px-3 py-1.5 text-sm font-medium text-white hover:bg-white/25"
          >
            ✕
          </button>
        </div>
        <div className="flex min-h-0 flex-1 items-center justify-center px-4 pb-4">
          {/* eslint-disable-next-line @next/next/no-img-element -- файл из API за сессией, next/image не нужен */}
          <img src={src} alt={alt} className="pointer-events-auto max-h-full max-w-full rounded-lg object-contain" />
        </div>
      </div>
    </dialog>
  );
}
