"use client";

import { reportPeriodSchema, type ReportPeriod } from "@crm/shared";
import { useState } from "react";
import { tashkentDayKey } from "@/lib/format";
import { REPORT_PRESET_LABELS, REPORT_PRESETS, matchPreset, presetPeriod } from "@/lib/report-period";

interface PeriodFilterProps {
  period: ReportPeriod;
  onChange: (period: ReportPeriod) => void;
}

/**
 * Период для всех отчётов страницы: пресеты и свои даты. Верная дата применяется сразу, а ошибка видна
 * только по уходу из поля или Enter: пока год набирают с клавиатуры, промежуточное «0002» — не ошибка.
 */
export function PeriodFilter({ period, onChange }: PeriodFilterProps) {
  const [draft, setDraft] = useState(period);
  const [error, setError] = useState<string | null>(null);
  // Сегодня — на момент отрисовки: вкладка могла пережить полночь.
  const today = tashkentDayKey(new Date());
  const selected = matchPreset(period, today);

  const apply = (next: ReportPeriod, showError = true) => {
    setDraft(next);
    const parsed = reportPeriodSchema.safeParse(next);
    if (!parsed.success) {
      if (showError) setError(parsed.error.issues[0]?.message ?? "Неверный период");
      return;
    }
    setError(null);
    if (parsed.data.from !== period.from || parsed.data.to !== period.to) onChange(parsed.data);
  };

  return (
    <div className="mb-6">
      <div className="flex flex-wrap items-center gap-3">
        <div className="inline-flex flex-wrap rounded-md border border-border bg-surface p-0.5" role="group" aria-label="Период">
          {REPORT_PRESETS.map((preset) => (
            <button
              key={preset}
              type="button"
              aria-pressed={selected === preset}
              onClick={() => apply(presetPeriod(preset, today))}
              className={`rounded px-3 py-1 text-sm ${selected === preset ? "bg-primary text-primary-foreground" : "text-muted hover:text-foreground"}`}
            >
              {REPORT_PRESET_LABELS[preset]}
            </button>
          ))}
        </div>
        <DateField label="с" value={draft.from} onDraft={(from) => apply({ ...draft, from }, false)} onCommit={() => apply(draft)} />
        <DateField label="по" value={draft.to} onDraft={(to) => apply({ ...draft, to }, false)} onCommit={() => apply(draft)} />
      </div>
      {error && (
        <p role="alert" className="mt-2 text-sm text-danger">
          {error}
        </p>
      )}
    </div>
  );
}

interface DateFieldProps {
  label: string;
  value: string;
  onDraft: (value: string) => void;
  onCommit: () => void;
}

function DateField({ label, value, onDraft, onCommit }: DateFieldProps) {
  return (
    <label className="flex items-center gap-2 text-sm text-muted">
      {label}
      <input
        type="date"
        className="h-8 rounded-md border border-border bg-surface px-2 text-sm text-foreground"
        value={value}
        onChange={(event) => event.target.value && onDraft(event.target.value)}
        onBlur={onCommit}
        onKeyDown={(event) => event.key === "Enter" && onCommit()}
      />
    </label>
  );
}
