"use client";

import type { BookingDto, DealDto, LinkTarget } from "@crm/shared";
import { useState, type ReactNode } from "react";
import { BookingSummary } from "@/components/bookings/booking-summary";
import { StageBadge } from "@/components/deals/stage-badge";
import { ErrorAlert } from "@/components/ui/alert";
import { formatStay } from "@/lib/format";
import { useBookingSearch, useDealSearch, type LinkKind } from "@/lib/linking";
import { useDebouncedValue } from "@/lib/use-debounced-value";

const SEARCH_DELAY_MS = 250;

const TABS: Array<{ kind: LinkKind; label: string; placeholder: string; emptyHint: string }> = [
  { kind: "booking", label: "Бронь", placeholder: "Квартира (U-51), имя гостя или телефон", emptyHint: "Текущие и ближайшие брони" },
  { kind: "deal", label: "Сделка", placeholder: "Название сделки, имя или телефон клиента", emptyHint: "Открытые сделки" },
];

const chip = (isOn: boolean) =>
  `rounded-md px-3 py-1.5 text-sm font-medium ${isOn ? "bg-primary text-primary-foreground" : "text-muted hover:bg-background"}`;

/** Первый шаг связывания: найти бронь (по квартире, гостю, телефону) или сделку. */
export function LinkSearch({ onSelect }: { onSelect: (target: LinkTarget) => void }) {
  const [kind, setKind] = useState<LinkKind>("booking");
  const [query, setQuery] = useState("");
  const debounced = useDebouncedValue(query.trim(), SEARCH_DELAY_MS);
  const tab = TABS.find((item) => item.kind === kind) ?? TABS[0];

  return (
    <div className="flex flex-col gap-3">
      <div className="flex gap-1" role="group" aria-label="Что искать">
        {TABS.map((item) => (
          <button key={item.kind} type="button" className={chip(kind === item.kind)} aria-pressed={kind === item.kind} onClick={() => setKind(item.kind)}>
            {item.label}
          </button>
        ))}
      </div>
      <input
        type="search"
        // Окно открыли, чтобы искать: курсор сразу в поле (и при возврате «Назад»).
        autoFocus
        data-autofocus
        className="h-9 w-full rounded-md border border-border bg-background px-3 text-sm outline-none focus:border-primary"
        placeholder={tab.placeholder}
        aria-label={tab.placeholder}
        value={query}
        onChange={(event) => setQuery(event.target.value)}
      />
      {!debounced && <p className="text-xs text-muted">{tab.emptyHint}</p>}
      <div className="max-h-80 overflow-y-auto rounded-md border border-border">
        {kind === "booking" ? (
          <BookingResults query={debounced} onSelect={(bookingId) => onSelect({ bookingId })} />
        ) : (
          <DealResults query={debounced} onSelect={(dealId) => onSelect({ dealId })} />
        )}
      </div>
    </div>
  );
}

interface ResultListProps<T> {
  items: T[] | undefined;
  error: Error | null;
  isPending: boolean;
  onSelect: (id: string) => void;
  render: (item: T) => ReactNode;
}

function ResultList<T extends { id: string }>({ items, error, isPending, onSelect, render }: ResultListProps<T>) {
  if (error) return <ErrorAlert message={error.message} />;
  if (isPending) return <p className="p-3 text-sm text-muted">Ищем…</p>;
  if (!items?.length) return <p className="p-3 text-sm text-muted">Ничего не нашлось</p>;
  return (
    <ul className="divide-y divide-border">
      {items.map((item) => (
        <li key={item.id}>
          <button type="button" className="block w-full px-3 py-2 text-left hover:bg-background" onClick={() => onSelect(item.id)}>
            {render(item)}
          </button>
        </li>
      ))}
    </ul>
  );
}

function BookingResults({ query, onSelect }: { query: string; onSelect: (id: string) => void }) {
  const results = useBookingSearch(query, true);
  return (
    <ResultList<BookingDto>
      items={results.data}
      error={results.error}
      isPending={results.isPending}
      onSelect={onSelect}
      render={(booking) => <BookingSummary booking={booking} showGuest />}
    />
  );
}

function DealResults({ query, onSelect }: { query: string; onSelect: (id: string) => void }) {
  const results = useDealSearch(query, true);
  return (
    <ResultList<DealDto>
      items={results.data}
      error={results.error}
      isPending={results.isPending}
      onSelect={onSelect}
      render={(deal) => {
        const stay = formatStay(deal.checkIn, deal.checkOut);
        return (
          <span className="flex items-start justify-between gap-3">
            <span className="min-w-0">
              <span className="block truncate text-sm font-medium">{deal.title}</span>
              <span className="block truncate text-xs text-muted">
                {deal.contact.name}
                {stay && ` · ${stay}`}
              </span>
            </span>
            <StageBadge stageId={deal.stageId} />
          </span>
        );
      }}
    />
  );
}
