"use client";

import { CURRENCIES, type Currency, type EntityRef, type PipelineDto } from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ContactFormModal } from "@/components/contacts/contact-form-modal";
import { ContactPicker } from "@/components/contacts/contact-picker";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { SelectField, TextAreaField, TextField } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { ApiRequestError, formLevelError } from "@/lib/api";
import { useCreateDeal } from "@/lib/deals";

const SHOWN_FIELDS = ["contactId", "title", "checkIn", "checkOut", "guests", "amount", "notes"];
const CURRENCY_OPTIONS = CURRENCIES.map((currency) => ({ value: currency, label: currency }));

interface DealFormModalProps {
  pipelines: PipelineDto[];
  defaultPipelineId?: string;
  defaultStageId?: string;
  /** Клиент заранее известен (создание из карточки клиента). */
  contact?: EntityRef;
  onClose: () => void;
  onCreated?: (dealId: string) => void;
}

const toNumberOrNull = (value: string) => (value.trim() === "" ? null : Number(value));

export function DealFormModal({ pipelines, defaultPipelineId, defaultStageId, contact, onClose, onCreated }: DealFormModalProps) {
  const createDeal = useCreateDeal();
  const [pipelineId, setPipelineId] = useState(defaultPipelineId ?? pipelines[0]?.id ?? "");
  const [stageId, setStageId] = useState(defaultStageId ?? "");
  const [selectedContact, setSelectedContact] = useState<EntityRef | null>(contact ?? null);
  const [newContactName, setNewContactName] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState<Currency>("USD");
  const [notes, setNotes] = useState("");
  const [contactError, setContactError] = useState<string>();

  const pipeline = pipelines.find((p) => p.id === pipelineId);
  const stageOptions = (pipeline?.stages ?? []).map((stage) => ({ value: stage.id, label: stage.name }));
  const error = createDeal.error instanceof ApiRequestError ? createDeal.error : null;
  const formMessage = formLevelError(createDeal.error, SHOWN_FIELDS);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedContact) {
      setContactError("Выберите или создайте клиента");
      return;
    }
    createDeal.mutate(
      {
        pipelineId,
        contactId: selectedContact.id,
        ...(stageId && { stageId }),
        ...(title.trim() && { title }),
        checkIn: checkIn || null,
        checkOut: checkOut || null,
        guests: toNumberOrNull(guests),
        amount: toNumberOrNull(amount),
        currency,
        notes,
      },
      {
        onSuccess: (deal) => {
          onCreated?.(deal.id);
          onClose();
        },
      },
    );
  }

  if (newContactName !== null) {
    return (
      <ContactFormModal
        initialName={newContactName}
        onClose={() => setNewContactName(null)}
        onSaved={(created) => {
          setSelectedContact({ id: created.id, name: created.name });
          setContactError(undefined);
        }}
      />
    );
  }

  return (
    <Modal title="Новая сделка" open onClose={onClose}>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
        {formMessage && <ErrorAlert message={formMessage} />}
        {contact ? (
          <TextField label="Клиент" value={contact.name} disabled />
        ) : (
          <ContactPicker
            value={selectedContact}
            onChange={(value) => {
              setSelectedContact(value);
              setContactError(undefined);
            }}
            onCreateNew={(name) => setNewContactName(name)}
            error={contactError ?? error?.fields.contactId}
          />
        )}
        <div className="grid grid-cols-2 gap-3">
          <SelectField
            label="Воронка"
            value={pipelineId}
            options={pipelines.map((p) => ({ value: p.id, label: p.name }))}
            onChange={(e) => {
              setPipelineId(e.target.value);
              setStageId("");
            }}
          />
          <SelectField
            label="Этап"
            value={stageId || stageOptions[0]?.value || ""}
            options={stageOptions}
            onChange={(e) => setStageId(e.target.value)}
          />
        </div>
        <TextField
          label="Название (необязательно)"
          placeholder="По умолчанию — имя клиента"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          error={error?.fields.title}
        />
        <div className="grid grid-cols-3 gap-3">
          <TextField label="Заезд" type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} error={error?.fields.checkIn} />
          <TextField label="Выезд" type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} error={error?.fields.checkOut} />
          <TextField label="Гостей" type="number" min={1} value={guests} onChange={(e) => setGuests(e.target.value)} error={error?.fields.guests} />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-2">
            <TextField label="Сумма" type="number" min={0} step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} error={error?.fields.amount} />
          </div>
          <SelectField label="Валюта" value={currency} options={CURRENCY_OPTIONS} onChange={(e) => setCurrency(e.target.value as Currency)} />
        </div>
        <TextAreaField label="Заметки" value={notes} onChange={(e) => setNotes(e.target.value)} error={error?.fields.notes} rows={2} />
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={onClose}>
            Отмена
          </Button>
          <Button type="submit" disabled={createDeal.isPending || !pipelineId}>
            Создать
          </Button>
        </div>
      </form>
    </Modal>
  );
}
