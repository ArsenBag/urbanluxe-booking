import type { ReplyTemplateDto, TemplateFileDto } from "@crm/shared";

/**
 * Файл сообщения: выбранный с компьютера (загружается при отправке) или файл шаблона
 * (уже на сервере — отправляется его копия).
 */
export type ComposerAttachment =
  | { source: "upload"; file: File }
  | { source: "template"; templateId: string; file: TemplateFileDto };

/** В сообщении один файл: шаблон с файлом заменяет прикреплённый, шаблон с одним текстом его не трогает. */
export function attachmentAfterTemplate(current: ComposerAttachment | null, template: ReplyTemplateDto): ComposerAttachment | null {
  return template.file ? { source: "template", templateId: template.id, file: template.file } : current;
}

/** Имя и размер для плашки над полем ввода. */
export function attachmentInfo(attachment: ComposerAttachment): { name: string; size: number } {
  return attachment.source === "upload"
    ? { name: attachment.file.name, size: attachment.file.size }
    : { name: attachment.file.fileName, size: attachment.file.size };
}
