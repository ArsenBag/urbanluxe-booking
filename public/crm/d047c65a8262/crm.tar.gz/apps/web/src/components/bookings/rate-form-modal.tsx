"use client";

import type { PropertyDto } from "@crm/shared";
import { useMemo, useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { SelectField, TextField } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { ApiRequestError, formLevelError } from "@/lib/api";
import { pluralize } from "@/lib/format";
import { useUpdateRates } from "@/lib/rates";
import { groupApartmentsByComplex } from "./chessboard-layout";
import { initialRateForm, rateFormInvalid, rateFormSummary, toRateRequest, type RateDraft, type RateForm, type RateToggle } from "./rate-form";

const SHOWN_FIELDS = ["propertyIds", "from", "to", "price", "minStay"];
const CHANGE_FIELDS = ["price", "minStay", "closed", "closedToArrival", "closedToDeparture"];
/** Порядок как в календаре: с понедельника. Значения — дни недели JavaScript (0 — воскресенье). */
const WEEKDAYS = [
  { value: 1, label: "Пн" },
  { value: 2, label: "Вт" },
  { value: 3, label: "Ср" },
  { value: 4, label: "Чт" },
  { value: 5, label: "Пт" },
  { value: 6, label: "Сб" },
  { value: 0, label: "Вс" },
];
const SALES_OPTIONS = [
  { value: "", label: "Не менять" },
  { value: "off", label: "Открыть" },
  { value: "on", label: "Закрыть" },
];
const STAY_OPTIONS = [
  { value: "", label: "Не менять" },
  { value: "off", label: "Разрешён" },
  { value: "on", label: "Запрещён" },
];

interface RateFormModalProps {
  apartments: PropertyDto[];
  draft: RateDraft;
  /** Базовая валюта цен; null — цены ещё не загрузились. */
  currency: string | null;
  onClose: () => void;
}

/**
 * Цены и ограничения на ночи квартир, как в RealtyCalendar: цена, минимум ночей, закрытие продаж, запрет
 * заезда или выезда. Можно сразу на несколько квартир и только на некоторые дни недели (например, пт–сб).
 */
export function RateFormModal({ apartments, draft, currency, onClose }: RateFormModalProps) {
  const save = useUpdateRates();
  const [form, setForm] = useState<RateForm>(() => initialRateForm(draft));
  const change = (patch: Partial<RateForm>) => setForm((current) => ({ ...current, ...patch }));
  const request = useMemo(() => toRateRequest(form), [form]);
  const changesSomething = CHANGE_FIELDS.some((field) => field in request);
  const summary = useMemo(() => rateFormSummary(form), [form]);
  const invalid = rateFormInvalid(form);
  const error = save.error instanceof ApiRequestError ? save.error : null;
  const formMessage = formLevelError(save.error, SHOWN_FIELDS);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    save.mutate(request, { onSuccess: onClose });
  }

  return (
    <Modal title="Цены и ограничения" open onClose={onClose} wide>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
        {formMessage && <ErrorAlert message={formMessage} />}
        <ApartmentPicker apartments={apartments} selected={form.propertyIds} onChange={(propertyIds) => change({ propertyIds })} error={error?.fields.propertyIds} />
        <div className="grid grid-cols-2 gap-3">
          <TextField label="Первая ночь" type="date" value={form.from} onChange={(e) => change({ from: e.target.value })} error={error?.fields.from} />
          <TextField label="Последняя ночь" type="date" value={form.to} min={form.from || undefined} onChange={(e) => change({ to: e.target.value })} error={error?.fields.to} />
        </div>
        <WeekdayPicker value={form.weekdays} onChange={(weekdays) => change({ weekdays })} />
        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1">
            <TextField
              label={currency ? `Цена за ночь, ${currency}` : "Цена за ночь"}
              type="number"
              min={0}
              step="0.01"
              placeholder={form.clearPrice ? "цена будет убрана" : "не менять"}
              value={form.clearPrice ? "" : form.price}
              disabled={form.clearPrice}
              onChange={(e) => change({ price: e.target.value })}
              error={error?.fields.price}
            />
            <label className="flex items-center gap-1.5 text-xs text-muted">
              <input type="checkbox" checked={form.clearPrice} onChange={(e) => change({ clearPrice: e.target.checked })} />
              Убрать цену
            </label>
          </div>
          <TextField
            label="Минимум ночей"
            type="number"
            min={1}
            step={1}
            placeholder="не менять"
            value={form.minStay}
            onChange={(e) => change({ minStay: e.target.value })}
            error={error?.fields.minStay}
          />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <SelectField label="Продажи" value={form.closed} options={SALES_OPTIONS} onChange={(e) => change({ closed: e.target.value as RateToggle })} />
          <SelectField label="Заезд" value={form.closedToArrival} options={STAY_OPTIONS} onChange={(e) => change({ closedToArrival: e.target.value as RateToggle })} />
          <SelectField label="Выезд" value={form.closedToDeparture} options={STAY_OPTIONS} onChange={(e) => change({ closedToDeparture: e.target.value as RateToggle })} />
        </div>
        {invalid && <p className="text-sm text-danger">В цене или минимуме ночей должно быть число.</p>}
        <p className="text-xs text-muted">
          {summary.total > 0
            ? `Изменится ${summary.nights} ${pluralize(summary.nights, ["ночь", "ночи", "ночей"])} у ${summary.apartments} ${pluralize(summary.apartments, ["квартиры", "квартир", "квартир"])}. `
            : ""}
          Пустые поля не меняются; минимум 1 ночь — без ограничения. На площадки цены уйдут, когда подключим менеджер каналов.
        </p>
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={onClose}>
            Закрыть
          </Button>
          <Button type="submit" disabled={save.isPending || summary.total === 0 || !changesSomething || invalid}>
            Сохранить
          </Button>
        </div>
      </form>
    </Modal>
  );
}

interface ApartmentPickerProps {
  apartments: PropertyDto[];
  selected: string[];
  onChange: (ids: string[]) => void;
  error?: string;
}

/** Галочки квартир по ЖК; галочка у ЖК выбирает или снимает все его квартиры. */
function ApartmentPicker({ apartments, selected, onChange, error }: ApartmentPickerProps) {
  const groups = useMemo(() => groupApartmentsByComplex(apartments), [apartments]);
  const chosen = new Set(selected);
  const toggle = (ids: string[], on: boolean) =>
    onChange(on ? [...new Set([...selected, ...ids])] : selected.filter((id) => !ids.includes(id)));

  return (
    <fieldset className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <legend className="text-sm font-medium">Квартиры · выбрано {selected.length}</legend>
        <div className="flex gap-2 text-xs">
          <button type="button" className="text-primary hover:underline" onClick={() => onChange(apartments.map((a) => a.id))}>
            Все
          </button>
          <button type="button" className="text-muted hover:underline" onClick={() => onChange([])}>
            Снять
          </button>
        </div>
      </div>
      <div className="max-h-56 overflow-auto rounded-md border border-border p-2">
        {groups.map((group) => {
          const ids = group.items.map((item) => item.id);
          const all = ids.every((id) => chosen.has(id));
          return (
            <div key={group.title} className="mb-2 last:mb-0">
              <label className="flex items-center gap-2 text-sm font-medium">
                <input type="checkbox" checked={all} onChange={(e) => toggle(ids, e.target.checked)} />
                {group.title} <span className="font-normal text-muted">({group.items.length})</span>
              </label>
              <div className="grid grid-cols-3 gap-x-2 pl-5 sm:grid-cols-4">
                {group.items.map((apartment) => (
                  <label key={apartment.id} className="flex min-w-0 items-center gap-1.5 text-sm">
                    <input type="checkbox" checked={chosen.has(apartment.id)} onChange={(e) => toggle([apartment.id], e.target.checked)} />
                    <span className="truncate">{apartment.title}</span>
                  </label>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      {error && <p className="text-sm text-danger">{error}</p>}
    </fieldset>
  );
}

/** Дни недели: ничего не выбрано — все дни периода. */
function WeekdayPicker({ value, onChange }: { value: number[]; onChange: (weekdays: number[]) => void }) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-sm font-medium">Дни недели</span>
      <div className="flex flex-wrap items-center gap-1">
        {WEEKDAYS.map((day) => {
          const active = value.includes(day.value);
          return (
            <button
              key={day.value}
              type="button"
              aria-pressed={active}
              className={`h-8 w-10 rounded-md border text-sm ${active ? "border-primary bg-primary text-white" : "border-border bg-surface hover:bg-black/5"}`}
              onClick={() => onChange(active ? value.filter((v) => v !== day.value) : [...value, day.value])}
            >
              {day.label}
            </button>
          );
        })}
        <span className="ml-1 text-xs text-muted">{value.length === 0 ? "все дни" : "только выбранные"}</span>
      </div>
    </div>
  );
}
