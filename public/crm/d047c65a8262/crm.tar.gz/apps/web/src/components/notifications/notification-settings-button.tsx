"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { saveNotificationSettings, useNotificationSettings, type NotificationSettings } from "@/lib/notification-settings";
import { playNotificationSound, unlockAudio } from "@/lib/notification-sounds";

type Permission = NotificationPermission | "unsupported";

const PERMISSION_HINTS: Record<Permission, string> = {
  granted: "Браузер разрешил уведомления.",
  default: "Браузер ещё не спрашивал разрешение.",
  denied: "Браузер запретил уведомления для CRM. Разрешите их в настройках сайта: значок слева от адреса → «Уведомления».",
  unsupported: "Этот браузер не поддерживает системные уведомления.",
};

const VOLUME_STEP = 5;
const PERCENT = 100;

/** Кнопка в меню: громкость и виды уведомлений на этом компьютере. */
export function NotificationSettingsButton() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <>
      <Button variant="ghost" className="-ml-4" onClick={() => setIsOpen(true)}>
        🔔 Уведомления
      </Button>
      <Modal title="Уведомления на этом компьютере" open={isOpen} onClose={() => setIsOpen(false)}>
        {isOpen && <NotificationSettingsForm onDone={() => setIsOpen(false)} />}
      </Modal>
    </>
  );
}

function NotificationSettingsForm({ onDone }: { onDone: () => void }) {
  const settings = useNotificationSettings();
  const [permission, setPermission] = useState<Permission>(() =>
    typeof Notification === "undefined" ? "unsupported" : Notification.permission,
  );
  const update = (patch: Partial<NotificationSettings>) => saveNotificationSettings({ ...settings, ...patch });
  const volumePercent = Math.round(settings.volume * PERCENT);

  // Клик разрешает звук; играем, когда браузер его включит.
  const preview = (sound: "message" | "booking") => {
    void unlockAudio().then(() => playNotificationSound(sound, settings.volume));
  };

  const askPermission = async () => {
    if (typeof Notification === "undefined") return;
    setPermission(await Notification.requestPermission());
  };

  return (
    <div className="flex flex-col gap-4 text-sm">
      <label className="flex flex-col gap-2">
        <span className="font-medium">Громкость: {volumePercent}%</span>
        <input
          type="range"
          min={0}
          max={PERCENT}
          step={VOLUME_STEP}
          value={volumePercent}
          onChange={(event) => update({ volume: Number(event.target.value) / PERCENT })}
          onPointerUp={() => preview("message")}
          className="accent-primary"
        />
      </label>
      <div className="flex gap-2">
        <Button variant="secondary" className="h-8" onClick={() => preview("message")}>
          ▶ Сообщение
        </Button>
        <Button variant="secondary" className="h-8" onClick={() => preview("booking")}>
          ▶ Бронь
        </Button>
      </div>

      <fieldset className="flex flex-col gap-2">
        <legend className="mb-1 font-medium">Звук</legend>
        <Checkbox label="Новые сообщения в моих и неназначенных чатах" checked={settings.messageSound} onChange={(messageSound) => update({ messageSound })} />
        <Checkbox label="Новые брони" checked={settings.bookingSound} onChange={(bookingSound) => update({ bookingSound })} />
      </fieldset>

      <div className="flex flex-col gap-1">
        <Checkbox
          label="Системные уведомления, когда CRM свёрнута"
          checked={settings.systemNotifications}
          onChange={(systemNotifications) => update({ systemNotifications })}
        />
        {settings.systemNotifications && (
          <Checkbox
            label="Показывать имя и текст (выключите, если экран видят гости)"
            checked={settings.systemNotificationText}
            onChange={(systemNotificationText) => update({ systemNotificationText })}
          />
        )}
        <p className="text-xs text-muted">{PERMISSION_HINTS[permission]}</p>
        {permission === "default" && settings.systemNotifications && (
          <Button variant="secondary" className="h-8 self-start" onClick={() => void askPermission()}>
            Разрешить уведомления
          </Button>
        )}
      </div>

      <p className="text-xs text-muted">
        Настройки сохраняются в этом браузере. Уведомления приходят, пока CRM открыта хотя бы во вкладке.
      </p>
      <Button className="self-end" onClick={onDone}>
        Готово
      </Button>
    </div>
  );
}

function Checkbox({ label, checked, onChange }: { label: string; checked: boolean; onChange: (checked: boolean) => void }) {
  return (
    <label className="flex items-center gap-2">
      <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} className="accent-primary" />
      {label}
    </label>
  );
}
