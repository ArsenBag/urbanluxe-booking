"use client";

import { BOOKING_STATUS_LABELS, type BookingDto } from "@crm/shared";
import { bookingChannel, bookingGuestName } from "@/lib/booking-channels";
import { formatStay } from "@/lib/format";
import { BOOKING_STATUS_COLORS } from "./booking-row";
import { ChannelBadge } from "./channel-badge";

/** Короткая сводка брони для узких мест (панель диалога, поиск): квартира, даты, статус и гость. */
export function BookingSummary({ booking, showGuest = false }: { booking: BookingDto; showGuest?: boolean }) {
  const guest = bookingGuestName(booking);
  const channel = bookingChannel(booking);
  return (
    <span className="flex items-start justify-between gap-3">
      <span className="min-w-0">
        <span className="block truncate text-sm font-medium">{booking.property?.title ?? "Объект не указан"}</span>
        <span className="block text-xs text-muted">{formatStay(booking.checkIn, booking.checkOut)}</span>
        {showGuest && guest && (
          <span className="flex items-center gap-1 truncate text-xs text-muted">
            {channel && <ChannelBadge channel={channel} />}
            <span className="truncate">
              {guest}
              {channel && (booking.contact ?? booking.guestName) && ` · ${channel.label}`}
            </span>
          </span>
        )}
      </span>
      <span className={`shrink-0 text-xs ${BOOKING_STATUS_COLORS[booking.status]}`}>{BOOKING_STATUS_LABELS[booking.status]}</span>
    </span>
  );
}
