"use client";

import { CHANNEL_TYPE_LABELS, type ConversationDto } from "@crm/shared";
import { GuestBadges } from "@/components/guests/guest-badges";
import { ErrorAlert } from "@/components/ui/alert";
import { formatListTime } from "@/lib/format";
import { useConversations, type ConversationFilters } from "@/lib/inbox";
import { useDebouncedValue } from "@/lib/use-debounced-value";
import { Avatar } from "./avatar";
import { ChannelIcon } from "./channel-icon";
import { ConversationFiltersPanel } from "./conversation-filters";

const SEARCH_DELAY_MS = 300;

interface ConversationListProps {
  filters: ConversationFilters;
  onFiltersChange: (filters: ConversationFilters) => void;
  selectedId: string | null;
  onSelect: (id: string) => void;
}

function ConversationItem({
  conversation,
  isSelected,
  onSelect,
}: {
  conversation: ConversationDto;
  isSelected: boolean;
  onSelect: () => void;
}) {
  const hasUnread = conversation.unreadCount > 0;
  const isBlacklisted = conversation.contact.blacklist !== null;
  const background = isSelected ? "bg-primary/10" : isBlacklisted ? "bg-danger/10 hover:bg-danger/15" : "hover:bg-background";
  return (
    <li>
      <button
        type="button"
        onClick={onSelect}
        aria-current={isSelected ? "true" : undefined}
        className={`flex w-full gap-3 border-l-4 px-3 py-2.5 text-left ${isBlacklisted ? "border-danger" : "border-transparent"} ${background}`}
      >
        <Avatar
          name={conversation.contact.name}
          seed={conversation.contact.id}
          fileId={conversation.contact.avatarFileId}
          channel={conversation.channel.type}
        />
        <span className="min-w-0 flex-1">
          <span className="flex items-baseline justify-between gap-2">
            <span className="flex min-w-0 items-center gap-1.5">
              <span className={`truncate text-sm ${hasUnread ? "font-semibold" : "font-medium"}`}>{conversation.contact.name}</span>
              <GuestBadges vip={conversation.contact.vip} blacklisted={isBlacklisted} compact />
            </span>
            {conversation.lastMessageAt && (
              <span className="shrink-0 text-xs text-muted">{formatListTime(conversation.lastMessageAt)}</span>
            )}
          </span>
          <span className="flex items-center justify-between gap-2">
            <span className={`truncate text-xs ${hasUnread ? "text-foreground" : "text-muted"}`}>
              {conversation.lastMessagePreview || "Нет сообщений"}
            </span>
            {hasUnread && (
              <span className="shrink-0 rounded-full bg-primary px-1.5 text-xs font-semibold text-primary-foreground">
                {conversation.unreadCount}
              </span>
            )}
          </span>
          <span className="flex min-w-0 items-center gap-1 text-[11px] text-muted">
            <ChannelIcon type={conversation.channel.type} size={12} />
            <span className="truncate">
              {CHANNEL_TYPE_LABELS[conversation.channel.type]}
              {conversation.assignee ? ` · ${conversation.assignee.name}` : " · не назначен"}
            </span>
          </span>
        </span>
      </button>
    </li>
  );
}

export function ConversationList({ filters, onFiltersChange, selectedId, onSelect }: ConversationListProps) {
  // Поле поиска показывает ввод сразу, а запрос уходит после паузы.
  const search = useDebouncedValue(filters.search.trim(), SEARCH_DELAY_MS);
  const conversations = useConversations({ ...filters, search });

  return (
    <div className="flex h-full flex-col">
      <ConversationFiltersPanel filters={filters} onChange={onFiltersChange} found={conversations.data?.total} />
      <div className="min-h-0 flex-1 overflow-y-auto">
        {conversations.isError && <ErrorAlert message={conversations.error.message} />}
        {conversations.isPending && <p className="p-4 text-sm text-muted">Загрузка…</p>}
        {conversations.data?.items.length === 0 && (
          <p className="p-4 text-sm text-muted">
            {filters.status === "OPEN" ? "Открытых диалогов не найдено" : "Закрытых диалогов не найдено"}
          </p>
        )}
        <ul>
          {conversations.data?.items.map((conversation) => (
            <ConversationItem
              key={conversation.id}
              conversation={conversation}
              isSelected={conversation.id === selectedId}
              onSelect={() => onSelect(conversation.id)}
            />
          ))}
        </ul>
      </div>
    </div>
  );
}
