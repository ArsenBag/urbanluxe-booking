"use client";

import { CHANNEL_STATUS_LABELS, formatPhone, type ChannelDto } from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { TextField } from "@/components/ui/field";
import { ApiRequestError } from "@/lib/api";
import { useDisconnectChannel, useStartTelegramLogin, useSubmitTelegramCode, useSubmitTelegramPassword } from "@/lib/channels";
import { formatDateTime } from "@/lib/format";

const STATUS_COLORS: Record<ChannelDto["status"], string> = {
  CONNECTED: "text-green-600",
  AWAITING_CODE: "text-amber-600",
  AWAITING_PASSWORD: "text-amber-600",
  DISCONNECTED: "text-muted",
  ERROR: "text-danger",
};

function fieldError(error: unknown, field: string): string | undefined {
  return error instanceof ApiRequestError ? error.fields[field] : undefined;
}

function formError(error: unknown, field: string): string | null {
  if (!error) return null;
  return fieldError(error, field) ? null : error instanceof Error ? error.message : "Ошибка";
}

/** Шаг 1: номер телефона аккаунта. */
function PhoneStep({ defaultPhone = "" }: { defaultPhone?: string }) {
  const start = useStartTelegramLogin();
  const [phone, setPhone] = useState(defaultPhone);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    start.mutate(phone);
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      {formError(start.error, "phone") && <ErrorAlert message={formError(start.error, "phone")!} />}
      <TextField
        label="Номер телефона аккаунта Telegram"
        placeholder="+998 93 206 28 91"
        value={phone}
        onChange={(e) => setPhone(e.target.value)}
        error={fieldError(start.error, "phone")}
        autoComplete="off"
      />
      <Button type="submit" disabled={!phone.trim() || start.isPending}>
        {start.isPending ? "Отправляем код…" : "Получить код"}
      </Button>
    </form>
  );
}

/** Шаги 2–3: код из Telegram и облачный пароль. Вводит владелец аккаунта, CRM их не хранит. */
function SecretStep({ channel, kind }: { channel: ChannelDto; kind: "code" | "password" }) {
  const submitCode = useSubmitTelegramCode();
  const submitPassword = useSubmitTelegramPassword();
  const mutation = kind === "code" ? submitCode : submitPassword;
  const [value, setValue] = useState("");

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (kind === "code") submitCode.mutate({ id: channel.id, code: value.trim() });
    else submitPassword.mutate({ id: channel.id, password: value });
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <p className="text-sm text-muted">
        {kind === "code"
          ? "Telegram прислал код в приложение (чат «Telegram») на этот номер. Введите его здесь."
          : "На аккаунте включена двухэтапная проверка. Введите облачный пароль Telegram."}
      </p>
      {formError(mutation.error, kind) && <ErrorAlert message={formError(mutation.error, kind)!} />}
      <TextField
        label={kind === "code" ? "Код из Telegram" : "Облачный пароль"}
        type={kind === "code" ? "text" : "password"}
        inputMode={kind === "code" ? "numeric" : undefined}
        autoComplete="off"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        error={fieldError(mutation.error, kind)}
        autoFocus
      />
      <Button type="submit" disabled={!value || mutation.isPending}>
        {mutation.isPending ? "Проверяем…" : "Подтвердить"}
      </Button>
    </form>
  );
}

function ChannelCard({ channel }: { channel: ChannelDto }) {
  const disconnect = useDisconnectChannel();

  return (
    <div className="rounded-xl border border-border bg-surface p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="font-semibold">
            {channel.username ? `@${channel.username}` : channel.name}
            {channel.phone && <span className="ml-2 text-sm font-normal text-muted">{formatPhone(channel.phone)}</span>}
          </div>
          <div className={`text-sm ${STATUS_COLORS[channel.status]}`}>{CHANNEL_STATUS_LABELS[channel.status]}</div>
          {channel.status === "CONNECTED" && (
            <div className="text-xs text-muted">
              {channel.historyImportedAt
                ? `История за 90 дней загружена ${formatDateTime(channel.historyImportedAt)}`
                : "Загружаем историю переписки за 90 дней…"}
            </div>
          )}
        </div>
        {channel.status !== "DISCONNECTED" && (
          <Button
            variant="ghost"
            className="text-danger"
            disabled={disconnect.isPending}
            onClick={() =>
              window.confirm("Отключить аккаунт? CRM перестанет получать и отправлять сообщения Telegram.") &&
              disconnect.mutate(channel.id)
            }
          >
            Отключить
          </Button>
        )}
      </div>
      {channel.lastError && <div className="mt-3"><ErrorAlert message={channel.lastError} /></div>}
      {disconnect.isError && <div className="mt-3"><ErrorAlert message={disconnect.error.message} /></div>}
      <div className="mt-4 max-w-sm">
        {channel.status === "AWAITING_CODE" && <SecretStep key="code" channel={channel} kind="code" />}
        {channel.status === "AWAITING_PASSWORD" && <SecretStep key="password" channel={channel} kind="password" />}
        {(channel.status === "DISCONNECTED" || channel.status === "ERROR") && <PhoneStep defaultPhone={channel.phone ?? ""} />}
      </div>
    </div>
  );
}

export function TelegramConnect({ channels }: { channels: ChannelDto[] }) {
  const telegramChannels = channels.filter((channel) => channel.type === "TELEGRAM");
  if (telegramChannels.length === 0) {
    return (
      <div className="max-w-sm rounded-xl border border-border bg-surface p-4">
        <PhoneStep />
      </div>
    );
  }
  return (
    <div className="flex flex-col gap-3">
      {telegramChannels.map((channel) => (
        <ChannelCard key={channel.id} channel={channel} />
      ))}
    </div>
  );
}
