import { ROLE_LABELS, ROLES } from "@crm/shared";

export const ROLE_OPTIONS = ROLES.map((role) => ({ value: role, label: ROLE_LABELS[role] }));
