"use client";

import { useState } from "react";
import { ContactPicker } from "@/components/contacts/contact-picker";
import { TextField } from "@/components/ui/field";
import type { BookingForm } from "./booking-form";

interface BookingGuestFieldsProps {
  form: BookingForm;
  onChange: (patch: Partial<BookingForm>) => void;
  errors: Record<string, string>;
}

/**
 * Гость брони: имя и телефон (CRM сама найдёт клиента по телефону или заведёт нового)
 * либо клиент CRM, выбранный поиском, — тогда имя и телефон берутся из его карточки.
 */
export function BookingGuestFields({ form, onChange, errors }: BookingGuestFieldsProps) {
  const [picking, setPicking] = useState(false);

  if (form.contact || picking) {
    return (
      <div className="flex flex-col gap-1">
        <ContactPicker
          value={form.contact}
          onChange={(contact) => {
            onChange({ contact });
            // «Изменить» у выбранного клиента — сразу к поиску другого.
            setPicking(contact === null);
          }}
          onCreateNew={(name) => {
            onChange({ contact: null, guestName: name });
            setPicking(false);
          }}
          // «Укажите гостя» сервер привязывает к имени — в режиме поиска показываем его здесь.
          error={errors.contactId ?? errors.guestName}
        />
        {!form.contact && (
          <button type="button" className="self-start text-xs text-primary hover:underline" onClick={() => setPicking(false)}>
            Ввести имя и телефон гостя
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-1">
      <div className="grid grid-cols-2 gap-3">
        <TextField label="Гость" placeholder="Имя и фамилия" value={form.guestName} onChange={(e) => onChange({ guestName: e.target.value })} error={errors.guestName} />
        <TextField label="Телефон" type="tel" placeholder="+998 90 123 45 67" value={form.guestPhone} onChange={(e) => onChange({ guestPhone: e.target.value })} error={errors.guestPhone} />
      </div>
      <button type="button" className="self-start text-xs text-primary hover:underline" onClick={() => setPicking(true)}>
        Выбрать клиента из CRM
      </button>
    </div>
  );
}
