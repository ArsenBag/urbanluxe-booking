"use client";

import type { CustomFieldDto } from "@crm/shared";
import { SelectField, TextField } from "@/components/ui/field";

/** Черновик значения в форме: строка для текстовых полей, флажок для «да / нет». */
export type DraftValue = string | boolean;

interface CustomFieldInputProps {
  field: CustomFieldDto;
  value: DraftValue;
  error?: string;
  onChange: (value: DraftValue) => void;
}

const BOOLEAN_OPTIONS = [
  { value: "", label: "Не указано" },
  { value: "true", label: "Да" },
  { value: "false", label: "Нет" },
];

/** Поле ввода под тип настраиваемого поля. */
export function CustomFieldInput({ field, value, error, onChange }: CustomFieldInputProps) {
  const text = typeof value === "string" ? value : "";
  switch (field.type) {
    case "BOOLEAN":
      return (
        <SelectField
          label={field.label}
          value={value === true ? "true" : value === false ? "false" : ""}
          options={BOOLEAN_OPTIONS}
          error={error}
          onChange={(event) => onChange(event.target.value === "" ? "" : event.target.value === "true")}
        />
      );
    case "SELECT":
      return (
        <SelectField
          label={field.label}
          value={text}
          // Значение могли убрать из вариантов — показываем его, чтобы не потерять молча.
          options={[
            { value: "", label: "Не указано" },
            ...(text && !field.options.includes(text) ? [{ value: text, label: `${text} (нет в списке)` }] : []),
            ...field.options.map((option) => ({ value: option, label: option })),
          ]}
          error={error}
          onChange={(event) => onChange(event.target.value)}
        />
      );
    case "DATE":
      return <TextField label={field.label} type="date" value={text} error={error} onChange={(event) => onChange(event.target.value)} />;
    case "NUMBER":
      return (
        <TextField label={field.label} inputMode="decimal" value={text} error={error} onChange={(event) => onChange(event.target.value)} />
      );
    case "TEXT":
      return <TextField label={field.label} value={text} maxLength={1000} error={error} onChange={(event) => onChange(event.target.value)} />;
  }
}
