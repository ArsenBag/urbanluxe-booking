"use client";

import type { BookingDto } from "@crm/shared";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { BookingRow } from "./booking-row";

/** Бронь, которую ведёт RealtyCalendar: на шахматке её только смотрят, меняют — в RealtyCalendar. */
export function BookingDetailsModal({ booking, onClose }: { booking: BookingDto; onClose: () => void }) {
  return (
    <Modal title="Бронь из RealtyCalendar" open onClose={onClose} wide>
      <ul>
        <BookingRow booking={booking} showStatus />
      </ul>
      <p className="mt-3 text-xs text-muted">
        {booking.source === "CRM" ? "Бронь внесли в CRM, а потом она пришла из RealtyCalendar. " : ""}
        Изменить или отменить её можно только в RealtyCalendar — CRM обновится сама.
      </p>
      <div className="mt-4 flex justify-end">
        <Button variant="secondary" onClick={onClose}>
          Закрыть
        </Button>
      </div>
    </Modal>
  );
}
