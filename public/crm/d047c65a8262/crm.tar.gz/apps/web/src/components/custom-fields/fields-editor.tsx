"use client";

import {
  CUSTOM_FIELD_TYPE_LABELS,
  CUSTOM_FIELD_TYPES,
  type CustomFieldDto,
  type CustomFieldEntity,
  type CustomFieldType,
} from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { SelectField, TextAreaField, TextField } from "@/components/ui/field";
import { ApiRequestError } from "@/lib/api";
import {
  useCreateCustomField,
  useCustomFields,
  useDeleteCustomField,
  useReorderCustomFields,
  useUpdateCustomField,
} from "@/lib/custom-fields";

const TYPE_OPTIONS = CUSTOM_FIELD_TYPES.map((type) => ({ value: type, label: CUSTOM_FIELD_TYPE_LABELS[type] }));

/** Варианты списка вводятся по одному в строке. */
const parseOptions = (text: string) =>
  text
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);

const fieldError = (error: Error | null, field: string) => (error instanceof ApiRequestError ? error.fields[field] : undefined);

/** Поля одной карточки (клиента или сделки): список с порядком, правкой и удалением, форма нового поля. */
export function FieldsEditor({ entity }: { entity: CustomFieldEntity }) {
  const fields = useCustomFields(entity);
  const reorder = useReorderCustomFields();
  const remove = useDeleteCustomField();
  const [editingId, setEditingId] = useState<string | null>(null);
  const list = fields.data ?? [];
  const actionError = reorder.error ?? remove.error;

  function move(index: number, step: -1 | 1) {
    const ids = list.map((field) => field.id);
    const target = index + step;
    if (target < 0 || target >= ids.length) return;
    [ids[index], ids[target]] = [ids[target]!, ids[index]!];
    reorder.mutate({ entity, ids });
  }

  function handleDelete(field: CustomFieldDto) {
    if (window.confirm(`Удалить поле «${field.label}»? Его значения во всех карточках будут стёрты.`)) {
      remove.mutate(field.id);
    }
  }

  return (
    <div className="flex flex-col gap-3">
      {fields.isError && <ErrorAlert message={fields.error.message} />}
      {actionError && <ErrorAlert message={actionError.message} />}
      {list.length === 0 && fields.isSuccess && <p className="text-sm text-muted">Полей пока нет — добавьте первое ниже.</p>}
      {list.length > 0 && (
        <ul className="divide-y divide-border rounded-lg border border-border">
          {list.map((field, index) =>
            editingId === field.id ? (
              <li key={field.id} className="p-3">
                <EditFieldForm field={field} onDone={() => setEditingId(null)} />
              </li>
            ) : (
              <li key={field.id} className="flex flex-wrap items-center gap-2 px-3 py-2">
                <div className="min-w-0 flex-1">
                  <span className="text-sm font-medium">{field.label}</span>
                  <span className="ml-2 text-xs text-muted">{CUSTOM_FIELD_TYPE_LABELS[field.type]}</span>
                  {field.type === "SELECT" && <span className="block truncate text-xs text-muted">{field.options.join(" · ")}</span>}
                </div>
                <Button variant="ghost" className="px-2" onClick={() => move(index, -1)} disabled={index === 0 || reorder.isPending} aria-label="Выше">
                  ↑
                </Button>
                <Button
                  variant="ghost"
                  className="px-2"
                  onClick={() => move(index, 1)}
                  disabled={index === list.length - 1 || reorder.isPending}
                  aria-label="Ниже"
                >
                  ↓
                </Button>
                <Button variant="ghost" onClick={() => setEditingId(field.id)}>
                  Изменить
                </Button>
                <Button variant="ghost" className="text-danger" onClick={() => handleDelete(field)} disabled={remove.isPending}>
                  Удалить
                </Button>
              </li>
            ),
          )}
        </ul>
      )}
      <NewFieldForm entity={entity} />
    </div>
  );
}

function EditFieldForm({ field, onDone }: { field: CustomFieldDto; onDone: () => void }) {
  const update = useUpdateCustomField();
  const [label, setLabel] = useState(field.label);
  const [options, setOptions] = useState(field.options.join("\n"));

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const input = field.type === "SELECT" ? { label, options: parseOptions(options) } : { label };
    update.mutate({ id: field.id, input }, { onSuccess: onDone });
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      {update.isError && !fieldError(update.error, "label") && !fieldError(update.error, "options") && (
        <ErrorAlert message={update.error.message} />
      )}
      <TextField label="Название" value={label} error={fieldError(update.error, "label")} onChange={(e) => setLabel(e.target.value)} />
      <p className="text-xs text-muted">Тип: {CUSTOM_FIELD_TYPE_LABELS[field.type]} — после создания не меняется.</p>
      {field.type === "SELECT" && (
        <TextAreaField
          label="Варианты — по одному в строке"
          rows={4}
          value={options}
          error={fieldError(update.error, "options")}
          onChange={(e) => setOptions(e.target.value)}
        />
      )}
      <div className="flex justify-end gap-2">
        <Button variant="ghost" onClick={onDone}>
          Отмена
        </Button>
        <Button type="submit" disabled={!label.trim() || update.isPending}>
          Сохранить
        </Button>
      </div>
    </form>
  );
}

function NewFieldForm({ entity }: { entity: CustomFieldEntity }) {
  const create = useCreateCustomField();
  const [label, setLabel] = useState("");
  const [type, setType] = useState<CustomFieldType>("TEXT");
  const [options, setOptions] = useState("");

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    create.mutate(
      { entity, label, type, options: type === "SELECT" ? parseOptions(options) : [] },
      {
        onSuccess: () => {
          setLabel("");
          setOptions("");
        },
      },
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3 rounded-lg border border-dashed border-border p-3">
      <p className="text-sm font-medium">Новое поле</p>
      {create.isError && !fieldError(create.error, "label") && !fieldError(create.error, "options") && (
        <ErrorAlert message={create.error.message} />
      )}
      <div className="grid gap-3 sm:grid-cols-[1fr_14rem]">
        <TextField
          label="Название"
          placeholder={entity === "CONTACT" ? "Например, Гражданство" : "Например, Цель поездки"}
          value={label}
          error={fieldError(create.error, "label")}
          onChange={(e) => setLabel(e.target.value)}
        />
        <SelectField label="Тип" value={type} options={TYPE_OPTIONS} onChange={(e) => setType(e.target.value as CustomFieldType)} />
      </div>
      {type === "SELECT" && (
        <TextAreaField
          label="Варианты — по одному в строке"
          rows={4}
          value={options}
          error={fieldError(create.error, "options")}
          onChange={(e) => setOptions(e.target.value)}
        />
      )}
      <div className="flex justify-end">
        <Button type="submit" disabled={!label.trim() || create.isPending}>
          Добавить поле
        </Button>
      </div>
    </form>
  );
}
