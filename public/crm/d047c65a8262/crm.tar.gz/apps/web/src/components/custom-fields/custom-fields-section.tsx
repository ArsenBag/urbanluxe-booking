"use client";

import {
  checkCustomFieldValue,
  formatCustomFieldValue,
  type CustomFieldDto,
  type CustomFieldEntity,
  type CustomFieldValue,
  type CustomFieldValues,
} from "@crm/shared";
import Link from "next/link";
import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Section } from "@/components/ui/section";
import { ApiRequestError } from "@/lib/api";
import { useCustomFields, useUpdateCustomValues } from "@/lib/custom-fields";
import { useSession } from "@/lib/session";
import { CustomFieldInput, type DraftValue } from "./custom-field-input";

interface CustomFieldsSectionProps {
  entity: CustomFieldEntity;
  recordId: string;
  values: CustomFieldValues;
}

const toDraft = (value: CustomFieldValue | undefined): DraftValue =>
  typeof value === "boolean" ? value : value === undefined ? "" : String(value);

/** Блок «Дополнительно» в карточке: поля, которые настроил администратор. */
export function CustomFieldsSection({ entity, recordId, values }: CustomFieldsSectionProps) {
  const fields = useCustomFields(entity);
  const session = useSession();
  const [isEditing, setIsEditing] = useState(false);
  const isAdmin = session.data?.role === "ADMIN";

  if (!fields.data) return null;
  if (fields.data.length === 0) {
    // Сотрудникам пустой блок не нужен; администратору — подсказка, где настроить.
    return isAdmin ? (
      <Section title="Дополнительно">
        <p className="text-sm text-muted">
          Здесь появятся ваши поля.{" "}
          <Link href="/settings/fields" className="text-primary hover:underline">
            Настроить поля карточек
          </Link>
        </p>
      </Section>
    ) : null;
  }

  return (
    <Section
      title="Дополнительно"
      action={
        !isEditing && (
          <Button variant="ghost" onClick={() => setIsEditing(true)}>
            Изменить
          </Button>
        )
      }
    >
      {isEditing ? (
        <CustomFieldsForm
          entity={entity}
          recordId={recordId}
          fields={fields.data}
          values={values}
          onDone={() => setIsEditing(false)}
        />
      ) : (
        <dl>
          {fields.data.map((field) => (
            <div key={field.id} className="grid grid-cols-3 gap-2 py-1.5 text-sm">
              <dt className="text-muted">{field.label}</dt>
              <dd className="col-span-2 whitespace-pre-wrap break-words">{formatCustomFieldValue(field, values[field.id])}</dd>
            </div>
          ))}
        </dl>
      )}
    </Section>
  );
}

interface CustomFieldsFormProps extends CustomFieldsSectionProps {
  fields: CustomFieldDto[];
  onDone: () => void;
}

function CustomFieldsForm({ entity, recordId, fields, values, onDone }: CustomFieldsFormProps) {
  const update = useUpdateCustomValues(entity, recordId);
  // Сравниваем с тем, что было при открытии формы: если коллега тем временем изменил поле,
  // а мы его не трогали, его значение не перезапишется нашим устаревшим.
  const [initial] = useState(values);
  const [drafts, setDrafts] = useState<Record<string, DraftValue>>(() =>
    Object.fromEntries(fields.map((field) => [field.id, toDraft(values[field.id])])),
  );
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({});
  const serverErrors = update.error instanceof ApiRequestError ? update.error.fields : {};

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const changed: Record<string, string | number | boolean | null> = {};
    const errors: Record<string, string> = {};
    for (const field of fields) {
      const draft = drafts[field.id];
      if (draft === toDraft(initial[field.id])) continue;
      const check = checkCustomFieldValue(field, draft === "" ? null : draft);
      if (check.ok) changed[field.id] = check.value;
      else errors[field.id] = check.error;
    }
    setLocalErrors(errors);
    if (Object.keys(errors).length > 0) return;
    if (Object.keys(changed).length === 0) {
      onDone();
      return;
    }
    update.mutate(changed, { onSuccess: onDone });
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      {update.isError && Object.keys(serverErrors).length === 0 && <ErrorAlert message={update.error.message} />}
      <div className="grid gap-3 sm:grid-cols-2">
        {fields.map((field) => (
          <CustomFieldInput
            key={field.id}
            field={field}
            value={drafts[field.id] ?? ""}
            error={localErrors[field.id] ?? serverErrors[field.id]}
            onChange={(value) => setDrafts((current) => ({ ...current, [field.id]: value }))}
          />
        ))}
      </div>
      <div className="flex justify-end gap-2">
        <Button variant="ghost" onClick={onDone} disabled={update.isPending}>
          Отмена
        </Button>
        <Button type="submit" disabled={update.isPending}>
          Сохранить
        </Button>
      </div>
    </form>
  );
}
