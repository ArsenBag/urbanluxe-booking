"use client";

import { useStageLookup } from "@/lib/pipelines";

/** Этап сделки цветной плашкой; неизвестный этап (воронки ещё грузятся) не показываем. */
export function StageBadge({ stageId }: { stageId: string }) {
  const stage = useStageLookup()(stageId);
  if (!stage) return null;
  return (
    <span className="shrink-0 rounded-full px-2 py-0.5 text-xs font-medium" style={{ backgroundColor: `${stage.color}22`, color: stage.color }}>
      {stage.name}
    </span>
  );
}
