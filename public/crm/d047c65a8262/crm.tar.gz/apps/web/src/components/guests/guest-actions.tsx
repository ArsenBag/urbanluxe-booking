"use client";

import type { GuestBlacklistDto } from "@crm/shared";
import { useState } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { useRemoveFromBlacklist, useSetVip } from "@/lib/guests";
import { useSession } from "@/lib/session";
import { BlacklistModal } from "./blacklist-modal";

interface GuestActionsProps {
  contactId: string;
  contactName: string;
  vip: boolean;
  blacklist: GuestBlacklistDto | null;
}

/** Кнопки меток гостя: VIP — любому сотруднику, чёрный список — внести любому, убрать — администратору. */
export function GuestActions({ contactId, contactName, vip, blacklist }: GuestActionsProps) {
  const session = useSession();
  const setVip = useSetVip(contactId);
  const remove = useRemoveFromBlacklist();
  const [isListing, setIsListing] = useState(false);
  const isAdmin = session.data?.role === "ADMIN";
  const error = setVip.error ?? remove.error;

  function unlist() {
    if (window.confirm(`Убрать «${contactName}» из чёрного списка?`)) remove.mutate(contactId);
  }

  return (
    <div className="flex flex-col gap-2">
      {error && <ErrorAlert message={error.message} />}
      <div className="flex gap-2">
        <Button
          variant="secondary"
          className="flex-1 px-2 whitespace-nowrap"
          aria-pressed={vip}
          title={vip ? "Снять отметку VIP" : "Отметить как VIP"}
          onClick={() => setVip.mutate(!vip)}
          disabled={setVip.isPending}
        >
          <span aria-hidden className={vip ? "text-amber-500" : "text-muted"}>
            {vip ? "★" : "☆"}
          </span>
          VIP
        </Button>
        {!blacklist && (
          <Button variant="secondary" className="flex-1 px-2 whitespace-nowrap text-danger" onClick={() => setIsListing(true)}>
            В чёрный список
          </Button>
        )}
      </div>
      {blacklist && isAdmin && (
        <Button variant="secondary" onClick={unlist} disabled={remove.isPending}>
          Убрать из чёрного списка
        </Button>
      )}
      <BlacklistModal contactId={contactId} contactName={contactName} open={isListing} onClose={() => setIsListing(false)} />
    </div>
  );
}
