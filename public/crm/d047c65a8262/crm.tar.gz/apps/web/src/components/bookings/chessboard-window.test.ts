import { describe, expect, it } from "vitest";
import { daysBetween } from "./chessboard-layout";
import { afterScroll, BUFFER_DAYS, firstVisible, jumpTarget, rangeAt } from "./chessboard-window";

const DAY = 40;
/** Прокрутка отрисованных 112 дней на экране шириной около 1100 px. */
const MAX_SCROLL = 200 + 112 * DAY - 1100;

describe("rangeAt", () => {
  it("puts the date at the left edge with a buffer of days before it", () => {
    expect(rangeAt("2026-10-12", DAY)).toEqual({ rangeStart: "2026-09-14", scrollLeft: BUFFER_DAYS * DAY });
  });
});

describe("firstVisible", () => {
  it("tolerates the fraction of a pixel a zoomed page reads back", () => {
    expect(firstVisible("2026-09-14", BUFFER_DAYS * DAY - 0.33, DAY)).toBe("2026-10-12");
    expect(firstVisible("2026-09-14", BUFFER_DAYS * DAY + DAY - 1, DAY)).toBe("2026-10-12");
  });
});

describe("afterScroll", () => {
  it("reads the first visible day from the scroll position", () => {
    const result = afterScroll("2026-09-14", BUFFER_DAYS * DAY + 3 * DAY + 10, MAX_SCROLL, DAY);

    expect(result).toEqual({ visibleStart: "2026-10-15", reanchorStart: null });
  });

  it("moves the drawn range near its edge, keeping the visible day with a buffer before it", () => {
    const result = afterScroll("2026-09-14", 2 * DAY + 15, MAX_SCROLL, DAY);

    expect(result).toEqual({ visibleStart: "2026-09-16", reanchorStart: "2026-08-19" });
  });

  it("does not move the range again once it has moved", () => {
    const moved = afterScroll("2026-09-14", 2 * DAY + 15, MAX_SCROLL, DAY);
    const shiftedScroll = 2 * DAY + 15 + daysBetween(moved.reanchorStart ?? "", "2026-09-14") * DAY;

    expect(afterScroll(moved.reanchorStart ?? "", shiftedScroll, MAX_SCROLL, DAY).reanchorStart).toBeNull();
  });

  it("never moves the range on a screen too wide to scroll it safely", () => {
    expect(afterScroll("2026-09-14", 0, 300, DAY).reanchorStart).toBeNull();
  });
});

describe("jumpTarget", () => {
  it("scrolls inside the drawn range when the date is there", () => {
    expect(jumpTarget("2026-09-14", "2026-10-19", MAX_SCROLL, DAY)).toEqual({ rangeStart: "2026-09-14", scrollLeft: 35 * DAY });
  });

  it("draws a new range around a far date", () => {
    expect(jumpTarget("2026-09-14", "2027-01-10", MAX_SCROLL, DAY)).toEqual(rangeAt("2027-01-10", DAY));
  });
});
