import type { GuestBlacklistDto } from "@crm/shared";
import { formatDateTime } from "@/lib/format";

/** Красная плашка над перепиской: гость в чёрном списке и за что. */
export function BlacklistBanner({ blacklist }: { blacklist: GuestBlacklistDto }) {
  const added = [formatDateTime(blacklist.at), blacklist.by?.name].filter(Boolean).join(" · ");
  return (
    <div role="alert" className="flex items-start gap-3 border-b-2 border-danger bg-danger/10 px-4 py-2">
      <span className="mt-0.5 shrink-0 rounded-full bg-danger px-2 py-0.5 text-xs font-bold tracking-wide text-background uppercase motion-safe:animate-blink">
        ⛔ Чёрный список
      </span>
      <div className="min-w-0 text-sm">
        <p className="font-medium break-words whitespace-pre-wrap text-danger">{blacklist.reason}</p>
        <p className="text-xs text-muted">Внесён в список: {added}</p>
      </div>
    </div>
  );
}
