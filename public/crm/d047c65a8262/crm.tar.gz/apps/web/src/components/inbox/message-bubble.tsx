"use client";

import type { MessageDto } from "@crm/shared";
import { formatTime } from "@/lib/format";
import { AttachmentView } from "./attachment-view";
import { CallNotice } from "./call-notice";

const STATUS_ICONS: Record<MessageDto["status"], string> = {
  RECEIVED: "",
  PENDING: "🕓",
  SENT: "✓",
  FAILED: "⚠",
};

const STATUS_TITLES: Record<MessageDto["status"], string> = {
  RECEIVED: "Получено",
  PENDING: "Отправляется",
  SENT: "Отправлено",
  FAILED: "Не отправлено",
};

interface MessageBubbleProps {
  message: MessageDto;
  onRetry: (message: MessageDto) => void;
  isRetrying: boolean;
}

export function MessageBubble({ message, onRetry, isRetrying }: MessageBubbleProps) {
  if (message.attachment?.kind === "call") return <CallNotice message={message} />;
  const isOut = message.direction === "OUT";
  const attachment = message.attachment;
  const metaColor = isOut ? "text-primary-foreground/75" : "text-muted";

  return (
    <div className={`flex ${isOut ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm shadow-sm ${
          isOut ? "rounded-br-sm bg-primary text-primary-foreground" : "rounded-bl-sm border border-border bg-surface"
        } ${message.status === "FAILED" ? "ring-2 ring-danger" : ""}`}
      >
        {attachment && <AttachmentView messageId={message.id} attachment={attachment} metaColor={metaColor} />}
        {message.text && <div className="whitespace-pre-wrap break-words">{message.text}</div>}
        <div className={`mt-1 flex items-center justify-end gap-1 text-[11px] ${metaColor}`}>
          {isOut && <span>{message.sender ? message.sender.name : "с телефона"} ·</span>}
          <span>{formatTime(message.sentAt)}</span>
          {isOut && <span title={STATUS_TITLES[message.status]}>{STATUS_ICONS[message.status]}</span>}
        </div>
        {message.status === "FAILED" && (
          <div className="mt-1 flex flex-wrap items-center gap-2 border-t border-white/25 pt-1 text-xs">
            <span>{message.error ?? "Не отправлено"}</span>
            <button type="button" className="font-semibold underline" disabled={isRetrying} onClick={() => onRetry(message)}>
              Повторить
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
