"use client";

import { callTitle, isMissedCall, type MessageDto } from "@crm/shared";
import { formatTime } from "@/lib/format";

/** Звонок — строка посередине переписки, как служебные сообщения в мессенджерах. */
export function CallNotice({ message }: { message: MessageDto }) {
  const isMissed = isMissedCall(message.direction, message.attachment);
  return (
    <div className="flex justify-center">
      <div
        className={`rounded-full border bg-surface px-3 py-1 text-xs ${
          isMissed ? "border-danger/40 font-medium text-danger" : "border-border text-muted"
        }`}
      >
        📞 {callTitle(message.direction, message.attachment?.call)}
        <span className="ml-2 font-normal opacity-70">{formatTime(message.sentAt)}</span>
      </div>
    </div>
  );
}
