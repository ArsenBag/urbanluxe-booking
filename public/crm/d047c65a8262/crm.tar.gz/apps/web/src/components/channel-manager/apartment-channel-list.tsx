"use client";

import { SALES_CHANNEL_LABELS, SALES_CHANNELS, type ChannelListingDto, type PropertyDto, type SalesChannel } from "@crm/shared";
import { useMemo, useState } from "react";
import { groupApartmentsByComplex } from "@/components/bookings/chessboard-layout";

export interface ListingSelection {
  propertyId: string;
  channel: SalesChannel;
}

export const listingKey = (propertyId: string, channel: SalesChannel) => `${propertyId}:${channel}`;

interface ApartmentChannelListProps {
  apartments: PropertyDto[];
  listings: ChannelListingDto[];
  selected: ListingSelection | null;
  onSelect: (selection: ListingSelection) => void;
}

/** Левая колонка, как в RealtyCalendar: квартиры по ЖК, у каждой — значки площадок. */
export function ApartmentChannelList({ apartments, listings, selected, onSelect }: ApartmentChannelListProps) {
  const [query, setQuery] = useState("");
  const byKey = useMemo(() => new Map(listings.map((listing) => [listingKey(listing.propertyId, listing.channel), listing])), [listings]);
  const groups = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return groupApartmentsByComplex(apartments.filter((apartment) => apartment.title.toLowerCase().includes(needle)));
  }, [apartments, query]);

  return (
    <div className="flex min-w-0 flex-col gap-2">
      <input
        type="search"
        className="h-9 rounded-md border border-border bg-surface px-3 text-sm outline-none focus:border-primary"
        placeholder="Поиск по коду квартиры"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        aria-label="Поиск по коду квартиры"
      />
      <div className="max-h-[calc(100vh-14rem)] overflow-auto rounded-xl border border-border bg-surface">
        {groups.length === 0 && <p className="p-4 text-sm text-muted">Квартиры не найдены.</p>}
        {groups.map((group) => (
          <div key={group.title}>
            <div className="sticky top-0 z-10 border-b border-border bg-background px-3 py-1 text-xs font-semibold uppercase tracking-wide text-muted">
              {group.title}
            </div>
            {group.items.map((apartment) => (
              <div key={apartment.id} className="border-b border-border px-3 py-2 last:border-0">
                <div className="truncate text-sm font-medium">{apartment.title}</div>
                <div className="mt-1 flex flex-wrap gap-1">
                  {SALES_CHANNELS.map((channel) => (
                    <ChannelChip
                      key={channel}
                      channel={channel}
                      listing={byKey.get(listingKey(apartment.id, channel))}
                      active={selected?.propertyId === apartment.id && selected.channel === channel}
                      onClick={() => onSelect({ propertyId: apartment.id, channel })}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

interface ChannelChipProps {
  channel: SalesChannel;
  listing: ChannelListingDto | undefined;
  active: boolean;
  onClick: () => void;
}

/** Значок площадки: зелёная точка — подключена, серая — выключена, «+» — ещё не настроена. */
function ChannelChip({ channel, listing, active, onClick }: ChannelChipProps) {
  const label = SALES_CHANNEL_LABELS[channel];
  const state = !listing ? "none" : listing.enabled ? "on" : "off";
  const look = active
    ? "border-primary bg-primary text-white"
    : state === "none"
      ? "border-dashed border-border text-muted hover:border-primary hover:text-primary"
      : "border-border bg-surface hover:border-primary";
  const title = state === "none" ? `${label}: не настроена` : state === "on" ? `${label}: включена` : `${label}: выключена`;
  return (
    <button type="button" aria-pressed={active} title={title} className={`flex h-6 items-center gap-1 rounded-full border px-2 text-xs ${look}`} onClick={onClick}>
      {state === "none" ? <span aria-hidden>+</span> : <span aria-hidden className={`h-1.5 w-1.5 rounded-full ${state === "on" ? "bg-emerald-500" : "bg-muted"}`} />}
      {label}
    </button>
  );
}
