"use client";

import { isCrmOnlyBooking, type BookingDto, type PropertyDto, type RateDayDto } from "@crm/shared";
import { memo, type MouseEvent } from "react";
import { bookingChannel, bookingGuestName, paidShare } from "@/lib/booking-channels";
import { formatStay, pluralize } from "@/lib/format";
import { ChannelBadge } from "./channel-badge";
import { assignLanes, barFor, type RateCell, type ChessboardRow as Row } from "./chessboard-layout";
import { formatNightPrice } from "./rate-form";
import { selectionFirst, selectionLast, type CellSelection } from "./use-cell-selection";

export const DAY_WIDTH = 40;
export const NAME_WIDTH = 200;
const ROW_HEIGHT = 36;
const BAR_HEIGHT = 28;

/** Зелёный полоски оплаты — тот же, что в RealtyCalendar. */
export const PAID_COLOR = "#7ED321";

/** Бронь только в CRM — в полоску: в RealtyCalendar её ещё нет, квартиру могут продать на площадках. */
export const CRM_ONLY_STRIPES = "repeating-linear-gradient(135deg, rgb(255 255 255 / 0.3) 0 6px, transparent 6px 12px)";

export const isWeekend = (date: string) => [0, 6].includes(new Date(`${date}T00:00:00Z`).getUTCDay());

export interface CellHandlers {
  onCellDown: (propertyId: string, index: number) => void;
  onCellEnter: (propertyId: string, index: number) => void;
  onCellDoubleClick: (propertyId: string, index: number) => void;
  onOpenBooking: (booking: BookingDto) => void;
}

/** Подсвеченная колонка: сегодня или выходной. Считается один раз на всю шахматку, а не в каждой строке. */
export interface ColumnMark {
  index: number;
  className: string;
}

/** Линии между днями — фоном, а не отдельным блоком на каждую из сотен ячеек строки. */
const DAY_LINES = `linear-gradient(to right, var(--color-border) 1px, transparent 1px)`;

interface ChessboardRowProps {
  row: Row<PropertyDto, BookingDto>;
  from: string;
  days: number;
  marks: readonly ColumnMark[];
  /** Выделение в этой строке; у остальных null, чтобы протяжка мышью не перерисовывала всю шахматку. */
  selection: CellSelection | null;
  /** false, пока догружаются брони нового диапазона: свободная на вид ночь может оказаться занятой. */
  interactive: boolean;
  handlers: CellHandlers;
  /** Цены и ограничения ночей этой квартиры в окне. */
  rates?: ReadonlyArray<RateCell<RateDayDto>>;
}

/** Строка квартиры: ячейка — ночь. На квартире из RealtyCalendar свободные ночи выделяются мышью. */
export const ChessboardRow = memo(function ChessboardRow({ row, from, days, marks, selection, interactive, handlers, rates }: ChessboardRowProps) {
  const { items, lanes } = assignLanes(row.bookings);
  const propertyId = row.property?.rcId != null ? row.property.id : null;
  const selectable = propertyId !== null && interactive;
  const cellAt = (event: MouseEvent<HTMLDivElement>) => {
    const left = event.currentTarget.getBoundingClientRect().left;
    return Math.min(days - 1, Math.max(0, Math.floor((event.clientX - left) / DAY_WIDTH)));
  };

  return (
    <div className={`flex border-b border-border last:border-0 ${row.unresolved ? "bg-amber-50" : ""}`}>
      <div
        className={`sticky left-0 z-10 shrink-0 border-r border-border px-3 py-2 text-sm ${row.unresolved ? "bg-amber-50" : "bg-surface"}`}
        style={{ width: NAME_WIDTH }}
        title={row.property?.address ?? undefined}
      >
        <span className="block truncate">{row.property?.title ?? "Без объекта"}</span>
        {row.unresolved && <span className="block text-[11px] text-muted">квартира не указана</span>}
        {/* В строке ЖК брони разных квартир пересекаются законно — предупреждаем только у квартиры. */}
        {lanes > 1 && !row.unresolved && <span className="block text-[11px] text-danger">брони пересекаются</span>}
      </div>
      <div
        className={`relative ${propertyId ? "cursor-cell" : ""}`}
        style={{ width: DAY_WIDTH * days, height: ROW_HEIGHT * lanes, backgroundImage: DAY_LINES, backgroundSize: `${DAY_WIDTH}px 100%` }}
        onMouseDown={(event) => {
          if (!selectable || event.button !== 0) return;
          // Иначе браузер начнёт выделять текст вместо ячеек.
          event.preventDefault();
          handlers.onCellDown(propertyId, cellAt(event));
        }}
        onMouseMove={(event) => selectable && handlers.onCellEnter(propertyId, cellAt(event))}
        onDoubleClick={(event) => selectable && handlers.onCellDoubleClick(propertyId, cellAt(event))}
      >
        {marks.map((mark) => (
          <div key={mark.index} className={`absolute top-0 h-full ${mark.className}`} style={{ left: mark.index * DAY_WIDTH, width: DAY_WIDTH }} />
        ))}
        {rates?.map((cell) => <PriceCell key={cell.index} cell={cell} />)}
        {selection && <SelectionOverlay selection={selection} />}
        {items.map(({ booking, lane }) => (
          <BookingBar key={booking.id} booking={booking} lane={lane} from={from} days={days} onOpen={handlers.onOpenBooking} />
        ))}
      </div>
    </div>
  );
});

/** Красная черта слева — заезд запрещён, справа — выезд запрещён. */
function restrictionEdges(day: RateDayDto): string | undefined {
  const edges = [
    day.closedToArrival ? "inset 2px 0 0 var(--color-danger)" : null,
    day.closedToDeparture ? "inset -2px 0 0 var(--color-danger)" : null,
  ].filter(Boolean);
  return edges.length > 0 ? edges.join(", ") : undefined;
}

/**
 * Цена ночи под бронями, как в RealtyCalendar: видна в свободных ячейках. Продажи закрыты — красный крестик,
 * минимум ночей — «≥3» под ценой.
 */
const PriceCell = memo(function PriceCell({ cell: { index, day } }: { cell: RateCell<RateDayDto> }) {
  return (
    <div
      className={`pointer-events-none absolute top-0 flex h-full flex-col items-center justify-center text-[10px] leading-tight ${
        day.closed ? "bg-danger/10 text-danger" : "text-muted"
      }`}
      style={{ left: index * DAY_WIDTH, width: DAY_WIDTH, boxShadow: restrictionEdges(day) }}
    >
      <span>{day.closed ? "✕" : day.price !== null ? formatNightPrice(day.price) : ""}</span>
      {day.minStay !== null && day.minStay > 1 && <span className="text-[9px]">≥{day.minStay}</span>}
    </div>
  );
});

function SelectionOverlay({ selection }: { selection: CellSelection }) {
  const first = selectionFirst(selection);
  const nights = selectionLast(selection) - first + 1;
  return (
    <div
      className="pointer-events-none absolute inset-y-0 z-[1] flex items-center justify-center rounded-sm border-2 border-primary bg-primary/15 text-[11px] font-medium text-primary"
      style={{ left: first * DAY_WIDTH, width: nights * DAY_WIDTH }}
    >
      {nights > 1 && `${nights} ${pluralize(nights, ["ночь", "ночи", "ночей"])}`}
    </div>
  );
}

interface BookingBarProps {
  booking: BookingDto;
  lane: number;
  from: string;
  days: number;
  onOpen: (booking: BookingDto) => void;
}

/** Гость из чёрного списка — красная бронь, заявка — жёлтая. */
function barColor(booking: BookingDto): string {
  if (booking.guestBlacklisted) return "bg-danger";
  return booking.status === "REQUEST" ? "bg-amber-500" : "bg-primary";
}

function BookingBar({ booking, lane, from, days, onOpen }: BookingBarProps) {
  const bar = barFor(booking, from, days);
  if (!bar) return null;
  const crmOnly = isCrmOnlyBooking(booking);
  const channel = bookingChannel(booking);
  const label = bookingGuestName(booking) ?? "Гость";
  const paid = paidShare(booking);
  const details = [
    formatStay(booking.checkIn, booking.checkOut),
    channel?.label,
    paid === null ? null : channel?.key === "AIRBNB" ? "оплачено через Airbnb" : `оплачено ${Math.round(paid * 100)}%`,
    crmOnly ? "только в CRM, в RealtyCalendar нет" : null,
    booking.guestBlacklisted ? "гость из чёрного списка" : null,
  ];
  const corners = bar.cutStart && bar.cutEnd ? "" : bar.cutStart ? "rounded-r-md" : bar.cutEnd ? "rounded-l-md" : "rounded-md";
  return (
    <button
      type="button"
      className={`absolute z-[2] flex items-center gap-1 overflow-hidden whitespace-nowrap px-1.5 text-left text-xs text-white hover:opacity-90 ${
        barColor(booking)
      } ${corners}`}
      style={{
        left: bar.start * DAY_WIDTH + 1,
        width: Math.max(bar.length * DAY_WIDTH - 2, 8),
        top: lane * ROW_HEIGHT + (ROW_HEIGHT - BAR_HEIGHT) / 2,
        height: BAR_HEIGHT,
        backgroundImage: crmOnly ? CRM_ONLY_STRIPES : undefined,
      }}
      title={`${label}: ${details.filter(Boolean).join(" · ")}`}
      // Нажатие на бронь не начинает выделение ячеек под ней.
      onMouseDown={(event) => event.stopPropagation()}
      onDoubleClick={(event) => event.stopPropagation()}
      onClick={() => onOpen(booking)}
    >
      {booking.guestBlacklisted && <span aria-hidden>⛔</span>}
      {channel && <ChannelBadge channel={channel} withTitle={false} />}
      {/* В одну ночь имя не помещается рядом со значком — оно в подсказке. */}
      {(!channel || bar.length >= 2) && <span className="truncate">{label}</span>}
      {paid !== null && <PaymentStrip share={paid} />}
    </button>
  );
}

/** Полоска оплаты внизу брони, как в RealtyCalendar: зелёная часть — сколько оплачено. */
function PaymentStrip({ share }: { share: number }) {
  return (
    <span className="pointer-events-none absolute inset-x-0 bottom-0 h-[3px] bg-white/85">
      <span className="block h-full" style={{ width: `${share * 100}%`, backgroundColor: PAID_COLOR }} />
    </span>
  );
}
