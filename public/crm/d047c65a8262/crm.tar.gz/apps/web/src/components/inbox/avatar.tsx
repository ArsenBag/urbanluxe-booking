"use client";

import { fileUrl, type ChannelType } from "@crm/shared";
import { useState } from "react";
import { initials } from "@/lib/format";
import { ChannelIcon } from "./channel-icon";

/** Цвет аватара стабилен для одного и того же клиента. */
const COLORS = ["#3b82f6", "#8b5cf6", "#ec4899", "#f59e0b", "#10b981", "#14b8a6", "#ef4444", "#6366f1"];

function colorFor(seed: string): string {
  let hash = 0;
  for (const char of seed) hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
  return COLORS[hash % COLORS.length];
}

interface AvatarProps {
  name: string;
  seed: string;
  /** Фото профиля из Telegram или WhatsApp; нет или не загрузилось — инициалы. */
  fileId?: string | null;
  size?: number;
  /** Значок мессенджера в углу: откуда диалог, видно сразу. */
  channel?: ChannelType;
}

const DEFAULT_SIZE = 40;
/** Доля значка мессенджера от размера аватара. */
const CHANNEL_BADGE_RATIO = 0.42;

export function Avatar({ channel, ...props }: AvatarProps) {
  if (!channel) return <AvatarImage {...props} />;
  const size = props.size ?? DEFAULT_SIZE;
  return (
    // Обёртка ровно по размеру аватара: в высокой строке списка значок не уезжает вниз.
    <span className="relative shrink-0 self-start" style={{ width: size, height: size }}>
      <AvatarImage {...props} />
      <ChannelIcon
        type={channel}
        size={Math.round(size * CHANNEL_BADGE_RATIO)}
        className="absolute -right-0.5 -bottom-0.5 ring-2 ring-surface"
      />
    </span>
  );
}

function AvatarImage({ name, seed, fileId, size = DEFAULT_SIZE }: Omit<AvatarProps, "channel">) {
  const [failedFileId, setFailedFileId] = useState<string | null>(null);

  if (fileId && fileId !== failedFileId) {
    return (
      // eslint-disable-next-line @next/next/no-img-element -- файл из API за сессией, next/image не нужен
      <img
        src={fileUrl(fileId)}
        alt=""
        width={size}
        height={size}
        loading="lazy"
        onError={() => setFailedFileId(fileId)}
        className="shrink-0 rounded-full object-cover"
        style={{ width: size, height: size }}
      />
    );
  }

  return (
    <span
      className="flex shrink-0 items-center justify-center rounded-full font-semibold text-white"
      style={{ width: size, height: size, backgroundColor: colorFor(seed), fontSize: size * 0.38 }}
      aria-hidden
    >
      {initials(name)}
    </span>
  );
}
