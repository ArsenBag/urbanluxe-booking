"use client";

import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { formLevelError } from "@/lib/api";
import { localDateTimeToIso } from "@/lib/format";
import { useSession } from "@/lib/session";
import { useCreateTask } from "@/lib/tasks";
import { useUserOptions } from "@/lib/users";

const INPUT = "h-9 rounded-md border border-border bg-surface px-3 text-sm outline-none focus:border-primary";

/** Быстрое добавление задачи: название, срок, исполнитель. */
export function TaskForm({ dealId, contactId }: { dealId?: string; contactId?: string }) {
  const createTask = useCreateTask();
  const session = useSession();
  const users = useUserOptions();
  const [title, setTitle] = useState("");
  const [dueAt, setDueAt] = useState("");
  const [assigneeId, setAssigneeId] = useState("");

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    createTask.mutate(
      {
        title,
        dueAt: localDateTimeToIso(dueAt),
        assigneeId: assigneeId || session.data?.id,
        dealId: dealId ?? null,
        contactId: contactId ?? null,
      },
      {
        onSuccess: () => {
          setTitle("");
          setDueAt("");
        },
      },
    );
  }

  const message = formLevelError(createTask.error, []);

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-2">
      {message && <ErrorAlert message={message} />}
      <input
        className={`${INPUT} w-full`}
        placeholder="Новая задача, например «Отправить адрес и код домофона»"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        aria-label="Текст задачи"
      />
      <div className="flex flex-wrap gap-2">
        <input
          type="datetime-local"
          className={INPUT}
          value={dueAt}
          onChange={(e) => setDueAt(e.target.value)}
          aria-label="Срок"
        />
        <select
          className={INPUT}
          value={assigneeId || session.data?.id || ""}
          onChange={(e) => setAssigneeId(e.target.value)}
          aria-label="Исполнитель"
        >
          {users.data?.map((user) => (
            <option key={user.id} value={user.id}>
              {user.name}
            </option>
          ))}
        </select>
        <Button type="submit" variant="secondary" disabled={!title.trim() || createTask.isPending}>
          Добавить
        </Button>
      </div>
    </form>
  );
}
