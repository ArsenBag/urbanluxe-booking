"use client";

import { useEffect, useRef, type ReactNode } from "react";

interface ModalProps {
  title: string;
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  /** Шире обычного — для списков с поиском. */
  wide?: boolean;
}

/** Модальное окно на нативном <dialog>: фокус, Esc и затемнение фона даёт браузер. */
export function Modal({ title, open, onClose, children, wide = false }: ModalProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (open && !dialog.open) {
      dialog.showModal();
      // Браузер ставит фокус на первый элемент окна; поле с data-autofocus (например, поиск) важнее.
      dialog.querySelector<HTMLElement>("[data-autofocus]")?.focus();
    }
    if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      ref={dialogRef}
      onClose={onClose}
      aria-label={title}
      className={`m-auto w-full ${wide ? "max-w-xl" : "max-w-md"} rounded-xl border border-border bg-surface p-6 text-foreground backdrop:bg-black/40`}
    >
      <h2 className="mb-4 text-lg font-semibold">{title}</h2>
      {children}
    </dialog>
  );
}
