import { MAX_RATE_RANGE_DAYS, MIN_FILTER_DATE, nightsOfRateUpdate, type RateUpdateRequest } from "@crm/shared";

/** Выбор в списке «не менять / да / нет»: пустая строка — поле не трогаем. */
export type RateToggle = "" | "on" | "off";

/** Черновик окна цен: выделенные на шахматке ночи (квартира может быть не выбрана — кнопка «Цены»). */
export interface RateDraft {
  propertyId?: string;
  /** Первая и последняя ночь включительно. */
  from: string;
  to: string;
}

/** Поля окна «Цены и ограничения» в виде строк, как их держат <input>. Пустое поле — не менять. */
export interface RateForm {
  propertyIds: string[];
  from: string;
  to: string;
  /** Дни недели (0 — воскресенье … 6 — суббота); пусто — все дни. */
  weekdays: number[];
  price: string;
  /** Убрать цену с этих ночей — поле цены тогда не учитывается. */
  clearPrice: boolean;
  /** «1» — без ограничения. */
  minStay: string;
  closed: RateToggle;
  closedToArrival: RateToggle;
  closedToDeparture: RateToggle;
}

export function initialRateForm(draft: RateDraft): RateForm {
  return {
    propertyIds: draft.propertyId ? [draft.propertyId] : [],
    from: draft.from,
    to: draft.to,
    weekdays: [],
    price: "",
    clearPrice: false,
    minStay: "",
    closed: "",
    closedToArrival: "",
    closedToDeparture: "",
  };
}

const toggleValue = (value: RateToggle) => (value === "" ? undefined : value === "on");

/** Число из поля; пустое или не число — undefined (NaN и Infinity в JSON стали бы null — «убрать»). */
function numberOf(text: string): number | undefined {
  const value = Number(text.trim());
  return text.trim() === "" || !Number.isFinite(value) ? undefined : value;
}

const isFilledButNotNumber = (text: string) => text.trim() !== "" && numberOf(text) === undefined;

/** В поле цены или минимума ночей не число — сохранять нельзя. */
export function rateFormInvalid(form: RateForm): boolean {
  return (!form.clearPrice && isFilledButNotNumber(form.price)) || isFilledButNotNumber(form.minStay);
}

export function toRateRequest(form: RateForm): RateUpdateRequest {
  const minStay = numberOf(form.minStay);
  const request: RateUpdateRequest = {
    propertyIds: form.propertyIds,
    from: form.from,
    to: form.to,
    weekdays: form.weekdays,
    price: form.clearPrice ? null : numberOf(form.price),
    minStay: minStay === undefined ? undefined : minStay <= 1 ? null : minStay,
    closed: toggleValue(form.closed),
    closedToArrival: toggleValue(form.closedToArrival),
    closedToDeparture: toggleValue(form.closedToDeparture),
  };
  // Незаполненные поля не отправляем вовсе: сервер их не меняет.
  return Object.fromEntries(Object.entries(request).filter(([, value]) => value !== undefined)) as RateUpdateRequest;
}

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const MS_PER_DAY = 86_400_000;
const spanDays = (from: string, to: string) => (Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / MS_PER_DAY;

/**
 * Сколько ночей и квартир изменится — подпись под формой. Пока год набирают с клавиатуры, поле даты отдаёт
 * 0002-11-06 и т.п. — такие периоды не перебираем (тысячи лет по ночам подвесили бы окно).
 */
export function rateFormSummary(form: RateForm): { nights: number; apartments: number; total: number } {
  const valid =
    ISO_DATE.test(form.from) &&
    ISO_DATE.test(form.to) &&
    form.from >= MIN_FILTER_DATE &&
    form.to >= form.from &&
    spanDays(form.from, form.to) < MAX_RATE_RANGE_DAYS;
  const nights = valid ? nightsOfRateUpdate(form).length : 0;
  return { nights, apartments: form.propertyIds.length, total: nights * form.propertyIds.length };
}

/** Цена в ячейке шахматки: «85», «85.5» — без лишних нулей, чтобы поместилась в узкую ячейку. */
export function formatNightPrice(price: string): string {
  return String(Number(price));
}
