"use client";

import { useLayoutEffect, useRef, useState, useSyncExternalStore } from "react";
import { daysBetween } from "./chessboard-layout";
import { afterScroll, firstVisible, jumpTarget, rangeAt } from "./chessboard-window";

/**
 * Первый видимый день меняется на каждые 40 px прокрутки. Держим его вне состояния шахматки, чтобы при
 * прокрутке перерисовывалось только поле даты, а не тысячи ячеек.
 */
export interface VisibleStartStore {
  get: () => string;
  set: (date: string) => void;
  subscribe: (listener: () => void) => () => void;
}

function createVisibleStartStore(initial: string): VisibleStartStore {
  let value = initial;
  const listeners = new Set<() => void>();
  return {
    get: () => value,
    set: (date) => {
      if (date === value) return;
      value = date;
      listeners.forEach((listener) => listener());
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
  };
}

export function useVisibleStart(store: VisibleStartStore): string {
  return useSyncExternalStore(store.subscribe, store.get, store.get);
}

/** Отрисованный диапазон; scrollLeft null — диапазон сдвинут прокруткой, на экране должны остаться те же дни. */
interface WindowState {
  rangeStart: string;
  scrollLeft: number | null;
}

/** Сколько длится плавная прокрутка к выбранной дате: в это время поле даты уже показывает её. */
const SMOOTH_SCROLL_MS = 700;

/**
 * Даты шахматки двигаются прокруткой (тачпадом, как в RealtyCalendar), стрелками и выбором даты.
 * Отрисован диапазон с запасом по бокам; у края он перестраивается вокруг видимых дней.
 */
export function useChessboardWindow(initialStart: string, dayWidth: number) {
  const scroller = useRef<HTMLDivElement>(null);
  const [range, setRange] = useState<WindowState>(() => rangeAt(initialStart, dayWidth));
  const [visibleStart] = useState(() => createVisibleStartStore(initialStart));
  /** С какого дня отрисована шахматка в DOM сейчас — от него считаем сдвиг прокрутки. */
  const drawnStart = useRef<string | null>(null);
  const settleUntil = useRef(0);

  // Новый диапазон уже в DOM — до отрисовки кадра ставим прокрутку. При сдвиге прибавляем разницу к текущей
  // прокрутке, а не к запомненной: за время перерисовки тачпад успевает уехать, и откат был бы заметен.
  useLayoutEffect(() => {
    const element = scroller.current;
    if (!element) return;
    const previous = drawnStart.current;
    const shift = previous === null ? 0 : daysBetween(range.rangeStart, previous) * dayWidth;
    element.scrollLeft = range.scrollLeft ?? element.scrollLeft + shift;
    drawnStart.current = range.rangeStart;
    // На очень широком экране прокрутку упирает в край — показываем день, который действительно первый.
    visibleStart.set(firstVisible(range.rangeStart, element.scrollLeft, dayWidth));
  }, [range, dayWidth, visibleStart]);

  const maxScrollLeft = (element: HTMLDivElement) => element.scrollWidth - element.clientWidth;

  function handleScroll() {
    const element = scroller.current;
    const drawn = drawnStart.current;
    if (!element || drawn === null) return;
    const next = afterScroll(drawn, element.scrollLeft, maxScrollLeft(element), dayWidth);
    // Пока идёт плавная прокрутка к выбранной дате, промежуточные дни в поле даты не мелькают.
    if (Date.now() >= settleUntil.current) visibleStart.set(next.visibleStart);
    if (next.reanchorStart && next.reanchorStart !== range.rangeStart) {
      setRange({ rangeStart: next.reanchorStart, scrollLeft: null });
    }
  }

  function goTo(date: string) {
    const element = scroller.current;
    const drawn = drawnStart.current;
    if (!element || drawn === null) return;
    const target = jumpTarget(drawn, date, maxScrollLeft(element), dayWidth);
    visibleStart.set(date);
    if (target.rangeStart === drawn && range.rangeStart === drawn) {
      settleUntil.current = Date.now() + SMOOTH_SCROLL_MS;
      element.scrollTo({ left: target.scrollLeft, behavior: "smooth" });
      return;
    }
    settleUntil.current = 0;
    setRange(target);
  }

  return { scroller, rangeStart: range.rangeStart, visibleStart, handleScroll, goTo };
}
