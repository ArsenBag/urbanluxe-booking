import type { BookingChannel } from "@/lib/booking-channels";

interface ChannelBadgeProps {
  channel: BookingChannel;
  className?: string;
  /** Внутри брони с полной подсказкой своя подсказка значка её только заслоняет. */
  withTitle?: boolean;
}

/** Цветной квадратик с буквой площадки (Airbnb, Booking.com, Яндекс…), как на шахматке RealtyCalendar. */
export function ChannelBadge({ channel, className = "", withTitle = true }: ChannelBadgeProps) {
  return (
    <span
      role="img"
      className={`inline-flex size-3.5 shrink-0 items-center justify-center rounded-[3px] text-[9px] font-bold leading-none ${className}`}
      style={{ backgroundColor: channel.background, color: channel.color }}
      title={withTitle ? channel.label : undefined}
      aria-label={channel.label}
    >
      {channel.letter}
    </span>
  );
}
