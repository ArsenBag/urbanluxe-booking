"use client";

import { addDays, daysOf } from "@/components/bookings/chessboard-layout";
import { formatNightPrice } from "@/components/bookings/rate-form";
import { tashkentDayKey } from "@/lib/format";
import { useRates } from "@/lib/rates";
import { previewPrices, type PlanRow } from "./listing-form";

const PREVIEW_NIGHTS = 7;
const DAY_FORMAT = new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short", timeZone: "UTC" });

/** Цены площадки на ближайшие ночи: цена ночи с шахматки и что получится по каждому тарифу. */
export function PricePreview({ propertyId, plans }: { propertyId: string; plans: readonly PlanRow[] }) {
  const today = tashkentDayKey(new Date());
  const rates = useRates(today, addDays(today, PREVIEW_NIGHTS - 1));
  const dates = daysOf(today, PREVIEW_NIGHTS);
  const baseByDate = new Map(
    (rates.data?.days ?? []).flatMap((day) => (day.propertyId === propertyId && day.price !== null ? [[day.date, Number(day.price)] as const] : [])),
  );
  const columns = dates.map((date) => {
    const base = baseByDate.get(date);
    return { date, base, prices: base === undefined ? null : previewPrices(base, plans) };
  });
  const currency = rates.data?.currency ?? "";

  if (rates.isPending) return <p className="text-sm text-muted">Загрузка цен…</p>;
  if (rates.error) return <p className="text-sm text-danger">Цены не загрузились: {rates.error.message}</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[520px] text-sm">
        <thead className="text-xs text-muted">
          <tr>
            <th className="pb-1 text-left font-medium">Цена, {currency}</th>
            {columns.map((column) => (
              <th key={column.date} className="pb-1 text-right font-medium">
                {DAY_FORMAT.format(new Date(`${column.date}T00:00:00Z`))}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          <tr className="text-muted">
            <td className="py-0.5">Цена ночи на шахматке</td>
            {columns.map((column) => (
              <td key={column.date} className="py-0.5 text-right">
                {column.base === undefined ? "—" : formatNightPrice(String(column.base))}
              </td>
            ))}
          </tr>
          {plans.map((plan, index) => (
            <tr key={plan.key}>
              <td className={`py-0.5 ${plan.parentKey ? "pl-4" : ""}`}>{plan.name || "Без названия"}</td>
              {columns.map((column) => (
                // 0 — скидка суммой больше цены ночи: такую ночь на площадку не отправим.
                <td key={column.date} className={`py-0.5 text-right font-medium ${column.prices?.[index] === 0 ? "text-danger" : ""}`}>
                  {column.prices ? formatNightPrice(String(column.prices[index])) : "—"}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {baseByDate.size === 0 && <p className="mt-1 text-xs text-muted">На эти ночи цена на шахматке не задана — задайте её в «Бронях».</p>}
    </div>
  );
}
