"use client";

import { useEffect, useState, useSyncExternalStore } from "react";
import type { NotificationContent } from "@/lib/notification-feed";

/** Бронь — событие редкое и важное: висит дольше сообщения. */
const TOAST_TTL_MS: Record<NotificationContent["kind"], number> = {
  message: 8_000,
  booking: 30_000,
};
/** Гость из чёрного списка — тоже: карточку должны успеть увидеть. */
const BLACKLIST_TOAST_TTL_MS = 30_000;

const ICONS: Record<NotificationContent["kind"], string> = {
  message: "💬",
  booking: "📅",
};

function subscribeVisibility(listener: () => void): () => void {
  document.addEventListener("visibilitychange", listener);
  return () => document.removeEventListener("visibilitychange", listener);
}

/** Вкладка CRM на экране. Пока её не видно, карточки не исчезают — их увидят, вернувшись. */
function useIsDocumentVisible(): boolean {
  return useSyncExternalStore(
    subscribeVisibility,
    () => document.visibilityState === "visible",
    () => true,
  );
}

interface ToastStackProps {
  toasts: NotificationContent[];
  onOpen: (href: string) => void;
  onDismiss: (id: string) => void;
}

/** Всплывающие уведомления в правом нижнем углу CRM. */
export function ToastStack({ toasts, onOpen, onDismiss }: ToastStackProps) {
  return (
    <div aria-live="polite" className="pointer-events-none fixed right-4 bottom-4 z-50 flex w-80 max-w-[calc(100vw-2rem)] flex-col gap-2">
      {toasts.map((toast) => (
        <Toast key={toast.id} toast={toast} onOpen={onOpen} onDismiss={onDismiss} />
      ))}
    </div>
  );
}

function toastBorder(toast: NotificationContent): string {
  if (toast.blacklisted) return "border-2 border-danger";
  return toast.kind === "booking" ? "border-primary" : "border-border";
}

function Toast({ toast, onOpen, onDismiss }: { toast: NotificationContent } & Omit<ToastStackProps, "toasts">) {
  const isVisible = useIsDocumentVisible();
  // Наведённую мышью или клавиатурой карточку не убираем, пока её читают.
  const [isHeld, setIsHeld] = useState(false);

  useEffect(() => {
    if (!isVisible || isHeld) return;
    const ttl = toast.blacklisted ? BLACKLIST_TOAST_TTL_MS : TOAST_TTL_MS[toast.kind];
    const timer = setTimeout(() => onDismiss(toast.id), ttl);
    return () => clearTimeout(timer);
  }, [isVisible, isHeld, toast.id, toast.kind, toast.blacklisted, onDismiss]);

  return (
    <div
      onMouseEnter={() => setIsHeld(true)}
      onMouseLeave={() => setIsHeld(false)}
      onFocus={() => setIsHeld(true)}
      onBlur={() => setIsHeld(false)}
      className={`pointer-events-auto flex items-start gap-2 rounded-lg border bg-surface p-3 shadow-lg ${toastBorder(toast)}`}
    >
      <button
        type="button"
        className="flex min-w-0 flex-1 items-start gap-2 text-left"
        onClick={() => {
          onOpen(toast.href);
          onDismiss(toast.id);
        }}
      >
        <span aria-hidden className={`text-lg leading-5 ${toast.blacklisted ? "motion-safe:animate-blink" : ""}`}>
          {toast.blacklisted ? "⛔" : ICONS[toast.kind]}
        </span>
        <span className="min-w-0">
          <span className="block truncate text-sm font-semibold">{toast.title}</span>
          <span className="line-clamp-2 text-xs text-muted">{toast.body}</span>
        </span>
      </button>
      <button type="button" aria-label="Закрыть уведомление" className="px-1 text-muted hover:text-foreground" onClick={() => onDismiss(toast.id)}>
        ×
      </button>
    </div>
  );
}
