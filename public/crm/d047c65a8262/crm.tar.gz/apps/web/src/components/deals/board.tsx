"use client";

import type { DealDto, PipelineDto } from "@crm/shared";
import {
  closestCorners,
  DndContext,
  DragOverlay,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragOverEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import { sortableKeyboardCoordinates } from "@dnd-kit/sortable";
import { useMemo, useState } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { useMoveDeal } from "@/lib/deals";
import { BoardColumn } from "./board-column";
import { findStageOf, groupByStage, moveCard, neighboursOf, type Columns } from "./board-state";
import { DealCardContent } from "./deal-card";
import { LostReasonModal } from "./lost-reason-modal";

/** Сколько пикселей нужно сдвинуть карточку, чтобы начался перенос (иначе это клик). */
const DRAG_ACTIVATION_DISTANCE = 6;

interface PendingMove {
  dealId: string;
  stageId: string;
  columns: Columns;
}

interface BoardProps {
  pipeline: PipelineDto;
  deals: DealDto[];
  onAddDeal: (stageId: string) => void;
}

export function Board({ pipeline, deals, onAddDeal }: BoardProps) {
  const moveDeal = useMoveDeal();
  const stageIds = useMemo(() => pipeline.stages.map((stage) => stage.id), [pipeline.stages]);
  const serverColumns = useMemo(() => groupByStage(deals, stageIds), [deals, stageIds]);
  /** Локальная раскладка во время переноса и до ответа сервера; null — показываем данные сервера. */
  const [draft, setDraft] = useState<Columns | null>(null);
  const [activeDeal, setActiveDeal] = useState<DealDto | null>(null);
  const [startStageId, setStartStageId] = useState<string | null>(null);
  const [pendingLost, setPendingLost] = useState<PendingMove | null>(null);

  const columns = draft ?? serverColumns;
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: DRAG_ACTIVATION_DISTANCE } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  function handleDragStart({ active }: DragStartEvent) {
    const id = String(active.id);
    setDraft(serverColumns);
    setStartStageId(findStageOf(serverColumns, id));
    setActiveDeal(deals.find((deal) => deal.id === id) ?? null);
  }

  /** Переход в другую колонку показываем сразу, пока карточку ещё тащат. */
  function handleDragOver({ active, over }: DragOverEvent) {
    if (!over || !draft) return;
    const from = findStageOf(draft, String(active.id));
    const to = findStageOf(draft, String(over.id));
    if (from && to && from !== to) {
      setDraft(moveCard(draft, String(active.id), String(over.id)));
    }
  }

  function handleDragEnd({ active, over }: DragEndEvent) {
    setActiveDeal(null);
    const dealId = String(active.id);
    if (!over || !draft) {
      setDraft(null);
      return;
    }
    const finalColumns = moveCard(draft, dealId, String(over.id));
    const stageId = findStageOf(finalColumns, dealId) as string;
    const unchanged =
      stageId === startStageId &&
      finalColumns[stageId].map((d) => d.id).join() === serverColumns[stageId].map((d) => d.id).join();
    if (unchanged) {
      setDraft(null);
      return;
    }
    setDraft(finalColumns);

    const targetStage = pipeline.stages.find((stage) => stage.id === stageId);
    if (targetStage?.kind === "LOST" && stageId !== startStageId) {
      setPendingLost({ dealId, stageId, columns: finalColumns });
      return;
    }
    submitMove(dealId, stageId, finalColumns);
  }

  function submitMove(dealId: string, stageId: string, layout: Columns, lostReason?: string) {
    moveDeal.mutate(
      { id: dealId, input: { stageId, ...neighboursOf(layout, stageId, dealId), ...(lostReason !== undefined && { lostReason }) } },
      { onSettled: () => setDraft(null) },
    );
  }

  return (
    <>
      {moveDeal.isError && <ErrorAlert message={moveDeal.error.message} />}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCorners}
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragEnd={handleDragEnd}
        onDragCancel={() => {
          setActiveDeal(null);
          setDraft(null);
        }}
      >
        <div className="flex min-h-0 flex-1 gap-3 overflow-x-auto pb-4">
          {pipeline.stages.map((stage) => (
            <BoardColumn key={stage.id} stage={stage} deals={columns[stage.id] ?? []} onAdd={onAddDeal} />
          ))}
        </div>
        <DragOverlay>
          {activeDeal && (
            <div className="w-68 rotate-2 rounded-lg border border-border bg-surface p-3 shadow-lg">
              <DealCardContent deal={activeDeal} />
            </div>
          )}
        </DragOverlay>
      </DndContext>

      {pendingLost && (
        <LostReasonModal
          onConfirm={(reason) => {
            submitMove(pendingLost.dealId, pendingLost.stageId, pendingLost.columns, reason);
            setPendingLost(null);
          }}
          onCancel={() => {
            setPendingLost(null);
            setDraft(null);
          }}
        />
      )}
    </>
  );
}
