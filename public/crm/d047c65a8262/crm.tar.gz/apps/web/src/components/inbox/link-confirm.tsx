"use client";

import type { EntityRef, LinkMergeContactDto, LinkTarget } from "@crm/shared";
import { useState } from "react";
import { StageBadge } from "@/components/deals/stage-badge";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { movedSummary } from "@/lib/link-summary";
import { useLinkConversation, useLinkPreview } from "@/lib/linking";

interface LinkConfirmProps {
  conversationId: string;
  target: LinkTarget;
  onBack: () => void;
  onDone: () => void;
}

/** Второй шаг связывания: что произойдёт (какая карточка вольётся, какие сделки объединятся) и подтверждение. */
export function LinkConfirm({ conversationId, target, onBack, onDone }: LinkConfirmProps) {
  const preview = useLinkPreview(conversationId, target);
  const link = useLinkConversation(conversationId);
  const [useOtherName, setUseOtherName] = useState(false);
  const [mergeDeals, setMergeDeals] = useState(true);

  if (preview.isPending) return <p className="text-sm text-muted">Проверяем…</p>;
  if (preview.isError) {
    return (
      <div className="flex flex-col gap-3">
        <ErrorAlert message={preview.error.message} />
        <div className="flex justify-end">
          <Button variant="secondary" onClick={onBack}>
            Назад
          </Button>
        </div>
      </div>
    );
  }

  const { contact, alreadyLinked, mergeContact, targetDeal, dealMergeCandidate } = preview.data;
  const subject = target.bookingId ? "Бронь" : "Сделка";
  const willMergeDeals = dealMergeCandidate !== null && mergeDeals;
  const nothingToDo = alreadyLinked && !dealMergeCandidate;

  function submit() {
    link.mutate(
      {
        ...target,
        useOtherName,
        // Сервер вольёт только эту карточку: если бронь успела смениться, он откажет, а окно обновится.
        mergeContactId: mergeContact?.id ?? null,
        mergeDealId: willMergeDeals ? (dealMergeCandidate?.id ?? null) : null,
      },
      { onSuccess: onDone },
    );
  }

  return (
    <div className="flex flex-col gap-4 text-sm">
      {alreadyLinked && <p>{subject} уже у клиента «{contact.name}».</p>}
      {!alreadyLinked && !mergeContact && <p>{subject} будет записана на клиента «{contact.name}».</p>}
      {mergeContact && (
        <MergeContactNotice
          contact={contact}
          other={mergeContact}
          otherSource={target.bookingId ? "из брони" : "из сделки"}
          useOtherName={useOtherName}
          onUseOtherNameChange={setUseOtherName}
        />
      )}

      {targetDeal && (
        <p className="flex flex-wrap items-center gap-2">
          <span>
            Сделка: <span className="font-medium">«{targetDeal.title}»</span>
          </span>
          <StageBadge stageId={targetDeal.stageId} />
        </p>
      )}
      {dealMergeCandidate && (
        <label className="flex items-start gap-2">
          <input type="checkbox" className="mt-0.5" checked={mergeDeals} onChange={(event) => setMergeDeals(event.target.checked)} />
          <span>
            Объединить со сделкой диалога <span className="font-medium">«{dealMergeCandidate.title}»</span>{" "}
            <StageBadge stageId={dealMergeCandidate.stageId} />
            <span className="block text-xs text-muted">Останется одна сделка — без дубля на канбане и в отчётах.</span>
          </span>
        </label>
      )}

      {nothingToDo && <p className="text-muted">Связывать нечего.</p>}
      {(mergeContact || willMergeDeals) && <p className="text-xs text-muted">Объединение нельзя отменить.</p>}
      {link.isError && <ErrorAlert message={link.error.message} />}

      <div className="flex justify-end gap-2">
        <Button variant="secondary" onClick={onBack} disabled={link.isPending}>
          Назад
        </Button>
        {!nothingToDo && (
          <Button onClick={submit} disabled={link.isPending}>
            {link.isPending ? "Связываем…" : "Связать"}
          </Button>
        )}
      </div>
    </div>
  );
}

interface MergeContactNoticeProps {
  contact: EntityRef;
  other: LinkMergeContactDto;
  otherSource: string;
  useOtherName: boolean;
  onUseOtherNameChange: (value: boolean) => void;
}

function MergeContactNotice({ contact, other, otherSource, useOtherName, onUseOtherNameChange }: MergeContactNoticeProps) {
  const moved = movedSummary(other);
  return (
    <div className="rounded-md border border-border bg-background p-3">
      <p>
        Карточка клиента <span className="font-medium">«{other.name}»</span>
        {moved && ` (${moved})`} вольётся в <span className="font-medium">«{contact.name}»</span>. Телефоны, заметки и история
        сохранятся.
      </p>
      {other.name !== contact.name && (
        <fieldset className="mt-3 flex flex-col gap-1">
          <legend className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted">Имя клиента</legend>
          <label className="flex items-center gap-2">
            <input type="radio" name="link-contact-name" checked={!useOtherName} onChange={() => onUseOtherNameChange(false)} />
            {contact.name} <span className="text-xs text-muted">из диалога</span>
          </label>
          <label className="flex items-center gap-2">
            <input type="radio" name="link-contact-name" checked={useOtherName} onChange={() => onUseOtherNameChange(true)} />
            {other.name} <span className="text-xs text-muted">{otherSource}</span>
          </label>
        </fieldset>
      )}
    </div>
  );
}
