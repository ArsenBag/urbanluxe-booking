import type { BookingDto, EntityRef, ManualBookingRequest, ManualBookingStatus } from "@crm/shared";

/** Черновик новой брони: выделенные на шахматке ячейки (квартира может быть не выбрана — кнопка «+ Бронь»). */
export interface BookingDraft {
  propertyId?: string;
  checkIn: string;
  checkOut: string;
}

/** Поля окна брони в виде строк, как их держат <input>. */
export interface BookingForm {
  propertyId: string;
  checkIn: string;
  checkOut: string;
  status: ManualBookingStatus;
  arrivalTime: string;
  departureTime: string;
  /** Выбран клиент CRM — тогда имя и телефон гостя берутся из его карточки. */
  contact: EntityRef | null;
  guestName: string;
  guestPhone: string;
  amount: string;
  prepayment: string;
  deposit: string;
  notes: string;
}

const EMPTY_GUEST_AND_MONEY = {
  arrivalTime: "",
  departureTime: "",
  contact: null,
  guestName: "",
  guestPhone: "",
  amount: "",
  prepayment: "",
  deposit: "",
  notes: "",
};

export function initialBookingForm(booking?: BookingDto, draft?: BookingDraft): BookingForm {
  if (!booking) {
    return {
      ...EMPTY_GUEST_AND_MONEY,
      propertyId: draft?.propertyId ?? "",
      checkIn: draft?.checkIn ?? "",
      checkOut: draft?.checkOut ?? "",
      status: "BOOKED",
    };
  }
  return {
    propertyId: booking.property?.id ?? "",
    checkIn: booking.checkIn,
    checkOut: booking.checkOut,
    // Отменённую бронь окно не правит; на всякий случай показываем её как подтверждённую.
    status: booking.status === "REQUEST" ? "REQUEST" : "BOOKED",
    arrivalTime: booking.arrivalTime ?? "",
    departureTime: booking.departureTime ?? "",
    contact: booking.contact,
    guestName: booking.guestName ?? "",
    guestPhone: booking.guestPhone ?? "",
    amount: booking.amount ?? "",
    prepayment: booking.prepayment ?? "",
    deposit: booking.deposit ?? "",
    notes: booking.notes ?? "",
  };
}

const numberOrNull = (value: string) => (value.trim() === "" ? null : Number(value));

/** Тело запроса: пустое — null; при выбранном клиенте CRM имя и телефон не передаём. */
export function toBookingRequest(form: BookingForm): ManualBookingRequest {
  return {
    propertyId: form.propertyId,
    status: form.status,
    checkIn: form.checkIn,
    checkOut: form.checkOut,
    arrivalTime: form.arrivalTime || null,
    departureTime: form.departureTime || null,
    contactId: form.contact?.id ?? null,
    guestName: form.contact ? null : form.guestName,
    guestPhone: form.contact ? null : form.guestPhone,
    amount: numberOrNull(form.amount),
    prepayment: numberOrNull(form.prepayment),
    deposit: numberOrNull(form.deposit),
    notes: form.notes,
  };
}
