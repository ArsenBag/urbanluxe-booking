import type { DealDto } from "@crm/shared";
import { describe, expect, it } from "vitest";
import { columnTotals, findStageOf, groupByStage, moveCard, neighboursOf } from "./board-state";

const deal = (id: string, stageId: string, position: number, amount: string | null = null): DealDto =>
  ({ id, stageId, position, amount, currency: "USD" }) as DealDto;

const STAGES = ["s1", "s2"];

describe("groupByStage", () => {
  it("groups by stage, sorts by position and keeps empty stages", () => {
    const columns = groupByStage([deal("b", "s1", 2000), deal("a", "s1", 1000)], STAGES);

    expect(columns.s1.map((d) => d.id)).toEqual(["a", "b"]);
    expect(columns.s2).toEqual([]);
  });
});

describe("findStageOf", () => {
  const columns = groupByStage([deal("a", "s1", 1)], STAGES);

  it("finds the column of a card or treats a column id as itself", () => {
    expect(findStageOf(columns, "a")).toBe("s1");
    expect(findStageOf(columns, "s2")).toBe("s2");
    expect(findStageOf(columns, "missing")).toBeNull();
  });
});

describe("moveCard", () => {
  const columns = groupByStage([deal("a", "s1", 1), deal("b", "s1", 2), deal("c", "s2", 1)], STAGES);

  it("moves a card over another card in a different column", () => {
    const next = moveCard(columns, "a", "c");

    expect(next.s1.map((d) => d.id)).toEqual(["b"]);
    expect(next.s2.map((d) => d.id)).toEqual(["a", "c"]);
    expect(next.s2[0].stageId).toBe("s2");
  });

  it("appends to the end when dropped on an empty column area", () => {
    expect(moveCard(columns, "a", "s2").s2.map((d) => d.id)).toEqual(["c", "a"]);
  });

  it("reorders within the same column", () => {
    expect(moveCard(columns, "a", "b").s1.map((d) => d.id)).toEqual(["b", "a"]);
  });

  it("does not mutate the original columns", () => {
    moveCard(columns, "a", "c");

    expect(columns.s1.map((d) => d.id)).toEqual(["a", "b"]);
  });
});

describe("neighboursOf", () => {
  it("returns ids of the cards above and below", () => {
    const columns = groupByStage([deal("a", "s1", 1), deal("b", "s1", 2), deal("c", "s1", 3)], STAGES);

    expect(neighboursOf(columns, "s1", "b")).toEqual({ prevDealId: "a", nextDealId: "c" });
    expect(neighboursOf(columns, "s1", "a")).toEqual({ prevDealId: null, nextDealId: "b" });
  });
});

describe("columnTotals", () => {
  it("sums amounts per currency", () => {
    expect(columnTotals([deal("a", "s1", 1, "100.5"), deal("b", "s1", 2, "20"), deal("c", "s1", 3)])).toEqual({ USD: 120.5 });
  });
});
