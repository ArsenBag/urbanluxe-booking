"use client";

import { MAX_BLACKLIST_REASON } from "@crm/shared";
import { useState, type FormEvent } from "react";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { TextAreaField } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { useAddToBlacklist } from "@/lib/guests";

interface BlacklistModalProps {
  contactId: string;
  contactName: string;
  open: boolean;
  onClose: () => void;
}

/** Внесение гостя в чёрный список с причиной — её увидят все, кто откроет его диалог. */
export function BlacklistModal({ contactId, contactName, open, onClose }: BlacklistModalProps) {
  const add = useAddToBlacklist(contactId);
  const [reason, setReason] = useState("");

  function close() {
    add.reset();
    setReason("");
    onClose();
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    add.mutate(
      { reason },
      {
        onSuccess: close,
      },
    );
  }

  return (
    <Modal title="В чёрный список" open={open} onClose={close}>
      <form onSubmit={submit} className="flex flex-col gap-4">
        <p className="text-sm">
          Гость «{contactName}» будет мигать красным в диалогах и уведомлениях о сообщениях и бронях. Убрать из списка может
          только администратор.
        </p>
        <TextAreaField
          label="Причина"
          value={reason}
          onChange={(event) => setReason(event.target.value)}
          maxLength={MAX_BLACKLIST_REASON}
          required
          data-autofocus
        />
        {add.isError && <ErrorAlert message={add.error.message} />}
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={close}>
            Отмена
          </Button>
          <Button type="submit" disabled={add.isPending || !reason.trim()}>
            Внести в чёрный список
          </Button>
        </div>
      </form>
    </Modal>
  );
}
