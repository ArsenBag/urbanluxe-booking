"use client";

import { CHANNEL_TYPE_LABELS, formatPhone, MAX_MESSAGE_LENGTH, STARTABLE_CHANNELS, type StartableChannel } from "@crm/shared";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { ChannelIcon } from "@/components/inbox/channel-icon";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { SelectField, TextAreaField, TextField } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { useStartConversation } from "@/lib/inbox";

interface StartConversationModalProps {
  contactId: string;
  phones: string[];
  open: boolean;
  onClose: () => void;
}

/** «Написать» из карточки клиента: мессенджер, номер (или @username в Telegram) и первое сообщение. */
export function StartConversationModal({ contactId, phones, open, onClose }: StartConversationModalProps) {
  return (
    <Modal title="Написать клиенту" open={open} onClose={onClose}>
      {open && <StartConversationForm contactId={contactId} phones={phones} onClose={onClose} />}
    </Modal>
  );
}

function StartConversationForm({ contactId, phones, onClose }: Omit<StartConversationModalProps, "open">) {
  const router = useRouter();
  const start = useStartConversation(contactId);
  const [channel, setChannel] = useState<StartableChannel>("WHATSAPP");
  const [phone, setPhone] = useState(phones[0] ?? "");
  const [username, setUsername] = useState("");
  const [text, setText] = useState("");

  const isByUsername = channel === "TELEGRAM" && username.trim() !== "";
  const canSend = text.trim() !== "" && (isByUsername || phone !== "");

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!canSend) return;
    start.mutate(
      { channel, text, ...(isByUsername ? { username: username.trim() } : { phone }) },
      {
        onSuccess: (result) => {
          onClose();
          router.push(`/inbox?c=${result.conversationId}`);
        },
      },
    );
  }

  return (
    <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
      <fieldset className="flex flex-col gap-1.5">
        <legend className="mb-1.5 text-sm font-medium">Мессенджер</legend>
        <div className="flex gap-2">
          {STARTABLE_CHANNELS.map((value) => (
            <button
              key={value}
              type="button"
              aria-pressed={channel === value}
              onClick={() => setChannel(value)}
              className={`flex flex-1 items-center justify-center gap-2 rounded-md border px-3 py-2 text-sm font-medium ${
                channel === value ? "border-primary bg-primary/10 text-primary" : "border-border hover:bg-background"
              }`}
            >
              <ChannelIcon type={value} size={18} />
              {CHANNEL_TYPE_LABELS[value]}
            </button>
          ))}
        </div>
      </fieldset>

      {phones.length > 0 ? (
        <SelectField
          label="Телефон"
          value={phone}
          onChange={(event) => setPhone(event.target.value)}
          options={phones.map((value) => ({ value, label: formatPhone(value) }))}
          disabled={isByUsername}
        />
      ) : (
        <p className="rounded-md bg-background px-3 py-2 text-sm text-muted">
          В карточке нет телефона. Добавьте его кнопкой «Изменить»
          {channel === "TELEGRAM" ? " или укажите @username ниже." : "."}
        </p>
      )}

      {channel === "TELEGRAM" && (
        <TextField
          label="Или имя в Telegram"
          placeholder="@username"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
          autoComplete="off"
        />
      )}

      <TextAreaField
        label="Сообщение"
        rows={4}
        maxLength={MAX_MESSAGE_LENGTH}
        value={text}
        onChange={(event) => setText(event.target.value)}
        placeholder="Здравствуйте! Пишу по вашей брони…"
        required
      />

      {start.isError && <ErrorAlert message={start.error.message} />}
      <p className="text-xs text-muted">
        CRM проверит, что клиент есть в {CHANNEL_TYPE_LABELS[channel]}, отправит сообщение и откроет чат.
      </p>

      <div className="flex justify-end gap-2">
        <Button variant="secondary" onClick={onClose}>
          Отмена
        </Button>
        <Button type="submit" disabled={!canSend || start.isPending}>
          {start.isPending ? "Отправляем…" : "Отправить"}
        </Button>
      </div>
    </form>
  );
}
