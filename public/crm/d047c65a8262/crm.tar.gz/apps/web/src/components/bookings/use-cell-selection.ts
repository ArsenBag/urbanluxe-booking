"use client";

import { useCallback, useEffect, useEffectEvent, useRef, useState } from "react";

/**
 * Выделенные ночи в строке квартиры: от ячейки, где нажали мышь, до ячейки под ней сейчас. Номера ячеек
 * отсчитываются от rangeStart — первого отрисованного дня шахматки в момент выделения.
 */
export interface CellSelection {
  rangeStart: string;
  propertyId: string;
  anchor: number;
  focus: number;
}

export const selectionFirst = (selection: CellSelection) => Math.min(selection.anchor, selection.focus);
export const selectionLast = (selection: CellSelection) => Math.max(selection.anchor, selection.focus);

/**
 * Протяжка мышью по ячейкам одной строки, как в RealtyCalendar. Отпустили на другой ячейке — onDragEnd
 * (окно новой брони); простой щелчок только выделяет ячейку, окно открывает двойной щелчок.
 */
export function useCellSelection(onDragEnd: (selection: CellSelection) => void) {
  const [selection, setSelection] = useState<CellSelection | null>(null);
  const drag = useRef<CellSelection | null>(null);

  // Кнопку могут отпустить и за пределами шахматки — слушаем окно целиком.
  const finishDrag = useEffectEvent(() => {
    const finished = drag.current;
    drag.current = null;
    if (finished && finished.anchor !== finished.focus) onDragEnd(finished);
  });

  useEffect(() => {
    const handleMouseUp = () => finishDrag();
    window.addEventListener("mouseup", handleMouseUp);
    return () => window.removeEventListener("mouseup", handleMouseUp);
  }, []);

  // Стабильные функции: строки шахматки мемоизированы и не перерисовываются из-за новых обработчиков.
  const start = useCallback((rangeStart: string, propertyId: string, index: number) => {
    const next = { rangeStart, propertyId, anchor: index, focus: index };
    drag.current = next;
    setSelection(next);
  }, []);

  const extend = useCallback((rangeStart: string, propertyId: string, index: number) => {
    const current = drag.current;
    // Шахматку прокрутили до нового диапазона — номера ячеек уже другие, выделение не продолжаем.
    if (!current || current.rangeStart !== rangeStart || current.propertyId !== propertyId || current.focus === index) return;
    const next = { ...current, focus: index };
    drag.current = next;
    setSelection(next);
  }, []);

  const clear = useCallback(() => {
    drag.current = null;
    setSelection(null);
  }, []);

  return { selection, start, extend, clear };
}
