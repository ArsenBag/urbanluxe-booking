import {
  STAGE_AUTOMATION_STAGE_FIELDS,
  type PipelineDto,
  type StageAutomationDto,
  type StageAutomationInput,
  type StageAutomationStageField,
} from "@crm/shared";

/**
 * Блок «Автоперенос сделок» в виде строк, как их держат <select> и <input>; этапы — из выбранной воронки,
 * пустая строка — правило выключено.
 */
export type StageAutomationForm = Omit<StageAutomationDto, StageAutomationStageField> &
  Record<StageAutomationStageField, string> & { pipelineId: string };

export function initialStageAutomationForm(settings: StageAutomationDto, pipelines: PipelineDto[]): StageAutomationForm {
  const chosen = new Set(STAGE_AUTOMATION_STAGE_FIELDS.flatMap((field) => settings[field] ?? []));
  const pipeline = pipelines.find((candidate) => candidate.stages.some((stage) => chosen.has(stage.id))) ?? pipelines[0];
  return {
    ...settings,
    pipelineId: pipeline?.id ?? "",
    checkInStageId: settings.checkInStageId ?? "",
    checkedInStageId: settings.checkedInStageId ?? "",
    checkOutSoonStageId: settings.checkOutSoonStageId ?? "",
    checkedOutStageId: settings.checkedOutStageId ?? "",
  };
}

/** Другая воронка — этапы прежней в ней не годятся. */
export function changePipeline(form: StageAutomationForm, pipelineId: string): StageAutomationForm {
  return { ...form, pipelineId, checkInStageId: "", checkedInStageId: "", checkOutSoonStageId: "", checkedOutStageId: "" };
}

/** Этапы «в работе» выбранной воронки: закрывающий этап закрыл бы сделку. */
export function stageOptions(pipelines: PipelineDto[], pipelineId: string, emptyLabel: string) {
  const stages = pipelines.find((pipeline) => pipeline.id === pipelineId)?.stages ?? [];
  return [
    { value: "", label: emptyLabel },
    ...stages.filter((stage) => stage.kind === "OPEN").map((stage) => ({ value: stage.id, label: stage.name })),
  ];
}

/**
 * Почему выбранные этапы не работают: этап удалили или сделали закрывающим, либо этапы переставили в воронке
 * (сервер тогда останавливает автоперенос). null — всё в порядке.
 */
export function settingsProblem(form: StageAutomationForm, pipelines: PipelineDto[]): string | null {
  const stages = pipelines.find((pipeline) => pipeline.id === form.pipelineId)?.stages ?? [];
  const chosen = STAGE_AUTOMATION_STAGE_FIELDS.flatMap((field) => (form[field] ? [stages.find((stage) => stage.id === form[field])] : []));
  if (chosen.some((stage) => !stage || stage.kind !== "OPEN")) {
    return "Один из выбранных этапов удалён или закрывает сделку — выберите другой.";
  }
  const positions = chosen.flatMap((stage) => (stage ? [stage.position] : []));
  if (positions.some((position, index) => index > 0 && position <= positions[index - 1])) {
    return "Этапы выбраны не по порядку воронки (должно быть: заезд сегодня → заселён → выезд завтра → выехал). Пока порядок не исправлен, автоперенос не работает.";
  }
  return null;
}

/** Воронка нужна только списку этапов: настройки хранят сами этапы. */
export function toStageAutomationInput(form: StageAutomationForm): StageAutomationInput {
  return {
    enabled: form.enabled,
    checkInStageId: form.checkInStageId || null,
    checkInTime: form.checkInTime,
    checkedInStageId: form.checkedInStageId || null,
    checkOutSoonStageId: form.checkOutSoonStageId || null,
    checkOutSoonTime: form.checkOutSoonTime,
    checkedOutStageId: form.checkedOutStageId || null,
    checkedOutTime: form.checkedOutTime,
  };
}
