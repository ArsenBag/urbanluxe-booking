"use client";

import type { TaskDto } from "@crm/shared";
import Link from "next/link";
import { formatDateTime, isOverdue } from "@/lib/format";

interface TaskItemProps {
  task: TaskDto;
  /** Показывать ссылку на сделку или клиента (на общей странице задач). */
  showContext?: boolean;
  onToggle: (task: TaskDto) => void;
  onDelete: (task: TaskDto) => void;
  disabled?: boolean;
}

export function TaskItem({ task, showContext = false, onToggle, onDelete, disabled }: TaskItemProps) {
  const overdue = !task.isDone && isOverdue(task.dueAt);

  return (
    <li className="group flex items-start gap-3 py-2">
      <input
        type="checkbox"
        className="mt-1 h-4 w-4 accent-[var(--primary)]"
        checked={task.isDone}
        disabled={disabled}
        onChange={() => onToggle(task)}
        aria-label={task.isDone ? `Вернуть в работу: ${task.title}` : `Отметить выполненной: ${task.title}`}
      />
      <div className="min-w-0 flex-1">
        <div className={`text-sm ${task.isDone ? "text-muted line-through" : ""}`}>{task.title}</div>
        <div className="flex flex-wrap gap-x-3 text-xs text-muted">
          {task.dueAt && (
            <span className={overdue ? "font-medium text-danger" : ""}>
              {overdue ? "Просрочена · " : ""}
              {formatDateTime(task.dueAt)}
            </span>
          )}
          {task.assignee && <span>{task.assignee.name}</span>}
          {showContext && task.deal && (
            <Link href={`/deals/${task.deal.id}`} className="text-primary hover:underline">
              {task.deal.title}
            </Link>
          )}
          {showContext && !task.deal && task.contact && (
            <Link href={`/contacts/${task.contact.id}`} className="text-primary hover:underline">
              {task.contact.name}
            </Link>
          )}
        </div>
      </div>
      <button
        type="button"
        className="text-xs text-muted opacity-0 hover:text-danger focus:opacity-100 group-hover:opacity-100"
        onClick={() => onDelete(task)}
        disabled={disabled}
      >
        Удалить
      </button>
    </li>
  );
}
