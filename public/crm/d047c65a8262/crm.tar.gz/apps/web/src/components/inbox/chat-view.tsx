"use client";

import { CHANNEL_TYPE_LABELS, type MessageDto } from "@crm/shared";
import Link from "next/link";
import { Fragment, useEffect, useRef } from "react";
import { BlacklistBanner } from "@/components/guests/blacklist-banner";
import { GuestBadges } from "@/components/guests/guest-badges";
import { ErrorAlert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { formatDayLabel, tashkentDayKey } from "@/lib/format";
import { useGuestStays } from "@/lib/guests";
import { useConversation, useMarkRead, useMessages, useRetryMessage } from "@/lib/inbox";
import { Avatar } from "./avatar";
import { ChannelIcon } from "./channel-icon";
import { Composer } from "./composer";
import { MessageBubble } from "./message-bubble";

/** Насколько близко к низу считается «сотрудник внизу чата». */
const NEAR_BOTTOM_PX = 120;

export function ChatView({ conversationId }: { conversationId: string }) {
  const conversation = useConversation(conversationId);
  const messages = useMessages(conversationId);
  const retry = useRetryMessage();
  const markRead = useMarkRead();
  const stays = useGuestStays(conversation.data?.contact.id ?? "");
  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const lastMessageIdRef = useRef<string | null>(null);
  const markedRef = useRef<string | null>(null);

  // Страницы приходят от новых к старым, внутри страницы — по возрастанию времени.
  const ordered: MessageDto[] = [...(messages.data?.pages ?? [])].reverse().flat();
  const lastMessageId = ordered.at(-1)?.id ?? null;

  // Новое сообщение прокручивает вниз, только если сотрудник и так внизу (не читает старое).
  useEffect(() => {
    if (!lastMessageId || lastMessageId === lastMessageIdRef.current) return;
    const isFirstRender = lastMessageIdRef.current === null;
    lastMessageIdRef.current = lastMessageId;
    const container = scrollRef.current;
    const nearBottom = !container || container.scrollHeight - container.scrollTop - container.clientHeight < NEAR_BOTTOM_PX;
    if (isFirstRender || nearBottom) {
      bottomRef.current?.scrollIntoView({ block: "end" });
    }
  }, [lastMessageId]);

  // Открытый диалог с непрочитанными помечаем прочитанным — один раз на каждое новое сообщение,
  // чтобы при ошибке сервера не повторять запрос в цикле.
  const unread = conversation.data?.unreadCount ?? 0;
  const lastMessageAt = conversation.data?.lastMessageAt ?? "";
  const { mutate: markAsRead } = markRead;
  useEffect(() => {
    const key = `${conversationId}:${lastMessageAt}`;
    if (unread > 0 && markedRef.current !== key) {
      markedRef.current = key;
      markAsRead(conversationId);
    }
  }, [unread, conversationId, lastMessageAt, markAsRead]);

  if (conversation.isError) return <ErrorAlert message={conversation.error.message} />;
  if (conversation.isPending) return <p className="p-6 text-sm text-muted">Загрузка…</p>;

  const data = conversation.data;

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center gap-3 border-b border-border bg-surface px-4 py-3">
        <Avatar
          name={data.contact.name}
          seed={data.contact.id}
          fileId={data.contact.avatarFileId}
          channel={data.channel.type}
          size={36}
        />
        <div className="min-w-0">
          <div className="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1">
            <Link href={`/contacts/${data.contact.id}`} className="truncate font-semibold hover:text-primary">
              {data.contact.name}
            </Link>
            <GuestBadges vip={data.contact.vip} blacklisted={data.contact.blacklist !== null} stays={stays} />
          </div>
          <div className="flex min-w-0 items-center gap-1 text-xs text-muted">
            <ChannelIcon type={data.channel.type} size={13} />
            <span className="truncate">
              {CHANNEL_TYPE_LABELS[data.channel.type]}
              {data.handle && ` · ${data.handle}`}
            </span>
          </div>
        </div>
      </header>
      {data.contact.blacklist && <BlacklistBanner blacklist={data.contact.blacklist} />}

      <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto bg-background px-4 py-3">
        {messages.hasNextPage && (
          <div className="mb-3 text-center">
            <Button variant="secondary" className="h-8 text-xs" onClick={() => messages.fetchNextPage()} disabled={messages.isFetchingNextPage}>
              Показать более ранние
            </Button>
          </div>
        )}
        {messages.isError && <ErrorAlert message={messages.error.message} />}
        {retry.isError && <ErrorAlert message={retry.error.message} />}
        <div className="flex flex-col gap-2">
          {ordered.map((message, index) => {
            const startsDay = index === 0 || tashkentDayKey(ordered[index - 1].sentAt) !== tashkentDayKey(message.sentAt);
            return (
              <Fragment key={message.id}>
                {startsDay && (
                  <div className="my-2 text-center text-xs text-muted">
                    <span className="rounded-full bg-surface px-3 py-1 shadow-sm">{formatDayLabel(message.sentAt)}</span>
                  </div>
                )}
                <MessageBubble message={message} onRetry={(m) => retry.mutate(m.id)} isRetrying={retry.isPending} />
              </Fragment>
            );
          })}
        </div>
        <div ref={bottomRef} />
      </div>

      <Composer conversationId={conversationId} contactId={data.contact.id} contactName={data.contact.name} />
    </div>
  );
}
