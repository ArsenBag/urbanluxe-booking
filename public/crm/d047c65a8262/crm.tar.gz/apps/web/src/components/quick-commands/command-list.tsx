"use client";

import { TEMPLATE_AUTOMATION_LABELS, type ReplyTemplateDto } from "@crm/shared";
import { useState } from "react";
import { TemplateForm } from "@/components/templates-editor";
import { Button } from "@/components/ui/button";

/** Поиск по команде, названию и тексту: «wifi», «пароль», «U-Tower». */
function matchesSearch(template: ReplyTemplateDto, search: string): boolean {
  const needle = search.trim().toLowerCase().replace(/^\//, "");
  if (!needle) return true;
  return [template.shortcut ?? "", template.title, template.body].some((value) => value.toLowerCase().includes(needle));
}

interface CommandListProps {
  templates: ReplyTemplateDto[];
  /** Команды правят все; автоотправку и шаблоны с ней — только администратор (так же проверяет API). */
  isAdmin: boolean;
}

/** Список быстрых команд: строка — команда, название, начало текста; «Изменить» раскрывает форму на месте. */
export function CommandList({ templates, isAdmin }: CommandListProps) {
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const visible = templates.filter((template) => matchesSearch(template, search));

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <input
          type="search"
          className="h-10 min-w-0 flex-1 rounded-md border border-border bg-surface px-3 text-sm outline-none focus:border-primary"
          placeholder="Найти команду: /wifi, пароль, адрес…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          aria-label="Поиск команд"
        />
        <Button onClick={() => setIsCreating(true)} disabled={isCreating}>
          Новая команда
        </Button>
      </div>

      {isCreating && (
        <div className="rounded-lg border border-primary/40 bg-surface p-4">
          <p className="mb-3 text-sm font-semibold">Новая команда</p>
          <TemplateForm canSetAutomation={isAdmin} onDone={() => setIsCreating(false)} onCancel={() => setIsCreating(false)} />
        </div>
      )}

      {templates.length > 0 && visible.length === 0 && <p className="text-sm text-muted">Ничего не найдено</p>}
      {templates.length === 0 && !isCreating && (
        <p className="text-sm text-muted">Команд пока нет. Нажмите «Новая команда» — например, /wifi с паролем от сети.</p>
      )}

      <ul className="divide-y divide-border rounded-lg border border-border bg-surface">
        {visible.map((template) =>
          editingId === template.id ? (
            <li key={template.id} className="p-4">
              {/* Ключ — только id: смена данных после сохранения не должна пересоздавать форму до её закрытия. */}
              <TemplateForm
                key={template.id}
                template={template}
                canSetAutomation={isAdmin}
                onDone={() => setEditingId(null)}
                onCancel={() => setEditingId(null)}
              />
            </li>
          ) : (
            <li key={template.id} className="flex items-start gap-3 px-4 py-3">
              <span className="w-28 shrink-0 truncate pt-0.5 font-mono text-sm text-primary">
                {template.shortcut ? `/${template.shortcut}` : <span className="text-muted">—</span>}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium">
                  {template.title}
                  {template.file && (
                    <span className="ml-2 text-xs font-normal text-muted" title="Уходит вместе с текстом">
                      📎 {template.file.fileName}
                    </span>
                  )}
                  {template.automation && (
                    <span className="ml-2 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-normal text-primary">
                      авто: {TEMPLATE_AUTOMATION_LABELS[template.automation]}
                    </span>
                  )}
                </p>
                <p className="line-clamp-2 whitespace-pre-wrap text-xs text-muted">{template.body}</p>
              </div>
              {isAdmin || !template.automation ? (
                <Button variant="ghost" onClick={() => setEditingId(template.id)}>
                  Изменить
                </Button>
              ) : (
                <span className="shrink-0 pt-0.5 text-xs text-muted" title="Уходит гостям автоматически — текст меняет администратор">
                  меняет администратор
                </span>
              )}
            </li>
          ),
        )}
      </ul>
    </div>
  );
}
