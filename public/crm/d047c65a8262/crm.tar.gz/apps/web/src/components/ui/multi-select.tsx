"use client";

import { useEffect, useId, useRef, useState } from "react";

export interface SelectOption {
  value: string;
  label: string;
  /** Цветная метка слева — например, цвет этапа воронки. */
  swatch?: string;
}

interface MultiSelectProps {
  label: string;
  options: SelectOption[];
  selected: string[];
  onChange: (values: string[]) => void;
  /** К какому краю кнопки прижат список: у правого края экрана — right, иначе список уедет за экран. */
  align?: "left" | "right";
}

/** Кнопка-фильтр со списком галочек. Ничего не выбрано — значит «все». */
export function MultiSelect({ label, options, selected, onChange, align = "left" }: MultiSelectProps) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const listId = useId();

  useEffect(() => {
    if (!open) return;
    const closeOnOutside = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      setOpen(false);
      buttonRef.current?.focus();
    };
    document.addEventListener("mousedown", closeOnOutside);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("mousedown", closeOnOutside);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [open]);

  const toggle = (value: string) =>
    onChange(selected.includes(value) ? selected.filter((item) => item !== value) : [...selected, value]);
  const chosen = options.filter((option) => selected.includes(option.value));
  const summary = chosen.length === 0 ? "все" : chosen.length === 1 ? chosen[0]!.label : String(chosen.length);

  return (
    <div ref={rootRef} className="relative">
      <button
        ref={buttonRef}
        type="button"
        aria-expanded={open}
        aria-controls={listId}
        onClick={() => setOpen((value) => !value)}
        className={`flex h-9 max-w-56 items-center gap-1 rounded-md border bg-surface px-3 text-sm ${
          chosen.length > 0 ? "border-primary text-primary" : "border-border"
        }`}
      >
        <span className="truncate">
          {label}: {summary}
        </span>
        <span aria-hidden>▾</span>
      </button>
      {open && (
        <div id={listId} role="group" aria-label={label} className={`absolute ${align === "right" ? "right-0" : "left-0"} z-20 mt-1 max-h-72 w-64 overflow-auto rounded-md border border-border bg-surface p-1 shadow-lg`}>
          {options.map((option) => (
            <label key={option.value} className="flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 text-sm hover:bg-background">
              <input type="checkbox" checked={selected.includes(option.value)} onChange={() => toggle(option.value)} />
              {option.swatch && <span className="size-2.5 shrink-0 rounded-full" style={{ background: option.swatch }} aria-hidden />}
              <span className="truncate">{option.label}</span>
            </label>
          ))}
          {chosen.length > 0 && (
            <button type="button" onClick={() => onChange([])} className="mt-1 w-full rounded px-2 py-1.5 text-left text-sm text-primary hover:bg-background">
              Сбросить
            </button>
          )}
        </div>
      )}
    </div>
  );
}
