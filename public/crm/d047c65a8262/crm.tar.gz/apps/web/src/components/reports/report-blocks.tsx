import type { ReactNode } from "react";

/** Ключевая цифра раздела: подпись, значение и пояснение мелким шрифтом. */
export function StatTile({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-lg border border-border bg-background/50 p-3">
      <div className="text-sm text-muted">{label}</div>
      <div className="mt-1 text-2xl font-semibold">{value}</div>
      {hint && <div className="mt-0.5 text-xs text-muted">{hint}</div>}
    </div>
  );
}

export function StatGrid({ children }: { children: ReactNode }) {
  return <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">{children}</div>;
}

export interface BarRow {
  key: string;
  label: string;
  value: number;
  /** Текст у конца полосы: число и, если нужно, доля. */
  display: string;
  /** Цвет метки слева от подписи — например, цвет этапа воронки. */
  swatch?: string;
}

/** Горизонтальные полосы одного цвета: длина — величина, подписи — обычным текстом. */
export function BarList({ rows, emptyText }: { rows: BarRow[]; emptyText: string }) {
  if (rows.length === 0) return <p className="text-sm text-muted">{emptyText}</p>;
  const max = Math.max(...rows.map((row) => row.value), 1);
  return (
    <ul className="space-y-3">
      {rows.map((row) => (
        <li key={row.key} className="text-sm">
          <div className="flex items-center justify-between gap-3">
            <span className="flex min-w-0 items-center gap-2">
              {row.swatch && <span className="size-2.5 shrink-0 rounded-full" style={{ background: row.swatch }} aria-hidden />}
              <span className="truncate" title={row.label}>
                {row.label}
              </span>
            </span>
            <span className="whitespace-nowrap tabular-nums text-muted">{row.display}</span>
          </div>
          {row.value > 0 && (
            <div
              className="mt-1 h-2 min-w-0.5 rounded-r-[4px] bg-chart-bar"
              style={{ width: `${(row.value / max) * 100}%` }}
              aria-hidden
            />
          )}
        </li>
      ))}
    </ul>
  );
}

/** Доля 0…1 полоской и числом в ячейке таблицы; без значения — пустая дорожка и прочерк. */
export function MeterCell({ share, label }: { share: number | null; label: string }) {
  return (
    <span className="flex items-center gap-2">
      <span className="block h-1.5 w-full min-w-12 rounded-full bg-border" aria-hidden>
        <span className="block h-full rounded-full bg-chart-bar" style={{ width: `${Math.min(1, share ?? 0) * 100}%` }} />
      </span>
      <span className={`w-10 shrink-0 text-right ${share === null ? "text-muted" : ""}`}>{label}</span>
    </span>
  );
}

export function ReportSubheading({ children }: { children: ReactNode }) {
  return <h3 className="mb-3 text-sm font-semibold">{children}</h3>;
}
