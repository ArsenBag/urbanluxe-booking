"use client";

import type { DealDto } from "@crm/shared";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import Link from "next/link";
import { formatMoney, formatStay, pluralize } from "@/lib/format";

export function DealCardContent({ deal }: { deal: DealDto }) {
  const stay = formatStay(deal.checkIn, deal.checkOut);
  const money = formatMoney(deal.amount, deal.currency);

  return (
    <>
      <Link
        href={`/deals/${deal.id}`}
        className="block truncate text-sm font-medium hover:text-primary"
        onPointerDown={(event) => event.stopPropagation()}
      >
        {deal.title}
      </Link>
      {deal.title !== deal.contact.name && <div className="truncate text-xs text-muted">{deal.contact.name}</div>}
      {stay && <div className="mt-1 text-xs">{stay}</div>}
      <div className="mt-1 flex items-center justify-between gap-2 text-xs text-muted">
        <span>{money ?? ""}</span>
        <span className="flex gap-2">
          {deal.guests && <span>{deal.guests} {pluralize(deal.guests, ["гость", "гостя", "гостей"])}</span>}
          {deal.openTasksCount > 0 && (
            <span title="Открытые задачи">
              ☐ {deal.openTasksCount}
            </span>
          )}
        </span>
      </div>
      {deal.owner && <div className="mt-1 truncate text-xs text-muted">{deal.owner.name}</div>}
    </>
  );
}

/** Карточка сделки, которую можно перетаскивать между этапами. */
export function SortableDealCard({ deal }: { deal: DealDto }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: deal.id });

  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={`cursor-grab rounded-lg border border-border bg-surface p-3 shadow-sm active:cursor-grabbing ${isDragging ? "opacity-40" : ""}`}
      {...attributes}
      {...listeners}
    >
      <DealCardContent deal={deal} />
    </div>
  );
}
