"use client";

import { CHANNEL_TYPE_LABELS, CHANNEL_TYPES, type ChannelType, type ConversationFilter } from "@crm/shared";
import type { ConversationFilters } from "@/lib/inbox";
import { useUserOptions } from "@/lib/users";

const FILTERS: Array<{ value: ConversationFilter; label: string }> = [
  { value: "all", label: "Все" },
  { value: "mine", label: "Мои" },
  { value: "unassigned", label: "Не назначены" },
];

const SELECT_CLASS = "h-8 min-w-0 rounded-md border border-border bg-background px-2 text-xs";

interface ConversationFiltersPanelProps {
  filters: ConversationFilters;
  onChange: (filters: ConversationFilters) => void;
  /** Сколько диалогов нашлось; undefined — ещё грузится. */
  found: number | undefined;
}

/** Поиск и фильтры над списком диалогов. Конкретный сотрудник важнее кнопок «Все / Мои / Не назначены». */
export function ConversationFiltersPanel({ filters, onChange, found }: ConversationFiltersPanelProps) {
  const users = useUserOptions();
  const chip = (isOn: boolean) => `rounded-md px-2.5 py-1 text-xs font-medium ${isOn ? "bg-primary text-primary-foreground" : "text-muted hover:bg-background"}`;

  return (
    <div className="flex flex-col gap-2 border-b border-border p-3">
      <input
        type="search"
        className="h-9 w-full rounded-md border border-border bg-background px-3 text-sm outline-none focus:border-primary"
        placeholder="Имя, телефон или @username"
        value={filters.search}
        onChange={(e) => onChange({ ...filters, search: e.target.value })}
        aria-label="Поиск диалогов"
      />
      <div className="flex items-center gap-1" role="group" aria-label="Чьи диалоги">
        {FILTERS.map((option) => (
          <button
            key={option.value}
            type="button"
            aria-pressed={!filters.assigneeId && filters.filter === option.value}
            onClick={() => onChange({ ...filters, filter: option.value, assigneeId: "" })}
            className={chip(!filters.assigneeId && filters.filter === option.value)}
          >
            {option.label}
          </button>
        ))}
        <span className="ml-auto text-xs text-muted" aria-live="polite">
          {found === undefined ? "" : `Найдено: ${found}`}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <select
          className={SELECT_CLASS}
          value={filters.channelType}
          onChange={(e) => onChange({ ...filters, channelType: e.target.value as ChannelType | "" })}
          aria-label="Мессенджер"
        >
          <option value="">Любой канал</option>
          {CHANNEL_TYPES.map((type) => (
            <option key={type} value={type}>
              {CHANNEL_TYPE_LABELS[type]}
            </option>
          ))}
        </select>
        <select
          className={SELECT_CLASS}
          value={filters.assigneeId}
          onChange={(e) => onChange({ ...filters, assigneeId: e.target.value })}
          aria-label="Сотрудник"
        >
          <option value="">Любой сотрудник</option>
          {(users.data ?? []).map((user) => (
            <option key={user.id} value={user.id}>
              {user.name}
            </option>
          ))}
        </select>
      </div>
      <div className="flex items-center justify-between text-xs text-muted">
        <button
          type="button"
          aria-pressed={filters.unanswered}
          onClick={() => onChange({ ...filters, unanswered: !filters.unanswered })}
          className={chip(filters.unanswered)}
          title="Последнее сообщение — от гостя, ему ещё не ответили"
        >
          Без ответа
        </button>
        <button
          type="button"
          className="hover:text-foreground"
          onClick={() => onChange({ ...filters, status: filters.status === "OPEN" ? "CLOSED" : "OPEN" })}
        >
          {filters.status === "OPEN" ? "Показать закрытые" : "Показать открытые"}
        </button>
      </div>
    </div>
  );
}
