"use client";

import type { BookingDto } from "@crm/shared";
import { Section } from "@/components/ui/section";
import { BookingRow } from "./booking-row";

/** Брони клиента или сделки. Пустой список не показываем — у многих сделок броней ещё нет. */
export function BookingsSection({ bookings }: { bookings: BookingDto[] | undefined }) {
  if (!bookings?.length) return null;
  return (
    <Section title="Брони (RealtyCalendar)">
      <ul className="divide-y divide-border">
        {bookings.map((booking) => (
          <BookingRow key={booking.id} booking={booking} showStatus />
        ))}
      </ul>
    </Section>
  );
}
