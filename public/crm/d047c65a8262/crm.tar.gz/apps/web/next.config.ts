import { resolve } from "node:path";
import type { NextConfig } from "next";

/**
 * Куда проксировать /api. Читается при сборке (next build) и запекается в сервер.
 * В проде /api обычно отдаёт Caddy напрямую в API, а этот прокси — запасной путь.
 */
const API_URL = process.env.API_URL ?? "http://localhost:4000";

const SECURITY_HEADERS = [
  // Запрет встраивания CRM в чужие страницы (clickjacking).
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Content-Security-Policy", value: "frame-ancestors 'none'; base-uri 'self'; form-action 'self'" },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
];

const nextConfig: NextConfig = {
  // Минимальный сервер для Docker-образа; корень трассировки — монорепо (нужен пакет @crm/shared).
  output: "standalone",
  outputFileTracingRoot: resolve(import.meta.dirname, "../.."),
  // Браузер ходит в API через тот же домен: cookie сессии первосторонняя, CORS не нужен.
  async rewrites() {
    return [{ source: "/api/:path*", destination: `${API_URL}/api/:path*` }];
  },
  async headers() {
    return [{ source: "/:path*", headers: SECURITY_HEADERS }];
  },
};

export default nextConfig;
