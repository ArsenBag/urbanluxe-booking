/**
 * Связь диалога с бронью и сделкой. Типичный случай: гость пишет в WhatsApp (карточка и обращение),
 * а бронь с Booking.com приходит из RealtyCalendar с другим телефоном — вторая карточка и вторая сделка.
 * Из диалога находим бронь по коду квартиры и связываем: карточки и сделки объединяются.
 */
import type { INestApplication } from '@nestjs/common';
import type { BookingDto, DealDto, LinkPreviewDto } from '@crm/shared';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import { RealtyCalendarSyncService } from '../src/realtycalendar/realtycalendar-sync.service.js';
import type { BookingSnapshot } from '../src/realtycalendar/rc-mapper.js';
import {
  type Agent,
  createTestApp,
  createUser,
  CSRF,
  deleteDealsWithHistory,
  login,
  only,
} from './helpers.js';

const RUN_ID = Date.now();
const MANAGER = {
  email: `link-manager-${RUN_ID}@test.local`,
  password: 'link-manager-password',
};
const RC_ID = 1_000_000_000 + Math.floor(Math.random() * 900_000_000);
const PROPERTY_CODE = `LK-${RUN_ID}`;
const CHAT_PHONE = `+99891${String(RUN_ID).slice(-7)}`;
const BOOKING_PHONE = `+99893${String(RUN_ID).slice(-7)}`;
// Метка прогона — буквами и цифрами: в десятичной записи RUN_ID попадались девять цифр телефона из чата,
// и поиск сделок по телефону находил ещё и бронь по её названию.
const GUEST_NAME = `Ivan Petrov ${RUN_ID.toString(36)}`;

function booking(overrides: Partial<BookingSnapshot> = {}): BookingSnapshot {
  return {
    rcId: RC_ID,
    importKey: null,
    status: 'BOOKED',
    checkIn: '2030-11-10',
    checkOut: '2030-11-13',
    nights: 3,
    arrivalTime: '14:00',
    departureTime: '12:00',
    amount: 255,
    prepayment: null,
    deposit: null,
    origin: 'Booking.com',
    guestName: GUEST_NAME,
    guestPhone: BOOKING_PHONE,
    guestEmail: null,
    notes: null,
    rcUrl: null,
    rcUpdatedAt: new Date('2026-10-06T10:00:00Z'),
    property: { rcId: RC_ID, title: PROPERTY_CODE, address: null },
    ...overrides,
  };
}

describe('Linking conversations to bookings and deals (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let manager: Agent;
  let sync: RealtyCalendarSyncService;
  let channelId: string;
  let chatContactId: string;
  let conversationId: string;
  let inquiryDealId: string;
  let bookingId: string;
  const contactIds: string[] = [];

  const bookingRow = () =>
    prisma.booking.findUniqueOrThrow({
      where: { rcId: RC_ID },
      include: { deal: { include: { stage: true } } },
    });

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    sync = app.get(RealtyCalendarSyncService);
    await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER');
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));

    // Гость написал в WhatsApp: карточка с ником и сделка-обращение на первом этапе.
    channelId = (
      await prisma.channel.create({
        data: {
          type: 'WHATSAPP',
          phone: `link-${RUN_ID}`,
          name: 'WhatsApp link test',
          status: 'CONNECTED',
        },
      })
    ).id;
    chatContactId = (
      await prisma.contact.create({
        data: { name: 'Ваня 🌴', phones: [CHAT_PHONE], source: 'WHATSAPP' },
      })
    ).id;
    contactIds.push(chatContactId);
    conversationId = (
      await prisma.conversation.create({
        data: {
          channelId,
          contactId: chatContactId,
          externalChatId: `link-${RUN_ID}`,
        },
      })
    ).id;
    const pipeline = (
      await manager.get('/api/pipelines').expect(200)
    ).body.data.find((p: { name: string }) => p.name === 'Бронирование');
    inquiryDealId = (
      await manager
        .post('/api/deals')
        .set(CSRF)
        .send({
          pipelineId: pipeline.id,
          contactId: chatContactId,
          notes: 'Хочет вид на город',
        })
        .expect(201)
    ).body.data.id;

    // Бронь с Booking.com с другим телефоном: RealtyCalendar заводит вторую карточку и сделку.
    await sync.apply(booking());
    const stored = await bookingRow();
    bookingId = stored.id;
    expect(stored.contactId).not.toBe(chatContactId);
    contactIds.push(stored.contactId!);
    expect(stored.deal?.stage.name).toBe('Бронь создана');
  });

  afterAll(async () => {
    await prisma.booking.deleteMany({
      where: { rcId: { in: [RC_ID, RC_ID + 1] } },
    });
    await prisma.property.deleteMany({ where: { rcId: RC_ID } });
    await prisma.task.deleteMany({ where: { contactId: { in: contactIds } } });
    await deleteDealsWithHistory(prisma, contactIds);
    await prisma.contact.deleteMany({ where: { id: { in: contactIds } } });
    await prisma.channel.deleteMany({ where: only({ id: channelId }) });
    await prisma.user.deleteMany({ where: { email: MANAGER.email } });
    await app.close();
  });

  it('finds the booking by apartment code written any way, by guest name and by phone digits', async () => {
    const queries = [
      PROPERTY_CODE.toLowerCase().replace('-', ' '),
      GUEST_NAME.toLowerCase(),
      BOOKING_PHONE.slice(-7),
    ];
    for (const q of queries) {
      const found = (
        await manager.get('/api/bookings/search').query({ q }).expect(200)
      ).body.data as BookingDto[];
      expect(found.map((b) => b.id)).toContain(bookingId);
    }
  });

  it('lists only active bookings when the query is empty', async () => {
    const found = (await manager.get('/api/bookings/search').expect(200)).body
      .data as BookingDto[];

    expect(found.length).toBeLessThanOrEqual(20);
    expect(
      found.every((b) => b.status === 'BOOKED' || b.status === 'REQUEST'),
    ).toBe(true);
  });

  it('finds deals by the client phone', async () => {
    // Последние 9 цифр: оператор (91) отличает телефон из чата от телефона из брони (93).
    const found = (
      await manager
        .get('/api/deals/search')
        .query({ q: CHAT_PHONE.slice(-9) })
        .expect(200)
    ).body.data as DealDto[];

    expect(found.map((d) => d.id)).toEqual([inquiryDealId]);
  });

  it('previews which card merges and which deals can be joined', async () => {
    const stored = await bookingRow();

    const preview = (
      await manager
        .get(`/api/conversations/${conversationId}/link-preview`)
        .query({ bookingId })
        .expect(200)
    ).body.data as LinkPreviewDto;

    expect(preview.alreadyLinked).toBe(false);
    expect(preview.contact.id).toBe(chatContactId);
    expect(preview.mergeContact).toMatchObject({
      id: stored.contactId,
      name: GUEST_NAME,
      bookings: 1,
      deals: 1,
      conversations: 0,
    });
    expect(preview.targetDeal?.id).toBe(stored.dealId);
    expect(preview.dealMergeCandidate?.id).toBe(inquiryDealId);
  });

  it('rejects a request with both a booking and a deal, or for an unknown conversation', async () => {
    await manager
      .post(`/api/conversations/${conversationId}/link`)
      .set(CSRF)
      .send({ bookingId, dealId: inquiryDealId })
      .expect(400);
    await manager
      .post(`/api/conversations/00000000-0000-4000-8000-000000000000/link`)
      .set(CSRF)
      .send({ bookingId })
      .expect(404);
  });

  it('refuses to merge a deal that is not an open deal of the conversation client', async () => {
    const stored = await bookingRow();

    await manager
      .post(`/api/conversations/${conversationId}/link`)
      .set(CSRF)
      .send({
        bookingId,
        mergeContactId: stored.contactId,
        mergeDealId: stored.dealId,
      })
      .expect(409);
    // Ничего не изменилось: вся работа в одной транзакции.
    expect((await bookingRow()).contactId).toBe(stored.contactId);
  });

  it('refuses a stale confirmation that did not see the card being merged', async () => {
    const stored = await bookingRow();

    // Окно подтверждения открыли, когда объединять было нечего, а бронь уже у другой карточки.
    await manager
      .post(`/api/conversations/${conversationId}/link`)
      .set(CSRF)
      .send({ bookingId, mergeContactId: null })
      .expect(409);
    expect((await bookingRow()).contactId).toBe(stored.contactId);
  });

  it('merges the booking card into the conversation client and joins the two deals', async () => {
    const before = await bookingRow();
    const bookingContactId = before.contactId!;
    const bookingDealId = before.dealId!;

    const result = (
      await manager
        .post(`/api/conversations/${conversationId}/link`)
        .set(CSRF)
        .send({
          bookingId,
          useOtherName: true,
          mergeContactId: bookingContactId,
          mergeDealId: inquiryDealId,
        })
        .expect(201)
    ).body.data;

    expect(result).toEqual({ contactId: chatContactId, dealId: inquiryDealId });
    expect(
      await prisma.contact.findUnique({ where: { id: bookingContactId } }),
    ).toBeNull();
    expect(
      await prisma.deal.findUnique({ where: { id: bookingDealId } }),
    ).toBeNull();

    const contact = await prisma.contact.findUniqueOrThrow({
      where: { id: chatContactId },
    });
    expect(contact.name).toBe(GUEST_NAME);
    expect(contact.phones).toEqual([CHAT_PHONE, BOOKING_PHONE]);

    const after = await bookingRow();
    expect(after.contactId).toBe(chatContactId);
    expect(after.dealId).toBe(inquiryDealId);
    expect(after.deal?.stage.name).toBe('Бронь создана');
    // Сделку назвали по старому имени клиента — она переименована вместе с ним.
    expect(after.deal?.title).toBe(GUEST_NAME);
    expect(after.deal?.notes).toBe('Хочет вид на город');
    expect(after.deal?.checkIn?.toISOString().slice(0, 10)).toBe('2030-11-10');

    const tasks = await prisma.task.findMany({ where: { bookingId } });
    expect(tasks.length).toBeGreaterThan(0);
    expect(
      tasks.every(
        (task) =>
          task.dealId === inquiryDealId && task.contactId === chatContactId,
      ),
    ).toBe(true);

    const history = (
      await manager.get(`/api/contacts/${chatContactId}/activity`).expect(200)
    ).body.data as Array<{ action: string; payload: Record<string, unknown> }>;
    expect(history.map((entry) => entry.action)).toEqual(
      expect.arrayContaining([
        'booking.created',
        'deal.merged',
        'contact.merged',
        'conversation.linked',
      ]),
    );
    // В журнале — id влитой карточки и поглощённой сделки: по ним можно разобраться, что объединили.
    const payloadOf = (action: string) =>
      history.find((entry) => entry.action === action)?.payload;
    expect(payloadOf('contact.merged')).toMatchObject({
      sourceContactId: bookingContactId,
      bookings: 1,
      deals: 1,
    });
    expect(payloadOf('deal.merged')).toMatchObject({
      absorbedDealId: bookingDealId,
    });
  });

  it('keeps the booking on the merged client and deal when RealtyCalendar updates it', async () => {
    await sync.apply(
      booking({
        checkOut: '2030-11-14',
        nights: 4,
        rcUpdatedAt: new Date('2026-10-06T12:00:00Z'),
      }),
    );

    const after = await bookingRow();
    expect(after.contactId).toBe(chatContactId);
    expect(after.dealId).toBe(inquiryDealId);
    expect(after.deal?.checkOut?.toISOString().slice(0, 10)).toBe('2030-11-14');
  });

  it('keeps the merged client when RealtyCalendar switches the guest to the chat phone', async () => {
    await sync.apply(
      booking({
        guestPhone: CHAT_PHONE,
        checkOut: '2030-11-14',
        nights: 4,
        rcUpdatedAt: new Date('2026-10-06T13:00:00Z'),
      }),
    );

    const after = await bookingRow();
    expect(after.contactId).toBe(chatContactId);
    expect(after.dealId).toBe(inquiryDealId);
  });

  it('reports the booking as already linked afterwards', async () => {
    const preview = (
      await manager
        .get(`/api/conversations/${conversationId}/link-preview`)
        .query({ bookingId })
        .expect(200)
    ).body.data as LinkPreviewDto;

    expect(preview).toMatchObject({
      alreadyLinked: true,
      mergeContact: null,
      dealMergeCandidate: null,
    });
  });

  it('links a deal of another client card the same way', async () => {
    const otherId = (
      await prisma.contact.create({
        data: { name: `Сестра ${RUN_ID}`, phones: [] },
      })
    ).id;
    contactIds.push(otherId);
    const pipeline = (
      await manager.get('/api/pipelines').expect(200)
    ).body.data.find((p: { name: string }) => p.name === 'Бронирование');
    const dealId = (
      await manager
        .post('/api/deals')
        .set(CSRF)
        .send({ pipelineId: pipeline.id, contactId: otherId })
        .expect(201)
    ).body.data.id;

    await manager
      .post(`/api/conversations/${conversationId}/link`)
      .set(CSRF)
      .send({ dealId, mergeContactId: otherId })
      .expect(201);

    const deal = await prisma.deal.findUniqueOrThrow({ where: { id: dealId } });
    expect(deal.contactId).toBe(chatContactId);
    expect(
      (await prisma.contact.findUniqueOrThrow({ where: { id: chatContactId } }))
        .name,
    ).toBe(GUEST_NAME);
  });

  it('puts a booking without a guest card on the conversation client', async () => {
    const rcId = RC_ID + 1;
    await sync.apply(
      booking({
        rcId,
        guestName: null,
        guestPhone: null,
        checkIn: '2030-12-01',
        checkOut: '2030-12-03',
        nights: 2,
      }),
    );
    const orphan = await prisma.booking.findUniqueOrThrow({ where: { rcId } });
    expect(orphan.contactId).toBeNull();

    const preview = (
      await manager
        .get(`/api/conversations/${conversationId}/link-preview`)
        .query({ bookingId: orphan.id })
        .expect(200)
    ).body.data as LinkPreviewDto;
    expect(preview).toMatchObject({ alreadyLinked: false, mergeContact: null });

    await manager
      .post(`/api/conversations/${conversationId}/link`)
      .set(CSRF)
      .send({ bookingId: orphan.id })
      .expect(201);
    expect(
      (await prisma.booking.findUniqueOrThrow({ where: { rcId } })).contactId,
    ).toBe(chatContactId);
  });
});
