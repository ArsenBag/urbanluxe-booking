/**
 * Автоперенос сделок по датам брони: настройки (только администратор) и правила
 * «Заезд сегодня» → (менеджер: «Заселён») → «Выезд завтра» → «Выехал».
 * Время задаётся явно (applyToDeal(id, now)); своя воронка, чтобы не трогать сделки локальной базы.
 */
import type { INestApplication } from '@nestjs/common';
import type { StageAutomation } from '../src/generated/prisma/client.js';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import { RealtyCalendarSyncService } from '../src/realtycalendar/realtycalendar-sync.service.js';
import type { BookingSnapshot } from '../src/realtycalendar/rc-mapper.js';
import { StageAutomationService } from '../src/stage-automation/stage-automation.service.js';
import { type Agent, createTestApp, createUser, CSRF, deleteDealsWithHistory, login, only } from './helpers.js';

const RUN_ID = Date.now();
const ADMIN = { email: `stage-admin-${RUN_ID}@test.local`, password: 'stage-admin-password' };
const MANAGER = { email: `stage-manager-${RUN_ID}@test.local`, password: 'stage-manager-password' };
const RC_ID = 1_000_000_000 + Math.floor(Math.random() * 900_000_000);
const RC_DIGITS = `99897${String(RUN_ID).slice(-7)}`;

/** Время по Ташкенту (UTC+5) → момент. */
const tashkent = (dateTime: string) => new Date(`${dateTime}:00+05:00`);

describe('Stage automation (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let manager: Agent;
  let automation: StageAutomationService;
  let original: StageAutomation | null = null;
  let pipelineId: string | undefined;
  let otherPipelineId: string | undefined;
  let contactId: string | undefined;
  let dealId: string;
  const stage: Record<'booked' | 'checkIn' | 'checkedIn' | 'checkOutSoon' | 'checkedOut' | 'lost', string> = {
    booked: '',
    checkIn: '',
    checkedIn: '',
    checkOutSoon: '',
    checkedOut: '',
    lost: '',
  };

  const settings = () => ({
    enabled: true,
    checkInStageId: stage.checkIn,
    checkInTime: '08:00',
    checkedInStageId: stage.checkedIn,
    checkOutSoonStageId: stage.checkOutSoon,
    checkOutSoonTime: '19:00',
    checkedOutStageId: stage.checkedOut,
    checkedOutTime: '12:00',
  });
  const stageOfDeal = async () => (await prisma.deal.findUniqueOrThrow({ where: { id: dealId } })).stageId;
  const moveAsManager = (stageId: string) => manager.post(`/api/deals/${dealId}/move`).set(CSRF).send({ stageId }).expect(201);

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    automation = app.get(StageAutomationService);
    // Настройки общие для всей базы: возвращаем как было в afterAll.
    original = await prisma.stageAutomation.findUnique({ where: { id: 1 } });

    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER');
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));

    const pipeline = await prisma.pipeline.create({
      data: {
        name: `Автоперенос ${RUN_ID}`,
        position: 1000,
        stages: {
          create: [
            { name: 'Бронь создана', position: 0, kind: 'OPEN' },
            { name: 'Заезд сегодня', position: 1, kind: 'OPEN' },
            { name: 'Заселён', position: 2, kind: 'OPEN' },
            { name: 'Выезд завтра', position: 3, kind: 'OPEN' },
            { name: 'Выехал', position: 4, kind: 'OPEN' },
            { name: 'Отказ', position: 5, kind: 'LOST' },
          ],
        },
      },
      include: { stages: { orderBy: { position: 'asc' } } },
    });
    pipelineId = pipeline.id;
    [stage.booked, stage.checkIn, stage.checkedIn, stage.checkOutSoon, stage.checkedOut, stage.lost] = pipeline.stages.map((s) => s.id);
    otherPipelineId = (
      await prisma.pipeline.create({
        data: { name: `Чужая ${RUN_ID}`, position: 1001, stages: { create: [{ name: 'Новые', position: 0 }] } },
      })
    ).id;

    contactId = (await prisma.contact.create({ data: { name: `Гость автопереноса ${RUN_ID}` } })).id;
    dealId = (
      await prisma.deal.create({
        data: { title: `Автоперенос ${RUN_ID}`, pipelineId, stageId: stage.booked, contactId, position: 1 },
      })
    ).id;
    await prisma.booking.create({
      data: {
        status: 'BOOKED',
        source: 'CRM',
        checkIn: new Date('2026-11-20T00:00:00Z'),
        checkOut: new Date('2026-11-23T00:00:00Z'),
        nights: 3,
        contactId,
        dealId,
        rcUpdatedAt: new Date('2026-11-01T00:00:00Z'),
      },
    });
  });

  afterAll(async () => {
    // Сначала настройки: иначе удаление этапов тестовой воронки обнулило бы ссылки на них.
    if (original) {
      const { id, updatedAt: _updatedAt, ...values } = original;
      await prisma.stageAutomation.update({ where: { id }, data: values });
    } else {
      await prisma.stageAutomation.deleteMany({ where: { id: 1 } });
    }
    await prisma.booking.deleteMany({ where: { OR: [only({ contactId }), { rcId: RC_ID }] } });
    const rcContacts = await prisma.contact.findMany({ where: { phones: { has: `+${RC_DIGITS}` } }, select: { id: true } });
    const contactIds = [...(contactId ? [contactId] : []), ...rcContacts.map((c) => c.id)];
    await prisma.task.deleteMany({ where: { contactId: { in: contactIds } } });
    await deleteDealsWithHistory(prisma, contactIds);
    await prisma.property.deleteMany({ where: { title: `U-Tower ${RUN_ID}` } });
    await prisma.contact.deleteMany({ where: { id: { in: contactIds } } });
    await prisma.activityLog.deleteMany({ where: { entityId: { in: [pipelineId, otherPipelineId].filter((id) => id !== undefined) } } });
    await prisma.pipeline.deleteMany({ where: { id: { in: [pipelineId, otherPipelineId].filter((id) => id !== undefined) } } });
    await prisma.user.deleteMany({ where: { email: { in: [ADMIN.email, MANAGER.email] } } });
    await app.close();
  });

  describe('settings', () => {
    it('are for admins only', async () => {
      await manager.get('/api/stage-automation').expect(403);
      await manager.put('/api/stage-automation').set(CSRF).send(settings()).expect(403);
    });

    it('reject stages out of the pipeline order', async () => {
      const response = await admin
        .put('/api/stage-automation')
        .set(CSRF)
        .send({ ...settings(), checkInStageId: stage.checkOutSoon, checkOutSoonStageId: stage.checkIn })
        .expect(400);

      expect(response.body.error.fields).toEqual({ checkedInStageId: 'В воронке этот этап должен стоять после «Выезд завтра»' });
    });

    it('reject a closing stage and stages from different pipelines', async () => {
      const closing = await admin.put('/api/stage-automation').set(CSRF).send({ ...settings(), checkedOutStageId: stage.lost }).expect(400);
      expect(closing.body.error.fields).toEqual({ checkedOutStageId: 'Нужен этап «В работе»: закрывающий этап закрыл бы сделку' });

      const foreign = await prisma.stage.findFirstOrThrow({ where: { pipelineId: otherPipelineId } });
      const mixed = await admin.put('/api/stage-automation').set(CSRF).send({ ...settings(), checkedOutStageId: foreign.id }).expect(400);
      expect(mixed.body.error.fields).toEqual({ checkedOutStageId: 'Все этапы должны быть из одной воронки' });
    });

    it('are saved by an admin and logged in the pipeline history', async () => {
      const saved = await admin.put('/api/stage-automation').set(CSRF).send(settings()).expect(200);

      expect(saved.body.data).toEqual(settings());
      expect((await admin.get('/api/stage-automation').expect(200)).body.data).toEqual(settings());
      const entry = await prisma.activityLog.findFirstOrThrow({ where: { entityId: pipelineId, action: 'stage-automation.updated' } });
      expect(entry.entityType).toBe('pipeline');
    });
  });

  describe('rules', () => {
    it('do nothing before 08:00 on the check-in day', async () => {
      expect(await automation.applyToDeal(dealId, tashkent('2026-11-20T07:59'))).toBe(0);
      expect(await stageOfDeal()).toBe(stage.booked);
    });

    it('move the deal to «Заезд сегодня» at 08:00 on the check-in day, with a history entry', async () => {
      expect(await automation.applyToDeal(dealId, tashkent('2026-11-20T08:00'))).toBe(1);

      expect(await stageOfDeal()).toBe(stage.checkIn);
      const entry = await prisma.activityLog.findFirstOrThrow({ where: { entityId: dealId, action: 'deal.moved' } });
      expect(entry.payload).toMatchObject({ toStageId: stage.checkIn, toStageName: 'Заезд сегодня', via: 'AUTOMATION' });
      expect(entry.actorId).toBeNull();
    });

    it('fire once: a deal the manager moved back stays there', async () => {
      await moveAsManager(stage.booked);

      expect(await automation.applyToDeal(dealId, tashkent('2026-11-20T10:00'))).toBe(0);
      expect(await stageOfDeal()).toBe(stage.booked);
    });

    it('wait for «Заселён» before «Выезд завтра», and move right after the manager marks it', async () => {
      expect(await automation.applyToDeal(dealId, tashkent('2026-11-22T19:30'))).toBe(0);
      expect(await stageOfDeal()).toBe(stage.booked);

      await moveAsManager(stage.checkedIn);
      expect(await automation.applyToDeal(dealId, tashkent('2026-11-22T18:59'))).toBe(0);
      expect(await automation.applyToDeal(dealId, tashkent('2026-11-22T19:30'))).toBe(1);
      expect(await stageOfDeal()).toBe(stage.checkOutSoon);
    });

    it('move the deal to «Выехал» at 12:00 on the check-out day', async () => {
      expect(await automation.applyToDeal(dealId, tashkent('2026-11-23T11:59'))).toBe(0);
      expect(await automation.applyToDeal(dealId, tashkent('2026-11-23T12:00'))).toBe(1);

      expect(await stageOfDeal()).toBe(stage.checkedOut);
    });

    it('do nothing when switched off', async () => {
      await moveAsManager(stage.checkedIn);
      await admin.put('/api/stage-automation').set(CSRF).send({ ...settings(), enabled: false }).expect(200);

      expect(await automation.runOnce(tashkent('2026-11-23T13:00'))).toBe(0);
      expect(await stageOfDeal()).toBe(stage.checkedIn);
      await admin.put('/api/stage-automation').set(CSRF).send(settings()).expect(200);
    });
  });

  describe('right after a change', () => {
    afterEach(() => vi.restoreAllMocks());

    it('answers a manual move with the deal already moved on by the rules', async () => {
      // В тестах автоматизации выключены (AUTOMATIONS_ENABLED=false) — включаем мгновенный перенос с нужным временем.
      vi.spyOn(automation, 'onDealChanged').mockImplementation(
        async (id) => (await automation.applyToDeal(id, tashkent('2026-11-22T21:00'))) > 0,
      );
      await prisma.stageMoveRun.deleteMany({ where: { booking: { dealId }, rule: 'CHECK_OUT_SOON' } });
      await prisma.deal.update({ where: { id: dealId }, data: { stageId: stage.checkIn } });

      const response = await moveAsManager(stage.checkedIn);

      expect(response.body.data.stageId).toBe(stage.checkOutSoon);
      expect(await stageOfDeal()).toBe(stage.checkOutSoon);
    });

    it('runs after a booking from RealtyCalendar is applied, and a cancellation resets the fired rules', async () => {
      const onDealChanged = vi.spyOn(automation, 'onDealChanged').mockResolvedValue(false);
      const snapshot: BookingSnapshot = {
        rcId: RC_ID,
        importKey: null,
        status: 'BOOKED',
        checkIn: '2026-11-25',
        checkOut: '2026-11-26',
        nights: 1,
        arrivalTime: null,
        departureTime: null,
        amount: null,
        prepayment: null,
        deposit: null,
        origin: null,
        guestName: 'Гость вебхука',
        guestPhone: `+${RC_DIGITS}`,
        guestEmail: null,
        notes: null,
        rcUrl: null,
        rcUpdatedAt: new Date('2026-11-01T00:00:00Z'),
        property: { rcId: null, title: `U-Tower ${RUN_ID}`, address: null },
      };

      await app.get(RealtyCalendarSyncService).apply(snapshot);

      const booking = await prisma.booking.findUniqueOrThrow({ where: { rcId: RC_ID } });
      expect(booking.dealId).not.toBeNull();
      expect(onDealChanged).toHaveBeenCalledWith(booking.dealId);

      // Отмена сбрасывает журнал: восстановленная бронь снова пройдёт «Заезд сегодня».
      await prisma.stageMoveRun.create({ data: { bookingId: booking.id, rule: 'CHECK_IN', date: booking.checkIn } });
      await app.get(RealtyCalendarSyncService).apply({
        ...snapshot,
        status: 'CANCELED',
        rcUpdatedAt: new Date('2026-11-02T00:00:00Z'),
      });
      expect(await prisma.stageMoveRun.count({ where: { bookingId: booking.id } })).toBe(0);
    });
  });
});
