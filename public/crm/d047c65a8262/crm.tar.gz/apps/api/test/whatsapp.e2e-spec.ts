/**
 * Сквозной сценарий этапа 4: WhatsApp через Green-API (фейковый клиент) → единый inbox.
 * Тела вебхуков — по документации Green-API.
 */
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import { AvatarService } from '../src/inbox/avatar.service.js';
import {
  GreenApiClient,
  GreenApiError,
} from '../src/whatsapp/green-api.client.js';
import {
  type Agent,
  createTestApp,
  createUser,
  CSRF,
  deleteDealsWithHistory,
  fakeJpeg,
  login,
  waitUntil,
} from './helpers.js';

const RUN_ID = Date.now();
const WEBHOOK_TOKEN = 'e2e-whatsapp-token-0123456789abcdef';
process.env.GREEN_API_ID_INSTANCE = String(RUN_ID);
process.env.GREEN_API_TOKEN = 'e2e-green-api-token';
process.env.GREEN_API_WEBHOOK_TOKEN = WEBHOOK_TOKEN;
process.env.PUBLIC_API_URL = 'https://crm.example.uz';
// Повторы скачивания вложений: сразу и через 300 мс, чтобы тест не ждал минутами.
process.env.ATTACHMENT_RETRY_DELAYS_MS = '0,300';

const ADMIN = {
  email: `wa-admin-${RUN_ID}@test.local`,
  password: 'wa-admin-password',
};
const NEW_GUEST = `99890${String(RUN_ID).slice(-7)}`;
const KNOWN_GUEST = `99893${String(RUN_ID).slice(-7)}`;
const CALLER = `99897${String(RUN_ID).slice(-7)}`;
const START_GUEST = `99894${String(RUN_ID).slice(-7)}`;
const NO_WHATSAPP = `99895${String(RUN_ID).slice(-7)}`;
const SEND_FAILS = `99896${String(RUN_ID).slice(-7)}`;
const BIG_PREVIEW = `99892${String(RUN_ID).slice(-7)}`;
const PHOTO_GUEST = `99887${String(RUN_ID).slice(-7)}`;

const sent: Array<{ chatId: string; message: string }> = [];
const avatarRequests: string[] = [];
const freshLinkRequests: Array<{ chatId: string; idMessage: string }> = [];
/** id сообщений, файла которых у Green-API сейчас нет. */
const filesMissing = new Set<string>();
let state = 'authorized';
const fakeClient = {
  isConfigured: true,
  instanceId: String(RUN_ID),
  sendMessage: async (chatId: string, message: string) => {
    if (chatId === `${SEND_FAILS}@c.us`)
      throw new Error('Green-API недоступен');
    sent.push({ chatId, message });
    return { idMessage: `API-${sent.length}-${RUN_ID}` };
  },
  getState: async () => state,
  getAvatar: async (chatId: string) => {
    avatarRequests.push(chatId);
    return {
      available: true,
      urlAvatar: 'https://pps.whatsapp.example/avatar.jpg',
    };
  },
  // Ссылка из вебхука перестала работать (просрочена) — Green-API отвечает 404.
  downloadFile: async (url: string) => {
    if (url.includes('expired'))
      throw new GreenApiError('Файл недоступен: ответ 404', 404);
    return { buffer: fakeJpeg('fake-whatsapp-file'), mimeType: 'image/jpeg' };
  },
  // Свежая ссылка по id сообщения; файла ещё (или уже) нет у Green-API — ошибка 500.
  getDownloadUrl: async (chatId: string, idMessage: string) => {
    freshLinkRequests.push({ chatId, idMessage });
    if (filesMissing.has(idMessage))
      throw new GreenApiError('Green-API ответил 500', 500);
    return `https://media.example/fresh/${idMessage}.jpg`;
  },
  checkWhatsapp: async (digits: string) => ({
    existsWhatsapp: digits !== NO_WHATSAPP,
  }),
};

function incoming(
  digits: string,
  idMessage: string,
  text: string,
  overrides: Record<string, unknown> = {},
) {
  return {
    typeWebhook: 'incomingMessageReceived',
    instanceData: {
      idInstance: RUN_ID,
      wid: '998932062891@c.us',
      typeInstance: 'whatsapp',
    },
    timestamp: Math.floor(Date.now() / 1000),
    idMessage,
    senderData: {
      chatId: `${digits}@c.us`,
      sender: `${digits}@c.us`,
      chatName: 'Гость',
      senderName: 'Гость',
      senderContactName: '',
    },
    messageData: {
      typeMessage: 'textMessage',
      textMessageData: { textMessage: text },
    },
    ...overrides,
  };
}

describe('WhatsApp via Green-API (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let knownContactId: string;
  const contactIds: string[] = [];

  const send = (body: unknown, token = WEBHOOK_TOKEN) =>
    request(app.getHttpServer())
      .post('/api/webhooks/whatsapp')
      .set('authorization', `Bearer ${token}`)
      .send(body as object);

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp((builder) =>
      builder.overrideProvider(GreenApiClient).useValue(fakeClient),
    ));
    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    // Гость уже есть в CRM (например, из брони RealtyCalendar).
    knownContactId = (
      await admin
        .post('/api/contacts')
        .set(CSRF)
        .send({ name: 'Из брони', phones: [`+${KNOWN_GUEST}`] })
        .expect(201)
    ).body.data.id;
    contactIds.push(knownContactId);
  });

  afterAll(async () => {
    const links = await prisma.contactChannel.findMany({
      where: {
        externalId: {
          in: [
            NEW_GUEST,
            KNOWN_GUEST,
            CALLER,
            START_GUEST,
            SEND_FAILS,
            BIG_PREVIEW,
            PHOTO_GUEST,
          ],
        },
      },
      select: { contactId: true },
    });
    const ids = [...new Set([...contactIds, ...links.map((l) => l.contactId)])];
    await prisma.channel.deleteMany({
      where: { phone: `green-api:${RUN_ID}` },
    });
    await deleteDealsWithHistory(prisma, ids);
    await prisma.contact.deleteMany({ where: { id: { in: ids } } });
    await prisma.user.deleteMany({ where: { email: ADMIN.email } });
    await app.close();
  });

  it('pretends the endpoint does not exist without the right token', async () => {
    await send(
      incoming(NEW_GUEST, 'X1', 'Привет'),
      'wrong-token-wrong-token-wrong-token',
    ).expect(404);
  });

  it('creates a client, a conversation and a deal for a new WhatsApp number', async () => {
    const response = await send(
      incoming(
        NEW_GUEST,
        `IN-1-${RUN_ID}`,
        'Здравствуйте! Есть студия на 3 ночи?',
      ),
    ).expect(200);
    expect(response.body.data.result).toBe('stored');

    const link = await prisma.contactChannel.findUniqueOrThrow({
      where: { type_externalId: { type: 'WHATSAPP', externalId: NEW_GUEST } },
      include: { contact: true },
    });
    expect(link.contact).toMatchObject({
      phones: [`+${NEW_GUEST}`],
      source: 'WHATSAPP',
    });
    expect(
      await prisma.deal.count({ where: { contactId: link.contactId } }),
    ).toBe(1);
  });

  it('ignores a repeated delivery of the same message', async () => {
    const response = await send(
      incoming(
        NEW_GUEST,
        `IN-1-${RUN_ID}`,
        'Здравствуйте! Есть студия на 3 ночи?',
      ),
    ).expect(200);

    expect(response.body.data.result).toBe('duplicate');
  });

  // Green-API кладёт превью картинки в уведомление (base64), и оно бывает больше 100 КБ. Отказ на
  // таком уведомлении останавливает всю очередь: Green-API повторяет его, а следующие ждут.
  it('accepts a notification larger than 100 KB with a big image preview', async () => {
    const preview = 'A'.repeat(300 * 1024);
    const response = await send(
      incoming(BIG_PREVIEW, `IN-BIG-${RUN_ID}`, '', {
        messageData: {
          typeMessage: 'imageMessage',
          fileMessageData: {
            caption: 'Фото с превью',
            mimeType: 'image/jpeg',
            jpegThumbnail: preview,
          },
        },
      }),
    ).expect(200);

    expect(response.body.data.result).toBe('stored');
  });

  it('reads a big body only with the Green-API token', async () => {
    const big = incoming(
      BIG_PREVIEW,
      `IN-BIG-FAKE-${RUN_ID}`,
      'x'.repeat(300 * 1024),
    );

    await send(big, 'wrong-token-wrong-token-wrong-token').expect(413);
  });

  it('keeps the usual 100 KB limit outside webhooks and answers 413, not 500', async () => {
    const response = await request(app.getHttpServer())
      .post('/api/auth/login')
      .set(CSRF)
      .send({ email: ADMIN.email, password: 'x'.repeat(200 * 1024) })
      .expect(413);

    expect(response.body).toMatchObject({
      success: false,
      error: { message: 'Запрос слишком большой' },
    });
  });

  it('attaches a known guest to the existing client by phone without a new deal', async () => {
    await send(
      incoming(
        KNOWN_GUEST,
        `IN-2-${RUN_ID}`,
        'Я у вас бронировал, подскажите код домофона',
      ),
    ).expect(200);

    const link = await prisma.contactChannel.findUniqueOrThrow({
      where: { type_externalId: { type: 'WHATSAPP', externalId: KNOWN_GUEST } },
    });
    expect(link.contactId).toBe(knownContactId);
    expect(
      await prisma.deal.count({ where: { contactId: knownContactId } }),
    ).toBe(0);
  });

  it('replies from the CRM and does not duplicate the API echo', async () => {
    const conversation = await prisma.conversation.findFirstOrThrow({
      where: { externalChatId: NEW_GUEST },
    });
    const reply = await admin
      .post(`/api/conversations/${conversation.id}/messages`)
      .set(CSRF)
      .send({ text: 'Да, студия свободна' })
      .expect(201);
    expect(reply.body.data.status).toBe('SENT');
    expect(sent.at(-1)).toEqual({
      chatId: `${NEW_GUEST}@c.us`,
      message: 'Да, студия свободна',
    });

    const echo = incoming(
      NEW_GUEST,
      `API-${sent.length}-${RUN_ID}`,
      'Да, студия свободна',
      { typeWebhook: 'outgoingAPIMessageReceived' },
    );
    expect((await send(echo).expect(200)).body.data.result).toBe('duplicate');
    expect(
      await prisma.message.count({
        where: { conversationId: conversation.id },
      }),
    ).toBe(2);
  });

  it('saves the WhatsApp profile photo of a new client and asks again only after a day', async () => {
    const chatId = `${NEW_GUEST}@c.us`;
    // Фото загружается в фоне после ответа вебхуку.
    const link = await waitUntil(
      () =>
        prisma.contactChannel.findUniqueOrThrow({
          where: {
            type_externalId: { type: 'WHATSAPP', externalId: NEW_GUEST },
          },
          include: { contact: true },
        }),
      (found) => found.contact.avatarFileId !== null,
    );
    expect(
      avatarRequests.filter((requested) => requested === chatId),
    ).toHaveLength(1);

    const conversation = await prisma.conversation.findFirstOrThrow({
      where: { externalChatId: NEW_GUEST },
    });
    const dto = (
      await admin.get(`/api/conversations/${conversation.id}`).expect(200)
    ).body.data;
    expect(dto.contact.avatarFileId).toBe(link.contact.avatarFileId);
    const file = await admin
      .get(`/api/files/${link.contact.avatarFileId}`)
      .expect(200);
    expect(file.headers['content-type']).toBe('image/jpeg');

    await send(
      incoming(NEW_GUEST, `IN-AVATAR-${RUN_ID}`, 'Ещё вопрос про парковку'),
    ).expect(200);
    await app.get(AvatarService).refresh(conversation.id);
    expect(
      avatarRequests.filter((requested) => requested === chatId),
    ).toHaveLength(1);
  });

  describe('writing first from the client card', () => {
    let contactId: string;
    const start = (body: Record<string, unknown>) =>
      admin
        .post(`/api/contacts/${contactId}/conversations`)
        .set(CSRF)
        .send(body);

    beforeAll(async () => {
      contactId = (
        await admin
          .post('/api/contacts')
          .set(CSRF)
          .send({
            name: 'Гость из брони',
            phones: [
              `+${START_GUEST}`,
              `+${NO_WHATSAPP}`,
              `+${SEND_FAILS}`,
              `+${KNOWN_GUEST}`,
            ],
          })
          .expect(201)
      ).body.data.id;
      contactIds.push(contactId);
    });

    it('checks the number, opens a chat and sends the first message', async () => {
      const response = await start({
        channel: 'WHATSAPP',
        phone: `+${START_GUEST}`,
        text: 'Здравствуйте! Пишу по вашей брони',
      }).expect(201);

      expect(response.body.data.message).toMatchObject({
        status: 'SENT',
        text: 'Здравствуйте! Пишу по вашей брони',
      });
      expect(sent.at(-1)).toEqual({
        chatId: `${START_GUEST}@c.us`,
        message: 'Здравствуйте! Пишу по вашей брони',
      });
      const conversation = await prisma.conversation.findUniqueOrThrow({
        where: { id: response.body.data.conversationId },
      });
      expect(conversation).toMatchObject({
        contactId,
        externalChatId: START_GUEST,
      });
      const adminUser = await prisma.user.findUniqueOrThrow({
        where: { email: ADMIN.email },
      });
      expect(conversation.assigneeId).toBe(adminUser.id);
    });

    it('continues the existing chat with the same number', async () => {
      const first = await prisma.conversation.findFirstOrThrow({
        where: { externalChatId: START_GUEST },
      });
      const response = await start({
        channel: 'WHATSAPP',
        phone: `+${START_GUEST}`,
        text: 'Ещё одно сообщение',
      }).expect(201);
      expect(response.body.data.conversationId).toBe(first.id);
    });

    it('writes only to phones saved in the client card', async () => {
      await start({
        channel: 'WHATSAPP',
        phone: '+998900000000',
        text: 'Тест',
      }).expect(400);
    });

    it('opens the existing chat of a number that belongs to another client', async () => {
      const response = await start({
        channel: 'WHATSAPP',
        phone: `+${KNOWN_GUEST}`,
        text: 'Напоминание о заезде',
      }).expect(201);
      const conversation = await prisma.conversation.findUniqueOrThrow({
        where: { id: response.body.data.conversationId },
      });
      expect(conversation.contactId).toBe(knownContactId);
    });

    it('keeps the new chat when delivery fails, so the message can be retried', async () => {
      const response = await start({
        channel: 'WHATSAPP',
        phone: `+${SEND_FAILS}`,
        text: 'Не дойдёт',
      }).expect(201);
      expect(response.body.data.message.status).toBe('FAILED');
      const conversation = await prisma.conversation.findUniqueOrThrow({
        where: { id: response.body.data.conversationId },
      });
      expect(conversation).toMatchObject({
        contactId,
        externalChatId: SEND_FAILS,
      });
    });

    it('limits new chats per hour and records who started them', async () => {
      const adminUser = await prisma.user.findUniqueOrThrow({
        where: { email: ADMIN.email },
      });
      const recorded = await prisma.activityLog.count({
        where: { action: 'conversation.start', actorId: adminUser.id },
      });
      expect(recorded).toBeGreaterThan(0);
      const filler = await prisma.activityLog.createManyAndReturn({
        data: Array.from({ length: 20 }, () => ({
          actorId: adminUser.id,
          action: 'conversation.start',
          entityType: 'contact',
          entityId: contactId,
          payload: { channel: 'WHATSAPP', by: 'phone', test: RUN_ID },
        })),
        select: { id: true },
      });
      try {
        const response = await start({
          channel: 'WHATSAPP',
          phone: `+${NO_WHATSAPP}`,
          text: 'Тест',
        }).expect(429);
        expect(response.body.error.message).toContain('новых диалогов');
        // Продолжение уже начатого чата лимит не трогает.
        await start({
          channel: 'WHATSAPP',
          phone: `+${START_GUEST}`,
          text: 'Продолжаем',
        }).expect(201);
      } finally {
        await prisma.activityLog.deleteMany({
          where: { id: { in: filler.map((row) => row.id) } },
        });
      }
    });

    it('explains when the number has no WhatsApp', async () => {
      const response = await start({
        channel: 'WHATSAPP',
        phone: `+${NO_WHATSAPP}`,
        text: 'Тест',
      }).expect(400);
      expect(response.body.error.message).toContain('нет WhatsApp');
    });
  });

  describe('calls', () => {
    const call = (idMessage: string, status: string) => ({
      from: `${CALLER}@c.us`,
      typeWebhook: 'incomingCall',
      instanceData: {
        idInstance: RUN_ID,
        wid: '998932062891@c.us',
        typeInstance: 'whatsapp',
      },
      status,
      timestamp: Math.floor(Date.now() / 1000),
      idMessage,
    });

    it('waits for the end of the call before recording it', async () => {
      expect(
        (await send(call(`CALL-1-${RUN_ID}`, 'offer')).expect(200)).body.data
          .result,
      ).toBe('ignored');
    });

    it('records a missed call from a new number with a client, a deal and a call-back task', async () => {
      expect(
        (await send(call(`CALL-1-${RUN_ID}`, 'declined')).expect(200)).body.data
          .result,
      ).toBe('stored');

      const link = await prisma.contactChannel.findUniqueOrThrow({
        where: { type_externalId: { type: 'WHATSAPP', externalId: CALLER } },
        include: { contact: true },
      });
      expect(link.contact.phones).toEqual([`+${CALLER}`]);
      expect(
        await prisma.deal.count({ where: { contactId: link.contactId } }),
      ).toBe(1);
      const tasks = await prisma.task.findMany({
        where: { contactId: link.contactId, autoKind: 'callback' },
      });
      expect(tasks).toHaveLength(1);
      expect(tasks[0].title).toMatch(/^Перезвонить в WhatsApp: /);
      const conversation = await prisma.conversation.findFirstOrThrow({
        where: { externalChatId: CALLER },
      });
      expect(conversation).toMatchObject({
        unreadCount: 1,
        lastMessagePreview: '📞 Пропущенный звонок',
      });
    });

    it('records an answered call without another task', async () => {
      expect(
        (await send(call(`CALL-2-${RUN_ID}`, 'pickUp')).expect(200)).body.data
          .result,
      ).toBe('stored');

      const conversation = await prisma.conversation.findFirstOrThrow({
        where: { externalChatId: CALLER },
      });
      expect(conversation).toMatchObject({
        unreadCount: 1,
        lastMessagePreview: '📞 Входящий звонок',
      });
      expect(
        await prisma.task.count({
          where: { contactId: conversation.contactId, autoKind: 'callback' },
        }),
      ).toBe(1);
    });

    it('ignores a repeated delivery of the call result', async () => {
      expect(
        (await send(call(`CALL-1-${RUN_ID}`, 'declined')).expect(200)).body.data
          .result,
      ).toBe('duplicate');

      const conversation = await prisma.conversation.findFirstOrThrow({
        where: { externalChatId: CALLER },
      });
      expect(
        await prisma.task.count({
          where: { contactId: conversation.contactId, autoKind: 'callback' },
        }),
      ).toBe(1);
    });

    it('asks the conversation assignee to call back again once the previous call-back is done', async () => {
      const conversation = await prisma.conversation.findFirstOrThrow({
        where: { externalChatId: CALLER },
      });
      const adminUser = await prisma.user.findUniqueOrThrow({
        where: { email: ADMIN.email },
      });
      await prisma.conversation.update({
        where: { id: conversation.id },
        data: { assigneeId: adminUser.id },
      });
      await prisma.task.updateMany({
        where: { contactId: conversation.contactId, autoKind: 'callback' },
        data: { isDone: true, doneAt: new Date() },
      });

      await send(call(`CALL-3-${RUN_ID}`, 'hungUp')).expect(200);

      const open = await prisma.task.findMany({
        where: {
          contactId: conversation.contactId,
          autoKind: 'callback',
          isDone: false,
        },
      });
      expect(open).toHaveLength(1);
      expect(open[0].assigneeId).toBe(adminUser.id);
    });

    it('stops creating call-back tasks during a flood of calls', async () => {
      const CALLBACK_LIMIT = 30;
      const conversation = await prisma.conversation.findFirstOrThrow({
        where: { externalChatId: CALLER },
      });
      await prisma.task.updateMany({
        where: { contactId: conversation.contactId, autoKind: 'callback' },
        data: { isDone: true, doneAt: new Date() },
      });
      const flood = await prisma.task.createManyAndReturn({
        data: Array.from({ length: CALLBACK_LIMIT }, () => ({
          title: `flood ${RUN_ID}`,
          autoKind: 'callback',
        })),
        select: { id: true },
      });

      await send(call(`CALL-4-${RUN_ID}`, 'declined')).expect(200);
      await prisma.task.deleteMany({
        where: { id: { in: flood.map((task) => task.id) } },
      });

      expect(
        await prisma.task.count({
          where: {
            contactId: conversation.contactId,
            autoKind: 'callback',
            isDone: false,
          },
        }),
      ).toBe(0);
    });

    it('replaces the phone placeholder with the name from the first message', async () => {
      await send(
        incoming(CALLER, `CALL-MSG-${RUN_ID}`, 'Я звонил, перезвоните', {
          senderData: {
            chatId: `${CALLER}@c.us`,
            sender: `${CALLER}@c.us`,
            chatName: 'Азиз',
            senderName: 'Азиз',
            senderContactName: '',
          },
        }),
      ).expect(200);

      const link = await prisma.contactChannel.findUniqueOrThrow({
        where: { type_externalId: { type: 'WHATSAPP', externalId: CALLER } },
        include: { contact: true },
      });
      expect(link.contact.name).toBe('Азиз');
      const deals = await prisma.deal.findMany({
        where: { contactId: link.contactId },
      });
      expect(deals.map((deal) => deal.title)).toEqual(['Азиз']);
    });
  });

  describe('files of incoming messages', () => {
    const photo = (idMessage: string, downloadUrl?: string) =>
      incoming(PHOTO_GUEST, idMessage, '', {
        messageData: {
          typeMessage: 'imageMessage',
          fileMessageData: {
            mimeType: 'image/jpeg',
            ...(downloadUrl && { downloadUrl }),
          },
        },
      });
    const messageOf = (idMessage: string) =>
      prisma.message.findFirstOrThrow({ where: { externalId: idMessage } });
    const fileIdOf = async (idMessage: string) =>
      ((await messageOf(idMessage)).attachment as { fileId?: string } | null)
        ?.fileId;
    const fetchFile = (messageId: string) =>
      admin.post(`/api/messages/${messageId}/attachment`).set(CSRF);

    it('saves the photo of an incoming message right away', async () => {
      const id = `IMG-OK-${RUN_ID}`;
      await send(photo(id, 'https://media.example/ok.jpg')).expect(200);

      expect(await fileIdOf(id)).toBeDefined();
    });

    it('gets a fresh link from Green-API when the link from the webhook does not work', async () => {
      const id = `IMG-EXPIRED-${RUN_ID}`;
      await send(photo(id, 'https://media.example/expired.jpg')).expect(200);

      const fileId = await waitUntil(() => fileIdOf(id), Boolean);
      expect(freshLinkRequests).toContainEqual({
        chatId: `${PHOTO_GUEST}@c.us`,
        idMessage: id,
      });
      await admin.get(`/api/files/${fileId}`).expect(200);
    });

    it('tries again later when the webhook has no link and Green-API does not have the file yet', async () => {
      const id = `IMG-LATER-${RUN_ID}`;
      filesMissing.add(id);
      await send(photo(id)).expect(200);
      // Первая попытка (сразу) не удалась; файл появился до второй.
      await waitUntil(
        async () => freshLinkRequests.filter((r) => r.idMessage === id).length,
        (count) => count >= 1,
      );
      filesMissing.delete(id);

      expect(await waitUntil(() => fileIdOf(id), Boolean)).toBeDefined();
    });

    it('loads the file on request after the automatic attempts', async () => {
      const id = `IMG-MANUAL-${RUN_ID}`;
      filesMissing.add(id);
      await send(photo(id, 'https://media.example/expired.jpg')).expect(200);
      // Обе автоматические попытки (сразу и через 300 мс) не удались.
      await waitUntil(
        async () => freshLinkRequests.filter((r) => r.idMessage === id).length,
        (count) => count >= 2,
      );
      const message = await messageOf(id);

      const failed = await fetchFile(message.id).expect(502);
      expect(failed.body.error.message).toContain('WhatsApp');

      filesMissing.delete(id);
      const loaded = await fetchFile(message.id).expect(200);
      expect(loaded.body.data.attachment).toMatchObject({
        kind: 'photo',
        mimeType: 'image/jpeg',
      });
      expect(loaded.body.data.attachment.fileId).toBeDefined();
      // Файл уже есть — повторный запрос его не перекачивает.
      const requests = freshLinkRequests.length;
      await fetchFile(message.id).expect(200);
      expect(freshLinkRequests).toHaveLength(requests);
    });

    it('explains that a text message has no file to load', async () => {
      const id = `TXT-${RUN_ID}`;
      await send(incoming(PHOTO_GUEST, id, 'Просто текст')).expect(200);

      await fetchFile((await messageOf(id)).id).expect(400);
      await fetchFile('00000000-0000-4000-8000-000000000000').expect(404);
    });
  });

  it('ignores group chats', async () => {
    const group = incoming(NEW_GUEST, `G-${RUN_ID}`, 'Всем привет', {
      senderData: {
        chatId: `${NEW_GUEST}-1581234048@g.us`,
        sender: `${NEW_GUEST}@c.us`,
        chatName: 'Группа',
        senderName: 'Гость',
      },
    });

    expect((await send(group).expect(200)).body.data.result).toBe('ignored');
  });

  it('tracks the number state and shows the webhook address to admins', async () => {
    await send({
      typeWebhook: 'stateInstanceChanged',
      instanceData: { idInstance: RUN_ID, wid: '998932062891@c.us' },
      timestamp: 1,
      stateInstance: 'notAuthorized',
    }).expect(200);
    let channel = await prisma.channel.findFirstOrThrow({
      where: { phone: `green-api:${RUN_ID}` },
    });
    expect(channel).toMatchObject({
      status: 'DISCONNECTED',
      name: 'WhatsApp +998 93 206 28 91',
    });
    expect(channel.lastError).toContain('QR');

    await send({
      typeWebhook: 'stateInstanceChanged',
      instanceData: { idInstance: RUN_ID },
      timestamp: 2,
      stateInstance: 'authorized',
    }).expect(200);
    channel = await prisma.channel.findFirstOrThrow({
      where: { phone: `green-api:${RUN_ID}` },
    });
    expect(channel).toMatchObject({ status: 'CONNECTED', lastError: null });

    const overview = (await admin.get('/api/channels').expect(200)).body.data;
    expect(overview).toMatchObject({
      whatsappConfigured: true,
      whatsappWebhookUrl: 'https://crm.example.uz/api/webhooks/whatsapp',
    });
  });

  it('keeps replies working during a temporary WhatsApp warning, showing it to the admin', async () => {
    await send({
      typeWebhook: 'stateInstanceChanged',
      instanceData: { idInstance: RUN_ID },
      timestamp: 4,
      stateInstance: 'yellowCard',
    }).expect(200);
    const channel = await prisma.channel.findFirstOrThrow({
      where: { phone: `green-api:${RUN_ID}` },
    });
    expect(channel.status).toBe('CONNECTED');
    expect(channel.lastError).toContain('массовых рассылок');

    const conversation = await prisma.conversation.findFirstOrThrow({
      where: { externalChatId: NEW_GUEST },
    });
    const reply = await admin
      .post(`/api/conversations/${conversation.id}/messages`)
      .set(CSRF)
      .send({ text: 'Ответ при предупреждении' })
      .expect(201);
    expect(reply.body.data.status).toBe('SENT');
  });

  it('fails a reply clearly when the number is disconnected', async () => {
    state = 'notAuthorized';
    await send({
      typeWebhook: 'stateInstanceChanged',
      instanceData: { idInstance: RUN_ID },
      timestamp: 3,
      stateInstance: 'notAuthorized',
    }).expect(200);
    const conversation = await prisma.conversation.findFirstOrThrow({
      where: { externalChatId: NEW_GUEST },
    });

    const reply = await admin
      .post(`/api/conversations/${conversation.id}/messages`)
      .set(CSRF)
      .send({ text: 'Тест' })
      .expect(201);

    expect(reply.body.data).toMatchObject({ status: 'FAILED' });
    expect(reply.body.data.error).toContain('Канал не подключён');
  });
});
