/**
 * Фото и файлы в переписке: сохранение вложений входящих WhatsApp, безопасная выдача сотрудникам,
 * отправка файлов клиенту и повтор неудавшейся отправки. Green-API — фейковый клиент.
 */
import type { INestApplication } from '@nestjs/common';
import type { MessageAttachment } from '@crm/shared';
import request from 'supertest';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import { GreenApiClient } from '../src/whatsapp/green-api.client.js';
import {
  type Agent,
  createTestApp,
  createUser,
  CSRF,
  deleteDealsWithHistory,
  login,
} from './helpers.js';

const RUN_ID = Date.now();
const WEBHOOK_TOKEN = 'e2e-files-webhook-token-0123456789ab';
process.env.GREEN_API_ID_INSTANCE = String(RUN_ID);
process.env.GREEN_API_TOKEN = 'e2e-green-api-token';
process.env.GREEN_API_WEBHOOK_TOKEN = WEBHOOK_TOKEN;

const MANAGER = { email: `files-manager-${RUN_ID}@test.local`, password: 'files-manager-password' };
const GUEST = `99897${String(RUN_ID).slice(-7)}`;
const DOWNLOAD_HOST = 'https://sw-media.storage.greenapi.net';

const downloads: string[] = [];
const sentFiles: Array<{ chatId: string; fileName: string; mimeType: string; size: number; caption: string }> = [];
/** Содержимое файлов по ссылке; null — файл больше лимита; Error — ссылка недоступна. */
const remoteFiles = new Map<string, Buffer | null | Error>();
let failUploads = false;

const fakeClient = {
  isConfigured: true,
  instanceId: String(RUN_ID),
  getState: async () => 'authorized',
  sendMessage: async () => ({ idMessage: `TXT-${RUN_ID}` }),
  sendFileByUpload: async (chatId: string, file: { buffer: Buffer; fileName: string; mimeType: string }, caption: string) => {
    if (failUploads) throw new Error('network down');
    sentFiles.push({ chatId, fileName: file.fileName, mimeType: file.mimeType, size: file.buffer.length, caption });
    return { idMessage: `FILE-${sentFiles.length}-${RUN_ID}` };
  },
  downloadFile: async (url: string) => {
    downloads.push(url);
    const content = remoteFiles.get(url);
    if (content instanceof Error) throw content;
    return content ? { buffer: content, mimeType: 'application/octet-stream' } : null;
  },
};

function fileWebhook(idMessage: string, typeMessage: string, file: { url: string; mimeType: string; fileName?: string; caption?: string }) {
  const data = { downloadUrl: file.url, mimeType: file.mimeType, fileName: file.fileName ?? '', caption: file.caption ?? '' };
  return {
    typeWebhook: 'incomingMessageReceived',
    instanceData: { idInstance: RUN_ID, wid: '998932062891@c.us', typeInstance: 'whatsapp' },
    timestamp: Math.floor(Date.now() / 1000),
    idMessage,
    senderData: { chatId: `${GUEST}@c.us`, sender: `${GUEST}@c.us`, chatName: 'Гость', senderName: 'Гость' },
    messageData: { typeMessage, fileMessageData: data },
  };
}

describe('Files in conversations (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let manager: Agent;
  let conversationId: string;
  const fileIds: string[] = [];
  const templateIds: string[] = [];

  const webhook = (body: unknown) =>
    request(app.getHttpServer()).post('/api/webhooks/whatsapp').set('authorization', `Bearer ${WEBHOOK_TOKEN}`).send(body as object).expect(200);

  async function attachmentOf(idMessage: string): Promise<MessageAttachment> {
    const message = await prisma.message.findFirstOrThrow({ where: { externalId: idMessage } });
    const attachment = message.attachment as unknown as MessageAttachment;
    if (attachment.fileId) fileIds.push(attachment.fileId);
    return attachment;
  }

  /** Тело ответа собираем в Buffer при любом Content-Type (иначе supertest не отдаст octet-stream). */
  const getFile = (agent: Agent, fileId: string) =>
    agent
      .get(`/api/files/${fileId}`)
      .buffer(true)
      .parse((response, callback) => {
        const chunks: Buffer[] = [];
        response.on('data', (chunk: Buffer) => chunks.push(chunk));
        response.on('end', () => callback(null, Buffer.concat(chunks)));
      });

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp((builder) => builder.overrideProvider(GreenApiClient).useValue(fakeClient)));
    await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER');
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));
  });

  afterAll(async () => {
    const links = await prisma.contactChannel.findMany({ where: { externalId: GUEST }, select: { contactId: true } });
    const contactIds = links.map((link) => link.contactId);
    await prisma.channel.deleteMany({ where: { phone: `green-api:${RUN_ID}` } });
    await deleteDealsWithHistory(prisma, contactIds);
    await prisma.contact.deleteMany({ where: { id: { in: contactIds } } });
    await prisma.replyTemplate.deleteMany({ where: { id: { in: templateIds } } });
    await prisma.storedFile.deleteMany({ where: { id: { in: fileIds } } });
    await prisma.user.deleteMany({ where: { email: MANAGER.email } });
    await app.close();
  });

  describe('incoming attachments', () => {
    it('saves a photo from WhatsApp and shows it inline', async () => {
      const url = `${DOWNLOAD_HOST}/photo-${RUN_ID}.jpg`;
      remoteFiles.set(url, Buffer.from('jpeg-bytes'));
      await webhook(fileWebhook(`IMG-${RUN_ID}`, 'imageMessage', { url, mimeType: 'image/jpeg', caption: 'Вот чек' }));

      const attachment = await attachmentOf(`IMG-${RUN_ID}`);
      expect(attachment).toMatchObject({ kind: 'photo', mimeType: 'image/jpeg', size: 10 });
      conversationId = (await prisma.message.findFirstOrThrow({ where: { externalId: `IMG-${RUN_ID}` } })).conversationId;

      const file = await getFile(manager, attachment.fileId!).expect(200);
      expect(file.headers).toMatchObject({
        'content-type': 'image/jpeg',
        'x-content-type-options': 'nosniff',
      });
      expect(file.headers['content-disposition']).toMatch(/^inline;/);
      expect((file.body as Buffer).toString()).toBe('jpeg-bytes');
    });

    it('serves a document that a browser could execute as a download', async () => {
      const url = `${DOWNLOAD_HOST}/page-${RUN_ID}.html`;
      remoteFiles.set(url, Buffer.from('<script>alert(1)</script>'));
      await webhook(fileWebhook(`DOC-${RUN_ID}`, 'documentMessage', { url, mimeType: 'text/html', fileName: 'Счёт.html' }));

      const attachment = await attachmentOf(`DOC-${RUN_ID}`);
      expect(attachment).toMatchObject({ kind: 'document', fileName: 'Счёт.html', mimeType: 'text/html' });
      const file = await getFile(manager, attachment.fileId!).expect(200);
      expect(file.headers['content-type']).toBe('application/octet-stream');
      expect(file.headers['content-disposition']).toContain(`attachment; filename="____.html"; filename*=UTF-8''${encodeURIComponent('Счёт.html')}`);
      expect(file.headers['content-security-policy']).toContain('sandbox');
    });

    it('keeps the message without a file when the attachment is too large or unavailable', async () => {
      const large = `${DOWNLOAD_HOST}/large-${RUN_ID}.mp4`;
      const broken = `${DOWNLOAD_HOST}/broken-${RUN_ID}.ogg`;
      remoteFiles.set(large, null);
      remoteFiles.set(broken, new Error('timeout'));
      await webhook(fileWebhook(`BIG-${RUN_ID}`, 'videoMessage', { url: large, mimeType: 'video/mp4' }));
      await webhook(fileWebhook(`OGG-${RUN_ID}`, 'audioMessage', { url: broken, mimeType: 'audio/ogg' }));

      expect(await attachmentOf(`BIG-${RUN_ID}`)).toEqual({ kind: 'video' });
      expect(await attachmentOf(`OGG-${RUN_ID}`)).toEqual({ kind: 'voice' });
    });

    it('does not download the file again when Green-API repeats the webhook', async () => {
      const url = `${DOWNLOAD_HOST}/photo-${RUN_ID}.jpg`;
      const before = downloads.length;
      await webhook(fileWebhook(`IMG-${RUN_ID}`, 'imageMessage', { url, mimeType: 'image/jpeg' }));

      expect(downloads.length).toBe(before);
    });
  });

  describe('file access', () => {
    it('requires a session', async () => {
      const attachment = await attachmentOf(`IMG-${RUN_ID}`);
      await request(app.getHttpServer()).get(`/api/files/${attachment.fileId}`).expect(401);
    });

    it('answers byte-range requests so Safari can play audio and video', async () => {
      const attachment = await attachmentOf(`IMG-${RUN_ID}`);
      const partial = await getFile(manager, attachment.fileId!).set('range', 'bytes=0-3').expect(206);

      expect(partial.headers['content-range']).toBe('bytes 0-3/10');
      expect((partial.body as Buffer).toString()).toBe('jpeg');
    });

    it('returns 404 for an unknown file', async () => {
      const response = await manager.get('/api/files/00000000-0000-4000-8000-000000000000').expect(404);
      expect(response.body.error.message).toBe('Файл не найден');
    });
  });

  describe('sending files', () => {
    it('sends a photo with a caption and decodes a Cyrillic file name', async () => {
      const response = await manager
        .post(`/api/conversations/${conversationId}/files`)
        .set(CSRF)
        .field('caption', '  Схема проезда  ')
        .attach('file', Buffer.from('png-bytes'), { filename: 'Схема.png', contentType: 'image/png' })
        .expect(201);

      const message = response.body.data;
      expect(message).toMatchObject({
        status: 'SENT',
        text: 'Схема проезда',
        attachment: { kind: 'photo', fileName: 'Схема.png', mimeType: 'image/png', size: 9 },
      });
      fileIds.push(message.attachment.fileId);
      expect(sentFiles.at(-1)).toEqual({
        chatId: `${GUEST}@c.us`,
        fileName: 'Схема.png',
        mimeType: 'image/png',
        size: 9,
        caption: 'Схема проезда',
      });
    });

    it('rejects a request without a file or without the CSRF header', async () => {
      const empty = await manager.post(`/api/conversations/${conversationId}/files`).set(CSRF).field('caption', 'x').expect(400);
      expect(empty.body.error.message).toBe('Выберите файл');
      await manager
        .post(`/api/conversations/${conversationId}/files`)
        .attach('file', Buffer.from('x'), 'a.txt')
        .expect(403);
    });

    it('marks a failed file as FAILED and re-sends the same file on retry', async () => {
      failUploads = true;
      const failed = await manager
        .post(`/api/conversations/${conversationId}/files`)
        .set(CSRF)
        .attach('file', Buffer.from('report'), { filename: 'report.txt', contentType: 'text/plain' })
        .expect(201);
      expect(failed.body.data.status).toBe('FAILED');
      fileIds.push(failed.body.data.attachment.fileId);

      failUploads = false;
      const retried = await manager.post(`/api/messages/${failed.body.data.id}/retry`).set(CSRF).expect(200);
      expect(retried.body.data.status).toBe('SENT');
      expect(sentFiles.at(-1)).toMatchObject({ fileName: 'report.txt', size: 6, caption: '' });
    });
  });

  describe('template files', () => {
    async function createTemplate(title: string, body = 'Видео входа в U-Tower'): Promise<string> {
      const created = await manager.post('/api/templates').set(CSRF).send({ title: `${title} ${RUN_ID}`, body }).expect(201);
      templateIds.push(created.body.data.id);
      return created.body.data.id;
    }

    const attach = (templateId: string, content: string, filename: string, contentType: string) =>
      manager.put(`/api/templates/${templateId}/file`).set(CSRF).attach('file', Buffer.from(content), { filename, contentType });

    const storedFileExists = async (id: string) => (await prisma.storedFile.findUnique({ where: { id } })) !== null;

    it('attaches a video to a template and sends it with the edited caption without copying the file', async () => {
      const templateId = await createTemplate('Вход');
      const attached = await attach(templateId, 'mp4-bytes', 'Вход.mp4', 'video/mp4').expect(200);
      const file = attached.body.data.file;
      fileIds.push(file.id);
      expect(file).toMatchObject({ fileName: 'Вход.mp4', mimeType: 'video/mp4', size: 9 });

      const listed = await manager.get('/api/templates').expect(200);
      expect(listed.body.data.find((template: { id: string }) => template.id === templateId).file).toEqual(file);

      const sent = await manager
        .post(`/api/conversations/${conversationId}/template-file`)
        .set(CSRF)
        .send({ templateId, fileId: file.id, caption: '  Видео входа, код 1234  ' })
        .expect(201);
      const message = sent.body.data;
      expect(message).toMatchObject({
        status: 'SENT',
        text: 'Видео входа, код 1234',
        attachment: { kind: 'video', fileName: 'Вход.mp4', mimeType: 'video/mp4', size: 9, fileId: file.id },
      });
      expect(sentFiles.at(-1)).toEqual({
        chatId: `${GUEST}@c.us`,
        fileName: 'Вход.mp4',
        mimeType: 'video/mp4',
        size: 9,
        caption: 'Видео входа, код 1234',
      });
      expect((await getFile(manager, file.id).expect(200)).body.toString()).toBe('mp4-bytes');
    });

    it('keeps a file already sent to a guest when the template file is replaced or the template deleted', async () => {
      const templateId = await createTemplate('Ночной заезд');
      const sentFile = (await attach(templateId, 'night-video', 'night.mp4', 'video/mp4').expect(200)).body.data.file;
      fileIds.push(sentFile.id);
      await manager
        .post(`/api/conversations/${conversationId}/template-file`)
        .set(CSRF)
        .send({ templateId, fileId: sentFile.id })
        .expect(201);

      const replacement = (await attach(templateId, 'night-video-2', 'night-2.mp4', 'video/mp4').expect(200)).body.data.file;
      fileIds.push(replacement.id);
      expect((await getFile(manager, sentFile.id).expect(200)).body.toString()).toBe('night-video');

      const stale = await manager
        .post(`/api/conversations/${conversationId}/template-file`)
        .set(CSRF)
        .send({ templateId, fileId: sentFile.id })
        .expect(409);
      expect(stale.body.error.message).toBe('Файл шаблона заменили — выберите шаблон заново');

      await manager.delete(`/api/templates/${templateId}`).set(CSRF).expect(200);
      expect(await storedFileExists(sentFile.id)).toBe(true);
      expect(await storedFileExists(replacement.id)).toBe(false);
    });

    it('replaces and removes a file nobody received, deleting the old one from storage', async () => {
      const templateId = await createTemplate('Фото дома');
      const first = (await attach(templateId, 'old', 'old.jpg', 'image/jpeg').expect(200)).body.data.file;
      const second = (await attach(templateId, 'new-photo', 'new.jpg', 'image/jpeg').expect(200)).body.data.file;
      fileIds.push(first.id, second.id);
      expect(second).toMatchObject({ fileName: 'new.jpg', size: 9 });
      expect(await storedFileExists(first.id)).toBe(false);

      const removed = await manager.delete(`/api/templates/${templateId}/file`).set(CSRF).expect(200);
      expect(removed.body.data.file).toBeNull();
      expect(await storedFileExists(second.id)).toBe(false);

      const withoutFile = await manager
        .post(`/api/conversations/${conversationId}/template-file`)
        .set(CSRF)
        .send({ templateId, fileId: second.id })
        .expect(400);
      expect(withoutFile.body.error.message).toBe('У шаблона больше нет файла — выберите шаблон заново');
    });

    it('keeps the text of a template with a file within the caption limit', async () => {
      const longText = 'а'.repeat(1025);
      const longTemplate = await createTemplate('Длинный', longText);
      const rejected = await attach(longTemplate, 'x', 'x.jpg', 'image/jpeg').expect(400);
      expect(rejected.body.error.fields.body).toBe('С файлом текст становится подписью — не длиннее 1024 символов');

      const templateId = await createTemplate('Короткий');
      fileIds.push((await attach(templateId, 'x', 'x.jpg', 'image/jpeg').expect(200)).body.data.file.id);
      const tooLong = await manager
        .patch(`/api/templates/${templateId}`)
        .set(CSRF)
        .send({ title: `Короткий ${RUN_ID}`, body: longText })
        .expect(400);
      expect(tooLong.body.error.fields.body).toBe('С файлом текст становится подписью — не длиннее 1024 символов');
    });

    it('deletes the file together with the template', async () => {
      const templateId = await createTemplate('Удаляемый');
      const file = (await attach(templateId, 'bytes', 'plan.pdf', 'application/pdf').expect(200)).body.data.file;
      fileIds.push(file.id);

      await manager.delete(`/api/templates/${templateId}`).set(CSRF).expect(200);
      expect(await storedFileExists(file.id)).toBe(false);
    });

    it('rejects a request without a file, without the CSRF header or for an unknown template', async () => {
      const templateId = await createTemplate('Проверки');
      const empty = await manager.put(`/api/templates/${templateId}/file`).set(CSRF).expect(400);
      expect(empty.body.error.message).toBe('Выберите файл');
      await manager.put(`/api/templates/${templateId}/file`).attach('file', Buffer.from('x'), 'a.txt').expect(403);
      await attach('00000000-0000-4000-8000-000000000000', 'x', 'a.txt', 'text/plain').expect(404);
      await manager
        .post(`/api/conversations/${conversationId}/template-file`)
        .set(CSRF)
        .send({ templateId: '00000000-0000-4000-8000-000000000000', fileId: '00000000-0000-4000-8000-000000000000' })
        .expect(404);
    });
  });
});
