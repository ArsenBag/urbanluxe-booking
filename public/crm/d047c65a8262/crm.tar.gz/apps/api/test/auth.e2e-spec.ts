/**
 * Сквозной тест входа и управления пользователями на настоящей БД.
 * Требует запущенный PostgreSQL (pnpm db:up) и применённые миграции.
 */
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import { type Agent, createTestApp, createUser, CSRF, login } from './helpers.js';
const RUN_ID = Date.now();
const ADMIN = { email: `e2e-admin-${RUN_ID}@test.local`, password: 'e2e-admin-password' };
const MANAGER_EMAIL = `e2e-manager-${RUN_ID}@test.local`;

describe('Auth & users (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  /** Сессия админа на весь файл: лимит — 5 входов в минуту с одного IP. */
  let adminAgent: Agent;

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    ({ agent: adminAgent } = await loginAs(ADMIN.email, ADMIN.password));
  });

  afterAll(async () => {
    await prisma.user.deleteMany({ where: { email: { in: [ADMIN.email, MANAGER_EMAIL] } } });
    await app.close();
  });

  const loginAs = (email: string, password: string) => login(app, email, password);

  it('rejects protected routes without a session', async () => {
    const response = await request(app.getHttpServer()).get('/api/auth/me');

    expect(response.status).toBe(401);
    expect(response.body).toMatchObject({ success: false, data: null });
  });

  it('rejects mutations without the CSRF header', async () => {
    const response = await request(app.getHttpServer()).post('/api/auth/login').send(ADMIN);

    expect(response.status).toBe(403);
  });

  it('returns malformed JSON errors in the API envelope', async () => {
    const response = await request(app.getHttpServer())
      .post('/api/auth/login')
      .set(CSRF)
      .set('content-type', 'application/json')
      .send('{"email":');

    expect(response.status).toBe(400);
    expect(response.body).toMatchObject({ success: false, data: null, error: { message: expect.any(String) } });
  });

  it('rejects wrong password with a generic message', async () => {
    const { response } = await loginAs(ADMIN.email, 'wrong-password');

    expect(response.status).toBe(401);
    expect(response.body.error.message).toBe('Неверный email или пароль');
  });

  it('logs in case-insensitively, sets an httpOnly cookie and returns the user', async () => {
    const { agent, response } = await loginAs(ADMIN.email.toUpperCase(), ADMIN.password);

    expect(response.status).toBe(200);
    expect(response.headers['set-cookie'][0]).toMatch(/crm_session=.+HttpOnly/i);
    const me = await agent.get('/api/auth/me');
    expect(me.body.data).toMatchObject({ email: ADMIN.email, role: 'ADMIN' });

    // Выход отзывает токен на сервере: сохранённая копия cookie больше не работает.
    const stolenCookie = response.headers['set-cookie'][0].split(';')[0];
    await agent.post('/api/auth/logout').set(CSRF).expect(200);
    const replay = await request(app.getHttpServer()).get('/api/auth/me').set('Cookie', stolenCookie);
    expect(replay.status).toBe(401);
  });

  it('lets an admin create a manager, who then cannot manage users', async () => {
    // Предыдущий тест вышел из аккаунта админа, а выход завершает все его сессии.
    ({ agent: adminAgent } = await loginAs(ADMIN.email, ADMIN.password));
    const created = await adminAgent
      .post('/api/users')
      .set(CSRF)
      .send({ email: MANAGER_EMAIL, name: 'E2E Manager', password: 'manager-password', role: 'MANAGER' });
    expect(created.status).toBe(201);
    expect(created.body.data).not.toHaveProperty('passwordHash');

    const { agent: managerAgent } = await loginAs(MANAGER_EMAIL, 'manager-password');
    const forbidden = await managerAgent.get('/api/users');
    expect(forbidden.status).toBe(403);

    // Блокировка действует сразу, без ожидания истечения токена.
    const manager = await prisma.user.findUniqueOrThrow({ where: { email: MANAGER_EMAIL } });

    await adminAgent.patch(`/api/users/${manager.id}`).set(CSRF).send({ isActive: false }).expect(200);

    const me = await managerAgent.get('/api/auth/me');
    expect(me.status).toBe(401);
  });

  // Должен идти последним: исчерпывает лимит входов (5 в минуту) для этого IP.
  it('throttles login after 5 attempts per minute', async () => {
    const LOGIN_LIMIT = 5;
    const statuses: number[] = [];
    for (let attempt = 0; attempt <= LOGIN_LIMIT && !statuses.includes(429); attempt++) {
      const { response } = await loginAs(ADMIN.email, ADMIN.password);
      statuses.push(response.status);
    }

    expect(statuses.at(-1)).toBe(429);
    const { response } = await loginAs(ADMIN.email, ADMIN.password);
    expect(response.body.error.message).toBe('Слишком много запросов. Подождите минуту и попробуйте снова.');
  });
});
