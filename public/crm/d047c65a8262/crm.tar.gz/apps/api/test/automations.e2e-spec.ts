/**
 * Сквозной сценарий этапа 6: автосообщения гостю (перенос сделок по датам — stage-automation.e2e-spec.ts).
 * Время задаётся явно (runOnce(now)); мессенджер — фейковый отправитель WhatsApp.
 */
import { type INestApplication, NotFoundException } from '@nestjs/common';
import { vi } from 'vitest';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import { AutomationService } from '../src/automations/automation.service.js';
import { FileStorageService } from '../src/files/file-storage.service.js';
import { ChannelRegistry } from '../src/inbox/channel-registry.js';
import { RealtyCalendarSyncService } from '../src/realtycalendar/realtycalendar-sync.service.js';
import type { BookingSnapshot } from '../src/realtycalendar/rc-mapper.js';
import {
  type Agent,
  createTestApp,
  createUser,
  CSRF,
  deleteDealsWithHistory,
  login,
  only,
} from './helpers.js';

const RUN_ID = Date.now();
const ADMIN = {
  email: `auto-admin-${RUN_ID}@test.local`,
  password: 'auto-admin-password',
};
const MANAGER = {
  email: `auto-manager-${RUN_ID}@test.local`,
  password: 'auto-manager-password',
};
const DIGITS = `99899${String(RUN_ID).slice(-7)}`;
const RC_ID = 1_000_000_000 + Math.floor(Math.random() * 900_000_000);
/** Вторая и третья брони того же гостя — для автосообщений с файлом. */
const SECOND_RC_ID = RC_ID + 1;
const THIRD_RC_ID = RC_ID + 2;

const sent: Array<{ chatId: string; text: string; file?: string }> = [];

function booking(overrides: Partial<BookingSnapshot> = {}): BookingSnapshot {
  return {
    rcId: RC_ID,
    importKey: null,
    status: 'BOOKED',
    checkIn: '2026-11-20',
    checkOut: '2026-11-23',
    nights: 3,
    arrivalTime: null,
    departureTime: null,
    amount: 255,
    prepayment: null,
    deposit: null,
    origin: null,
    guestName: 'Дилноза Каримова',
    guestPhone: `+${DIGITS}`,
    guestEmail: null,
    notes: null,
    rcUrl: null,
    rcUpdatedAt: new Date('2026-10-04T10:00:00Z'),
    property: { rcId: null, title: `U-Tower ${RUN_ID}`, address: null },
    ...overrides,
  };
}

describe('Automations (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let manager: Agent;
  let automations: AutomationService;
  let contactId: string;
  let channelId: string;
  const templateIds: string[] = [];

  const stageOfDeal = async () => {
    const stored = await prisma.booking.findUniqueOrThrow({
      where: { rcId: RC_ID },
      include: { deal: { include: { stage: true } } },
    });
    return stored.deal?.stage.name;
  };

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    automations = app.get(AutomationService);
    app.get(ChannelRegistry).register({
      type: 'WHATSAPP',
      send: async (message) => {
        sent.push({
          chatId: message.externalChatId,
          text: message.text,
          ...(message.file && { file: message.file.fileName }),
        });
        return {
          externalMessageId: `AUTO-${sent.length}-${RUN_ID}`,
          sentAt: new Date(),
        };
      },
      fetchAvatar: async () => null,
      findRecipient: async () => {
        throw new Error('Поиск собеседника в этом тесте не используется');
      },
    });
    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER');
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));

    // Гость писал в подключённый WhatsApp — туда и уйдут автосообщения.
    channelId = (
      await prisma.channel.create({
        data: {
          type: 'WHATSAPP',
          phone: `auto-${RUN_ID}`,
          name: 'WhatsApp test',
          status: 'CONNECTED',
        },
      })
    ).id;
    contactId = (
      await prisma.contact.create({
        data: { name: 'Дилноза Каримова', phones: [`+${DIGITS}`] },
      })
    ).id;
    await prisma.conversation.create({
      data: {
        channelId,
        contactId,
        externalChatId: DIGITS,
        lastMessageAt: new Date('2026-10-01T10:00:00Z'),
      },
    });

    await app.get(RealtyCalendarSyncService).apply(booking());
    expect(await stageOfDeal()).toBe('Бронь создана');
  });

  afterAll(async () => {
    // Файлы шаблонов и их копии в отправленных сообщениях — до удаления самих записей.
    const templateFiles = await prisma.replyTemplate.findMany({
      where: { id: { in: templateIds } },
      select: { fileId: true },
    });
    const messages = await prisma.message.findMany({
      // only: если beforeAll упал до создания канала, пустое условие выбрало бы все сообщения базы.
      where: { conversation: only({ channelId }) },
      select: { attachment: true },
    });
    const fileIds = [
      ...templateFiles.flatMap((template) => template.fileId ?? []),
      ...messages.flatMap(
        (message) =>
          (message.attachment as { fileId?: string } | null)?.fileId ?? [],
      ),
    ];
    await prisma.replyTemplate.deleteMany({
      where: { id: { in: templateIds } },
    });
    await prisma.storedFile.deleteMany({ where: { id: { in: fileIds } } });
    await prisma.booking.deleteMany({
      where: { rcId: { in: [RC_ID, SECOND_RC_ID, THIRD_RC_ID] } },
    });
    await prisma.property.deleteMany({ where: { title: `U-Tower ${RUN_ID}` } });
    await prisma.channel.deleteMany({ where: only({ id: channelId }) });
    await prisma.task.deleteMany({ where: only({ contactId }) });
    await deleteDealsWithHistory(prisma, [contactId]);
    await prisma.contact.deleteMany({ where: only({ id: contactId }) });
    await prisma.user.deleteMany({
      where: { email: { in: [ADMIN.email, MANAGER.email] } },
    });
    await app.close();
  });

  it('lets admins mark a template for automatic sending, one template per kind', async () => {
    const first = await admin
      .post('/api/templates')
      .set(CSRF)
      .send({
        title: `Инструкция ${RUN_ID}`,
        body: '{имя}, ждём вас {заезд} в {объект}. Заезд с 15:00.',
        automation: 'BEFORE_CHECK_IN',
      })
      .expect(201);
    templateIds.push(first.body.data.id);
    expect(first.body.data.automation).toBe('BEFORE_CHECK_IN');
  });

  it('does nothing before the send window', async () => {
    const result = await automations.runOnce(new Date('2026-11-19T12:00:00Z')); // 17:00 по Ташкенту

    expect(result.messagesSent).toBe(0);
    expect(sent).toHaveLength(0);
  });

  it('sends the check-in instruction the evening before, filled with booking data, exactly once', async () => {
    const evening = new Date('2026-11-19T13:30:00Z'); // 18:30 по Ташкенту
    expect((await automations.runOnce(evening)).messagesSent).toBe(1);
    expect(sent.at(-1)).toEqual({
      chatId: DIGITS,
      text: `Дилноза, ждём вас 20 ноября в U-Tower ${RUN_ID}. Заезд с 15:00.`,
    });

    expect((await automations.runOnce(evening)).messagesSent).toBe(0);
    expect(sent).toHaveLength(1);

    const message = await prisma.message.findFirstOrThrow({
      where: { externalId: `AUTO-1-${RUN_ID}` },
    });
    expect(message).toMatchObject({
      direction: 'OUT',
      status: 'SENT',
      senderId: null,
    });
    const conversation = await prisma.conversation.findFirstOrThrow({
      where: { channelId },
    });
    expect(conversation.assigneeId).toBeNull();
  });

  it('sends a review request only once a template is chosen for it, and moves the kind between templates', async () => {
    expect(
      (await automations.runOnce(new Date('2026-11-23T10:00:00Z')))
        .messagesSent,
    ).toBe(0);

    const review = await admin
      .post('/api/templates')
      .set(CSRF)
      .send({
        title: `Отзыв ${RUN_ID}`,
        body: '{имя}, спасибо за проживание!',
        automation: 'AFTER_CHECK_OUT',
      })
      .expect(201);
    templateIds.push(review.body.data.id);
    const second = await admin
      .post('/api/templates')
      .set(CSRF)
      .send({
        title: `Отзыв 2 ${RUN_ID}`,
        body: '{имя}, будем рады вашему отзыву!',
        automation: 'AFTER_CHECK_OUT',
      })
      .expect(201);
    templateIds.push(second.body.data.id);
    const first = await prisma.replyTemplate.findUniqueOrThrow({
      where: { id: review.body.data.id },
    });
    expect(first.automation).toBeNull();

    expect(
      (await automations.runOnce(new Date('2026-11-23T10:00:00Z')))
        .messagesSent,
    ).toBe(1);
    expect(sent.at(-1)?.text).toBe('Дилноза, будем рады вашему отзыву!');
  });

  describe('templates with a file', () => {
    const attach = (
      agent: Agent,
      templateId: string,
      filename: string,
      contentType: string,
    ) =>
      agent
        .put(`/api/templates/${templateId}/file`)
        .set(CSRF)
        .attach('file', Buffer.from('file-bytes'), { filename, contentType });

    it('leaves the file of an automatic template to admins', async () => {
      const [instruction] = templateIds;
      await attach(manager, instruction, 'Вход.mp4', 'video/mp4').expect(403);
      await manager
        .delete(`/api/templates/${instruction}/file`)
        .set(CSRF)
        .expect(403);
    });

    it('sends the file with the filled text as its caption', async () => {
      const [instruction] = templateIds;
      await attach(admin, instruction, 'Вход.mp4', 'video/mp4').expect(200);
      await app.get(RealtyCalendarSyncService).apply(
        booking({
          rcId: SECOND_RC_ID,
          checkIn: '2026-12-10',
          checkOut: '2026-12-12',
          nights: 2,
        }),
      );

      const evening = new Date('2026-12-09T13:30:00Z'); // 18:30 по Ташкенту
      expect((await automations.runOnce(evening)).messagesSent).toBe(1);
      expect(sent.at(-1)).toEqual({
        chatId: DIGITS,
        text: `Дилноза, ждём вас 10 декабря в U-Tower ${RUN_ID}. Заезд с 15:00.`,
        file: 'Вход.mp4',
      });
    });

    it('sends only the text when the template file disappeared during the pass', async () => {
      vi.spyOn(app.get(FileStorageService), 'find').mockRejectedValueOnce(
        new NotFoundException('Файл не найден'),
      );
      await app.get(RealtyCalendarSyncService).apply(
        booking({
          rcId: THIRD_RC_ID,
          checkIn: '2026-12-20',
          checkOut: '2026-12-22',
          nights: 2,
        }),
      );

      const evening = new Date('2026-12-19T13:30:00Z'); // 18:30 по Ташкенту
      expect((await automations.runOnce(evening)).messagesSent).toBe(1);
      expect(sent.at(-1)).toEqual({
        chatId: DIGITS,
        text: `Дилноза, ждём вас 20 декабря в U-Tower ${RUN_ID}. Заезд с 15:00.`,
      });
    });

    it('sends only the full text when it outgrew the caption after filling it in', async () => {
      const review = templateIds[2];
      const thanks = 'Спасибо! '.repeat(112);
      await admin
        .patch(`/api/templates/${review}`)
        .set(CSRF)
        .send({
          title: `Отзыв 2 ${RUN_ID}`,
          body: `${thanks}{объект}`,
          automation: 'AFTER_CHECK_OUT',
        })
        .expect(200);
      await attach(admin, review, 'Отзыв.jpg', 'image/jpeg').expect(200);

      const before = sent.length;
      const afterCheckOut = new Date('2026-12-12T10:00:00Z'); // 15:00 по Ташкенту
      expect((await automations.runOnce(afterCheckOut)).messagesSent).toBe(1);
      expect(sent.slice(before)).toEqual([
        { chatId: DIGITS, text: `${thanks}U-Tower ${RUN_ID}` },
      ]);
      const run = await prisma.automationRun.findFirstOrThrow({
        where: { kind: 'AFTER_CHECK_OUT', booking: { rcId: SECOND_RC_ID } },
      });
      const linked = await prisma.message.findUniqueOrThrow({
        where: { id: run.messageId ?? '' },
      });
      expect(linked.text).toBe(`${thanks}U-Tower ${RUN_ID}`);
    });
  });
});
