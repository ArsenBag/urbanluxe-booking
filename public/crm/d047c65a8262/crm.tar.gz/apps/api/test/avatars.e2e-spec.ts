/**
 * Фото профиля клиентов: когда спрашиваем мессенджер, что сохраняем и что делаем при сбоях.
 * Мессенджеры — фейковые отправщики в ChannelRegistry.
 */
import type { INestApplication } from '@nestjs/common';
import { AvatarService } from '../src/inbox/avatar.service.js';
import { ChannelRegistry } from '../src/inbox/channel-registry.js';
import {
  AvatarSourceUnavailableError,
  type AvatarTarget,
} from '../src/inbox/messenger.types.js';
import type { ChannelType } from '../src/generated/prisma/client.js';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import {
  type Agent,
  createTestApp,
  createUser,
  CSRF,
  fakeJpeg,
  login,
} from './helpers.js';

const RUN_ID = Date.now();
const ADMIN = {
  email: `avatars-admin-${RUN_ID}@test.local`,
  password: 'avatars-admin-password',
};
const DAY_AND_HOUR_MS = 25 * 3_600_000;
const FUTURE_MS = 24 * 3_600_000;

type Answer = Buffer | null | Error;

describe('Contact avatars (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let avatars: AvatarService;
  let admin: Agent;
  const answers: Record<'TELEGRAM' | 'WHATSAPP', Answer> = {
    TELEGRAM: null,
    WHATSAPP: null,
  };
  const requests: Array<{ type: ChannelType; chat: string }> = [];
  const channelIds: Partial<Record<ChannelType, string>> = {};
  const contactIds: string[] = [];

  const fakeMessenger = (type: 'TELEGRAM' | 'WHATSAPP') => ({
    type,
    send: async () => {
      throw new Error('Отправка в этом тесте не используется');
    },
    findRecipient: async () => {
      throw new Error('Поиск собеседника в этом тесте не используется');
    },
    fetchAvatar: async (target: AvatarTarget) => {
      requests.push({ type, chat: target.externalChatId });
      const answer = answers[type];
      if (answer instanceof Error) throw answer;
      return (
        answer && {
          buffer: answer,
          mimeType: 'text/html',
          fileName: 'ignored.html',
        }
      );
    },
  });

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    avatars = app.get(AvatarService);
    const registry = app.get(ChannelRegistry);
    registry.register(fakeMessenger('TELEGRAM'));
    registry.register(fakeMessenger('WHATSAPP'));
    for (const type of ['TELEGRAM', 'WHATSAPP'] as const) {
      channelIds[type] = (
        await prisma.channel.create({
          data: {
            type,
            name: `${type} e2e`,
            status: 'CONNECTED',
            phone: `avatars-${type}-${RUN_ID}`,
          },
        })
      ).id;
    }
    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
  });

  afterAll(async () => {
    const contacts = await prisma.contact.findMany({
      where: { id: { in: contactIds } },
      select: { avatarFileId: true },
    });
    const fileIds = contacts.flatMap((contact) =>
      contact.avatarFileId ? [contact.avatarFileId] : [],
    );
    await prisma.channel.deleteMany({
      where: { id: { in: Object.values(channelIds) } },
    });
    await prisma.contact.deleteMany({ where: { id: { in: contactIds } } });
    await prisma.storedFile.deleteMany({ where: { id: { in: fileIds } } });
    await prisma.user.deleteMany({ where: { email: ADMIN.email } });
    await app.close();
  });

  async function guest(name: string) {
    const contact = await prisma.contact.create({ data: { name, phones: [] } });
    contactIds.push(contact.id);
    return contact;
  }

  /** Диалог «свежее всех»: дозагрузка начинает с него. */
  async function conversation(
    type: ChannelType,
    contactId: string,
    chat: string,
  ) {
    return prisma.conversation.create({
      data: {
        channelId: channelIds[type]!,
        contactId,
        externalChatId: `${chat}-${RUN_ID}`,
        lastMessageAt: new Date(Date.now() + FUTURE_MS),
      },
    });
  }

  const contactOf = (id: string) =>
    prisma.contact.findUniqueOrThrow({ where: { id } });
  const checkedAtOf = async (id: string) =>
    (await prisma.conversation.findUniqueOrThrow({ where: { id } }))
      .avatarCheckedAt;
  const dayPassed = (id: string) =>
    prisma.conversation.update({
      where: { id },
      data: { avatarCheckedAt: new Date(Date.now() - DAY_AND_HOUR_MS) },
    });
  const requestsTo = (type: ChannelType) =>
    requests.filter((request) => request.type === type).length;

  describe('one guest in Telegram and WhatsApp', () => {
    let contactId: string;
    let telegramChat: string;
    let whatsappChat: string;
    let firstFileId: string;

    beforeAll(async () => {
      contactId = (await guest('Гость с фото')).id;
      telegramChat = (await conversation('TELEGRAM', contactId, 'tg')).id;
      whatsappChat = (await conversation('WHATSAPP', contactId, 'wa')).id;
    });

    it('saves the photo by its real format and does not ask again within a day', async () => {
      answers.TELEGRAM = fakeJpeg('photo-1');

      expect(await avatars.refresh(telegramChat)).toBe('saved');
      expect(await avatars.refresh(telegramChat)).toBe('skipped');

      const contact = await contactOf(contactId);
      expect(contact.avatarSource).toBe('TELEGRAM');
      const file = await prisma.storedFile.findUniqueOrThrow({
        where: { id: contact.avatarFileId! },
      });
      expect(file).toMatchObject({
        mimeType: 'image/jpeg',
        fileName: 'avatar.jpg',
      });
      expect(requestsTo('TELEGRAM')).toBe(1);
      firstFileId = contact.avatarFileId!;
    });

    it('keeps the same photo without a new file', async () => {
      await dayPassed(telegramChat);
      expect(await avatars.refresh(telegramChat)).toBe('unchanged');
      expect((await contactOf(contactId)).avatarFileId).toBe(firstFileId);
    });

    it('replaces a changed photo and deletes the old file', async () => {
      await dayPassed(telegramChat);
      answers.TELEGRAM = fakeJpeg('photo-2');

      expect(await avatars.refresh(telegramChat)).toBe('saved');

      expect((await contactOf(contactId)).avatarFileId).not.toBe(firstFileId);
      expect(
        await prisma.storedFile.findUnique({ where: { id: firstFileId } }),
      ).toBeNull();
    });

    it('keeps the photo when the guest hides it', async () => {
      const { avatarFileId } = await contactOf(contactId);
      await dayPassed(telegramChat);
      answers.TELEGRAM = null;

      expect(await avatars.refresh(telegramChat)).toBe('unchanged');
      expect((await contactOf(contactId)).avatarFileId).toBe(avatarFileId);
    });

    it('asks the other messenger separately but does not let it overwrite the photo', async () => {
      const { avatarFileId } = await contactOf(contactId);
      answers.WHATSAPP = fakeJpeg('whatsapp-photo');

      expect(await avatars.refresh(whatsappChat)).toBe('unchanged');

      expect(requestsTo('WHATSAPP')).toBe(1);
      expect((await contactOf(contactId)).avatarFileId).toBe(avatarFileId);
    });

    it('deletes the photo together with the client', async () => {
      const { avatarFileId } = await contactOf(contactId);

      await admin.delete(`/api/contacts/${contactId}`).set(CSRF).expect(200);

      expect(
        await prisma.storedFile.findUnique({ where: { id: avatarFileId! } }),
      ).toBeNull();
    });
  });

  it('rejects data that is not an image, whatever the server says it is', async () => {
    const { id } = await guest('Гость с подделкой');
    const chat = await conversation('WHATSAPP', id, 'fake');
    answers.WHATSAPP = Buffer.from(
      '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>',
    );

    expect(await avatars.refresh(chat.id)).toBe('unchanged');
    expect((await contactOf(id)).avatarFileId).toBeNull();
  });

  it('asks again later when the messenger is not connected, and stops the backfill', async () => {
    const first = await conversation(
      'TELEGRAM',
      (await guest('Ждёт подключения 1')).id,
      'wait-1',
    );
    const second = await conversation(
      'TELEGRAM',
      (await guest('Ждёт подключения 2')).id,
      'wait-2',
    );
    answers.TELEGRAM = new AvatarSourceUnavailableError(
      'Telegram ещё не подключён',
    );
    const before = requestsTo('TELEGRAM');

    const result = await avatars.backfill(10);

    expect(result.saved).toBe(0);
    expect(requestsTo('TELEGRAM') - before).toBe(1);
    expect(await checkedAtOf(first.id)).toBeNull();
    expect(await checkedAtOf(second.id)).toBeNull();
  });

  it('counts other failures as checked for a day and stops the backfill', async () => {
    answers.TELEGRAM = Object.assign(new Error('FLOOD_WAIT_120'), {
      seconds: 120,
    });
    const before = requestsTo('TELEGRAM');

    await avatars.backfill(10);

    expect(requestsTo('TELEGRAM') - before).toBe(1);
    const waiting = await prisma.conversation.findMany({
      where: {
        channelId: channelIds.TELEGRAM,
        externalChatId: { startsWith: 'wait-' },
      },
      select: { avatarCheckedAt: true },
    });
    expect(
      waiting.filter((chat) => chat.avatarCheckedAt !== null),
    ).toHaveLength(1);
  });
});
