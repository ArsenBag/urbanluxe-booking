/**
 * Метки гостя: VIP и чёрный список. Отметка видна в карточке, диалоге и уведомлениях,
 * добавить может любой сотрудник, убрать — только администратор.
 */
import type { INestApplication } from '@nestjs/common';
import type {
  BlacklistEntryDto,
  BookingDto,
  ContactDto,
  ConversationDto,
  NotificationFeedDto,
} from '@crm/shared';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import {
  type Agent,
  createTestApp,
  createUser,
  CSRF,
  login,
  only,
} from './helpers.js';

const RUN_ID = Date.now();
const ADMIN = {
  email: `blacklist-admin-${RUN_ID}@test.local`,
  password: 'blacklist-admin-password',
};
const MANAGER = {
  email: `blacklist-manager-${RUN_ID}@test.local`,
  password: 'blacklist-manager-password',
};
const REASON = 'Испортил мебель, не оплатил ущерб';

describe('Guest marks: VIP and blacklist (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let manager: Agent;
  let managerId: string;
  let channelId: string;
  let contactId: string;
  let conversationId: string;
  let bookingId: string;

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    managerId = (
      await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER')
    ).id;
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));
    channelId = (
      await prisma.channel.create({
        data: {
          type: 'WHATSAPP',
          name: 'WhatsApp blacklist e2e',
          status: 'CONNECTED',
          phone: `blacklist-${RUN_ID}`,
        },
      })
    ).id;
    contactId = (
      await prisma.contact.create({
        data: { name: 'Гость ЧС e2e', phones: ['+998900000777'] },
      })
    ).id;
    conversationId = (
      await prisma.conversation.create({
        data: {
          channelId,
          contactId,
          externalChatId: `blacklist-${RUN_ID}`,
        },
      })
    ).id;
    bookingId = (
      await prisma.booking.create({
        data: {
          source: 'CRM',
          contactId,
          status: 'BOOKED',
          checkIn: new Date('2025-03-01T00:00:00Z'),
          checkOut: new Date('2025-03-04T00:00:00Z'),
          nights: 3,
          rcUpdatedAt: new Date(),
        },
      })
    ).id;
  });

  afterAll(async () => {
    await prisma.booking.deleteMany({ where: only({ id: bookingId }) });
    await prisma.channel.deleteMany({ where: only({ id: channelId }) });
    await prisma.activityLog.deleteMany({
      where: only({ entityId: contactId }),
    });
    await prisma.contact.deleteMany({ where: only({ id: contactId }) });
    await prisma.user.deleteMany({
      where: { email: { in: [ADMIN.email, MANAGER.email] } },
    });
    await app.close();
  });

  const conversation = async () =>
    (await manager.get(`/api/conversations/${conversationId}`).expect(200))
      .body.data as ConversationDto;

  const blacklist = async (agent: Agent) =>
    (await agent.get('/api/blacklist').expect(200)).body
      .data as BlacklistEntryDto[];

  it('lets a manager mark the guest as VIP, visible in the conversation', async () => {
    const response = await manager
      .patch(`/api/contacts/${contactId}`)
      .set(CSRF)
      .send({ vip: true })
      .expect(200);

    expect((response.body.data as ContactDto).vip).toBe(true);
    expect((await conversation()).contact.vip).toBe(true);
    const history = await manager
      .get(`/api/contacts/${contactId}/activity`)
      .expect(200);
    expect(
      (history.body.data as Array<{ payload: unknown }>).map(
        (entry) => entry.payload,
      ),
    ).toContainEqual({ fields: ['vip'], vip: true });
  });

  it('requires a reason to blacklist a guest', async () => {
    await manager
      .put(`/api/blacklist/${contactId}`)
      .set(CSRF)
      .send({ reason: '  ' })
      .expect(400);
  });

  it('answers 404 for an unknown guest', async () => {
    await manager
      .put('/api/blacklist/00000000-0000-4000-8000-000000000000')
      .set(CSRF)
      .send({ reason: REASON })
      .expect(404);
  });

  it('lets a manager blacklist the guest from the conversation', async () => {
    const response = await manager
      .put(`/api/blacklist/${contactId}`)
      .set(CSRF)
      .send({ reason: `  ${REASON} ` })
      .expect(200);

    const contact = response.body.data as ContactDto;
    expect(contact.blacklist).toMatchObject({
      reason: REASON,
      by: { id: managerId },
    });
    expect((await conversation()).contact.blacklist?.reason).toBe(REASON);
  });

  it('marks the guest bookings so the chessboard can show them in red', async () => {
    const bookings = (
      await manager.get(`/api/contacts/${contactId}/bookings`).expect(200)
    ).body.data as BookingDto[];

    expect(bookings.find((item) => item.id === bookingId)).toMatchObject({
      guestBlacklisted: true,
    });
  });

  it('shows the guest in the blacklist section with who added them', async () => {
    const entry = (await blacklist(manager)).find(
      (item) => item.contact.id === contactId,
    );

    expect(entry).toMatchObject({
      contact: { id: contactId, phones: ['+998900000777'] },
      blacklist: { reason: REASON, by: { id: managerId } },
    });
  });

  it('refuses to list the guest again: the reason and its author stay as they were', async () => {
    const before = (await conversation()).contact.blacklist;

    await admin
      .put(`/api/blacklist/${contactId}`)
      .set(CSRF)
      .send({ reason: 'Шумел ночью' })
      .expect(409);

    expect((await conversation()).contact.blacklist).toEqual(before);
  });

  it('ignores blacklist fields in a contact edit', async () => {
    await manager
      .patch(`/api/contacts/${contactId}`)
      .set(CSRF)
      .send({
        notes: 'Звонил насчёт депозита',
        blacklistedAt: null,
        blacklistReason: null,
        blacklistedById: null,
      })
      .expect(200);

    expect((await conversation()).contact.blacklist?.reason).toBe(REASON);
  });

  it('does not let a manager strip the phone the guest would be found by', async () => {
    await manager
      .patch(`/api/contacts/${contactId}`)
      .set(CSRF)
      .send({ phones: [] })
      .expect(403);

    await manager
      .patch(`/api/contacts/${contactId}`)
      .set(CSRF)
      .send({ phones: ['+998900000777', '+998900000778'] })
      .expect(200);
    await admin
      .patch(`/api/contacts/${contactId}`)
      .set(CSRF)
      .send({ phones: ['+998900000777'] })
      .expect(200);
  });

  it('records the blacklisting in the guest history', async () => {
    const history = await manager
      .get(`/api/contacts/${contactId}/activity`)
      .expect(200);

    const actions = (history.body.data as Array<{ action: string }>).map(
      (entry) => entry.action,
    );
    expect(actions).toContain('contact.blacklisted');
  });

  it('flags a new message from a blacklisted guest in the notification feed', async () => {
    const { cursor } = (await manager.get('/api/notifications').expect(200))
      .body.data as NotificationFeedDto;
    const message = await prisma.message.create({
      data: {
        conversationId,
        externalId: `blacklist-msg-${RUN_ID}`,
        direction: 'IN',
        status: 'RECEIVED',
        text: 'Здравствуйте, есть свободные квартиры?',
        sentAt: new Date(),
      },
    });

    const feed = (
      await manager
        .get('/api/notifications')
        .query({ after: cursor })
        .expect(200)
    ).body.data as NotificationFeedDto;

    expect(feed.events.find((event) => event.id === message.id)).toMatchObject(
      { kind: 'message', blacklisted: true },
    );
  });

  it('does not let anyone delete a blacklisted guest card', async () => {
    await admin.delete(`/api/contacts/${contactId}`).set(CSRF).expect(409);
  });

  it('only lets an admin take the guest off the blacklist', async () => {
    await manager.delete(`/api/blacklist/${contactId}`).set(CSRF).expect(403);

    const response = await admin
      .delete(`/api/blacklist/${contactId}`)
      .set(CSRF)
      .expect(200);

    expect((response.body.data as ContactDto).blacklist).toBeNull();
    expect((await conversation()).contact.blacklist).toBeNull();
    expect(
      (await blacklist(admin)).some((item) => item.contact.id === contactId),
    ).toBe(false);
    await admin.delete(`/api/blacklist/${contactId}`).set(CSRF).expect(409);
  });
});
