/**
 * Лента уведомлений: новые входящие в моих и неназначенных чатах и новые брони RealtyCalendar.
 */
import type { INestApplication } from '@nestjs/common';
import type { NotificationFeedDto } from '@crm/shared';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import request from 'supertest';
import {
  type Agent,
  createTestApp,
  createUser,
  login,
  only,
} from './helpers.js';

const RUN_ID = Date.now();
const ME = {
  email: `notify-me-${RUN_ID}@test.local`,
  password: 'notify-me-password',
};
const OTHER = {
  email: `notify-other-${RUN_ID}@test.local`,
  password: 'notify-other-password',
};
const RC_ID = 1_900_000_000 + Math.floor(Math.random() * 100_000_000);
const HOUR_MS = 3_600_000;

describe('Notification feed (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let me: Agent;
  let meId: string;
  let otherId: string;
  let channelId: string;
  let contactId: string;
  let listedContactId: string;
  const bookingIds: string[] = [];

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    meId = (await createUser(prisma, ME.email, ME.password, 'MANAGER')).id;
    otherId = (await createUser(prisma, OTHER.email, OTHER.password, 'MANAGER'))
      .id;
    ({ agent: me } = await login(app, ME.email, ME.password));
    channelId = (
      await prisma.channel.create({
        data: {
          type: 'WHATSAPP',
          name: 'WhatsApp e2e',
          status: 'CONNECTED',
          phone: `notify-${RUN_ID}`,
        },
      })
    ).id;
    contactId = (
      await prisma.contact.create({
        data: { name: 'Гость уведомлений', phones: [] },
      })
    ).id;
  });

  afterAll(async () => {
    await prisma.booking.deleteMany({ where: { id: { in: bookingIds } } });
    await prisma.channel.deleteMany({ where: only({ id: channelId }) });
    await prisma.contact.deleteMany({ where: only({ id: contactId }) });
    await prisma.contact.deleteMany({ where: only({ id: listedContactId }) });
    await prisma.user.deleteMany({
      where: { email: { in: [ME.email, OTHER.email] } },
    });
    await app.close();
  });

  const feed = async (after?: string) =>
    (
      await me
        .get('/api/notifications')
        .query(after ? { after } : {})
        .expect(200)
    ).body.data as NotificationFeedDto;

  const conversation = (chat: string, assigneeId: string | null) =>
    prisma.conversation.create({
      data: {
        channelId,
        contactId,
        externalChatId: `${chat}-${RUN_ID}`,
        assigneeId,
      },
    });

  const message = (
    conversationId: string,
    externalId: string,
    data: {
      direction?: 'IN' | 'OUT';
      text?: string | null;
      attachment?: object;
      sentAt?: Date;
      createdAt?: Date;
    } = {},
  ) =>
    prisma.message.create({
      data: {
        conversationId,
        externalId,
        direction: data.direction ?? 'IN',
        status: data.direction === 'OUT' ? 'SENT' : 'RECEIVED',
        text: data.text === undefined ? 'Здравствуйте' : data.text,
        attachment: data.attachment,
        sentAt: data.sentAt ?? new Date(),
        ...(data.createdAt && { createdAt: data.createdAt }),
      },
    });

  const booking = async (
    rcId: number | null,
    status: 'BOOKED' | 'CANCELED' = 'BOOKED',
    checkOut = new Date('2030-01-13T00:00:00Z'),
  ) => {
    const created = await prisma.booking.create({
      data: {
        rcId,
        status,
        checkIn: new Date('2030-01-10T00:00:00Z'),
        checkOut,
        nights: 3,
        guestName: 'Гость брони',
        origin: 'Booking.com',
        rcUpdatedAt: new Date(),
      },
    });
    bookingIds.push(created.id);
    return created;
  };

  it('starts with a cursor and no backlog', async () => {
    const first = await feed();
    expect(first.events).toEqual([]);
    expect(Number.isNaN(Date.parse(first.cursor))).toBe(false);
  });

  it('returns new incoming messages of my and unassigned chats and new RealtyCalendar bookings', async () => {
    const { cursor } = await feed();
    const unassigned = await conversation('unassigned', null);
    const mine = await conversation('mine', meId);
    const others = await conversation('others', otherId);

    const fromNewClient = await message(unassigned.id, 'm1');
    const missedCall = await message(unassigned.id, 'm2', {
      text: null,
      attachment: { kind: 'call', call: { outcome: 'missed' } },
    });
    const inMyChat = await message(mine.id, 'm3');
    await message(unassigned.id, 'm4', {
      text: null,
      attachment: { kind: 'call', call: { outcome: 'answered' } },
    });
    await message(mine.id, 'm5', {
      direction: 'OUT',
      text: 'Ответ с телефона',
    });
    await message(others.id, 'm6');
    await message(unassigned.id, 'm7', {
      sentAt: new Date(Date.now() - 30 * 24 * HOUR_MS),
    });
    const fromRealtyCalendar = await booking(RC_ID);
    await booking(null);
    await booking(RC_ID + 1, 'CANCELED');

    const { events } = await feed(cursor);

    expect(events.map((event) => event.id).sort()).toEqual(
      [
        fromNewClient.id,
        missedCall.id,
        inMyChat.id,
        fromRealtyCalendar.id,
      ].sort(),
    );
    expect(events.find((event) => event.id === missedCall.id)).toMatchObject({
      kind: 'message',
      conversationId: unassigned.id,
      contactName: 'Гость уведомлений',
      channelType: 'WHATSAPP',
      preview: '📞 Пропущенный звонок',
      blacklisted: false,
    });
    expect(
      events.find((event) => event.id === fromRealtyCalendar.id),
    ).toMatchObject({
      kind: 'booking',
      status: 'BOOKED',
      guestName: 'Гость брони',
      checkIn: '2030-01-10',
      checkOut: '2030-01-13',
      origin: 'Booking.com',
      blacklisted: false,
    });
  });

  it('flags a new booking by a blacklisted guest', async () => {
    const { cursor } = await feed();
    listedContactId = (
      await prisma.contact.create({
        data: {
          name: 'Гость из чёрного списка',
          phones: [],
          blacklistedAt: new Date(),
          blacklistReason: 'Тест',
        },
      })
    ).id;
    const created = await booking(RC_ID + 3);
    await prisma.booking.update({
      where: { id: created.id },
      data: { contactId: listedContactId },
    });

    const { events } = await feed(cursor);

    expect(events.find((event) => event.id === created.id)).toMatchObject({
      kind: 'booking',
      blacklisted: true,
    });
  });

  it('repeats events that landed just before the cursor, but not older ones', async () => {
    const { cursor } = await feed();
    const chat = await conversation('overlap', null);
    const cursorMs = Date.parse(cursor);
    const committedLate = await message(chat.id, 'o1', {
      createdAt: new Date(cursorMs - 30_000),
    });
    await message(chat.id, 'o2', {
      createdAt: new Date(cursorMs - 2 * 60_000),
    });
    const longGone = await booking(
      RC_ID + 2,
      'BOOKED',
      new Date('2020-01-05T00:00:00Z'),
    );

    const { events } = await feed(cursor);

    // В запас попадают и события прошлых тестов — смотрим только на свои.
    const own = events.filter((event) =>
      event.kind === 'message'
        ? event.conversationId === chat.id
        : event.id === longGone.id,
    );
    expect(own.map((event) => event.id)).toEqual([committedLate.id]);
  });

  it('does not reach further back than ten minutes even with an old cursor', async () => {
    const chat = await conversation('lookback', null);
    await message(chat.id, 'l1', {
      createdAt: new Date(Date.now() - 15 * 60_000),
    });
    const fresh = await message(chat.id, 'l2');

    const { events } = await feed(
      new Date(Date.now() - 60 * 60_000).toISOString(),
    );

    const own = events.filter(
      (event) => event.kind === 'message' && event.conversationId === chat.id,
    );
    expect(own.map((event) => event.id)).toEqual([fresh.id]);
  });

  it('requires a session', async () => {
    await request(app.getHttpServer()).get('/api/notifications').expect(401);
  });

  it('counts only unassigned chats that have unread messages in the inbox badge', async () => {
    const counters = async () =>
      (await me.get('/api/conversations/counters').expect(200)).body.data as {
        unassigned: number;
        mineUnread: number;
      };
    const before = await counters();

    await conversation('archive', null);
    const fresh = await conversation('fresh', null);
    await prisma.conversation.update({
      where: { id: fresh.id },
      data: { unreadCount: 2 },
    });

    expect((await counters()).unassigned - before.unassigned).toBe(1);
  });

  it('rejects a malformed cursor', async () => {
    await me.get('/api/notifications').query({ after: 'вчера' }).expect(400);
  });
});
