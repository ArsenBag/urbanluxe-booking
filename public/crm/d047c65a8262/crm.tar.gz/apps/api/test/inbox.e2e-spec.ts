/**
 * Сквозной сценарий этапа 2 на настоящей БД с фейковым Telegram:
 * подключение аккаунта, импорт истории, входящие, ответы, ошибки, отключение.
 */
import type { INestApplication } from '@nestjs/common';
import type { ChannelDto, ConversationDto, MessageDto } from '@crm/shared';
import request from 'supertest';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import { TelegramClientFactory } from '../src/telegram/telegram-client.factory.js';
import { TelegramRuntime } from '../src/telegram/telegram-runtime.service.js';
import { FakeTelegram, fakeUser, nowSeconds } from './fake-telegram.js';
import {
  type Agent,
  createTestApp,
  createUser,
  CSRF,
  deleteDealsWithHistory,
  login,
  only,
} from './helpers.js';

const RUN_ID = Date.now();
const ADMIN = {
  email: `inbox-admin-${RUN_ID}@test.local`,
  password: 'inbox-admin-password',
};
const MANAGER = {
  email: `inbox-manager-${RUN_ID}@test.local`,
  password: 'inbox-manager-password',
};
const PHONE = `+99893${String(RUN_ID).slice(-7)}`;
const DAY = 86_400;

// Уникальные id собеседников на прогон, чтобы тесты не мешали друг другу и данным разработки.
const historyGuest = fakeUser(`${RUN_ID}1`, 'Гость', {
  lastName: 'Из истории',
  username: `history_${RUN_ID}`,
});
const newGuest = fakeUser(`${RUN_ID}2`, 'Новый', {
  lastName: 'Клиент',
  phone: '998901112233',
});

async function waitFor(
  check: () => Promise<boolean>,
  timeoutMs = 5000,
): Promise<void> {
  const started = Date.now();
  while (!(await check())) {
    if (Date.now() - started > timeoutMs)
      throw new Error('Условие не выполнилось вовремя');
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
}

describe('Inbox + Telegram (e2e)', () => {
  const telegram = new FakeTelegram();
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let manager: Agent;
  let managerId: string;
  let channel: ChannelDto;
  /** Дополнительные собеседники, созданные в отдельных тестах, — для очистки. */
  const createdExtraPeers: string[] = [];
  /** Шаблоны, созданные тестами, — для очистки, если тест упал до удаления. */
  const createdTemplateIds: string[] = [];

  beforeAll(async () => {
    telegram.dialogs = [
      {
        entity: historyGuest,
        date: nowSeconds() - DAY,
        pinned: false,
        messages: [
          {
            className: 'Message',
            id: 1,
            out: false,
            message: 'Очень старое сообщение',
            date: nowSeconds() - 120 * DAY,
          },
          {
            className: 'Message',
            id: 2,
            out: false,
            message: 'Есть студия на выходные?',
            date: nowSeconds() - 2 * DAY,
          },
          {
            className: 'Message',
            id: 3,
            out: true,
            message: 'Да, в U-Tower',
            date: nowSeconds() - DAY,
          },
        ],
      },
    ];
    ({ app, prisma } = await createTestApp((builder) =>
      builder
        .overrideProvider(TelegramClientFactory)
        .useValue(telegram.factory),
    ));
    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    managerId = (
      await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER')
    ).id;
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));
  });

  afterAll(async () => {
    const links = await prisma.contactChannel.findMany({
      where: {
        externalId: {
          in: [
            historyGuest.id.toString(),
            newGuest.id.toString(),
            ...createdExtraPeers,
          ],
        },
      },
      select: { contactId: true },
    });
    const contactIds = links.map((link) => link.contactId);
    await prisma.channel.deleteMany({ where: { phone: PHONE } });
    await prisma.task.deleteMany({ where: { contactId: { in: contactIds } } });
    await deleteDealsWithHistory(prisma, contactIds);
    await prisma.contact.deleteMany({ where: { id: { in: contactIds } } });
    await prisma.replyTemplate.deleteMany({
      where: { id: { in: createdTemplateIds } },
    });
    await prisma.user.deleteMany({
      where: { email: { in: [ADMIN.email, MANAGER.email] } },
    });
    await app.close();
  });

  async function conversationOf(user: ReturnType<typeof fakeUser>) {
    return prisma.conversation.findFirst({
      where: { channelId: channel.id, externalChatId: user.id.toString() },
    });
  }

  describe('connecting the account', () => {
    it('is admin-only and reports that Telegram is configured', async () => {
      await manager.get('/api/channels').expect(403);
      const overview = await admin.get('/api/channels').expect(200);
      expect(overview.body.data.telegramConfigured).toBe(true);
    });

    it('sends a login code to the normalized phone', async () => {
      const response = await admin
        .post('/api/channels/telegram/login')
        .set(CSRF)
        .send({ phone: PHONE.replace('+998', '') })
        .expect(200);
      channel = response.body.data;

      expect(channel.status).toBe('AWAITING_CODE');
      expect(telegram.sentCodes).toContain(PHONE);
    });

    it('reports a wrong code on the code field', async () => {
      telegram.codeError = 'PHONE_CODE_INVALID';
      const response = await admin
        .post(`/api/channels/${channel.id}/login/code`)
        .set(CSRF)
        .send({ code: '11111' });
      telegram.codeError = null;

      expect(response.status).toBe(400);
      expect(response.body.error.fields.code).toContain('Неверный код');
    });

    it('asks for the cloud password when two-step verification is on', async () => {
      telegram.passwordNeeded = true;
      telegram.wrongPassword = 'wrong';
      const response = await admin
        .post(`/api/channels/${channel.id}/login/code`)
        .set(CSRF)
        .send({ code: '12345' })
        .expect(200);

      expect(response.body.data.status).toBe('AWAITING_PASSWORD');
    });

    it('rejects a wrong cloud password without looping', async () => {
      const response = await admin
        .post(`/api/channels/${channel.id}/login/password`)
        .set(CSRF)
        .send({ password: 'wrong' });

      expect(response.status).toBe(400);
      expect(response.body.error.message).toContain('Неверный облачный пароль');
    });

    it('connects, stores the session encrypted and imports 90 days of history without deals', async () => {
      const response = await admin
        .post(`/api/channels/${channel.id}/login/password`)
        .set(CSRF)
        .send({ password: 'right' })
        .expect(200);
      expect(response.body.data).toMatchObject({
        status: 'CONNECTED',
        username: 'high_life_uz',
      });

      const stored = await prisma.channel.findUniqueOrThrow({
        where: { id: channel.id },
      });
      expect(stored.sessionEncrypted).toMatch(/^v1\./);
      expect(stored.sessionEncrypted).not.toContain('fake-session-string');

      await waitFor(async () =>
        Boolean(
          (
            await prisma.channel.findUniqueOrThrow({
              where: { id: channel.id },
            })
          ).historyImportedAt,
        ),
      );
      const conversation = await conversationOf(historyGuest);
      const messages = await prisma.message.findMany({
        where: { conversationId: conversation!.id },
        orderBy: { sentAt: 'asc' },
      });
      expect(messages.map((m) => m.text)).toEqual([
        'Есть студия на выходные?',
        'Да, в U-Tower',
      ]);
      expect(messages.map((m) => m.direction)).toEqual(['IN', 'OUT']);
      expect(conversation!.unreadCount).toBe(0);
      expect(
        await prisma.deal.count({
          where: { contactId: conversation!.contactId },
        }),
      ).toBe(0);

      const contact = await prisma.contact.findUniqueOrThrow({
        where: { id: conversation!.contactId },
      });
      expect(contact).toMatchObject({
        name: 'Гость Из истории',
        source: 'TELEGRAM',
      });
    });
  });

  describe('live messages', () => {
    let conversation: ConversationDto;

    it('creates a contact, an unassigned conversation and a deal for a new client', async () => {
      await telegram.emit(newGuest, {
        id: 501,
        out: false,
        message: 'Здравствуйте! Свободно 20–23 октября?',
        date: nowSeconds(),
      });

      const stored = await conversationOf(newGuest);
      expect(stored).toMatchObject({
        unreadCount: 1,
        assigneeId: null,
        status: 'OPEN',
        externalAccessHash: `-${newGuest.id.toString()}`,
      });
      const contact = await prisma.contact.findUniqueOrThrow({
        where: { id: stored!.contactId },
      });
      expect(contact).toMatchObject({
        name: 'Новый Клиент',
        phones: ['+998901112233'],
      });
      const deal = await prisma.deal.findFirstOrThrow({
        where: { contactId: contact.id },
        include: { stage: true },
      });
      expect(deal.stage.name).toBe('Новое обращение');

      const list = await manager
        .get('/api/conversations')
        .query({ filter: 'unassigned' })
        .expect(200);
      conversation = (list.body.data.items as ConversationDto[]).find(
        (c) => c.id === stored!.id,
      )!;
      expect(conversation.lastMessagePreview).toContain(
        'Свободно 20–23 октября',
      );
    });

    it('ignores a repeated event', async () => {
      await telegram.emit(newGuest, {
        id: 501,
        out: false,
        message: 'Здравствуйте! Свободно 20–23 октября?',
        date: nowSeconds(),
      });

      expect(
        await prisma.message.count({
          where: { conversationId: conversation.id },
        }),
      ).toBe(1);
    });

    it('saves the Telegram profile photo of a new client', async () => {
      // Фото загружается в фоне после приёма сообщения.
      let avatarFileId: string | null = null;
      await waitFor(async () => {
        const contact = await prisma.contact.findUniqueOrThrow({
          where: { id: conversation.contact.id },
        });
        avatarFileId = contact.avatarFileId;
        return avatarFileId !== null;
      });
      const file = await manager.get(`/api/files/${avatarFileId}`).expect(200);
      expect(file.headers['content-type']).toBe('image/jpeg');
      expect(Buffer.from(file.body as Buffer)).toEqual(telegram.avatarContent);
    });

    it('sends a reply, assigns the conversation to the sender and clears unread', async () => {
      const response = await manager
        .post(`/api/conversations/${conversation.id}/messages`)
        .set(CSRF)
        .send({ text: 'Да, свободно! Студия в U-Tower — $85 за ночь.' })
        .expect(201);

      expect(response.body.data).toMatchObject({
        status: 'SENT',
        direction: 'OUT',
        sender: { id: managerId },
      });
      expect(telegram.sent.at(-1)?.text).toBe(
        'Да, свободно! Студия в U-Tower — $85 за ночь.',
      );
      const stored = await prisma.conversation.findUniqueOrThrow({
        where: { id: conversation.id },
      });
      expect(stored).toMatchObject({ assigneeId: managerId, unreadCount: 0 });
    });

    it('does not duplicate the echo of a message sent from the CRM', async () => {
      const last = await prisma.message.findFirstOrThrow({
        where: { conversationId: conversation.id, direction: 'OUT' },
      });
      await telegram.emit(newGuest, {
        id: Number(last.externalId),
        out: true,
        message: last.text!,
        date: nowSeconds(),
      });

      expect(
        await prisma.message.count({
          where: { conversationId: conversation.id },
        }),
      ).toBe(2);
    });

    it('stores messages written from the phone as outgoing', async () => {
      await telegram.emit(newGuest, {
        id: 777,
        out: true,
        message: 'Отправил геолокацию',
        date: nowSeconds(),
      });

      const messages = await manager
        .get(`/api/conversations/${conversation.id}/messages`)
        .expect(200);
      const last = (messages.body.data as MessageDto[]).at(-1)!;
      expect(last).toMatchObject({
        text: 'Отправил геолокацию',
        direction: 'OUT',
        status: 'SENT',
        sender: null,
      });
    });

    it('keeps a failed message with a readable error and resends it on retry', async () => {
      telegram.sendError = 'USER_IS_BLOCKED';
      const failed = await manager
        .post(`/api/conversations/${conversation.id}/messages`)
        .set(CSRF)
        .send({ text: 'Вы тут?' })
        .expect(201);
      expect(failed.body.data).toMatchObject({
        status: 'FAILED',
        error: 'Клиент заблокировал аккаунт компании в Telegram.',
      });

      telegram.sendError = null;
      const retried = await manager
        .post(`/api/messages/${failed.body.data.id}/retry`)
        .set(CSRF)
        .expect(200);
      expect(retried.body.data.status).toBe('SENT');
    });

    it('reopens a closed conversation when the client writes again', async () => {
      await manager
        .patch(`/api/conversations/${conversation.id}`)
        .set(CSRF)
        .send({ status: 'CLOSED' })
        .expect(200);
      await telegram.emit(newGuest, {
        id: 502,
        out: false,
        message: 'И ещё вопрос',
        date: nowSeconds(),
      });

      const stored = await prisma.conversation.findUniqueOrThrow({
        where: { id: conversation.id },
      });
      expect(stored).toMatchObject({ status: 'OPEN', unreadCount: 1 });
      // Повторное обращение существующего клиента не создаёт новую сделку.
      expect(
        await prisma.deal.count({ where: { contactId: stored.contactId } }),
      ).toBe(1);
    });

    it('keeps a reply SENT when an unmatched echo arrives before the send result', async () => {
      // Эхо с отличающимся текстом не сопоставится и создаст свою запись с тем же внешним id.
      telegram.echoBeforeReply = { user: newGuest, textSuffix: ' (изменено)' };
      const response = await manager
        .post(`/api/conversations/${conversation.id}/messages`)
        .set(CSRF)
        .send({ text: 'Ждём вас!' })
        .expect(201);
      telegram.echoBeforeReply = null;

      expect(response.body.data).toMatchObject({
        status: 'SENT',
        text: 'Ждём вас!',
      });
      const stored = await prisma.message.findUniqueOrThrow({
        where: { id: response.body.data.id },
      });
      const copies = await prisma.message.count({
        where: {
          conversationId: conversation.id,
          externalId: stored.externalId,
        },
      });
      expect(copies).toBe(1);
    });

    it('sends a failed message only once when retry is double-clicked', async () => {
      telegram.sendError = 'PEER_FLOOD';
      const failed = await manager
        .post(`/api/conversations/${conversation.id}/messages`)
        .set(CSRF)
        .send({ text: 'Дубль?' })
        .expect(201);
      telegram.sendError = null;
      const sentBefore = telegram.sent.length;

      const results = await Promise.all([
        manager.post(`/api/messages/${failed.body.data.id}/retry`).set(CSRF),
        manager.post(`/api/messages/${failed.body.data.id}/retry`).set(CSRF),
      ]);

      expect(results.map((r) => r.status).sort((a, b) => a - b)).toEqual([
        200, 400,
      ]);
      expect(telegram.sent.length - sentBefore).toBe(1);
    });

    it('handles the first two messages of a new client arriving at the same moment', async () => {
      const burstGuest = fakeUser(`${RUN_ID}3`, 'Быстрый', {
        lastName: 'Гость',
      });
      createdExtraPeers.push(burstGuest.id.toString());
      const date = nowSeconds();
      await Promise.all([
        telegram.emit(burstGuest, {
          id: 601,
          out: false,
          message: 'Здравствуйте',
          date,
        }),
        telegram.emit(burstGuest, {
          id: 602,
          out: false,
          message: 'Есть парковка?',
          date,
        }),
      ]);

      const links = await prisma.contactChannel.findMany({
        where: { externalId: burstGuest.id.toString() },
      });
      expect(links).toHaveLength(1);
      const stored = await conversationOf(burstGuest);
      expect(
        await prisma.message.count({ where: { conversationId: stored!.id } }),
      ).toBe(2);
    });

    it('pages through messages that share the same timestamp without skipping', async () => {
      const pagingGuest = fakeUser(`${RUN_ID}4`, 'Листающий');
      createdExtraPeers.push(pagingGuest.id.toString());
      const date = nowSeconds() - 60;
      for (let id = 700; id < 705; id++) {
        await telegram.emit(pagingGuest, {
          id,
          out: false,
          message: `Сообщение ${id}`,
          date,
        });
      }
      const stored = await conversationOf(pagingGuest);

      const first = await manager
        .get(`/api/conversations/${stored!.id}/messages`)
        .query({ limit: 2 })
        .expect(200);
      const oldest = (first.body.data as MessageDto[])[0];
      const rest = await manager
        .get(`/api/conversations/${stored!.id}/messages`)
        .query({ limit: 10, before: oldest.sentAt, beforeId: oldest.id })
        .expect(200);

      expect(first.body.data.length + rest.body.data.length).toBe(5);
    });

    it('stops auto-creating deals during a flood of new senders', async () => {
      const AUTO_DEAL_LIMIT = 30;
      const floodGuest = fakeUser(`${RUN_ID}5`, 'Спам');
      createdExtraPeers.push(floodGuest.id.toString());
      const fakeLogs = await prisma.activityLog.createManyAndReturn({
        data: Array.from({ length: AUTO_DEAL_LIMIT }, () => ({
          action: 'deal.created',
          entityType: 'deal',
          payload: { auto: true, test: RUN_ID },
        })),
        select: { id: true },
      });

      await telegram.emit(floodGuest, {
        id: 801,
        out: false,
        message: 'Купите рекламу',
        date: nowSeconds(),
      });
      await prisma.activityLog.deleteMany({
        where: { id: { in: fakeLogs.map((log) => log.id) } },
      });

      const stored = await conversationOf(floodGuest);
      expect(stored).not.toBeNull();
      expect(
        await prisma.deal.count({ where: { contactId: stored!.contactId } }),
      ).toBe(0);
    });

    it('saves the photo of an incoming message and serves it to staff', async () => {
      telegram.mediaContent = Buffer.from('jpeg-bytes-from-telegram');
      await telegram.emit(newGuest, {
        id: 601,
        out: false,
        message: '',
        date: nowSeconds(),
        media: { className: 'MessageMediaPhoto' },
      });

      const stored = await prisma.message.findFirstOrThrow({
        where: { conversationId: conversation.id, externalId: '601' },
      });
      const attachment = stored.attachment as {
        kind: string;
        fileId?: string;
        mimeType?: string;
      };
      expect(attachment).toMatchObject({
        kind: 'photo',
        mimeType: 'image/jpeg',
      });
      const file = await manager
        .get(`/api/files/${attachment.fileId}`)
        .expect(200);
      expect(file.headers['content-type']).toBe('image/jpeg');
      expect(Buffer.from(file.body as Buffer).toString()).toBe(
        'jpeg-bytes-from-telegram',
      );
    });

    it('loads a photo from Telegram on request when it did not download at first', async () => {
      telegram.mediaError = 'FILE_REFERENCE_EXPIRED';
      await telegram.emit(newGuest, {
        id: 602,
        out: false,
        message: '',
        date: nowSeconds(),
        media: { className: 'MessageMediaPhoto' },
      });
      const stored = await prisma.message.findFirstOrThrow({
        where: { conversationId: conversation.id, externalId: '602' },
      });
      expect((stored.attachment as { fileId?: string }).fileId).toBeUndefined();

      telegram.mediaContent = Buffer.from('jpeg-bytes-loaded-later');
      telegram.mediaError = null;
      const response = await manager
        .post(`/api/messages/${stored.id}/attachment`)
        .set(CSRF)
        .expect(200);

      const { fileId } = response.body.data.attachment as { fileId: string };
      const file = await manager.get(`/api/files/${fileId}`).expect(200);
      expect(Buffer.from(file.body as Buffer).toString()).toBe(
        'jpeg-bytes-loaded-later',
      );
    });

    it('does not save an empty file when Telegram no longer has the photo', async () => {
      // Так Telegram отдаёт удалённое фото «на один просмотр»: пустой ответ вместо ошибки.
      telegram.mediaContent = Buffer.alloc(0);
      await telegram.emit(newGuest, {
        id: 603,
        out: false,
        message: '',
        date: nowSeconds(),
        media: { className: 'MessageMediaPhoto' },
      });
      const stored = await prisma.message.findFirstOrThrow({
        where: { conversationId: conversation.id, externalId: '603' },
      });

      const response = await manager
        .post(`/api/messages/${stored.id}/attachment`)
        .set(CSRF)
        .expect(502);

      expect(response.body.error.message).toContain('Telegram');
      const after = await prisma.message.findUniqueOrThrow({
        where: { id: stored.id },
      });
      expect((after.attachment as { fileId?: string }).fileId).toBeUndefined();
      telegram.mediaContent = Buffer.from('fake-media');
    });

    it('sends a document as a Telegram file with a caption', async () => {
      const response = await manager
        .post(`/api/conversations/${conversation.id}/files`)
        .set(CSRF)
        .field('caption', 'Договор аренды')
        .attach('file', Buffer.from('%PDF-1.4 fake'), {
          filename: 'Договор.pdf',
          contentType: 'application/pdf',
        })
        .expect(201);

      expect(response.body.data).toMatchObject({
        status: 'SENT',
        text: 'Договор аренды',
        attachment: {
          kind: 'document',
          fileName: 'Договор.pdf',
          mimeType: 'application/pdf',
        },
      });
      expect(telegram.sentFiles.at(-1)).toMatchObject({
        name: 'Договор.pdf',
        caption: 'Договор аренды',
        forceDocument: true,
      });
    });

    it('marks a conversation as read', async () => {
      await manager
        .post(`/api/conversations/${conversation.id}/read`)
        .set(CSRF)
        .expect(200);

      const counters = await manager
        .get('/api/conversations/counters')
        .expect(200);
      expect(counters.body.data.mineUnread).toBe(0);
    });
  });

  describe('calls', () => {
    const caller = fakeUser(`${RUN_ID}6`, 'Звонивший');

    beforeAll(() => {
      createdExtraPeers.push(caller.id.toString());
    });

    const callbackTasks = (contactId: string) =>
      prisma.task.findMany({ where: { contactId, autoKind: 'callback' } });

    it('records a missed call from a new client with a deal and a call-back task', async () => {
      await telegram.emitCall(caller, {
        id: 901,
        out: false,
        date: nowSeconds(),
        reason: 'PhoneCallDiscardReasonMissed',
      });

      const stored = await conversationOf(caller);
      expect(stored).toMatchObject({
        unreadCount: 1,
        lastMessagePreview: '📞 Пропущенный звонок',
      });
      const message = await prisma.message.findFirstOrThrow({
        where: { conversationId: stored!.id, externalId: '901' },
      });
      expect(message).toMatchObject({
        direction: 'IN',
        text: null,
        attachment: { kind: 'call', call: { outcome: 'missed' } },
      });
      const deal = await prisma.deal.findFirstOrThrow({
        where: { contactId: stored!.contactId },
      });
      const tasks = await callbackTasks(stored!.contactId);
      expect(tasks).toHaveLength(1);
      expect(tasks[0]).toMatchObject({
        title: 'Перезвонить в Telegram: Звонивший',
        dealId: deal.id,
        isDone: false,
      });
      expect(tasks[0].dueAt!.getTime()).toBeGreaterThan(Date.now());
    });

    it('keeps one open call-back task for repeated missed calls', async () => {
      await telegram.emitCall(caller, {
        id: 902,
        out: false,
        date: nowSeconds(),
        reason: 'PhoneCallDiscardReasonBusy',
      });

      const stored = await conversationOf(caller);
      expect(stored?.unreadCount).toBe(2);
      expect(await callbackTasks(stored!.contactId)).toHaveLength(1);
    });

    it('records an answered outgoing call without a task or an unread mark', async () => {
      await telegram.emitCall(caller, {
        id: 903,
        out: true,
        date: nowSeconds(),
        duration: 65,
        reason: 'PhoneCallDiscardReasonHangup',
      });

      const stored = await conversationOf(caller);
      expect(stored).toMatchObject({
        unreadCount: 2,
        lastMessagePreview: '📞 Исходящий звонок · 1:05',
      });
      expect(await callbackTasks(stored!.contactId)).toHaveLength(1);
    });
  });

  describe('catching up missed messages', () => {
    const stranger = fakeUser(`${RUN_ID}7`, 'Незнакомец');

    beforeAll(() => {
      createdExtraPeers.push(stranger.id.toString());
    });

    it('fetches messages that arrived without the sender data', async () => {
      const first = {
        id: 1001,
        out: false,
        message: 'Здравствуйте, интересует бронь',
        date: nowSeconds() - 60,
      };
      const reply = {
        id: 1002,
        out: true,
        message: 'Добрый день!',
        date: nowSeconds() - 30,
      };
      telegram.dialogs.push({
        entity: stranger,
        date: reply.date,
        pinned: false,
        messages: [
          { className: 'Message', ...first },
          { className: 'Message', ...reply },
        ],
      });

      await telegram.emitUnresolved(first);
      expect(await conversationOf(stranger)).toBeNull();

      await app.get(TelegramRuntime).syncNow(channel.id);

      const stored = await conversationOf(stranger);
      expect(stored).not.toBeNull();
      const messages = await prisma.message.findMany({
        where: { conversationId: stored!.id },
        orderBy: { sentAt: 'asc' },
      });
      expect(messages.map((m) => [m.direction, m.externalId])).toEqual([
        ['IN', '1001'],
        ['OUT', '1002'],
      ]);
      expect(stored!.unreadCount).toBe(1);
      expect(
        await prisma.deal.count({ where: { contactId: stored!.contactId } }),
      ).toBe(1);
    });

    it('does not duplicate messages that were already received', async () => {
      await app.get(TelegramRuntime).syncNow(channel.id);

      const stored = await conversationOf(stranger);
      expect(
        await prisma.message.count({ where: { conversationId: stored!.id } }),
      ).toBe(2);
    });
  });

  describe('writing first from the client card', () => {
    const byPhone = fakeUser(`${RUN_ID}8`, 'Гость', { lastName: 'По номеру' });
    const byName = fakeUser(`${RUN_ID}9`, 'Гость', {
      username: `guest_${RUN_ID}`,
    });
    const phoneDigits = `99899${String(RUN_ID).slice(-7)}`;
    const hiddenDigits = `99898${String(RUN_ID).slice(-7)}`;
    let contactId: string;
    const start = (body: Record<string, unknown>) =>
      manager
        .post(`/api/contacts/${contactId}/conversations`)
        .set(CSRF)
        .send(body);

    beforeAll(async () => {
      createdExtraPeers.push(byPhone.id.toString(), byName.id.toString());
      telegram.phoneDirectory.set(phoneDigits, byPhone);
      telegram.addKnownUser(byName);
      contactId = (
        await manager
          .post('/api/contacts')
          .set(CSRF)
          .send({
            name: 'Гость из брони',
            phones: [`+${phoneDigits}`, `+${hiddenDigits}`],
          })
          .expect(201)
      ).body.data.id;
    });

    afterAll(async () => {
      await prisma.conversation.deleteMany({ where: only({ contactId }) });
      await prisma.contactChannel.deleteMany({ where: only({ contactId }) });
      await prisma.contact.deleteMany({ where: only({ id: contactId }) });
    });

    it('finds the guest by phone and sends the first message', async () => {
      const response = await start({
        channel: 'TELEGRAM',
        phone: `+${phoneDigits}`,
        text: 'Здравствуйте! Пишу по вашей брони',
      }).expect(201);

      expect(response.body.data.message.status).toBe('SENT');
      expect(telegram.sent.at(-1)?.text).toBe(
        'Здравствуйте! Пишу по вашей брони',
      );
      const conversation = await prisma.conversation.findUniqueOrThrow({
        where: { id: response.body.data.conversationId },
      });
      expect(conversation).toMatchObject({
        contactId,
        externalChatId: byPhone.id.toString(),
        externalAccessHash: byPhone.accessHash.toString(),
      });
    });

    it('finds the guest by @username', async () => {
      const response = await start({
        channel: 'TELEGRAM',
        username: `@guest_${RUN_ID}`,
        text: 'Добрый день!',
      }).expect(201);
      const conversation = await prisma.conversation.findUniqueOrThrow({
        where: { id: response.body.data.conversationId },
      });
      expect(conversation.externalChatId).toBe(byName.id.toString());
    });

    it('explains when Telegram does not find the number', async () => {
      const response = await start({
        channel: 'TELEGRAM',
        phone: `+${hiddenDigits}`,
        text: 'Тест',
      }).expect(400);
      expect(response.body.error.message).toContain(
        'Не нашли номер в Telegram',
      );
    });
  });

  describe('templates', () => {
    it('lists seeded templates for everyone and lets managers add, edit and delete them', async () => {
      const templates = await manager.get('/api/templates').expect(200);
      expect(
        templates.body.data.map((t: { title: string }) => t.title),
      ).toContain('Правила проживания');

      const shortcut = `parking${RUN_ID}`;
      const created = await manager
        .post('/api/templates')
        .set(CSRF)
        .send({ title: 'Парковка', body: 'Парковка во дворе', shortcut })
        .expect(201);
      createdTemplateIds.push(created.body.data.id);

      const edited = await manager
        .patch(`/api/templates/${created.body.data.id}`)
        .set(CSRF)
        .send({
          title: 'Парковка',
          body: 'Парковка во дворе, бесплатно',
          shortcut,
        })
        .expect(200);
      expect(edited.body.data).toMatchObject({
        body: 'Парковка во дворе, бесплатно',
        shortcut,
        automation: null,
      });

      await manager
        .delete(`/api/templates/${created.body.data.id}`)
        .set(CSRF)
        .expect(200);
      expect(
        await prisma.replyTemplate.count({
          where: { id: created.body.data.id },
        }),
      ).toBe(0);

      // Общий текст правят все — журнал хранит, кто и что поменял, и удалённый текст целиком.
      const logs = await prisma.activityLog.findMany({
        where: { entityType: 'template', entityId: created.body.data.id },
        orderBy: { createdAt: 'asc' },
      });
      expect(logs.map((log) => [log.action, log.actorId])).toEqual([
        ['template.created', managerId],
        ['template.updated', managerId],
        ['template.deleted', managerId],
      ]);
      expect(logs[1]?.payload).toMatchObject({
        before: { body: 'Парковка во дворе' },
        after: { body: 'Парковка во дворе, бесплатно' },
      });
      expect(logs[2]?.payload).toMatchObject({
        title: 'Парковка',
        body: 'Парковка во дворе, бесплатно',
        shortcut,
      });
    });

    it('does not let anyone change templates without signing in', async () => {
      const server = request(app.getHttpServer());
      const someId = '00000000-0000-4000-8000-000000000000';
      await server
        .post('/api/templates')
        .set(CSRF)
        .send({ title: 'Нельзя', body: 'Нельзя' })
        .expect(401);
      await server
        .patch(`/api/templates/${someId}`)
        .set(CSRF)
        .send({ title: 'Нельзя', body: 'Нельзя' })
        .expect(401);
      await server.delete(`/api/templates/${someId}`).set(CSRF).expect(401);
    });

    it('leaves automatic sending and automatic templates to admins', async () => {
      const refused = await manager
        .post('/api/templates')
        .set(CSRF)
        .send({
          title: 'Отзыв',
          body: 'Спасибо!',
          automation: 'AFTER_CHECK_OUT',
        })
        .expect(403);
      expect(refused.body.error.message).toBe(
        'Автоотправку настраивает администратор',
      );

      const manual = await manager
        .post('/api/templates')
        .set(CSRF)
        .send({ title: `Ручной ${RUN_ID}`, body: 'Текст' })
        .expect(201);
      createdTemplateIds.push(manual.body.data.id);
      await manager
        .patch(`/api/templates/${manual.body.data.id}`)
        .set(CSRF)
        .send({ title: 'Ручной', body: 'Текст', automation: 'AFTER_CHECK_OUT' })
        .expect(403);

      // Вид автоотправки один на все шаблоны: забираем его у локального шаблона и возвращаем в конце.
      const holder = await prisma.replyTemplate.findUnique({
        where: { automation: 'AFTER_CHECK_OUT' },
        select: { id: true },
      });
      const automated = await admin
        .post('/api/templates')
        .set(CSRF)
        .send({
          title: `Отзыв ${RUN_ID}`,
          body: 'Спасибо!',
          automation: 'AFTER_CHECK_OUT',
        })
        .expect(201);
      createdTemplateIds.push(automated.body.data.id);
      try {
        const edit = await manager
          .patch(`/api/templates/${automated.body.data.id}`)
          .set(CSRF)
          .send({
            title: 'Отзыв',
            body: 'Другой текст',
            automation: 'AFTER_CHECK_OUT',
          })
          .expect(403);
        expect(edit.body.error.message).toBe(
          'Шаблон с автоотправкой меняет администратор',
        );
        // Без поля automation схема подставит null — это выключило бы автоотправку.
        await manager
          .patch(`/api/templates/${automated.body.data.id}`)
          .set(CSRF)
          .send({ title: 'Отзыв', body: 'Другой текст' })
          .expect(403);
        await manager
          .delete(`/api/templates/${automated.body.data.id}`)
          .set(CSRF)
          .expect(403);
        const kept = await prisma.replyTemplate.findUniqueOrThrow({
          where: { id: automated.body.data.id },
        });
        expect(kept).toMatchObject({
          body: 'Спасибо!',
          automation: 'AFTER_CHECK_OUT',
        });
      } finally {
        await prisma.replyTemplate.deleteMany({
          where: { id: { in: [automated.body.data.id] } },
        });
        if (holder) {
          await prisma.replyTemplate.update({
            where: { id: holder.id },
            data: { automation: 'AFTER_CHECK_OUT' },
          });
        }
      }
    });

    it('saves a slash command and rejects a command another template already uses', async () => {
      const shortcut = `wifi${RUN_ID}`;
      const created = await admin
        .post('/api/templates')
        .set(CSRF)
        .send({
          title: 'Wi-Fi',
          body: 'Сеть HighLife, пароль 12345678',
          shortcut: ` /WIFI${RUN_ID} `,
        })
        .expect(201);
      createdTemplateIds.push(created.body.data.id);
      expect(created.body.data.shortcut).toBe(shortcut);

      const duplicate = await admin
        .post('/api/templates')
        .set(CSRF)
        .send({ title: 'Wi-Fi 2', body: 'Другой', shortcut })
        .expect(409);
      expect(duplicate.body.error).toEqual({
        message: `Команда /${shortcut} уже есть у другого шаблона`,
        fields: { shortcut: 'Команда уже занята' },
      });

      const cleared = await admin
        .patch(`/api/templates/${created.body.data.id}`)
        .set(CSRF)
        .send({ title: 'Wi-Fi', body: 'Сеть HighLife', shortcut: '' })
        .expect(200);
      expect(cleared.body.data.shortcut).toBeNull();
      await admin
        .delete(`/api/templates/${created.body.data.id}`)
        .set(CSRF)
        .expect(200);
    });
  });

  describe('disconnecting', () => {
    it('logs out, drops the session and makes sending fail clearly', async () => {
      const response = await admin
        .post(`/api/channels/${channel.id}/disconnect`)
        .set(CSRF)
        .expect(200);
      expect(response.body.data.status).toBe('DISCONNECTED');
      expect(
        (await prisma.channel.findUniqueOrThrow({ where: { id: channel.id } }))
          .sessionEncrypted,
      ).toBeNull();

      const conversation = await conversationOf(newGuest);
      const failed = await manager
        .post(`/api/conversations/${conversation!.id}/messages`)
        .set(CSRF)
        .send({ text: 'Тест' })
        .expect(201);
      expect(failed.body.data).toMatchObject({ status: 'FAILED' });
      expect(failed.body.data.error).toContain('Канал не подключён');
    });
  });
});
