/**
 * Отчёты: обращения, воронка, брони и загрузка, команда. Данные — в 2003 году, где других записей нет (и это прошлое: «без ответа» не считает будущие ожидания),
 * поэтому итоги за период точные; общие для базы величины (число квартир) не проверяем.
 */
import type { INestApplication } from '@nestjs/common';
import type {
  BookingsReportDto,
  FunnelReportDto,
  InquiriesReportDto,
  TeamReportDto,
} from '@crm/shared';
import request from 'supertest';
import { CANCEL_REASON } from '../src/realtycalendar/deal-stage-keys.js';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import {
  type Agent,
  createTestApp,
  createUser,
  login,
  only,
} from './helpers.js';

const RUN_ID = Date.now();
const ADMIN = {
  email: `reports-admin-${RUN_ID}@test.local`,
  password: 'reports-admin-password',
};
const AGENT = {
  email: `reports-agent-${RUN_ID}@test.local`,
  password: 'reports-agent-password',
};
const MANAGER = {
  email: `reports-manager-${RUN_ID}@test.local`,
  password: 'reports-manager-password',
};
const PERIOD = { from: '2003-03-01', to: '2003-03-07' };
const RC_BASE = 1_700_000_000 + Math.floor(Math.random() * 100_000_000);
const ORIGIN = `E2E-origin-${RUN_ID}`;

/** Время по Ташкенту (UTC+5). */
const at = (date: string, time: string) => new Date(`${date}T${time}:00+05:00`);
const day = (date: string) => new Date(`${date}T00:00:00.000Z`);

describe('Reports (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let manager: Agent;
  let adminId: string;
  let agentId: string;
  let contactId: string;
  let pipelineId: string;
  const channelIds: string[] = [];
  const propertyIds: string[] = [];
  const bookingIds: string[] = [];

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    adminId = (await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN'))
      .id;
    agentId = (await createUser(prisma, AGENT.email, AGENT.password, 'MANAGER'))
      .id;
    await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER');
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));
    contactId = (
      await prisma.contact.create({
        data: { name: 'Гость отчётов', phones: [] },
      })
    ).id;
    await seedConversations();
    await seedDeals();
    await seedBookings();
    await seedTasks();
  });

  afterAll(async () => {
    await prisma.task.deleteMany({ where: only({ assigneeId: agentId }) });
    await prisma.channel.deleteMany({ where: { id: { in: channelIds } } });
    await prisma.booking.deleteMany({ where: { id: { in: bookingIds } } });
    await prisma.property.deleteMany({ where: { id: { in: propertyIds } } });
    await prisma.deal.deleteMany({ where: only({ pipelineId }) });
    await prisma.pipeline.deleteMany({ where: only({ id: pipelineId }) });
    await prisma.contact.deleteMany({ where: only({ id: contactId }) });
    await prisma.user.deleteMany({
      where: { email: { in: [ADMIN.email, AGENT.email, MANAGER.email] } },
    });
    await app.close();
  });

  async function conversation(type: 'TELEGRAM' | 'WHATSAPP', chat: string) {
    const channel = await prisma.channel.create({
      data: {
        type,
        name: `Отчёты ${chat}`,
        status: 'CONNECTED',
        phone: `reports-${chat}-${RUN_ID}`,
      },
    });
    channelIds.push(channel.id);
    return (
      await prisma.conversation.create({
        data: { channelId: channel.id, contactId, externalChatId: chat },
      })
    ).id;
  }

  type Line = {
    dir: 'IN' | 'OUT';
    sentAt: Date;
    senderId?: string;
    attachment?: object;
  };
  async function messages(conversationId: string, lines: Line[]) {
    const created = [];
    for (const line of lines) {
      created.push(
        await prisma.message.create({
          data: {
            conversationId,
            direction: line.dir,
            status: line.dir === 'IN' ? 'RECEIVED' : 'SENT',
            text: line.attachment ? null : 'текст',
            attachment: line.attachment,
            senderId: line.senderId ?? null,
            sentAt: line.sentAt,
          },
        }),
      );
    }
    return created;
  }

  let automatedMessageId: string;

  async function seedConversations() {
    // Гость написал первым: два ожидания, ответы через 10 и 60 минут, вечером — автосообщение.
    const whatsapp = await conversation('WHATSAPP', 'a');
    const lines = await messages(whatsapp, [
      { dir: 'IN', sentAt: at('2003-03-01', '10:00') },
      { dir: 'OUT', sentAt: at('2003-03-01', '10:10'), senderId: agentId },
      { dir: 'IN', sentAt: at('2003-03-01', '12:00') },
      { dir: 'IN', sentAt: at('2003-03-01', '12:05') },
      { dir: 'OUT', sentAt: at('2003-03-01', '13:00'), senderId: agentId },
      { dir: 'OUT', sentAt: at('2003-03-01', '18:00') },
    ]);
    automatedMessageId = lines[5]!.id;
    // Мы написали первыми с телефона; гость ответил, ему ответили через 2 часа; пропущенный звонок не ожидание.
    const telegram = await conversation('TELEGRAM', 'b');
    await messages(telegram, [
      { dir: 'OUT', sentAt: at('2003-03-02', '09:00') },
      { dir: 'IN', sentAt: at('2003-03-02', '09:30') },
      {
        dir: 'IN',
        sentAt: at('2003-03-02', '10:00'),
        attachment: { kind: 'call', call: { outcome: 'missed' } },
      },
      { dir: 'OUT', sentAt: at('2003-03-02', '11:30') },
    ]);
    // Поздно вечером по Ташкенту (в UTC — ещё тот же день), без ответа.
    await messages(await conversation('TELEGRAM', 'c'), [
      { dir: 'IN', sentAt: at('2003-03-03', '23:00') },
    ]);
    // Диалог начался до периода: в новые не входит, ожидание до периода не считается.
    await messages(await conversation('WHATSAPP', 'd'), [
      { dir: 'IN', sentAt: at('2003-02-28', '23:30') },
      { dir: 'OUT', sentAt: at('2003-03-01', '00:05'), senderId: adminId },
    ]);
  }

  async function seedDeals() {
    const pipeline = await prisma.pipeline.create({
      data: {
        name: `Отчёт e2e ${RUN_ID}`,
        position: 1000,
        stages: {
          create: [
            { name: 'Новые', position: 0, kind: 'OPEN' },
            { name: 'Бронь', position: 1, kind: 'OPEN', systemKey: 'BOOKED' },
            { name: 'Успешно', position: 2, kind: 'WON' },
            { name: 'Отказ', position: 3, kind: 'LOST' },
          ],
        },
      },
      include: { stages: { orderBy: { position: 'asc' } } },
    });
    pipelineId = pipeline.id;
    const [fresh, booked, won, lost] = pipeline.stages.map((stage) => stage.id);
    const deal = (
      stageId: string,
      ownerId: string | null,
      createdAt: Date,
      lostReason: string | null = null,
    ) => ({
      title: 'Сделка отчёта',
      pipelineId,
      stageId,
      contactId,
      ownerId,
      position: 1,
      createdAt,
      lostReason,
    });
    await prisma.deal.createMany({
      data: [
        deal(fresh!, agentId, at('2003-03-01', '09:00')),
        deal(booked!, agentId, at('2003-03-02', '09:00')),
        deal(won!, adminId, at('2003-03-03', '09:00')),
        deal(lost!, agentId, at('2003-03-04', '09:00'), 'Дорого'),
        deal(lost!, null, at('2003-03-05', '09:00'), ' дорого '),
        deal(lost!, null, at('2003-03-07', '23:59')),
        deal(lost!, agentId, at('2003-03-06', '09:00'), CANCEL_REASON),
        deal(fresh!, agentId, at('2003-02-28', '23:59')),
      ],
    });
  }

  async function seedBookings() {
    const property = (offset: number) =>
      prisma.property.create({
        data: {
          rcId: RC_BASE + offset,
          title: `E2E-${offset}`,
          address: 'Массив Бешагач 1/1',
        },
      });
    const first = await property(1);
    const second = await property(2);
    propertyIds.push(first.id, second.id);
    const booking = (
      offset: number,
      propertyId: string,
      status: 'BOOKED' | 'CANCELED' | 'REQUEST',
      checkIn: string,
      checkOut: string,
      nights: number,
      amount: number,
    ) =>
      prisma.booking.create({
        data: {
          rcId: RC_BASE + offset,
          propertyId,
          status,
          checkIn: day(checkIn),
          checkOut: day(checkOut),
          nights,
          amount,
          origin: ORIGIN,
          rcUpdatedAt: new Date(),
        },
      });
    const created = await Promise.all([
      booking(11, first.id, 'BOOKED', '2003-03-01', '2003-03-04', 3, 300),
      booking(12, second.id, 'BOOKED', '2003-03-06', '2003-03-10', 4, 400),
      booking(13, first.id, 'CANCELED', '2003-03-05', '2003-03-06', 1, 100),
      booking(14, second.id, 'REQUEST', '2003-03-02', '2003-03-04', 2, 200),
    ]);
    bookingIds.push(...created.map((row) => row.id));
    await prisma.automationRun.create({
      data: {
        kind: 'BEFORE_CHECK_IN',
        bookingId: created[0]!.id,
        messageId: automatedMessageId,
      },
    });
  }

  async function seedTasks() {
    await prisma.task.createMany({
      data: [
        {
          title: 'Сделано',
          assigneeId: agentId,
          isDone: true,
          doneAt: at('2003-03-02', '12:00'),
        },
        {
          title: 'Просрочено',
          assigneeId: agentId,
          dueAt: new Date('2020-01-01T00:00:00Z'),
        },
      ],
    });
  }

  const report = async <T>(
    path: string,
    query: Record<string, string> = PERIOD,
  ) =>
    (await admin.get(`/api/reports/${path}`).query(query).expect(200)).body
      .data as T;

  it.each(['inquiries', 'funnel', 'bookings', 'team'])(
    '%s is for admins only',
    async (path) => {
      await manager.get(`/api/reports/${path}`).query(PERIOD).expect(403);
      await request(app.getHttpServer())
        .get(`/api/reports/${path}`)
        .query(PERIOD)
        .expect(401);
    },
  );

  it('validates the period', async () => {
    await admin
      .get('/api/reports/team')
      .query({ from: '2003-03-07', to: '2003-03-01' })
      .expect(400);
    await admin
      .get('/api/reports/inquiries')
      .query({ from: '2001-01-01', to: '2003-01-01' })
      .expect(400);
    await admin
      .get('/api/reports/bookings')
      .query({ from: '0001-01-01', to: '0001-01-31' })
      .expect(400);
    await admin
      .get('/api/reports/funnel')
      .query({ ...PERIOD, pipelineId: '1b4e28ba-2fa1-41d2-883f-0016d3cca427' })
      .expect(404);
  });

  it('counts new conversations and messages', async () => {
    const data = await report<InquiriesReportDto>('inquiries');
    expect(data.newConversations).toEqual({
      fromGuests: { TELEGRAM: 1, WHATSAPP: 1, INSTAGRAM: 0 },
      fromUs: { TELEGRAM: 1, WHATSAPP: 0, INSTAGRAM: 0 },
    });
    expect(data.byDay).toHaveLength(7);
    expect(data.byDay[0]).toEqual({
      date: '2003-03-01',
      counts: { TELEGRAM: 0, WHATSAPP: 1, INSTAGRAM: 0 },
    });
    expect(data.byDay[2]).toEqual({
      date: '2003-03-03',
      counts: { TELEGRAM: 1, WHATSAPP: 0, INSTAGRAM: 0 },
    });
    expect(data.messages).toEqual({
      incoming: 5,
      fromCrm: 3,
      fromPhone: 2,
      automated: 1,
    });
    expect(data.missedCalls).toBe(1);
  });

  it('shows deals created in the period by stage and owner', async () => {
    const data = await report<FunnelReportDto>('funnel', {
      ...PERIOD,
      pipelineId,
    });
    expect(data.pipeline).toEqual({
      id: pipelineId,
      name: `Отчёт e2e ${RUN_ID}`,
    });
    expect(data.pipelines.some((row) => row.id === pipelineId)).toBe(true);
    expect(data.totals).toEqual({
      deals: 7,
      booked: 3,
      cancelled: 1,
      lost: 3,
      open: 1,
    });
    expect(data.stages.map((stage) => [stage.name, stage.deals])).toEqual([
      ['Новые', 1],
      ['Бронь', 1],
      ['Успешно', 1],
      ['Отказ', 4],
    ]);
    expect(data.lostReasons).toEqual([
      { reason: 'Дорого', deals: 2 },
      { reason: 'Без причины', deals: 1 },
    ]);
    expect(data.owners).toEqual([
      {
        owner: { id: agentId, name: 'E2E MANAGER' },
        deals: 4,
        booked: 2,
        cancelled: 1,
        lost: 1,
      },
      { owner: null, deals: 2, booked: 0, cancelled: 0, lost: 2 },
      {
        owner: { id: adminId, name: 'E2E ADMIN' },
        deals: 1,
        booked: 1,
        cancelled: 0,
        lost: 0,
      },
    ]);
  });

  it('sums nights, revenue and sources of confirmed bookings', async () => {
    const data = await report<BookingsReportDto>('bookings');
    expect(data.days).toBe(7);
    expect(data.totals).toMatchObject({
      nights: 5,
      revenue: 500,
      arrivals: 2,
      averageNightPrice: 100,
      cancellations: 1,
    });
    expect(data.byDay[0]).toEqual({ date: '2003-03-01', occupied: 1 });
    expect(data.byDay[6]).toEqual({ date: '2003-03-07', occupied: 1 });
    expect(
      data.byApartment.find((row) => row.id === propertyIds[0]),
    ).toMatchObject({ nights: 3, revenue: 300, complex: 'U-Tower' });
    expect(
      data.byApartment.find((row) => row.id === propertyIds[1]),
    ).toMatchObject({ nights: 2, revenue: 200 });
    expect(data.byOrigin).toEqual([
      { origin: ORIGIN, bookings: 2, nights: 5, revenue: 500 },
    ]);
  });

  it('measures first-response time per employee and from the phone', async () => {
    const data = await report<TeamReportDto>('team');
    expect(data.overall).toEqual({
      answered: 3,
      medianMinutes: 60,
      within15Minutes: 1,
      withinHour: 2,
    });
    // Позднее сообщение в диалоге «c» осталось без ответа.
    expect(data.unanswered).toBe(1);
    expect(data.phone).toEqual({
      messagesSent: 2,
      response: {
        answered: 1,
        medianMinutes: 120,
        within15Minutes: 0,
        withinHour: 0,
      },
    });
    expect(data.members.find((row) => row.user.id === agentId)).toEqual({
      user: { id: agentId, name: 'E2E MANAGER' },
      isActive: true,
      messagesSent: 2,
      response: {
        answered: 2,
        medianMinutes: 35,
        within15Minutes: 1,
        withinHour: 2,
      },
      tasksDone: 1,
      tasksOverdue: 1,
    });
    expect(data.members.find((row) => row.user.id === adminId)).toMatchObject({
      messagesSent: 1,
      response: {
        answered: 0,
        medianMinutes: null,
        within15Minutes: 0,
        withinHour: 0,
      },
    });
  });
});
