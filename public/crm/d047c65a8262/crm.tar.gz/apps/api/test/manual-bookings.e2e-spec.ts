/**
 * Брони, внесённые сотрудником на шахматке: клиент, сделка и задачи как у броней RealtyCalendar,
 * проверка занятых дат, правка и отмена, привязка вебхуком, когда ту же бронь внесли в RealtyCalendar.
 */
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import type { BookingDto } from '@crm/shared';
import request from 'supertest';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import {
  type Agent,
  createTestApp,
  createUser,
  CSRF,
  deleteDealsWithHistory,
  login,
  only,
} from './helpers.js';

const SECRET = 'e2e-manual-rc-secret-0123456789ab';
process.env.RC_WEBHOOK_SECRET = SECRET;

const RUN_ID = Date.now();
const MANAGER = {
  email: `manual-booking-${RUN_ID}@test.local`,
  password: 'manual-booking-password',
};
// id квартиры и броней в RealtyCalendar — int4; уникальные на прогон.
const baseId = 1_000_000_000 + Math.floor(Math.random() * 900_000_000);
const APARTMENT_RC_ID = baseId;
const GUEST_PHONE = `+99891${String(RUN_ID).slice(-7)}`;
const template = JSON.parse(
  readFileSync(
    resolve(import.meta.dirname, 'fixtures/rc-create-booking.json'),
    'utf8',
  ),
);

/** Вебхук RealtyCalendar по брони на тестовую квартиру; гость без имени и телефона, как часто бывает. */
function webhook(
  rcId: number,
  checkIn: string,
  checkOut: string,
  origin: string | null = null,
) {
  const body = structuredClone(template);
  Object.assign(body.data.booking, {
    id: rcId,
    realty_id: APARTMENT_RC_ID,
    begin_date: checkIn,
    end_date: checkOut,
    number_of_nights: null,
    updated_at: '2026-10-12T10:00:00+05:00',
    amount: 300,
    url: `https://realtycalendar.ru/event_calendars/${rcId}`,
  });
  body.data.booking.apartment = {
    id: APARTMENT_RC_ID,
    title: `U-E2E ${RUN_ID}`,
  };
  body.data.booking.client = {
    fio: null,
    phone: null,
    email: null,
    additional_phone: null,
  };
  body.data.booking.booking_origin = { id: null, title: origin };
  return body;
}

describe('Bookings entered on the chessboard (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let manager: Agent;
  let apartmentId: string;
  let complexId: string;
  let bookingId: string;
  const contactIds: string[] = [];

  const create = (body: Record<string, unknown>) =>
    manager.post('/api/bookings').set(CSRF).send(body);

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER');
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));
    apartmentId = (
      await prisma.property.create({
        data: { rcId: APARTMENT_RC_ID, title: `U-E2E ${RUN_ID}` },
      })
    ).id;
    // Строка ЖК из старой выгрузки: квартира не определена, вносить бронь на неё нельзя.
    complexId = (
      await prisma.property.create({ data: { title: `ЖК E2E ${RUN_ID}` } })
    ).id;
  });

  afterAll(async () => {
    const properties = { propertyId: { in: [apartmentId, complexId] } };
    const bookings = await prisma.booking.findMany({
      where: only(properties),
      select: { contactId: true },
    });
    const ids = [
      ...new Set([
        ...contactIds,
        ...bookings.flatMap((b) => (b.contactId ? [b.contactId] : [])),
      ]),
    ];
    await prisma.task.deleteMany({ where: { contactId: { in: ids } } });
    await prisma.booking.deleteMany({ where: only(properties) });
    await prisma.property.deleteMany({
      where: only({ id: { in: [apartmentId, complexId] } }),
    });
    await deleteDealsWithHistory(prisma, ids);
    await prisma.contact.deleteMany({ where: { id: { in: ids } } });
    await prisma.user.deleteMany({ where: { email: MANAGER.email } });
    await app.close();
  });

  it('creates a booking with a new client, a deal at «Бронь создана» and check-in/out tasks', async () => {
    const response = await create({
      propertyId: apartmentId,
      checkIn: '2027-03-10',
      checkOut: '2027-03-12',
      guestName: 'Гость E2E',
      guestPhone: GUEST_PHONE,
      amount: 120,
      arrivalTime: '14:00',
    }).expect(201);
    const booking = response.body.data as BookingDto;
    bookingId = booking.id;
    contactIds.push(booking.contact?.id ?? '');

    expect(booking).toMatchObject({
      source: 'CRM',
      rcId: null,
      status: 'BOOKED',
      nights: 2,
      guestPhone: GUEST_PHONE,
      amount: '120',
      property: { id: apartmentId },
    });
    expect(booking.contact?.name).toBe('Гость E2E');
    expect(booking.deal).not.toBeNull();

    const deal = await prisma.deal.findUniqueOrThrow({
      where: { id: booking.deal?.id },
      include: { stage: true, owner: { select: { email: true } } },
    });
    expect(deal.stage.name).toBe('Бронь создана');
    expect(deal.owner?.email).toBe(MANAGER.email);
    const tasks = await prisma.task.findMany({
      where: { bookingId },
      orderBy: { dueAt: 'asc' },
    });
    expect(tasks.map((t) => t.autoKind)).toEqual(['CHECK_IN', 'CHECK_OUT']);
    expect(tasks[0].dueAt?.toISOString()).toBe('2027-03-10T09:00:00.000Z');

    const range = await manager
      .get('/api/bookings')
      .query({ from: '2027-03-01', to: '2027-03-31' })
      .expect(200);
    expect(range.body.data.map((b: BookingDto) => b.id)).toContain(bookingId);
  });

  it('refuses dates taken by another booking but allows a check-in on the check-out day', async () => {
    const taken = await create({
      propertyId: apartmentId,
      checkIn: '2027-03-11',
      checkOut: '2027-03-13',
      guestName: 'Другой гость',
    }).expect(409);
    expect(taken.body.error.message).toContain('занята');

    const backToBack = await create({
      propertyId: apartmentId,
      checkIn: '2027-03-12',
      checkOut: '2027-03-13',
      guestName: 'Следующий гость',
      status: 'REQUEST',
    }).expect(201);
    contactIds.push(backToBack.body.data.contact.id);
    await manager
      .post(`/api/bookings/${backToBack.body.data.id}/cancel`)
      .set(CSRF)
      .expect(200);
  });

  it('accepts only an apartment, not a complex row from the old export', async () => {
    const response = await create({
      propertyId: complexId,
      checkIn: '2027-04-01',
      checkOut: '2027-04-02',
      guestName: 'Гость E2E',
    }).expect(400);

    expect(response.body.error.fields.propertyId).toBeDefined();
  });

  it('moves the dates of the booking, its deal and its tasks', async () => {
    const current = await prisma.booking.findUniqueOrThrow({
      where: { id: bookingId },
    });
    const response = await manager
      .put(`/api/bookings/${bookingId}`)
      .set(CSRF)
      .send({
        propertyId: apartmentId,
        checkIn: '2027-03-15',
        checkOut: '2027-03-18',
        contactId: current.contactId,
        guestName: 'Гость E2E',
        guestPhone: GUEST_PHONE,
        amount: 180,
      })
      .expect(200);

    expect(response.body.data).toMatchObject({
      checkIn: '2027-03-15',
      nights: 3,
      contact: { id: current.contactId },
      deal: { id: current.dealId },
    });
    const deal = await prisma.deal.findUniqueOrThrow({
      where: { id: current.dealId ?? '' },
    });
    expect(deal.checkIn?.toISOString().slice(0, 10)).toBe('2027-03-15');
    const checkIn = await prisma.task.findFirstOrThrow({
      where: { bookingId, autoKind: 'CHECK_IN' },
    });
    expect(checkIn.dueAt?.toISOString()).toBe('2027-03-15T10:00:00.000Z');
  });

  it('keeps a platform booking on the same dates separate, so the overbooking stays visible', async () => {
    const rcId = baseId + 3;
    const response = await request(app.getHttpServer())
      .post(`/api/webhooks/realtycalendar/${SECRET}`)
      .send(webhook(rcId, '2027-03-15', '2027-03-18', 'Airbnb'))
      .expect(200);
    expect(response.body.data.result).toBe('created');

    const crmBooking = await prisma.booking.findUniqueOrThrow({
      where: { id: bookingId },
    });
    expect(crmBooking).toMatchObject({ rcId: null, guestName: 'Гость E2E' });
    // Отменяем площадочную бронь, чтобы дальше вебхук привязал бронь CRM.
    await prisma.booking.update({
      where: { rcId },
      data: { status: 'CANCELED' },
    });
  });

  it('lets RealtyCalendar adopt the same booking instead of duplicating it', async () => {
    const before = await prisma.booking.findUniqueOrThrow({
      where: { id: bookingId },
    });
    const rcId = baseId + 1;
    const response = await request(app.getHttpServer())
      .post(`/api/webhooks/realtycalendar/${SECRET}`)
      .send(webhook(rcId, '2027-03-15', '2027-03-18'))
      .expect(200);
    expect(response.body.data.result).toBe('updated');

    const adopted = await prisma.booking.findUniqueOrThrow({
      where: { id: bookingId },
    });
    expect(adopted).toMatchObject({
      rcId,
      source: 'CRM',
      contactId: before.contactId,
      dealId: before.dealId,
      // В RealtyCalendar бронь внесли без гостя — остаются имя и телефон, введённые в CRM; сумма — из RC.
      guestPhone: GUEST_PHONE,
      guestName: 'Гость E2E',
    });
    expect(adopted.amount?.toString()).toBe('300');
    expect(
      await prisma.booking.count({ where: { propertyId: apartmentId, rcId } }),
    ).toBe(1);

    const edit = await manager
      .put(`/api/bookings/${bookingId}`)
      .set(CSRF)
      .send({
        propertyId: apartmentId,
        checkIn: '2027-03-15',
        checkOut: '2027-03-19',
        guestName: 'Гость E2E',
      })
      .expect(409);
    expect(edit.body.error.message).toContain('RealtyCalendar');
  });

  it('cancels a CRM booking: the deal goes to «Отказ» and open tasks are removed', async () => {
    const created = await create({
      propertyId: apartmentId,
      checkIn: '2027-05-01',
      checkOut: '2027-05-03',
      guestName: 'Отменит E2E',
      guestPhone: `+99893${String(RUN_ID).slice(-7)}`,
    }).expect(201);
    const booking = created.body.data as BookingDto;
    contactIds.push(booking.contact?.id ?? '');

    const canceled = await manager
      .post(`/api/bookings/${booking.id}/cancel`)
      .set(CSRF)
      .expect(200);
    expect(canceled.body.data.status).toBe('CANCELED');

    const deal = await prisma.deal.findUniqueOrThrow({
      where: { id: booking.deal?.id },
      include: { stage: true },
    });
    expect(deal.lostReason).toBe('Бронь отменена в CRM');
    expect(deal.stage.kind).toBe('LOST');
    expect(await prisma.task.count({ where: { bookingId: booking.id } })).toBe(
      0,
    );

    await manager
      .post(`/api/bookings/${booking.id}/cancel`)
      .set(CSRF)
      .expect(409);
    // Даты отменённой брони снова свободны; гостя берём из карточки клиента.
    const again = await create({
      propertyId: apartmentId,
      checkIn: '2027-05-01',
      checkOut: '2027-05-03',
      contactId: booking.contact?.id,
    }).expect(201);
    expect(again.body.data.guestName).toBe('Отменит E2E');
  });

  it('refuses to change a booking that came from RealtyCalendar', async () => {
    const rcBooking = await prisma.booking.create({
      data: {
        rcId: baseId + 2,
        propertyId: apartmentId,
        status: 'BOOKED',
        checkIn: new Date('2027-06-01T00:00:00Z'),
        checkOut: new Date('2027-06-02T00:00:00Z'),
        nights: 1,
        rcUpdatedAt: new Date(),
      },
    });

    await manager
      .post(`/api/bookings/${rcBooking.id}/cancel`)
      .set(CSRF)
      .expect(409);
  });
});
