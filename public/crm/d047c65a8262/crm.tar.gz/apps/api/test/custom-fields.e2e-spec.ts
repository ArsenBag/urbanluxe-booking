/**
 * Настраиваемые поля карточек: администратор описывает поля, сотрудники заполняют их в карточках
 * клиентов и сделок, удаление поля стирает его значения.
 */
import type { INestApplication } from '@nestjs/common';
import type { CustomFieldDto } from '@crm/shared';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import { type Agent, createTestApp, createUser, CSRF, deleteDealsWithHistory, login, only } from './helpers.js';

const RUN_ID = Date.now();
const ADMIN = { email: `cf-admin-${RUN_ID}@test.local`, password: 'cf-admin-password' };
const MANAGER = { email: `cf-manager-${RUN_ID}@test.local`, password: 'cf-manager-password' };

describe('Custom fields (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let manager: Agent;
  let contactId: string;
  let dealId: string;
  const fields: Record<string, CustomFieldDto> = {};

  const createField = async (body: Record<string, unknown>) =>
    (await admin.post('/api/custom-fields').set(CSRF).send(body).expect(201)).body.data as CustomFieldDto;

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER');
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));
    contactId = (await manager.post('/api/contacts').set(CSRF).send({ name: `Поля ${RUN_ID}` }).expect(201)).body.data.id;
    const pipelines = (await manager.get('/api/pipelines').expect(200)).body.data as Array<{ id: string }>;
    dealId = (
      await manager.post('/api/deals').set(CSRF).send({ pipelineId: pipelines[0]!.id, contactId }).expect(201)
    ).body.data.id;
  });

  afterAll(async () => {
    await prisma.customField.deleteMany({ where: { label: { endsWith: String(RUN_ID) } } });
    await prisma.activityLog.deleteMany({ where: { entityType: 'custom-field', actor: { email: ADMIN.email } } });
    await deleteDealsWithHistory(prisma, [contactId]);
    await prisma.contact.deleteMany({ where: only({ id: contactId }) });
    await prisma.user.deleteMany({ where: { email: { in: [ADMIN.email, MANAGER.email] } } });
    await app.close();
  });

  describe('field definitions', () => {
    it('lets an admin add fields of every type in order', async () => {
      fields.passport = await createField({ entity: 'CONTACT', label: `Паспорт ${RUN_ID}`, type: 'TEXT' });
      fields.guests = await createField({ entity: 'CONTACT', label: `Визитов ${RUN_ID}`, type: 'NUMBER' });
      fields.country = await createField({
        entity: 'CONTACT',
        label: `Гражданство ${RUN_ID}`,
        type: 'SELECT',
        options: ['Узбекистан', 'Россия', 'Казахстан'],
      });
      fields.birthday = await createField({ entity: 'CONTACT', label: `День рождения ${RUN_ID}`, type: 'DATE' });
      fields.invoice = await createField({ entity: 'DEAL', label: `Нужен счёт ${RUN_ID}`, type: 'BOOLEAN' });

      expect(fields.guests!.position).toBe(fields.passport!.position + 1);
      const list = (await manager.get('/api/custom-fields').query({ entity: 'CONTACT' }).expect(200)).body.data as CustomFieldDto[];
      const ours = list.filter((field) => field.label.endsWith(String(RUN_ID))).map((field) => field.type);
      expect(ours).toEqual(['TEXT', 'NUMBER', 'SELECT', 'DATE']);
    });

    it('does not let a manager change fields', async () => {
      await manager.post('/api/custom-fields').set(CSRF).send({ entity: 'CONTACT', label: 'x', type: 'TEXT' }).expect(403);
      await manager.delete(`/api/custom-fields/${fields.passport!.id}`).set(CSRF).expect(403);
    });

    it('requires options for a list', async () => {
      const response = await admin
        .post('/api/custom-fields')
        .set(CSRF)
        .send({ entity: 'CONTACT', label: `Пустой ${RUN_ID}`, type: 'SELECT', options: [] })
        .expect(400);
      expect(response.body.error.fields.options).toBe('Добавьте хотя бы один вариант');
    });

    it('renames a field and edits list options but keeps the type', async () => {
      const updated = await admin
        .patch(`/api/custom-fields/${fields.country!.id}`)
        .set(CSRF)
        .send({ label: `Страна ${RUN_ID}`, options: ['Узбекистан', 'Россия', 'Казахстан', 'Другая'], type: 'TEXT' })
        .expect(200);
      expect(updated.body.data).toMatchObject({ label: `Страна ${RUN_ID}`, type: 'SELECT' });
      expect(updated.body.data.options).toContain('Другая');
    });

    it('reorders fields and rejects an outdated list', async () => {
      const all = (await admin.get('/api/custom-fields').query({ entity: 'CONTACT' }).expect(200)).body.data as CustomFieldDto[];
      const reversed = all.map((field) => field.id).reverse();
      const response = await admin.post('/api/custom-fields/reorder').set(CSRF).send({ entity: 'CONTACT', ids: reversed }).expect(200);
      expect((response.body.data as CustomFieldDto[]).map((field) => field.id)).toEqual(reversed);

      await admin
        .post('/api/custom-fields/reorder')
        .set(CSRF)
        .send({ entity: 'CONTACT', ids: reversed.slice(1) })
        .expect(400);
    });
  });

  describe('values in cards', () => {
    it('saves values of a client card and returns them with the client', async () => {
      const response = await manager
        .patch(`/api/contacts/${contactId}/custom-fields`)
        .set(CSRF)
        .send({
          values: {
            [fields.passport!.id]: '  AA1234567 ',
            [fields.guests!.id]: '3',
            [fields.country!.id]: 'Россия',
            [fields.birthday!.id]: '1990-05-17',
          },
        })
        .expect(200);
      expect(response.body.data).toEqual({
        [fields.passport!.id]: 'AA1234567',
        [fields.guests!.id]: 3,
        [fields.country!.id]: 'Россия',
        [fields.birthday!.id]: '1990-05-17',
      });

      const contact = await manager.get(`/api/contacts/${contactId}`).expect(200);
      expect(contact.body.data.customFields[fields.country!.id]).toBe('Россия');
    });

    it('changes one field without touching the others and clears with null', async () => {
      const response = await manager
        .patch(`/api/contacts/${contactId}/custom-fields`)
        .set(CSRF)
        .send({ values: { [fields.guests!.id]: null, [fields.passport!.id]: 'AB7654321' } })
        .expect(200);
      expect(response.body.data[fields.guests!.id]).toBeUndefined();
      expect(response.body.data[fields.passport!.id]).toBe('AB7654321');
      expect(response.body.data[fields.country!.id]).toBe('Россия');
    });

    it('rejects invalid values field by field and saves nothing', async () => {
      const response = await manager
        .patch(`/api/contacts/${contactId}/custom-fields`)
        .set(CSRF)
        .send({ values: { [fields.country!.id]: 'Марс', [fields.birthday!.id]: '2026-02-30', [fields.passport!.id]: 'новый' } })
        .expect(400);
      expect(response.body.error.fields).toEqual({
        [fields.country!.id]: 'Выберите вариант из списка',
        [fields.birthday!.id]: 'Некорректная дата',
      });
      const contact = await manager.get(`/api/contacts/${contactId}`).expect(200);
      expect(contact.body.data.customFields[fields.passport!.id]).toBe('AB7654321');
    });

    it('does not accept a deal field on a client card', async () => {
      const response = await manager
        .patch(`/api/contacts/${contactId}/custom-fields`)
        .set(CSRF)
        .send({ values: { [fields.invoice!.id]: true } })
        .expect(400);
      expect(response.body.error.fields[fields.invoice!.id]).toBe('Поле удалено — обновите страницу');
    });

    it('saves values of a deal card', async () => {
      await manager.patch(`/api/deals/${dealId}/custom-fields`).set(CSRF).send({ values: { [fields.invoice!.id]: false } }).expect(200);
      const deal = await manager.get(`/api/deals/${dealId}`).expect(200);
      expect(deal.body.data.customFields[fields.invoice!.id]).toBe(false);
    });

    it('returns 404 for an unknown card', async () => {
      await manager
        .patch('/api/contacts/00000000-0000-4000-8000-000000000000/custom-fields')
        .set(CSRF)
        .send({ values: { [fields.passport!.id]: 'x' } })
        .expect(404);
    });

    it('erases the values of a deleted field from cards', async () => {
      await admin.delete(`/api/custom-fields/${fields.passport!.id}`).set(CSRF).expect(200);

      const contact = await manager.get(`/api/contacts/${contactId}`).expect(200);
      expect(contact.body.data.customFields[fields.passport!.id]).toBeUndefined();
      expect(contact.body.data.customFields[fields.country!.id]).toBe('Россия');
    });
  });
});
