/**
 * Сквозной сценарий этапа 1 на настоящей БД: клиенты, воронки, сделки, задачи, история.
 * Требует запущенный PostgreSQL и применённые миграции (в том числе воронку «Бронирование»).
 */
import type { INestApplication } from '@nestjs/common';
import type { DealDto, PipelineDto } from '@crm/shared';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import { type Agent, createTestApp, createUser, CSRF, login, deleteDealsWithHistory } from './helpers.js';

const RUN_ID = Date.now();
const ADMIN = { email: `crm-admin-${RUN_ID}@test.local`, password: 'crm-admin-password' };
const MANAGER = { email: `crm-manager-${RUN_ID}@test.local`, password: 'crm-manager-password' };
const PHONE_TAIL = String(RUN_ID).slice(-7);

describe('CRM stage 1 (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let manager: Agent;
  let managerId: string;
  let pipeline: PipelineDto;
  const createdContactIds: string[] = [];
  const createdPipelineIds: string[] = [];

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    managerId = (await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER')).id;
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));

    const pipelines = await manager.get('/api/pipelines').expect(200);
    pipeline = (pipelines.body.data as PipelineDto[]).find((p) => p.name === 'Бронирование') as PipelineDto;
  });

  afterAll(async () => {
    await prisma.task.deleteMany({ where: { contactId: { in: createdContactIds } } });
    await deleteDealsWithHistory(prisma, createdContactIds);
    await prisma.contact.deleteMany({ where: { id: { in: createdContactIds } } });
    await prisma.pipeline.deleteMany({ where: { id: { in: createdPipelineIds } } });
    await prisma.user.deleteMany({ where: { email: { in: [ADMIN.email, MANAGER.email] } } });
    await app.close();
  });

  async function createContact(agent: Agent, body: Record<string, unknown>) {
    const response = await agent.post('/api/contacts').set(CSRF).send(body);
    if (response.status === 201) createdContactIds.push(response.body.data.id);
    return response;
  }

  async function createDeal(body: Record<string, unknown>): Promise<DealDto> {
    const response = await manager.post('/api/deals').set(CSRF).send({ pipelineId: pipeline.id, ...body }).expect(201);
    return response.body.data;
  }

  const stage = (index: number) => pipeline.stages[index];
  const stageOfKind = (kind: string) => pipeline.stages.find((s) => s.kind === kind)!;

  describe('pipelines', () => {
    it('ships the default booking pipeline with ordered stages', () => {
      expect(pipeline.stages.map((s) => s.name)).toEqual([
        'Новое обращение',
        'Подбор / предложение',
        'Бронь создана',
        'Заселён',
        'Выехал',
        'Отзыв получен',
        'Отказ',
      ]);
    });

    it('lets only admins change pipelines', async () => {
      await manager.post('/api/pipelines').set(CSRF).send({ name: 'Нельзя' }).expect(403);
    });

    it('creates a pipeline with default stages, adds and reorders stages', async () => {
      const created = await admin.post('/api/pipelines').set(CSRF).send({ name: `Тест ${RUN_ID}` }).expect(201);
      const extra: PipelineDto = created.body.data;
      createdPipelineIds.push(extra.id);
      expect(extra.stages.map((s) => s.kind)).toEqual(['OPEN', 'WON', 'LOST']);

      const added = await admin
        .post(`/api/pipelines/${extra.id}/stages`)
        .set(CSRF)
        .send({ name: 'Переговоры', color: '#123456' })
        .expect(201);
      const reversed = [added.body.data.id, ...extra.stages.map((s) => s.id)];
      const reordered = await admin
        .put(`/api/pipelines/${extra.id}/stages/order`)
        .set(CSRF)
        .send({ stageIds: reversed })
        .expect(200);
      expect(reordered.body.data.stages[0].name).toBe('Переговоры');

      await admin.put(`/api/pipelines/${extra.id}/stages/order`).set(CSRF).send({ stageIds: reversed.slice(1) }).expect(400);
    });
  });

  describe('contacts', () => {
    let contactId: string;

    it('normalizes phones and assigns the creator as owner', async () => {
      const response = await createContact(manager, {
        name: `Гость ${RUN_ID}`,
        phones: [`90 ${PHONE_TAIL}`],
        source: 'TELEGRAM',
        tags: ['VIP'],
      });

      expect(response.status).toBe(201);
      expect(response.body.data).toMatchObject({
        phones: [`+99890${PHONE_TAIL}`],
        source: 'TELEGRAM',
        owner: { id: managerId },
      });
      contactId = response.body.data.id;
    });

    it('rejects an invalid phone with a field error', async () => {
      const response = await createContact(manager, { name: 'Ошибка', phones: ['12'] });

      expect(response.status).toBe(400);
      expect(Object.keys(response.body.error.fields)[0]).toMatch(/^phones/);
    });

    it('finds a contact by the last digits of the phone and by name', async () => {
      const byPhone = await manager.get('/api/contacts').query({ search: PHONE_TAIL.slice(-5) }).expect(200);
      const byName = await manager.get('/api/contacts').query({ search: `гость ${RUN_ID}` }).expect(200);

      expect(byPhone.body.data.items.map((c: { id: string }) => c.id)).toContain(contactId);
      expect(byName.body.data).toMatchObject({ total: 1, page: 1 });
    });

    it('updates a contact and does not let a manager delete it', async () => {
      await manager.patch(`/api/contacts/${contactId}`).set(CSRF).send({ notes: 'Любит высокие этажи' }).expect(200);

      await manager.delete(`/api/contacts/${contactId}`).set(CSRF).expect(403);
    });
  });

  describe('deals and tasks', () => {
    let contactId: string;
    let deal: DealDto;

    beforeAll(async () => {
      contactId = (await createContact(manager, { name: `Покупатель ${RUN_ID}` })).body.data.id;
    });

    it('creates a deal in the first stage named after the client', async () => {
      deal = await createDeal({ contactId, amount: 240.5, checkIn: '2026-11-01', checkOut: '2026-11-04', guests: 2 });

      expect(deal).toMatchObject({
        title: `Покупатель ${RUN_ID}`,
        stageId: stage(0).id,
        stageKind: 'OPEN',
        amount: '240.5',
        currency: 'USD',
        checkIn: '2026-11-01',
        checkOut: '2026-11-04',
        owner: { id: managerId },
        closedAt: null,
      });
    });

    it('validates a single changed date against the stored one', async () => {
      const response = await manager.patch(`/api/deals/${deal.id}`).set(CSRF).send({ checkOut: '2026-10-30' });

      expect(response.status).toBe(400);
      expect(response.body.error.fields).toHaveProperty('checkOut');
    });

    it('orders cards inside a stage by neighbours', async () => {
      const second = await createDeal({ contactId, title: 'Вторая' });
      const third = await createDeal({ contactId, title: 'Третья' });

      // Третью ставим между первой и второй.
      await manager
        .post(`/api/deals/${third.id}/move`)
        .set(CSRF)
        .send({ stageId: stage(0).id, prevDealId: deal.id, nextDealId: second.id })
        .expect(201);

      const board = await manager.get('/api/deals').query({ pipelineId: pipeline.id }).expect(200);
      const order = (board.body.data as DealDto[])
        .filter((d) => [deal.id, second.id, third.id].includes(d.id))
        .map((d) => d.title);
      expect(order).toEqual([deal.title, 'Третья', 'Вторая']);
    });

    it('appends a deal to the end of a stage when no neighbours are given', async () => {
      const target = stage(1).id;
      const first = await createDeal({ contactId, title: 'Первая в колонке', stageId: target });
      const moved = await createDeal({ contactId, title: 'Перенесённая' });

      await manager.post(`/api/deals/${moved.id}/move`).set(CSRF).send({ stageId: target }).expect(201);

      const board = await manager.get('/api/deals').query({ pipelineId: pipeline.id }).expect(200);
      const column = (board.body.data as DealDto[]).filter((d) => d.stageId === target).map((d) => d.id);
      expect(column.indexOf(moved.id)).toBeGreaterThan(column.indexOf(first.id));
    });

    it('rejects identical neighbours instead of looping', async () => {
      await manager
        .post(`/api/deals/${deal.id}/move`)
        .set(CSRF)
        .send({ stageId: stage(0).id, prevDealId: deal.id, nextDealId: deal.id })
        .expect(400);
    });

    it('returns 400 for a non-existent owner', async () => {
      const response = await manager
        .patch(`/api/deals/${deal.id}`)
        .set(CSRF)
        .send({ ownerId: '00000000-0000-4000-8000-000000000000' });

      expect(response.status).toBe(400);
      expect(response.body.error.fields).toHaveProperty('ownerId');
    });

    it('rejects a move based on an outdated board', async () => {
      const response = await manager
        .post(`/api/deals/${deal.id}/move`)
        .set(CSRF)
        .send({ stageId: stage(1).id, prevDealId: deal.id });

      expect(response.status).toBe(409);
    });

    it('closes a deal on a lost stage and reopens it when moved back', async () => {
      const lost = await manager
        .post(`/api/deals/${deal.id}/move`)
        .set(CSRF)
        .send({ stageId: stageOfKind('LOST').id, lostReason: 'Нашёл дешевле' })
        .expect(201);
      expect(lost.body.data).toMatchObject({ stageKind: 'LOST', lostReason: 'Нашёл дешевле' });
      expect(lost.body.data.closedAt).not.toBeNull();

      const reopened = await manager.post(`/api/deals/${deal.id}/move`).set(CSRF).send({ stageId: stage(2).id }).expect(201);
      expect(reopened.body.data).toMatchObject({ closedAt: null, lostReason: null, stageKind: 'OPEN' });
    });

    it('refuses to move a deal into another pipeline stage', async () => {
      const foreignStage = createdPipelineIds.length
        ? (await prisma.stage.findFirstOrThrow({ where: { pipelineId: createdPipelineIds[0] } })).id
        : null;
      expect(foreignStage).not.toBeNull();

      await manager.post(`/api/deals/${deal.id}/move`).set(CSRF).send({ stageId: foreignStage }).expect(400);
    });

    it('creates a task on a deal, links the client and completes it', async () => {
      const created = await manager
        .post('/api/tasks')
        .set(CSRF)
        .send({ title: 'Отправить инструкцию по заселению', dealId: deal.id, dueAt: '2026-10-31T10:00:00+05:00' })
        .expect(201);
      expect(created.body.data).toMatchObject({
        contact: { id: contactId },
        assignee: { id: managerId },
        dueAt: '2026-10-31T05:00:00.000Z',
      });

      const mine = await manager.get('/api/tasks').expect(200);
      expect(mine.body.data.map((t: { id: string }) => t.id)).toContain(created.body.data.id);

      const done = await manager.patch(`/api/tasks/${created.body.data.id}`).set(CSRF).send({ isDone: true }).expect(200);
      expect(done.body.data.doneAt).not.toBeNull();

      // Повторная отметка не меняет время выполнения.
      const again = await manager.patch(`/api/tasks/${created.body.data.id}`).set(CSRF).send({ isDone: true }).expect(200);
      expect(again.body.data.doneAt).toBe(done.body.data.doneAt);

      const board = await manager.get(`/api/deals/${deal.id}`).expect(200);
      expect(board.body.data.openTasksCount).toBe(0);
    });

    it('does not let a manager delete a task created by an admin', async () => {
      const adminTask = await admin
        .post('/api/tasks')
        .set(CSRF)
        .send({ title: 'Проверить уборку', contactId, assigneeId: managerId })
        .expect(201);

      await manager.delete(`/api/tasks/${adminTask.body.data.id}`).set(CSRF).expect(403);
      await admin.delete(`/api/tasks/${adminTask.body.data.id}`).set(CSRF).expect(200);
    });

    it('shows client history across the client and its deals', async () => {
      const history = await manager.get(`/api/contacts/${contactId}/activity`).expect(200);
      const actions = (history.body.data as Array<{ action: string }>).map((entry) => entry.action);

      expect(actions).toEqual(expect.arrayContaining(['contact.created', 'deal.created', 'deal.moved', 'task.completed']));
    });

    it('refuses to delete a client that has deals', async () => {
      await admin.delete(`/api/contacts/${contactId}`).set(CSRF).expect(409);
    });

    it('refuses to delete a stage that still has deals', async () => {
      await admin.delete(`/api/stages/${stage(2).id}`).set(CSRF).expect(409);
    });

    it('refuses to change the kind of a stage that has deals', async () => {
      await admin.patch(`/api/stages/${stage(2).id}`).set(CSRF).send({ kind: 'WON' }).expect(409);
      await admin.patch(`/api/stages/${stage(2).id}`).set(CSRF).send({ color: '#f59e0b' }).expect(200);
    });

    it('takes the task client from its deal even if another client is sent', async () => {
      const otherContact = (await createContact(manager, { name: `Другой ${RUN_ID}` })).body.data.id;
      const task = await manager
        .post('/api/tasks')
        .set(CSRF)
        .send({ title: 'Проверка связи', dealId: deal.id, contactId: otherContact })
        .expect(201);

      expect(task.body.data.contact.id).toBe(contactId);
    });
  });
});
