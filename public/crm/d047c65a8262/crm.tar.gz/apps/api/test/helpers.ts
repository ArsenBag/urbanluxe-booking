import type { INestApplication } from '@nestjs/common';
import { Test, type TestingModuleBuilder } from '@nestjs/testing';
import argon2 from 'argon2';
import cookieParser from 'cookie-parser';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { AppModule } from '../src/app.module.js';
import { useBodyParsers } from '../src/common/body-parsers.js';
import { loadRootEnv } from '../src/config/load-root-env.js';
import type { Role } from '../src/generated/prisma/client.js';
import { PrismaService } from '../src/prisma/prisma.service.js';

loadRootEnv();
// Фоновые автоматизации в тестах не запускаем: тесты вызывают их явно.
process.env.AUTOMATIONS_ENABLED = 'false';
// Пауза между запросами фото профиля бережёт аккаунт Telegram; в тестах мессенджеры фейковые.
process.env.AVATAR_REQUEST_GAP_MS = '0';
// Файлы переписки из тестов — во временную папку, а не в data/ разработки.
process.env.FILES_DIR = join(tmpdir(), 'crm-e2e-files');

export const CSRF = { 'x-requested-with': 'crm-web' };

export type Agent = ReturnType<typeof request.agent>;
type LoginResponse = Awaited<ReturnType<Agent['post']>>;

export async function createTestApp(
  configure: (builder: TestingModuleBuilder) => TestingModuleBuilder = (
    builder,
  ) => builder,
): Promise<{ app: INestApplication; prisma: PrismaService }> {
  const moduleRef = await configure(
    Test.createTestingModule({ imports: [AppModule] }),
  ).compile();
  // Как в main.ts: тело запросов разбирают свои парсеры с лимитами.
  const app = moduleRef.createNestApplication({ bodyParser: false });
  app.use(cookieParser());
  useBodyParsers(app);
  app.setGlobalPrefix('api');
  await app.init();
  return { app, prisma: app.get(PrismaService) };
}

export async function createUser(
  prisma: PrismaService,
  email: string,
  password: string,
  role: Role,
) {
  return prisma.user.create({
    data: {
      email,
      name: `E2E ${role}`,
      role,
      passwordHash: await argon2.hash(password, { type: argon2.argon2id }),
    },
  });
}

export async function login(
  app: INestApplication,
  email: string,
  password: string,
): Promise<{ agent: Agent; response: LoginResponse }> {
  const agent = request.agent(app.getHttpServer());
  const response = await agent
    .post('/api/auth/login')
    .set(CSRF)
    .send({ email, password });
  return { agent, response };
}

/** Удаляет сделки клиентов вместе с их записями журнала: иначе журнал засоряется между прогонами. */
export async function deleteDealsWithHistory(
  prisma: PrismaService,
  contactIds: string[],
): Promise<void> {
  const deals = await prisma.deal.findMany({
    where: { contactId: { in: contactIds } },
    select: { id: true },
  });
  const entityIds = [...deals.map((deal) => deal.id), ...contactIds];
  await prisma.activityLog.deleteMany({
    where: { entityId: { in: entityIds } },
  });
  await prisma.deal.deleteMany({ where: { contactId: { in: contactIds } } });
}

/**
 * Условие для уборки в afterAll. Если beforeAll упал раньше, чем появился id, Prisma прочла бы
 * { pipelineId: undefined } как «без условия» и удалила бы всю таблицу (так однажды стёрлись все сделки
 * локальной базы). С пустым значением возвращаем условие, под которое не попадает ни одна строка.
 */
export function only<T extends Record<string, unknown>>(where: T): T {
  const isIncomplete = Object.values(where).some(
    (value) => value === undefined,
  );
  return isIncomplete ? ({ id: { in: [] } } as unknown as T) : where;
}

/** Байты, похожие на JPEG: проверка формата фото смотрит на сигнатуру FF D8 FF. */
export function fakeJpeg(label: string): Buffer {
  return Buffer.concat([
    Buffer.from([0xff, 0xd8, 0xff, 0xe0]),
    Buffer.from(label),
  ]);
}

/** Ждёт, пока фоновая работа (например, загрузка фото) даст результат. */
export async function waitUntil<T>(
  read: () => Promise<T>,
  isDone: (value: T) => boolean,
  timeoutMs = 5000,
): Promise<T> {
  const started = Date.now();
  for (;;) {
    const value = await read();
    if (isDone(value)) return value;
    if (Date.now() - started > timeoutMs)
      throw new Error('Условие не выполнилось вовремя');
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
}
