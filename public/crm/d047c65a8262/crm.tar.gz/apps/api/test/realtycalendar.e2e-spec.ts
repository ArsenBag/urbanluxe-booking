/**
 * Сквозной сценарий этапа 3: вебхуки RealtyCalendar → брони, клиенты, сделки, задачи.
 * Тело вебхука — пример из официальной документации RealtyCalendar.
 */
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import type { BookingDayDto, BookingDto } from '@crm/shared';
import request from 'supertest';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import {
  type Agent,
  createTestApp,
  createUser,
  CSRF,
  login,
  deleteDealsWithHistory,
} from './helpers.js';

const SECRET = 'e2e-rc-secret-0123456789abcdef';
process.env.RC_WEBHOOK_SECRET = SECRET;
process.env.PUBLIC_API_URL = 'https://crm.example.uz';

const RUN_ID = Date.now();
const ADMIN = {
  email: `rc-admin-${RUN_ID}@test.local`,
  password: 'rc-admin-password',
};
const MANAGER = {
  email: `rc-manager-${RUN_ID}@test.local`,
  password: 'rc-manager-password',
};
// id в RealtyCalendar — int4; уникальные на прогон.
const baseId = 1_000_000_000 + Math.floor(Math.random() * 900_000_000);
const PROPERTY_RC_ID = baseId;
// Квартира для проверки названий: отдельная, чтобы не трогать основную.
const SPARE_PROPERTY_RC_ID = baseId + 1;
const GUEST_PHONE = `+99890${String(RUN_ID).slice(-7)}`;
const template = JSON.parse(
  readFileSync(
    resolve(import.meta.dirname, 'fixtures/rc-create-booking.json'),
    'utf8',
  ),
);

interface WebhookOptions {
  rcId: number;
  status?: 'booked' | 'request' | 'canceled' | 'deleted';
  action?: string;
  beginDate?: string;
  endDate?: string;
  updatedAt: string;
  phone?: string;
  fio?: string;
  origin?: string | null;
  amount?: number;
}

function webhook(options: WebhookOptions) {
  const body = structuredClone(template);
  body.action = options.action ?? 'create_booking';
  body.status = options.status ?? 'booked';
  const booking = body.data.booking;
  Object.assign(booking, {
    id: options.rcId,
    realty_id: PROPERTY_RC_ID,
    begin_date: options.beginDate ?? '2026-11-10',
    end_date: options.endDate ?? '2026-11-13',
    number_of_nights: null,
    updated_at: options.updatedAt,
    amount: options.amount ?? 255,
    url: `https://realtycalendar.ru/event_calendars/${options.rcId}`,
  });
  booking.apartment = { id: PROPERTY_RC_ID, title: `U-Tower ${RUN_ID}` };
  booking.client = {
    fio: options.fio ?? 'Дилноза',
    phone: options.phone ?? GUEST_PHONE,
    email: null,
    additional_phone: null,
  };
  booking.booking_origin = { id: null, title: options.origin ?? null };
  return body;
}

describe('RealtyCalendar webhooks (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let manager: Agent;
  let managerId: string;
  let contactId: string;
  let dealId: string;
  const contactIds: string[] = [];

  const send = (body: unknown, secret = SECRET) =>
    request(app.getHttpServer())
      .post(`/api/webhooks/realtycalendar/${secret}`)
      .send(body as object);

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    managerId = (
      await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER')
    ).id;
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));

    // Клиент уже писал в мессенджер, по нему есть сделка на первом этапе.
    const pipeline = (
      await manager.get('/api/pipelines').expect(200)
    ).body.data.find((p: { name: string }) => p.name === 'Бронирование');
    contactId = (
      await manager
        .post('/api/contacts')
        .set(CSRF)
        .send({ name: 'Дилноза', phones: [GUEST_PHONE] })
        .expect(201)
    ).body.data.id;
    contactIds.push(contactId);
    dealId = (
      await manager
        .post('/api/deals')
        .set(CSRF)
        .send({ pipelineId: pipeline.id, contactId })
        .expect(201)
    ).body.data.id;
  });

  afterAll(async () => {
    const bookings = await prisma.booking.findMany({
      where: {
        property: { rcId: { in: [PROPERTY_RC_ID, SPARE_PROPERTY_RC_ID] } },
      },
      select: { contactId: true },
    });
    const ids = [
      ...new Set([
        ...contactIds,
        ...bookings
          .map((b) => b.contactId)
          .filter((id): id is string => Boolean(id)),
      ]),
    ];
    await prisma.booking.deleteMany({
      where: {
        property: { rcId: { in: [PROPERTY_RC_ID, SPARE_PROPERTY_RC_ID] } },
      },
    });
    await prisma.property.deleteMany({
      where: { rcId: { in: [PROPERTY_RC_ID, SPARE_PROPERTY_RC_ID] } },
    });
    await prisma.task.deleteMany({ where: { contactId: { in: ids } } });
    await deleteDealsWithHistory(prisma, ids);
    await prisma.contact.deleteMany({ where: { id: { in: ids } } });
    await prisma.user.deleteMany({
      where: { email: { in: [ADMIN.email, MANAGER.email] } },
    });
    await app.close();
  });

  it('pretends the endpoint does not exist for a wrong secret', async () => {
    await send(
      webhook({ rcId: baseId + 1, updatedAt: '2026-10-04T10:00:00+05:00' }),
      'wrong-secret',
    ).expect(404);
  });

  it('acknowledges an unrecognized body without retries', async () => {
    const response = await send({ hello: 'world' }).expect(200);

    expect(response.body.data.result).toBe('ignored');
  });

  it('links a booking to the existing client and moves the deal to «Бронь создана» with tasks', async () => {
    const response = await send(
      webhook({ rcId: baseId + 1, updatedAt: '2026-10-04T10:00:00+05:00' }),
    ).expect(200);
    expect(response.body.data.result).toBe('created');

    const booking = await prisma.booking.findUniqueOrThrow({
      where: { rcId: baseId + 1 },
      include: { property: true },
    });
    expect(booking).toMatchObject({
      contactId,
      dealId,
      status: 'BOOKED',
      nights: 3,
    });
    expect(booking.property?.title).toBe(`U-Tower ${RUN_ID}`);

    const deal = (await manager.get(`/api/deals/${dealId}`).expect(200)).body
      .data;
    const stage = await prisma.stage.findUniqueOrThrow({
      where: { id: deal.stageId },
    });
    expect(stage.name).toBe('Бронь создана');
    expect(deal).toMatchObject({
      checkIn: '2026-11-10',
      checkOut: '2026-11-13',
      amount: '255',
    });

    const tasks = await prisma.task.findMany({
      where: { bookingId: booking.id },
      orderBy: { dueAt: 'asc' },
    });
    expect(tasks.map((t) => t.autoKind)).toEqual(['CHECK_IN', 'CHECK_OUT']);
    expect(tasks[0]).toMatchObject({ assigneeId: managerId, dealId });
    expect(tasks[0].dueAt?.toISOString()).toBe('2026-11-10T10:00:00.000Z');
  });

  it('ignores a stale retry of an older version', async () => {
    const response = await send(
      webhook({
        rcId: baseId + 1,
        updatedAt: '2026-10-04T09:00:00+05:00',
        beginDate: '2026-12-01',
        endDate: '2026-12-02',
      }),
    ).expect(200);

    expect(response.body.data.result).toBe('stale');
    const booking = await prisma.booking.findUniqueOrThrow({
      where: { rcId: baseId + 1 },
    });
    expect(booking.checkIn.toISOString().slice(0, 10)).toBe('2026-11-10');
  });

  it('moves dates of the booking, the deal and the open tasks; a completed task stays as is', async () => {
    const booking = await prisma.booking.findUniqueOrThrow({
      where: { rcId: baseId + 1 },
    });
    const checkIn = await prisma.task.findUniqueOrThrow({
      where: {
        bookingId_autoKind: { bookingId: booking.id, autoKind: 'CHECK_IN' },
      },
    });
    await manager
      .patch(`/api/tasks/${checkIn.id}`)
      .set(CSRF)
      .send({ isDone: true })
      .expect(200);

    // Сдвигается только выезд: выполненная задача заезда остаётся выполненной.
    await send(
      webhook({
        rcId: baseId + 1,
        action: 'update_booking',
        updatedAt: '2026-10-04T11:00:00+05:00',
        beginDate: '2026-11-10',
        endDate: '2026-11-15',
      }),
    ).expect(200);

    const deal = (await manager.get(`/api/deals/${dealId}`).expect(200)).body
      .data;
    expect(deal).toMatchObject({
      checkIn: '2026-11-10',
      checkOut: '2026-11-15',
    });
    const tasks = await prisma.task.findMany({
      where: { bookingId: booking.id },
    });
    const byKind = Object.fromEntries(tasks.map((t) => [t.autoKind, t]));
    expect(byKind.CHECK_OUT.dueAt?.toISOString()).toBe(
      '2026-11-15T07:00:00.000Z',
    );
    expect(byKind.CHECK_IN.dueAt?.toISOString()).toBe(
      '2026-11-10T10:00:00.000Z',
    );
    expect(byKind.CHECK_IN.isDone).toBe(true);
  });

  it('keeps a manual reschedule of a task when an unrelated booking field changes', async () => {
    const booking = await prisma.booking.findUniqueOrThrow({
      where: { rcId: baseId + 1 },
    });
    const checkOut = await prisma.task.findUniqueOrThrow({
      where: {
        bookingId_autoKind: { bookingId: booking.id, autoKind: 'CHECK_OUT' },
      },
    });
    await manager
      .patch(`/api/tasks/${checkOut.id}`)
      .set(CSRF)
      .send({ dueAt: '2026-11-15T09:00:00+05:00' })
      .expect(200);

    await send(
      webhook({
        rcId: baseId + 1,
        action: 'update_booking',
        updatedAt: '2026-10-04T11:30:00+05:00',
        beginDate: '2026-11-10',
        endDate: '2026-11-15',
        amount: 300,
      }),
    ).expect(200);

    const after = await prisma.task.findUniqueOrThrow({
      where: { id: checkOut.id },
    });
    expect(after.dueAt?.toISOString()).toBe('2026-11-15T04:00:00.000Z');
  });

  it('acknowledges a webhook with an impossible date instead of failing forever', async () => {
    const response = await send(
      webhook({
        rcId: baseId + 9,
        updatedAt: '2026-10-04T10:00:00+05:00',
        beginDate: '2026-13-45',
      }),
    ).expect(200);

    expect(response.body.data.result).toBe('ignored');
  });

  it('creates a client and a deal for a Booking.com guest who never wrote before', async () => {
    const phone = `+7916${String(RUN_ID).slice(-7)}`;
    await send(
      webhook({
        rcId: baseId + 2,
        updatedAt: '2026-10-04T10:00:00+05:00',
        phone,
        fio: 'John Smith',
        origin: 'Booking.com',
      }),
    ).expect(200);

    const booking = await prisma.booking.findUniqueOrThrow({
      where: { rcId: baseId + 2 },
      include: { contact: true, deal: { include: { stage: true } } },
    });
    contactIds.push(booking.contactId!);
    expect(booking.contact).toMatchObject({
      name: 'John Smith',
      source: 'BOOKING',
      phones: [phone],
    });
    expect(booking.deal?.stage.name).toBe('Бронь создана');
    expect(booking.origin).toBe('Booking.com');
  });

  it('moves the deal to «Отказ» and removes open tasks when the booking is canceled', async () => {
    await send(
      webhook({
        rcId: baseId + 1,
        action: 'cancel_booking',
        status: 'canceled',
        updatedAt: '2026-10-04T12:00:00+05:00',
        beginDate: '2026-11-10',
        endDate: '2026-11-15',
      }),
    ).expect(200);

    const deal = (await manager.get(`/api/deals/${dealId}`).expect(200)).body
      .data;
    expect(deal).toMatchObject({
      stageKind: 'LOST',
      lostReason: 'Бронь отменена в RealtyCalendar',
    });
    const booking = await prisma.booking.findUniqueOrThrow({
      where: { rcId: baseId + 1 },
    });
    const tasks = await prisma.task.findMany({
      where: { bookingId: booking.id },
    });
    expect(tasks.map((t) => t.autoKind)).toEqual(['CHECK_IN']);
    expect(booking.status).toBe('CANCELED');
  });

  it('reopens the deal and restores tasks when a canceled booking is booked again', async () => {
    await send(
      webhook({
        rcId: baseId + 3,
        updatedAt: '2026-10-04T10:00:00+05:00',
        phone: `+99891${String(RUN_ID).slice(-7)}`,
        fio: 'Передумавший',
      }),
    ).expect(200);
    await send(
      webhook({
        rcId: baseId + 3,
        status: 'canceled',
        action: 'cancel_booking',
        updatedAt: '2026-10-04T10:05:00+05:00',
        phone: `+99891${String(RUN_ID).slice(-7)}`,
        fio: 'Передумавший',
      }),
    ).expect(200);
    await send(
      webhook({
        rcId: baseId + 3,
        status: 'booked',
        action: 'update_booking',
        updatedAt: '2026-10-04T10:10:00+05:00',
        phone: `+99891${String(RUN_ID).slice(-7)}`,
        fio: 'Передумавший',
      }),
    ).expect(200);

    const booking = await prisma.booking.findUniqueOrThrow({
      where: { rcId: baseId + 3 },
      include: { deal: { include: { stage: true } } },
    });
    contactIds.push(booking.contactId!);
    expect(booking.deal).toMatchObject({ closedAt: null, lostReason: null });
    expect(booking.deal?.stage.name).toBe('Бронь создана');
    expect(
      await prisma.task.count({
        where: { bookingId: booking.id, isDone: false },
      }),
    ).toBe(2);
  });

  it('moves a booking to the new client when the guest is changed in RealtyCalendar', async () => {
    const newPhone = `+99895${String(RUN_ID).slice(-7)}`;
    await send(
      webhook({
        rcId: baseId + 3,
        action: 'update_booking',
        updatedAt: '2026-10-04T10:20:00+05:00',
        phone: newPhone,
        fio: 'Другой гость',
      }),
    ).expect(200);

    const booking = await prisma.booking.findUniqueOrThrow({
      where: { rcId: baseId + 3 },
      include: { contact: true, deal: true },
    });
    contactIds.push(booking.contactId!);
    expect(booking.contact).toMatchObject({
      name: 'Другой гость',
      phones: [newPhone],
    });
    expect(booking.deal?.contactId).toBe(booking.contactId);
    const tasks = await prisma.task.findMany({
      where: { bookingId: booking.id },
    });
    expect(tasks.every((task) => task.contactId === booking.contactId)).toBe(
      true,
    );
  });

  it('shows arrivals for a day and active bookings for the chessboard', async () => {
    const day = (
      await manager
        .get('/api/bookings/day')
        .query({ date: '2026-11-10' })
        .expect(200)
    ).body.data as BookingDayDto;
    expect(day.arrivals.map((b) => b.rcId)).toContain(baseId + 2);

    const range = (
      await manager
        .get('/api/bookings')
        .query({ from: '2026-11-01', to: '2026-11-30' })
        .expect(200)
    ).body.data as BookingDto[];
    const rcIds = range.map((b) => b.rcId);
    expect(rcIds).toContain(baseId + 2);
    // Отменённая бронь на шахматке не показывается.
    expect(rcIds).not.toContain(baseId + 1);
  });

  it('shows the client bookings in their card', async () => {
    const bookings = (
      await manager.get(`/api/contacts/${contactId}/bookings`).expect(200)
    ).body.data as BookingDto[];

    expect(bookings[0]).toMatchObject({
      rcId: baseId + 1,
      status: 'CANCELED',
      currency: 'USD',
    });
  });

  it('shows the webhook address only to admins', async () => {
    await manager.get('/api/integrations/realtycalendar').expect(403);
    const status = (
      await admin.get('/api/integrations/realtycalendar').expect(200)
    ).body.data;

    expect(status.webhookUrl).toBe(
      `https://crm.example.uz/api/webhooks/realtycalendar/${SECRET}`,
    );
    expect(status.bookingsCount).toBeGreaterThanOrEqual(2);
  });

  it('keeps stored values when an update brings an unreadable field', async () => {
    const rcId = baseId + 91;
    await send(
      webhook({ rcId, updatedAt: '2026-10-08T09:00:00+05:00', amount: 255 }),
    ).expect(200);
    const update = webhook({
      rcId,
      action: 'update_booking',
      updatedAt: '2026-10-08T09:30:00+05:00',
    });
    Object.assign(update.data.booking, {
      amount: { value: 999 },
      arrival_time: 'после обеда',
    });

    const response = await send(update).expect(200);
    expect(response.body.data.result).toBe('updated');
    const saved = await prisma.booking.findUniqueOrThrow({ where: { rcId } });
    expect(saved.amount?.toNumber()).toBe(255);
  });

  it('keeps a Booking.com booking that arrives in channel formats', async () => {
    const rcId = baseId + 90;
    const body = webhook({
      rcId,
      updatedAt: '2026-10-08T10:00:00+05:00',
      origin: 'Booking.com',
      fio: 'Booking Guest',
    });
    Object.assign(body.data.booking, {
      id: String(rcId),
      begin_date: '2026-12-01T00:00:00',
      end_date: '2026-12-04T00:00:00',
      arrival_time: '14:00:00',
      departure_time: '11:00-12:00',
      amount: '120,50',
    });
    // Booking.com прячет телефон гостя и даёт адрес-пересылку.
    body.data.booking.client.phone = null;
    body.data.booking.client.email = `guest-${RUN_ID}@guest.booking.com`;

    const response = await send(body).expect(200);
    expect(response.body.data.result).toBe('created');
    const saved = await prisma.booking.findUnique({ where: { rcId } });
    expect(saved).toMatchObject({
      status: 'BOOKED',
      origin: 'Booking.com',
      arrivalTime: '14:00',
      departureTime: '11:00',
    });
    expect(saved?.amount?.toNumber()).toBe(120.5);
    expect(saved?.contactId).not.toBeNull();
  });

  it('names an apartment once a booking brings its name and never renames it to an address', async () => {
    const phone = `+99893${String(RUN_ID).slice(-7)}`;
    const send2 = (
      rcId: number,
      day: string,
      apartment: object | null,
      address: string | null,
    ) => {
      const body = webhook({
        rcId,
        updatedAt: '2026-10-08T10:00:00+05:00',
        beginDate: `2027-03-${day}`,
        endDate: `2027-03-${String(Number(day) + 1).padStart(2, '0')}`,
        phone,
      });
      body.data.booking.realty_id = SPARE_PROPERTY_RC_ID;
      if (apartment) body.data.booking.apartment = apartment;
      else delete body.data.booking.apartment;
      body.data.booking.address = address;
      return send(body).expect(200);
    };
    const spare = () =>
      prisma.property.findUniqueOrThrow({
        where: { rcId: SPARE_PROPERTY_RC_ID },
      });

    // Площадка прислала бронь без квартиры: имя временное.
    await send2(baseId + 92, '01', null, null);
    expect((await spare()).title).toBe(`Объект ${SPARE_PROPERTY_RC_ID}`);

    // Первая бронь с названием квартиры заменяет временное имя.
    await send2(
      baseId + 93,
      '03',
      {
        id: SPARE_PROPERTY_RC_ID,
        title: 'U-777',
        address: 'Массив Бешагач 1/1',
      },
      null,
    );
    expect(await spare()).toMatchObject({
      title: 'U-777',
      address: 'Массив Бешагач 1/1',
    });

    // Бронь только с адресом дома не переименовывает квартиру и не стирает адрес.
    await send2(
      baseId + 94,
      '05',
      null,
      'Шайхантахурский район, массив Бешагач, 1/1',
    );
    await send2(baseId + 95, '07', null, null);
    expect(await spare()).toMatchObject({
      title: 'U-777',
      address: 'Шайхантахурский район, массив Бешагач, 1/1',
    });
  });
});

describe('RealtyCalendar Excel import (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  const contactIds: string[] = [];
  const phone = `+99897${String(Date.now()).slice(-7)}`;
  const otherPhone = `+99896${String(Date.now()).slice(-7)}`;
  const rcId = 1_000_000_000 + Math.floor(Math.random() * 900_000_000);
  const apartmentRcId = rcId + 3;
  // webhook() по умолчанию шлёт бронь в квартиру PROPERTY_RC_ID первого блока. Его afterAll её уже
  // удалил, а вебхуки этого блока заводят её заново («U-Tower <RUN_ID>» на шахматке) — убираем и её.
  const propertyRcIds = [PROPERTY_RC_ID, apartmentRcId];
  const ours = {
    OR: [
      { rcId: { in: [rcId, rcId + 1, rcId + 2] } },
      { guestPhone: { in: [phone, otherPhone] } },
    ],
  };

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
  });

  afterAll(async () => {
    const bookings = await prisma.booking.findMany({
      where: ours,
      select: { contactId: true },
    });
    const ids = bookings
      .map((b) => b.contactId)
      .filter((id): id is string => Boolean(id));
    await prisma.booking.deleteMany({ where: ours });
    await prisma.property.deleteMany({
      where: { rcId: { in: propertyRcIds } },
    });
    await prisma.task.deleteMany({ where: { contactId: { in: ids } } });
    await deleteDealsWithHistory(prisma, ids);
    await prisma.contact.deleteMany({ where: { id: { in: ids } } });
    await app.close();
  });

  it('imports a row and lets the later webhook adopt it instead of duplicating', async () => {
    const { toImportSnapshots } =
      await import('../src/realtycalendar/rc-excel.js');
    const { RealtyCalendarSyncService } =
      await import('../src/realtycalendar/realtycalendar-sync.service.js');
    const sync = app.get(RealtyCalendarSyncService);
    const row = {
      Объект: 'Массив Бешагач 1/1',
      Заезд: '20.11.2026',
      Выезд: '23.11.2026',
      Контакты: `Импорт Гость ${phone}`,
      Примечания: 'из выгрузки',
      Гостей: '',
      Сумма: '240',
      Источник: 'booking.com',
      Менеджер: 'М',
    };
    const [snapshot] = toImportSnapshots(
      [row],
      '2026-10-04',
      new Date('2026-10-04T10:00:00Z'),
    );

    expect(await sync.apply(snapshot)).toBe('created');
    expect(await sync.apply(snapshot)).toBe('updated');
    const imported = await prisma.booking.findFirstOrThrow({
      where: { guestPhone: phone },
      include: { property: true, deal: { include: { stage: true } } },
    });
    contactIds.push(imported.contactId!);
    expect(imported).toMatchObject({ rcId: null, origin: 'booking.com' });
    expect(imported.property?.title).toBe('U-Tower');
    expect(imported.deal?.stage.name).toBe('Бронь создана');

    // Вебхук приходит позже, с более ранним updated_at, чем время импорта — бронь всё равно привязывается.
    const body = webhook({
      rcId,
      updatedAt: '2026-10-01T09:00:00+05:00',
      beginDate: '2026-11-20',
      endDate: '2026-11-23',
      phone,
      fio: 'Импорт Гость',
    });
    const response = await request(app.getHttpServer())
      .post(`/api/webhooks/realtycalendar/${SECRET}`)
      .send(body)
      .expect(200);

    expect(response.body.data.result).toBe('updated');
    expect(await prisma.booking.count({ where: { guestPhone: phone } })).toBe(
      1,
    );
    const adopted = await prisma.booking.findUniqueOrThrow({
      where: { id: imported.id },
    });
    expect(adopted).toMatchObject({ rcId, dealId: imported.dealId });

    // Повторная выгрузка с той же строкой не перезаписывает бронь, которую уже ведёт вебхук.
    expect(await sync.apply(snapshot)).toBe('matched');
    const kept = await prisma.booking.findUniqueOrThrow({
      where: { id: imported.id },
    });
    expect(kept).toMatchObject({ rcId, propertyId: adopted.propertyId });
  });

  it('never adopts an export row of another guest just because the complex and dates agree', async () => {
    const { toImportSnapshots } =
      await import('../src/realtycalendar/rc-excel.js');
    const { RealtyCalendarSyncService } =
      await import('../src/realtycalendar/realtycalendar-sync.service.js');
    const sync = app.get(RealtyCalendarSyncService);
    const [row] = toImportSnapshots(
      [
        {
          Объект: 'Массив Бешагач 1/1',
          Заезд: '10.01.2027',
          Выезд: '12.01.2027',
          Контакты: `Гость Выгрузки ${phone}`,
          Примечания: '',
          Гостей: '',
          Сумма: '200',
          Источник: 'booking.com',
          Менеджер: 'М',
        },
      ],
      '2026-10-04',
      new Date('2026-10-05T10:00:00Z'),
    );
    expect(await sync.apply(row)).toBe('created');

    const other = webhook({
      rcId: rcId + 2,
      updatedAt: '2026-10-08T12:00:00+05:00',
      beginDate: '2027-01-10',
      endDate: '2027-01-12',
      phone: otherPhone,
      fio: 'Другой Гость',
    });
    other.data.booking.apartment = {
      id: apartmentRcId,
      title: 'U-13',
      address: null,
    };
    other.data.booking.realty_id = apartmentRcId;
    const response = await request(app.getHttpServer())
      .post(`/api/webhooks/realtycalendar/${SECRET}`)
      .send(other)
      .expect(200);

    expect(response.body.data.result).toBe('created');
    const imported = await prisma.booking.findFirstOrThrow({
      where: { importKey: row.importKey },
    });
    expect(imported).toMatchObject({ rcId: null, guestPhone: phone });
  });

  it('loads a finished stay from the export without check-in and check-out tasks', async () => {
    const { toImportSnapshots } =
      await import('../src/realtycalendar/rc-excel.js');
    const { RealtyCalendarSyncService } =
      await import('../src/realtycalendar/realtycalendar-sync.service.js');
    const sync = app.get(RealtyCalendarSyncService);
    const [snapshot] = toImportSnapshots(
      [
        {
          Объект: 'Массив Бешагач 1/1',
          Заезд: '01.09.2026',
          Выезд: '03.09.2026',
          Контакты: `Прошлый Гость ${phone}`,
          Примечания: '',
          Гостей: '',
          Сумма: '150',
          Источник: 'Booking.com',
          Менеджер: 'М',
        },
      ],
      '2026-09-01',
      new Date(),
    );

    expect(await sync.apply(snapshot)).toBe('created');
    const booking = await prisma.booking.findFirstOrThrow({
      where: { guestPhone: phone, checkIn: new Date('2026-09-01T00:00:00Z') },
    });
    expect(await prisma.task.count({ where: { bookingId: booking.id } })).toBe(
      0,
    );
    // Гость уже уехал: сделку на доске не заводим, бронь и клиент — есть.
    expect(booking.dealId).toBeNull();
    expect(booking.contactId).not.toBeNull();
  });

  it('never revives a canceled booking from a later export: the export has no status', async () => {
    const { toImportSnapshots } =
      await import('../src/realtycalendar/rc-excel.js');
    const { RealtyCalendarSyncService } =
      await import('../src/realtycalendar/realtycalendar-sync.service.js');
    const sync = app.get(RealtyCalendarSyncService);
    const row = {
      Объект: 'Массив Бешагач 1/1',
      Заезд: '01.12.2026',
      Выезд: '04.12.2026',
      Контакты: `Отменивший Гость ${phone}`,
      Примечания: '',
      Гостей: '',
      Сумма: '300',
      Источник: 'booking.com',
      Менеджер: 'М',
    };
    const [first] = toImportSnapshots(
      [row],
      '2026-10-04',
      new Date('2026-10-05T10:00:00Z'),
    );
    expect(await sync.apply(first)).toBe('created');
    expect(
      await sync.apply({
        ...first,
        status: 'CANCELED',
        rcUpdatedAt: new Date('2026-10-05T11:00:00Z'),
      }),
    ).toBe('updated');

    const [again] = toImportSnapshots(
      [row],
      '2026-10-04',
      new Date('2026-10-08T10:00:00Z'),
    );
    expect(again.importKey).toBe(first.importKey);
    expect(await sync.apply(again)).toBe('matched');

    const booking = await prisma.booking.findFirstOrThrow({
      where: { guestPhone: phone, checkIn: new Date('2026-12-01T00:00:00Z') },
    });
    expect(booking.status).toBe('CANCELED');
    expect(
      await prisma.task.count({
        where: { bookingId: booking.id, isDone: false },
      }),
    ).toBe(0);

    // Вебхук на те же даты и того же гостя не привязывается к отменённой строке, а заводит свою бронь.
    const response = await request(app.getHttpServer())
      .post(`/api/webhooks/realtycalendar/${SECRET}`)
      .send(
        webhook({
          rcId: rcId + 1,
          updatedAt: '2026-10-08T12:00:00+05:00',
          beginDate: '2026-12-01',
          endDate: '2026-12-04',
          phone,
          fio: 'Отменивший Гость',
        }),
      )
      .expect(200);
    expect(response.body.data.result).toBe('created');
    expect(
      await prisma.booking.findUniqueOrThrow({ where: { id: booking.id } }),
    ).toMatchObject({ rcId: null, status: 'CANCELED' });
  });
});
