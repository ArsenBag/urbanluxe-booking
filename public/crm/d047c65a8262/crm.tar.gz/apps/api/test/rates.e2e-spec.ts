/**
 * Цены и ограничения на шахматке: администратор задаёт цену, минимум ночей и закрытие продаж на ночи квартир,
 * все сотрудники видят их на шахматке. Каждое изменение пишется в журнал для менеджера каналов.
 */
import type { INestApplication } from '@nestjs/common';
import type { RatesDto, RateUpdateResultDto } from '@crm/shared';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import { RatesService } from '../src/rates/rates.service.js';
import {
  type Agent,
  createTestApp,
  createUser,
  CSRF,
  login,
  only,
} from './helpers.js';

const RUN_ID = Date.now();
const ADMIN = {
  email: `rates-admin-${RUN_ID}@test.local`,
  password: 'rates-admin-password',
};
const MANAGER = {
  email: `rates-manager-${RUN_ID}@test.local`,
  password: 'rates-manager-password',
};
const RC_BASE = 1_500_000_000 + (RUN_ID % 100_000_000);
const MISSING_ID = '00000000-0000-4000-8000-000000000000';

describe('Prices and restrictions on the chessboard (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let manager: Agent;
  let apartmentA: string;
  let apartmentB: string;

  const update = (agent: Agent, body: Record<string, unknown>) =>
    agent.put('/api/rates').set(CSRF).send(body);
  const read = async (from: string, to: string) => {
    const response = await manager.get('/api/rates').query({ from, to });
    expect(response.status).toBe(200);
    const body = response.body as { data: RatesDto };
    const mine = new Set([apartmentA, apartmentB]);
    return body.data.days.filter((day) => mine.has(day.propertyId));
  };
  const dayOf = (days: Awaited<ReturnType<typeof read>>, propertyId: string, date: string) =>
    days.find((day) => day.propertyId === propertyId && day.date === date);

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER');
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));
    apartmentA = (
      await prisma.property.create({
        data: { rcId: RC_BASE, title: `Rates-A ${RUN_ID}` },
      })
    ).id;
    apartmentB = (
      await prisma.property.create({
        data: { rcId: RC_BASE + 1, title: `Rates-B ${RUN_ID}` },
      })
    ).id;
  });

  afterAll(async () => {
    // Цены и журнал изменений удаляются вместе с квартирами (onDelete: Cascade).
    await prisma.property.deleteMany({
      where: only({ id: { in: [apartmentA, apartmentB] } }),
    });
    await prisma.user.deleteMany({
      where: { email: { in: [ADMIN.email, MANAGER.email] } },
    });
    await app.close();
  });

  it('lets only the administrator change prices', async () => {
    const response = await update(manager, {
      propertyIds: [apartmentA],
      from: '2027-11-01',
      to: '2027-11-30',
      price: 85,
    });

    expect(response.status).toBe(403);
  });

  it('sets a price on every night of the period for several apartments and logs one change per apartment', async () => {
    const response = await update(admin, {
      propertyIds: [apartmentA, apartmentB],
      from: '2027-11-01',
      to: '2027-11-30',
      price: 85,
    });

    expect(response.status).toBe(200);
    expect((response.body as { data: RateUpdateResultDto }).data.nights).toBe(60);
    const days = await read('2027-11-01', '2027-11-30');
    expect(days).toHaveLength(60);
    expect(dayOf(days, apartmentA, '2027-11-15')).toEqual({
      propertyId: apartmentA,
      date: '2027-11-15',
      price: '85.00',
      minStay: null,
      closed: false,
      closedToArrival: false,
      closedToDeparture: false,
    });
    const changes = await prisma.rateChange.findMany({
      where: { propertyId: { in: [apartmentA, apartmentB] } },
    });
    expect(changes).toHaveLength(2);
    expect(changes.every((change) => change.syncedAt === null)).toBe(true);
  });

  it('changes only the chosen weekdays (Friday and Saturday)', async () => {
    const response = await update(admin, {
      propertyIds: [apartmentA],
      from: '2027-11-01',
      to: '2027-11-14',
      weekdays: [5, 6],
      price: 95,
    });

    expect((response.body as { data: RateUpdateResultDto }).data.nights).toBe(4);
    const days = await read('2027-11-01', '2027-11-14');
    // 2027-11-05 — пятница, 2027-11-06 — суббота, 2027-11-08 — понедельник.
    expect(dayOf(days, apartmentA, '2027-11-05')?.price).toBe('95.00');
    expect(dayOf(days, apartmentA, '2027-11-06')?.price).toBe('95.00');
    expect(dayOf(days, apartmentA, '2027-11-08')?.price).toBe('85.00');
    expect(dayOf(days, apartmentB, '2027-11-05')?.price).toBe('85.00');
  });

  it('keeps the price when only the minimum stay changes, and removes the price on null', async () => {
    await update(admin, {
      propertyIds: [apartmentA],
      from: '2027-11-10',
      to: '2027-11-12',
      minStay: 3,
    });
    let days = await read('2027-11-10', '2027-11-12');
    expect(dayOf(days, apartmentA, '2027-11-11')).toMatchObject({
      price: '85.00',
      minStay: 3,
    });

    await update(admin, {
      propertyIds: [apartmentA],
      from: '2027-11-11',
      to: '2027-11-11',
      price: null,
    });
    days = await read('2027-11-10', '2027-11-12');
    expect(dayOf(days, apartmentA, '2027-11-11')).toMatchObject({
      price: null,
      minStay: 3,
    });
  });

  it('closes sales on nights that had no price yet', async () => {
    await update(admin, {
      propertyIds: [apartmentB],
      from: '2027-12-30',
      to: '2028-01-02',
      closed: true,
      closedToArrival: true,
    });

    const days = await read('2027-12-30', '2028-01-02');
    expect(days).toHaveLength(4);
    expect(dayOf(days, apartmentB, '2028-01-01')).toMatchObject({
      price: null,
      closed: true,
      closedToArrival: true,
      closedToDeparture: false,
    });
  });

  it('opens sales again with closed: false and drops nights where nothing is left', async () => {
    await update(admin, {
      propertyIds: [apartmentB],
      from: '2027-12-30',
      to: '2027-12-31',
      closed: false,
      closedToArrival: false,
    });

    const days = await read('2027-12-30', '2028-01-02');
    expect(dayOf(days, apartmentB, '2027-12-30')).toBeUndefined();
    expect(dayOf(days, apartmentB, '2028-01-01')).toMatchObject({
      closed: true,
    });
    const stored = await prisma.rateDay.count({
      where: {
        propertyId: apartmentB,
        date: { lte: new Date('2027-12-31T00:00:00.000Z') },
        closed: true,
      },
    });
    expect(stored).toBe(0);
  });

  it('does not set prices on a complex row (apartment unknown)', async () => {
    const complex = await prisma.property.create({
      data: { title: `ЖК Rates ${RUN_ID}` },
    });
    try {
      const response = await update(admin, {
        propertyIds: [complex.id],
        from: '2027-10-01',
        to: '2027-10-02',
        price: 70,
      });
      expect(response.status).toBe(400);
    } finally {
      await prisma.property.deleteMany({ where: only({ id: complex.id }) });
    }
  });

  it('replaces imported nights entirely: price and all restrictions of each night', async () => {
    const rates = app.get(RatesService);
    const night = (date: string, price: number, minStay: number | null) => ({
      date,
      price,
      minStay,
      closed: false,
      closedToArrival: minStay !== null,
      closedToDeparture: false,
    });

    await rates.replaceNights(
      apartmentA,
      [night('2028-03-01', 90, 3), night('2028-03-02', 95, null)],
      null,
    );
    let days = await read('2028-03-01', '2028-03-02');
    expect(dayOf(days, apartmentA, '2028-03-01')).toMatchObject({
      price: '90.00',
      minStay: 3,
      closedToArrival: true,
    });
    expect(dayOf(days, apartmentA, '2028-03-02')?.price).toBe('95.00');

    // Повторная загрузка заменяет ночь целиком: прежнего минимума ночей не остаётся.
    await rates.replaceNights(apartmentA, [night('2028-03-01', 92, null)], null);
    days = await read('2028-03-01', '2028-03-02');
    expect(dayOf(days, apartmentA, '2028-03-01')).toMatchObject({
      price: '92.00',
      minStay: null,
      closedToArrival: false,
    });
    const changes = await prisma.rateChange.count({
      where: {
        propertyId: apartmentA,
        from: new Date('2028-03-01T00:00:00.000Z'),
      },
    });
    expect(changes).toBe(2);
  });

  it('rejects an unknown apartment without writing anything', async () => {
    const response = await update(admin, {
      propertyIds: [apartmentA, MISSING_ID],
      from: '2027-10-01',
      to: '2027-10-02',
      price: 70,
    });

    expect(response.status).toBe(400);
    expect(await read('2027-10-01', '2027-10-02')).toEqual([]);
  });

  it('rejects a request that changes nothing and a too long window', async () => {
    const empty = await update(admin, {
      propertyIds: [apartmentA],
      from: '2027-10-01',
      to: '2027-10-02',
    });
    expect(empty.status).toBe(400);

    const window = await manager
      .get('/api/rates')
      .query({ from: '2027-01-01', to: '2027-12-31' });
    expect(window.status).toBe(400);
  });
});
