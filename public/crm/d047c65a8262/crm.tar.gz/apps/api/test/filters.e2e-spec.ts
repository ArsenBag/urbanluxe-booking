/**
 * Фильтры канбана сделок (даты создания и закрытия, ответственный, источник клиента)
 * и списка диалогов (мессенджер, сотрудник, без ответа, поиск по телефону).
 */
import type { INestApplication } from '@nestjs/common';
import type { ConversationDto, DealDto, Paginated } from '@crm/shared';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import {
  type Agent,
  createTestApp,
  createUser,
  login,
  only,
} from './helpers.js';

const RUN_ID = Date.now();
const TAG = `flt${RUN_ID}`;
const ADMIN = {
  email: `filters-admin-${RUN_ID}@test.local`,
  password: 'filters-admin-password',
};
const OTHER = {
  email: `filters-other-${RUN_ID}@test.local`,
  password: 'filters-other-password',
};
/** Случайные 9 цифр номера (не из RUN_ID: он есть в именах клиентов и нашёлся бы по имени). */
const PHONE_DIGITS = String(
  Math.floor(100_000_000 + Math.random() * 899_999_999),
);
const DAY_MS = 86_400_000;

/** Время по Ташкенту (UTC+5). */
const at = (date: string, time = '12:00') =>
  new Date(`${date}T${time}:00+05:00`);

describe('Deal board and inbox filters (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let adminId: string;
  let otherId: string;
  let pipelineId: string;
  const contactIds: string[] = [];
  const channelIds: string[] = [];
  const deals: Record<string, string> = {};
  const chats: Record<string, string> = {};

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    adminId = (await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN'))
      .id;
    otherId = (await createUser(prisma, OTHER.email, OTHER.password, 'MANAGER'))
      .id;
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    await seedDeals();
    await seedConversations();
  });

  afterAll(async () => {
    await prisma.channel.deleteMany({ where: { id: { in: channelIds } } });
    await prisma.deal.deleteMany({ where: only({ pipelineId }) });
    await prisma.pipeline.deleteMany({ where: only({ id: pipelineId }) });
    await prisma.contact.deleteMany({ where: { id: { in: contactIds } } });
    await prisma.user.deleteMany({
      where: { email: { in: [ADMIN.email, OTHER.email] } },
    });
    await app.close();
  });

  async function contact(
    name: string,
    source: 'TELEGRAM' | 'BOOKING' | 'WHATSAPP',
    phones: string[] = [],
  ) {
    const created = await prisma.contact.create({
      data: { name: `${name} ${TAG}`, source, phones },
    });
    contactIds.push(created.id);
    return created.id;
  }

  async function seedDeals() {
    const pipeline = await prisma.pipeline.create({
      data: {
        name: `Фильтры ${TAG}`,
        position: 1000,
        stages: {
          create: [
            { name: 'Новые', position: 0, kind: 'OPEN' },
            { name: 'Отказ', position: 1, kind: 'LOST' },
          ],
        },
      },
      include: { stages: { orderBy: { position: 'asc' } } },
    });
    pipelineId = pipeline.id;
    const [open, lost] = pipeline.stages.map((stage) => stage.id);
    const telegramGuest = await contact('Гость Telegram', 'TELEGRAM');
    const bookingGuest = await contact('Гость Booking', 'BOOKING');
    const deal = async (
      key: string,
      data: {
        stageId: string;
        contactId: string;
        ownerId: string | null;
        createdAt: Date;
        closedAt?: Date;
        checkIn?: Date;
      },
    ) => {
      deals[key] = (
        await prisma.deal.create({
          data: { title: key, pipelineId, position: 1, ...data },
        })
      ).id;
    };
    await deal('telegramOpen', {
      stageId: open!,
      contactId: telegramGuest,
      ownerId: adminId,
      createdAt: at('2026-09-10'),
      checkIn: new Date('2026-10-12T00:00:00Z'),
    });
    await deal('bookingOpen', {
      stageId: open!,
      contactId: bookingGuest,
      ownerId: otherId,
      createdAt: at('2026-09-20'),
      checkIn: new Date('2026-10-20T00:00:00Z'),
    });
    // Закрыта давно — на доске по умолчанию её нет.
    await deal('closedLongAgo', {
      stageId: lost!,
      contactId: telegramGuest,
      ownerId: null,
      createdAt: at('2026-08-01'),
      closedAt: at('2026-08-05'),
    });
    await deal('closedRecently', {
      stageId: lost!,
      contactId: bookingGuest,
      ownerId: adminId,
      createdAt: at('2026-07-01'),
      closedAt: new Date(Date.now() - DAY_MS),
    });
  }

  const board = async (query: Record<string, string> = {}) => {
    const response = await admin
      .get('/api/deals')
      .query({ pipelineId, ...query })
      .expect(200);
    return (response.body.data as DealDto[]).map((deal) => deal.title).sort();
  };

  it('shows open and recently closed deals by default', async () => {
    expect(await board()).toEqual([
      'bookingOpen',
      'closedRecently',
      'telegramOpen',
    ]);
  });

  it('filters by creation date in Tashkent days', async () => {
    expect(await board({ createdFrom: '2026-09-15' })).toEqual(['bookingOpen']);
    expect(
      await board({ createdFrom: '2026-09-10', createdTo: '2026-09-10' }),
    ).toEqual(['telegramOpen']);
  });

  it('finds deals closed in a period, even long ago', async () => {
    expect(
      await board({ closedFrom: '2026-08-05', closedTo: '2026-08-05' }),
    ).toEqual(['closedLongAgo']);
  });

  it('filters by owner, including deals without one', async () => {
    expect(await board({ ownerIds: adminId })).toEqual([
      'closedRecently',
      'telegramOpen',
    ]);
    expect(await board({ ownerIds: 'none', closedFrom: '2026-08-01' })).toEqual(
      ['closedLongAgo'],
    );
    expect(await board({ ownerIds: `${otherId},none` })).toEqual([
      'bookingOpen',
    ]);
  });

  it('filters by where the client came from and combines filters', async () => {
    expect(await board({ sources: 'BOOKING' })).toEqual([
      'bookingOpen',
      'closedRecently',
    ]);
    expect(await board({ sources: 'TELEGRAM', ownerIds: adminId })).toEqual([
      'telegramOpen',
    ]);
  });

  it('filters by check-in date, leaving out deals without one', async () => {
    expect(
      await board({ checkInFrom: '2026-10-10', checkInTo: '2026-10-15' }),
    ).toEqual(['telegramOpen']);
    expect(await board({ checkInFrom: '2026-10-15' })).toEqual(['bookingOpen']);
    expect(await board({ checkInTo: '2026-10-20' })).toEqual([
      'bookingOpen',
      'telegramOpen',
    ]);
  });

  it('finds deals by client name or deal title, ignoring case', async () => {
    expect(await board({ search: 'гость booking' })).toEqual([
      'bookingOpen',
      'closedRecently',
    ]);
    expect(await board({ search: 'telegramOpen' })).toEqual(['telegramOpen']);
    expect(await board({ search: 'нет такого гостя' })).toEqual([]);
  });

  it('rejects an inverted date range', async () => {
    await admin
      .get('/api/deals')
      .query({ pipelineId, createdFrom: '2026-09-02', createdTo: '2026-09-01' })
      .expect(400);
  });

  async function conversation(
    key: string,
    type: 'TELEGRAM' | 'WHATSAPP',
    assigneeId: string | null,
    phones: string[] = [],
  ) {
    const channel = await prisma.channel.create({
      data: {
        type,
        name: `Фильтры ${key}`,
        status: 'CONNECTED',
        phone: `filters-${key}-${RUN_ID}`,
      },
    });
    channelIds.push(channel.id);
    const contactId = await contact(`Собеседник ${key}`, type, phones);
    chats[key] = (
      await prisma.conversation.create({
        data: {
          channelId: channel.id,
          contactId,
          externalChatId: key,
          assigneeId,
          lastMessageAt: new Date(),
        },
      })
    ).id;
    return chats[key];
  }

  type Line = {
    dir: 'IN' | 'OUT';
    minutesAgo: number;
    status?: 'SENT' | 'FAILED';
    attachment?: object;
  };
  async function messages(conversationId: string, lines: Line[]) {
    for (const line of lines) {
      await prisma.message.create({
        data: {
          conversationId,
          direction: line.dir,
          status: line.dir === 'IN' ? 'RECEIVED' : (line.status ?? 'SENT'),
          text: line.attachment ? null : 'текст',
          attachment: line.attachment,
          sentAt: new Date(Date.now() - line.minutesAgo * 60_000),
        },
      });
    }
  }

  async function seedConversations() {
    // Гость ждёт ответа.
    await messages(
      await conversation('waWaiting', 'WHATSAPP', otherId, [
        `+998${PHONE_DIGITS}`,
      ]),
      [
        { dir: 'OUT', minutesAgo: 60 },
        { dir: 'IN', minutesAgo: 30 },
      ],
    );
    // Ответили.
    await messages(await conversation('tgAnswered', 'TELEGRAM', null), [
      { dir: 'IN', minutesAgo: 60 },
      { dir: 'OUT', minutesAgo: 30 },
    ]);
    // Последнее — принятый звонок: с гостем уже поговорили.
    await messages(await conversation('tgCalled', 'TELEGRAM', otherId), [
      { dir: 'IN', minutesAgo: 60 },
      {
        dir: 'IN',
        minutesAgo: 30,
        attachment: { kind: 'call', call: { outcome: 'answered' } },
      },
    ]);
    // Ответ не ушёл — гость по-прежнему ждёт.
    await messages(await conversation('waFailedReply', 'WHATSAPP', null), [
      { dir: 'IN', minutesAgo: 60 },
      { dir: 'OUT', minutesAgo: 30, status: 'FAILED' },
    ]);
  }

  const inbox = async (query: Record<string, string>) => {
    const response = await admin
      .get('/api/conversations')
      .query({ search: TAG, limit: '100', ...query })
      .expect(200);
    const ids = (response.body.data as Paginated<ConversationDto>).items.map(
      (item) => item.id,
    );
    return Object.keys(chats)
      .filter((key) => ids.includes(chats[key]!))
      .sort();
  };

  it('filters conversations by messenger', async () => {
    expect(await inbox({ channelType: 'WHATSAPP' })).toEqual([
      'waFailedReply',
      'waWaiting',
    ]);
    expect(await inbox({ channelType: 'TELEGRAM' })).toEqual([
      'tgAnswered',
      'tgCalled',
    ]);
  });

  it('filters conversations by a specific employee', async () => {
    expect(await inbox({ assigneeId: otherId })).toEqual([
      'tgCalled',
      'waWaiting',
    ]);
    expect(await inbox({ assigneeId: otherId, filter: 'unassigned' })).toEqual([
      'tgCalled',
      'waWaiting',
    ]);
  });

  it('shows conversations where the guest is still waiting for a reply', async () => {
    expect(await inbox({ unanswered: 'true' })).toEqual([
      'waFailedReply',
      'waWaiting',
    ]);
    expect(
      await inbox({ unanswered: 'true', channelType: 'TELEGRAM' }),
    ).toEqual([]);
  });

  it('finds a conversation by the digits of the guest phone', async () => {
    const response = await admin
      .get('/api/conversations')
      .query({ search: PHONE_DIGITS })
      .expect(200);
    const ids = (response.body.data as Paginated<ConversationDto>).items.map(
      (item) => item.id,
    );
    expect(ids).toEqual([chats.waWaiting]);
  });
});
