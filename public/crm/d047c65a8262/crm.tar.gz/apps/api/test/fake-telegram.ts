/**
 * Фейковый клиент GramJS для e2e-тестов: повторяет только используемые методы
 * и даёт тесту управлять ответами Telegram и вызывать обработчик новых сообщений.
 */
import { Raw } from 'telegram/events/index.js';

export interface FakeTelegramUser {
  className: 'User';
  id: { toString(): string };
  accessHash: { toString(): string };
  firstName?: string;
  lastName?: string;
  username?: string;
  phone?: string;
  bot: false;
  self: false;
}

export function fakeUser(
  id: string,
  firstName: string,
  extra: Partial<FakeTelegramUser> = {},
): FakeTelegramUser {
  return {
    className: 'User',
    id: { toString: () => id },
    accessHash: { toString: () => `-${id}` },
    firstName,
    bot: false,
    self: false,
    ...extra,
  };
}

export interface FakeMessage {
  className: 'Message';
  id: number;
  out: boolean;
  message: string;
  date: number;
  media?: unknown;
}

export interface FakeCall {
  id: number;
  out: boolean;
  date: number;
  duration?: number;
  video?: boolean;
  /** PhoneCallDiscardReasonMissed, …Busy, …Hangup. */
  reason?: string;
}

export const nowSeconds = () => Math.floor(Date.now() / 1000);

type Handler = (event: unknown) => Promise<void>;

const rpcError = (errorMessage: string) =>
  Object.assign(new Error(errorMessage), { errorMessage });

export class FakeTelegram {
  /** Что ответит Telegram на ввод кода и пароля. */
  codeError: string | null = null;
  passwordNeeded = false;
  wrongPassword: string | null = null;
  sendError: string | null = null;
  /** Telegram присылает эхо отправленного раньше, чем возвращается ответ на отправку (с иным текстом). */
  echoBeforeReply: { user: FakeTelegramUser; textSuffix: string } | null = null;
  dialogs: Array<{
    entity: FakeTelegramUser;
    date: number;
    pinned: boolean;
    messages: FakeMessage[];
  }> = [];

  readonly sentCodes: string[] = [];
  readonly sent: Array<{ peer: unknown; text: string }> = [];
  readonly sentFiles: Array<{
    peer: unknown;
    name: string;
    size: number;
    caption: string;
    forceDocument: boolean;
  }> = [];
  /** Что вернёт downloadMedia (содержимое вложения входящего сообщения). */
  mediaContent: Buffer = Buffer.from('fake-media');
  /** Ошибка Telegram при скачивании файла (например, FILE_REFERENCE_EXPIRED); null — скачивается. */
  mediaError: string | null = null;
  /** Сообщения, пришедшие через emit: Telegram отдаёт их по id (getMessages с ids). */
  private readonly emitted = new Map<number, FakeMessage>();
  /** Что вернёт downloadProfilePhoto: пустой буфер — фото нет или скрыто. */
  avatarContent: Buffer = Buffer.concat([
    Buffer.from([0xff, 0xd8, 0xff, 0xe0]),
    Buffer.from('fake-telegram-avatar'),
  ]);
  handler: Handler | null = null;
  /** Обработчик Raw: служебные сообщения (звонки). */
  rawHandler: Handler | null = null;
  private readonly users = new Map<string, FakeTelegramUser>();
  /** Кого Telegram найдёт по номеру (contacts.ResolvePhone): цифры номера → пользователь. */
  readonly phoneDirectory = new Map<string, FakeTelegramUser>();

  /** Пользователь, которого Telegram знает по @username (без сообщений от него). */
  addKnownUser(user: FakeTelegramUser): void {
    this.users.set(user.id.toString(), user);
  }
  private nextSentId = 9000;

  readonly factory = {
    isConfigured: true,
    credentials: { apiId: 1, apiHash: '0'.repeat(32) },
    create: () => this.client(),
  };

  /** Имитирует новое сообщение от клиента или эхо отправленного с телефона. */
  async emit(
    user: FakeTelegramUser,
    message: Omit<FakeMessage, 'className'>,
  ): Promise<void> {
    if (!this.handler)
      throw new Error('Обработчик сообщений не зарегистрирован');
    this.users.set(user.id.toString(), user);
    this.emitted.set(message.id, { className: 'Message', ...message });
    await this.handler({
      isPrivate: true,
      message: { className: 'Message', ...message, getChat: async () => user },
    });
  }

  /** Имитирует сообщение нового собеседника, пришедшее без данных о нём (getChat ничего не даёт). */
  async emitUnresolved(message: Omit<FakeMessage, 'className'>): Promise<void> {
    if (!this.handler)
      throw new Error('Обработчик сообщений не зарегистрирован');
    await this.handler({
      isPrivate: true,
      message: {
        className: 'Message',
        ...message,
        getChat: async () => undefined,
      },
    });
  }

  /** Имитирует служебное сообщение о звонке (UpdateNewMessage с MessageService). */
  async emitCall(user: FakeTelegramUser, call: FakeCall): Promise<void> {
    if (!this.rawHandler)
      throw new Error('Обработчик служебных сообщений не зарегистрирован');
    this.users.set(user.id.toString(), user);
    await this.rawHandler({
      className: 'UpdateNewMessage',
      message: {
        className: 'MessageService',
        id: call.id,
        out: call.out,
        date: call.date,
        peerId: { className: 'PeerUser', userId: user.id },
        action: {
          className: 'MessageActionPhoneCall',
          ...(call.video && { video: true }),
          ...(call.duration !== undefined && { duration: call.duration }),
          ...(call.reason && { reason: { className: call.reason } }),
        },
      },
    });
  }

  private client() {
    return {
      session: { save: () => 'fake-session-string' },
      connect: async () => undefined,
      destroy: async () => undefined,
      getMe: async () => ({
        id: { toString: () => '100500' },
        username: 'high_life_uz',
      }),
      sendCode: async (_credentials: unknown, phone: string) => {
        this.sentCodes.push(phone);
        return { phoneCodeHash: 'hash' };
      },
      invoke: async (request: { className?: string; phone?: string }) => {
        if (request.className === 'contacts.ResolvePhone') {
          const user = this.phoneDirectory.get(request.phone ?? '');
          if (!user) throw rpcError('PHONE_NOT_OCCUPIED');
          this.users.set(user.id.toString(), user);
          return { users: [user] };
        }
        if (request.className === 'auth.SignIn') {
          if (this.codeError) throw rpcError(this.codeError);
          if (this.passwordNeeded) throw rpcError('SESSION_PASSWORD_NEEDED');
        }
        return {};
      },
      signInWithPassword: async (
        _credentials: unknown,
        params: {
          password: () => Promise<string>;
          onError: (error: Error) => Promise<boolean>;
        },
      ) => {
        const password = await params.password();
        if (password === this.wrongPassword) {
          await params.onError(rpcError('PASSWORD_HASH_INVALID'));
          throw new Error('AUTH_USER_CANCEL');
        }
        return {};
      },
      addEventHandler: (handler: Handler, builder?: unknown) => {
        if (builder instanceof Raw) this.rawHandler = handler;
        else this.handler = handler;
      },
      getEntity: async (peer: string | { userId: { toString(): string } }) => {
        if (typeof peer === 'string') {
          const byName = [...this.users.values()].find(
            (user) => user.username === peer,
          );
          if (!byName) throw new Error(`No user has "${peer}" as username`);
          return byName;
        }
        const user = this.users.get(peer.userId.toString());
        if (!user) throw new Error('Собеседник не найден');
        return user;
      },
      sendMessage: async (peer: unknown, params: { message: string }) => {
        if (this.sendError) throw rpcError(this.sendError);
        this.sent.push({ peer, text: params.message });
        const id = this.nextSentId++;
        if (this.echoBeforeReply) {
          const { user, textSuffix } = this.echoBeforeReply;
          await this.emit(user, {
            id,
            out: true,
            message: `${params.message}${textSuffix}`,
            date: nowSeconds(),
          });
        }
        return { id, date: nowSeconds() };
      },
      sendFile: async (
        peer: unknown,
        params: {
          file: { name: string; size: number };
          caption: string;
          forceDocument: boolean;
        },
      ) => {
        if (this.sendError) throw rpcError(this.sendError);
        this.sentFiles.push({
          peer,
          name: params.file.name,
          size: params.file.size,
          caption: params.caption,
          forceDocument: params.forceDocument,
        });
        return { id: this.nextSentId++, date: nowSeconds() };
      },
      downloadMedia: async () => {
        if (this.mediaError) throw rpcError(this.mediaError);
        return this.mediaContent;
      },
      // Как Telegram: диалоги и сообщения — от свежих к старым.
      getDialogs: async () =>
        [...this.dialogs]
          .sort((a, b) => b.date - a.date)
          .map(({ entity, date, pinned }) => ({ entity, date, pinned })),
      getMessages: async (
        entity: FakeTelegramUser,
        params: { limit?: number; ids?: number[] },
      ) => {
        if (params.ids) return params.ids.map((id) => this.emitted.get(id));
        const dialog = this.dialogs.find((d) => d.entity === entity);
        return [...(dialog?.messages ?? [])]
          .sort((a, b) => b.date - a.date)
          .slice(0, params.limit);
      },
      downloadProfilePhoto: async () => this.avatarContent,
      iterDialogs: async function* (this: FakeTelegram) {
        for (const dialog of this.dialogs) yield dialog;
      }.bind(this),
      iterMessages: async function* (
        this: FakeTelegram,
        entity: FakeTelegramUser,
      ) {
        const dialog = this.dialogs.find((d) => d.entity === entity);
        // Telegram отдаёт от новых к старым.
        for (const message of [...(dialog?.messages ?? [])].sort(
          (a, b) => b.date - a.date,
        ))
          yield message;
      }.bind(this),
    };
  }
}
