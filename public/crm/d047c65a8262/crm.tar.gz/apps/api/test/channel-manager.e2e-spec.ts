/**
 * Менеджер каналов: у квартиры — площадки (Airbnb, Booking, Ostrovok, сайт) с ID на площадке, комиссией и
 * тарифами (наценка %, суммой, дочерний тариф от основного). Настраивает только администратор.
 */
import type { INestApplication } from '@nestjs/common';
import type { ChannelListingDto } from '@crm/shared';
import type { PrismaService } from '../src/prisma/prisma.service.js';
import {
  type Agent,
  createTestApp,
  createUser,
  CSRF,
  login,
  only,
} from './helpers.js';

const RUN_ID = Date.now();
const ADMIN = {
  email: `cm-admin-${RUN_ID}@test.local`,
  password: 'cm-admin-password',
};
const MANAGER = {
  email: `cm-manager-${RUN_ID}@test.local`,
  password: 'cm-manager-password',
};
const RC_BASE = 1_700_000_000 + (RUN_ID % 100_000_000);

describe('Channel manager settings (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let admin: Agent;
  let manager: Agent;
  let apartmentA: string;
  let apartmentB: string;
  let complexId: string;

  const save = (agent: Agent, body: Record<string, unknown>) =>
    agent.put('/api/channel-listings').set(CSRF).send(body);
  const listingOf = (response: { body: unknown }) =>
    (response.body as { data: ChannelListingDto }).data;
  const mine = async () => {
    const response = await admin.get('/api/channel-listings');
    expect(response.status).toBe(200);
    const ids = new Set([apartmentA, apartmentB]);
    return (response.body as { data: ChannelListingDto[] }).data.filter(
      (listing) => ids.has(listing.propertyId),
    );
  };

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
    await createUser(prisma, ADMIN.email, ADMIN.password, 'ADMIN');
    await createUser(prisma, MANAGER.email, MANAGER.password, 'MANAGER');
    ({ agent: admin } = await login(app, ADMIN.email, ADMIN.password));
    ({ agent: manager } = await login(app, MANAGER.email, MANAGER.password));
    apartmentA = (
      await prisma.property.create({
        data: { rcId: RC_BASE, title: `CM-A ${RUN_ID}` },
      })
    ).id;
    apartmentB = (
      await prisma.property.create({
        data: { rcId: RC_BASE + 1, title: `CM-B ${RUN_ID}` },
      })
    ).id;
    complexId = (
      await prisma.property.create({ data: { title: `ЖК CM ${RUN_ID}` } })
    ).id;
  });

  afterAll(async () => {
    // Площадки и тарифы удаляются вместе с квартирами (onDelete: Cascade).
    await prisma.property.deleteMany({
      where: only({ id: { in: [apartmentA, apartmentB, complexId] } }),
    });
    await prisma.user.deleteMany({
      where: { email: { in: [ADMIN.email, MANAGER.email] } },
    });
    await app.close();
  });

  it('is closed to managers', async () => {
    expect((await manager.get('/api/channel-listings')).status).toBe(403);
    const response = await save(manager, {
      propertyId: apartmentA,
      channel: 'BOOKING',
    });
    expect(response.status).toBe(403);
  });

  it('saves a Booking listing with a standard plan and a non-refundable child plan', async () => {
    const response = await save(admin, {
      propertyId: apartmentA,
      channel: 'BOOKING',
      externalHotelId: '17060443',
      externalRoomId: '1706044301',
      commissionPercent: 15,
      ratePlans: [
        { name: 'Standard Rate', markupKind: 'PERCENT', markupValue: 20 },
        {
          name: 'Non-refundable',
          parentIndex: 0,
          markupKind: 'PERCENT',
          markupValue: -5,
        },
      ],
    });

    expect(response.status).toBe(200);
    const listing = listingOf(response);
    expect(listing).toMatchObject({
      propertyId: apartmentA,
      channel: 'BOOKING',
      enabled: true,
      externalHotelId: '17060443',
      externalRoomId: '1706044301',
      commissionPercent: '15.00',
    });
    const [standard, child] = listing.ratePlans;
    expect(standard).toMatchObject({
      name: 'Standard Rate',
      parentId: null,
      markupValue: '20.00',
    });
    expect(child).toMatchObject({
      name: 'Non-refundable',
      parentId: standard.id,
      markupValue: '-5.00',
    });
    expect(await mine()).toHaveLength(1);
  });

  it('updates the same listing in place: keeps plan ids, drops removed plans, adds new ones', async () => {
    const [before] = await mine();
    const standardId = before.ratePlans[0].id;

    const response = await save(admin, {
      propertyId: apartmentA,
      channel: 'BOOKING',
      enabled: false,
      ratePlans: [
        {
          id: standardId,
          name: 'Standard Rate',
          markupKind: 'PERCENT',
          markupValue: 25,
        },
        {
          name: 'Weekly',
          parentIndex: 0,
          markupKind: 'AMOUNT',
          markupValue: -10,
          minNights: 7,
        },
      ],
    });

    expect(response.status).toBe(200);
    const listing = listingOf(response);
    expect(listing.id).toBe(before.id);
    expect(listing.enabled).toBe(false);
    expect(listing.externalHotelId).toBeNull();
    expect(listing.ratePlans.map((plan) => plan.name)).toEqual([
      'Standard Rate',
      'Weekly',
    ]);
    expect(listing.ratePlans[0].id).toBe(standardId);
    expect(listing.ratePlans[1]).toMatchObject({
      parentId: standardId,
      markupKind: 'AMOUNT',
      markupValue: '-10.00',
      minNights: 7,
      maxNights: 365,
    });
    const stored = await prisma.channelRatePlan.count({
      where: { listingId: before.id },
    });
    expect(stored).toBe(2);
  });

  it('keeps a child plan as a main plan when its parent is removed', async () => {
    const created = listingOf(
      await save(admin, {
        propertyId: apartmentB,
        channel: 'OSTROVOK',
        ratePlans: [
          { name: 'Стандартный', markupValue: 25 },
          { name: 'Невозвратный', parentIndex: 0, markupValue: -5 },
        ],
      }),
    );
    const childId = created.ratePlans[1].id;

    const response = await save(admin, {
      propertyId: apartmentB,
      channel: 'OSTROVOK',
      ratePlans: [{ id: childId, name: 'Невозвратный', markupValue: -5 }],
    });

    expect(response.status).toBe(200);
    expect(listingOf(response).ratePlans).toEqual([
      expect.objectContaining({ id: childId, parentId: null }),
    ]);
    await admin.delete(`/api/channel-listings/${created.id}`).set(CSRF);
  });

  it('refuses a child plan whose parent comes after it', async () => {
    const response = await save(admin, {
      propertyId: apartmentB,
      channel: 'AIRBNB',
      ratePlans: [
        { name: 'Child', parentIndex: 1 },
        { name: 'Parent' },
      ],
    });

    expect(response.status).toBe(400);
  });

  it('refuses a plan id from another listing', async () => {
    const [bookingListing] = await mine();
    const response = await save(admin, {
      propertyId: apartmentB,
      channel: 'AIRBNB',
      ratePlans: [{ id: bookingListing.ratePlans[0].id, name: 'Stolen' }],
    });

    expect(response.status).toBe(400);
    const plans = await prisma.channelRatePlan.findMany({
      where: { listingId: bookingListing.id },
    });
    expect(plans.map((plan) => plan.name)).toContain('Standard Rate');
  });

  it('refuses a complex row and an unknown apartment', async () => {
    expect(
      (await save(admin, { propertyId: complexId, channel: 'BOOKING' })).status,
    ).toBe(400);
    expect(
      (
        await save(admin, {
          propertyId: '00000000-0000-4000-8000-000000000000',
          channel: 'BOOKING',
        })
      ).status,
    ).toBe(400);
  });

  it('removes a listing with its plans', async () => {
    const saved = listingOf(
      await save(admin, {
        propertyId: apartmentB,
        channel: 'WEBSITE',
        ratePlans: [{ name: 'Прямая', markupKind: 'PERCENT', markupValue: -10 }],
      }),
    );

    const response = await admin
      .delete(`/api/channel-listings/${saved.id}`)
      .set(CSRF);

    expect(response.status).toBe(200);
    expect((await mine()).map((listing) => listing.channel)).toEqual([
      'BOOKING',
    ]);
    expect(
      await prisma.channelRatePlan.count({ where: { listingId: saved.id } }),
    ).toBe(0);
  });
});
