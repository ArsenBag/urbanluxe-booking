/**
 * Создаёт первого администратора из переменных SEED_ADMIN_*.
 * Повторный запуск безопасен: существующего пользователя не трогает.
 */
import { PrismaPg } from '@prisma/adapter-pg';
import { createUserSchema } from '@crm/shared';
import argon2 from 'argon2';
import { loadRootEnv } from '../src/config/load-root-env.js';
import { PrismaClient } from '../src/generated/prisma/client.js';

loadRootEnv();

async function main(): Promise<void> {
  const input = createUserSchema.safeParse({
    email: process.env.SEED_ADMIN_EMAIL,
    name: process.env.SEED_ADMIN_NAME,
    password: process.env.SEED_ADMIN_PASSWORD,
    role: 'ADMIN',
  });
  if (!input.success) {
    const details = input.error.issues.map((i) => `  - SEED_ADMIN_${String(i.path[0]).toUpperCase()}: ${i.message}`);
    throw new Error(`Заполните переменные первого администратора в .env:\n${details.join('\n')}`);
  }

  const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }) });
  try {
    const existing = await prisma.user.findUnique({ where: { email: input.data.email } });
    if (existing) {
      console.info(`Администратор ${existing.email} уже существует, пропускаю.`);
      return;
    }
    const passwordHash = await argon2.hash(input.data.password, { type: argon2.argon2id });
    const admin = await prisma.user.create({
      data: { email: input.data.email, name: input.data.name, role: 'ADMIN', passwordHash },
    });
    console.info(`Создан администратор ${admin.email}.`);
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
