-- «Без ответа» во входящих и отчёты отличают автосообщения от ответов сотрудников.
CREATE INDEX "automation_runs_messageId_idx" ON "automation_runs"("messageId");
