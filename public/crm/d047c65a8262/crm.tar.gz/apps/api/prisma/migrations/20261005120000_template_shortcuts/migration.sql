-- AlterTable
ALTER TABLE "reply_templates" ADD COLUMN     "shortcut" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "reply_templates_shortcut_key" ON "reply_templates"("shortcut");


-- Команды для стандартных шаблонов (если их не переименовали). По одной строке: названия не уникальны.
UPDATE "reply_templates" SET "shortcut" = 'привет' WHERE "id" = (
  SELECT "id" FROM "reply_templates" WHERE "title" = 'Приветствие' AND "shortcut" IS NULL ORDER BY "createdAt" LIMIT 1
);
UPDATE "reply_templates" SET "shortcut" = 'правила' WHERE "id" = (
  SELECT "id" FROM "reply_templates" WHERE "title" = 'Правила проживания' AND "shortcut" IS NULL ORDER BY "createdAt" LIMIT 1
);
UPDATE "reply_templates" SET "shortcut" = 'оплата' WHERE "id" = (
  SELECT "id" FROM "reply_templates" WHERE "title" = 'Способы оплаты' AND "shortcut" IS NULL ORDER BY "createdAt" LIMIT 1
);
