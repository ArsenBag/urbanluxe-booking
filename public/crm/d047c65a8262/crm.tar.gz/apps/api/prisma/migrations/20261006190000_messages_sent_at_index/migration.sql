-- Отчёты считают сообщения за период по времени в мессенджере.
CREATE INDEX "messages_sentAt_idx" ON "messages"("sentAt");
