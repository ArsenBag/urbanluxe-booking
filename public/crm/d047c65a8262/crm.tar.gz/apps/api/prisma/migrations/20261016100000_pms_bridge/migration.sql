-- Мост CRM ↔ PMS Urban Luxe (2026-10-16): брони и квартиры знают свой id в PMS, источник броней PMS.
ALTER TYPE "BookingSource" ADD VALUE IF NOT EXISTS 'PMS';

ALTER TABLE "bookings" ADD COLUMN "pmsId" TEXT,
                       ADD COLUMN "pmsSyncedAt" TIMESTAMP(3),
                       ADD COLUMN "pmsError" TEXT;
CREATE UNIQUE INDEX "bookings_pmsId_key" ON "bookings"("pmsId");

ALTER TABLE "properties" ADD COLUMN "pmsId" TEXT,
                         ADD COLUMN "pmsSyncedAt" TIMESTAMP(3);
CREATE UNIQUE INDEX "properties_pmsId_key" ON "properties"("pmsId");
