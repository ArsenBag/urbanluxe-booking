-- CreateEnum
CREATE TYPE "BookingStatus" AS ENUM ('BOOKED', 'REQUEST', 'CANCELED', 'DELETED');

-- AlterTable
ALTER TABLE "stages" ADD COLUMN     "systemKey" TEXT;

-- AlterTable
ALTER TABLE "tasks" ADD COLUMN     "autoKind" TEXT,
ADD COLUMN     "bookingId" UUID;

-- CreateTable
CREATE TABLE "properties" (
    "id" UUID NOT NULL,
    "rcId" INTEGER NOT NULL,
    "title" TEXT NOT NULL,
    "address" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "properties_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "bookings" (
    "id" UUID NOT NULL,
    "rcId" INTEGER NOT NULL,
    "propertyId" UUID,
    "contactId" UUID,
    "dealId" UUID,
    "status" "BookingStatus" NOT NULL,
    "checkIn" DATE NOT NULL,
    "checkOut" DATE NOT NULL,
    "nights" INTEGER NOT NULL,
    "arrivalTime" TEXT,
    "departureTime" TEXT,
    "amount" DECIMAL(12,2),
    "prepayment" DECIMAL(12,2),
    "deposit" DECIMAL(12,2),
    "origin" TEXT,
    "guestName" TEXT,
    "guestPhone" TEXT,
    "guestEmail" TEXT,
    "notes" TEXT,
    "rcUrl" TEXT,
    "rcUpdatedAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "bookings_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "properties_rcId_key" ON "properties"("rcId");

-- CreateIndex
CREATE UNIQUE INDEX "bookings_rcId_key" ON "bookings"("rcId");

-- CreateIndex
CREATE INDEX "bookings_checkIn_idx" ON "bookings"("checkIn");

-- CreateIndex
CREATE INDEX "bookings_checkOut_idx" ON "bookings"("checkOut");

-- CreateIndex
CREATE INDEX "bookings_propertyId_checkIn_idx" ON "bookings"("propertyId", "checkIn");

-- CreateIndex
CREATE INDEX "bookings_contactId_idx" ON "bookings"("contactId");

-- CreateIndex
CREATE UNIQUE INDEX "stages_pipelineId_systemKey_key" ON "stages"("pipelineId", "systemKey");

-- CreateIndex
CREATE UNIQUE INDEX "tasks_bookingId_autoKind_key" ON "tasks"("bookingId", "autoKind");

-- AddForeignKey
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES "bookings"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES "contacts"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES "deals"("id") ON DELETE SET NULL ON UPDATE CASCADE;


-- Этап «Бронь создана» воронки по умолчанию — цель автоматического переноса при брони из RealtyCalendar
UPDATE "stages" SET "systemKey" = 'BOOKED' WHERE "name" = 'Бронь создана' AND "systemKey" IS NULL;
