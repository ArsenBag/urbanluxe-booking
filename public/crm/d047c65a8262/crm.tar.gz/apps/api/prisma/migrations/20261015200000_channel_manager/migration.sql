-- CreateEnum
CREATE TYPE "SalesChannel" AS ENUM ('AIRBNB', 'BOOKING', 'OSTROVOK', 'WEBSITE');

-- CreateEnum
CREATE TYPE "MarkupKind" AS ENUM ('PERCENT', 'AMOUNT');

-- CreateTable
CREATE TABLE "channel_listings" (
    "id" UUID NOT NULL,
    "propertyId" UUID NOT NULL,
    "channel" "SalesChannel" NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "externalHotelId" TEXT,
    "externalRoomId" TEXT,
    "commissionPercent" DECIMAL(5,2),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "channel_listings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "channel_rate_plans" (
    "id" UUID NOT NULL,
    "listingId" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "parentId" UUID,
    "markupKind" "MarkupKind" NOT NULL DEFAULT 'PERCENT',
    "markupValue" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "minNights" INTEGER NOT NULL DEFAULT 1,
    "maxNights" INTEGER NOT NULL DEFAULT 365,
    "closed" BOOLEAN NOT NULL DEFAULT false,
    "position" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "channel_rate_plans_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "channel_listings_propertyId_channel_key" ON "channel_listings"("propertyId", "channel");

-- CreateIndex
CREATE INDEX "channel_rate_plans_listingId_position_idx" ON "channel_rate_plans"("listingId", "position");

-- AddForeignKey
ALTER TABLE "channel_listings" ADD CONSTRAINT "channel_listings_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "channel_rate_plans" ADD CONSTRAINT "channel_rate_plans_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES "channel_listings"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "channel_rate_plans" ADD CONSTRAINT "channel_rate_plans_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES "channel_rate_plans"("id") ON DELETE CASCADE ON UPDATE CASCADE;

