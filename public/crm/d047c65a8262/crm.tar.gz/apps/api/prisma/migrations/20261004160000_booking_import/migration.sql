-- AlterTable
ALTER TABLE "bookings" ADD COLUMN     "importKey" TEXT,
ALTER COLUMN "rcId" DROP NOT NULL;

-- AlterTable
ALTER TABLE "properties" ALTER COLUMN "rcId" DROP NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "bookings_importKey_key" ON "bookings"("importKey");

