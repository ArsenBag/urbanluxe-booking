-- CreateTable
CREATE TABLE "rate_days" (
    "propertyId" UUID NOT NULL,
    "date" DATE NOT NULL,
    "price" DECIMAL(12,2),
    "minStay" INTEGER,
    "closed" BOOLEAN NOT NULL DEFAULT false,
    "closedToArrival" BOOLEAN NOT NULL DEFAULT false,
    "closedToDeparture" BOOLEAN NOT NULL DEFAULT false,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "rate_days_pkey" PRIMARY KEY ("propertyId","date")
);

-- CreateTable
CREATE TABLE "rate_changes" (
    "id" UUID NOT NULL,
    "propertyId" UUID NOT NULL,
    "from" DATE NOT NULL,
    "to" DATE NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "syncedAt" TIMESTAMP(3),

    CONSTRAINT "rate_changes_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "rate_days_date_idx" ON "rate_days"("date");

-- CreateIndex
CREATE INDEX "rate_changes_syncedAt_createdAt_idx" ON "rate_changes"("syncedAt", "createdAt");

-- CreateIndex
CREATE INDEX "rate_changes_propertyId_idx" ON "rate_changes"("propertyId");

-- AddForeignKey
ALTER TABLE "rate_days" ADD CONSTRAINT "rate_days_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "rate_changes" ADD CONSTRAINT "rate_changes_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;

