-- CreateTable
CREATE TABLE "stage_automation" (
    "id" INTEGER NOT NULL DEFAULT 1,
    "enabled" BOOLEAN NOT NULL DEFAULT false,
    "checkInStageId" UUID,
    "checkInTime" TEXT NOT NULL DEFAULT '08:00',
    "checkedInStageId" UUID,
    "checkOutSoonStageId" UUID,
    "checkOutSoonTime" TEXT NOT NULL DEFAULT '19:00',
    "checkedOutStageId" UUID,
    "checkedOutTime" TEXT NOT NULL DEFAULT '12:00',
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "stage_automation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "stage_move_runs" (
    "id" UUID NOT NULL,
    "rule" TEXT NOT NULL,
    "bookingId" UUID NOT NULL,
    "date" DATE NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "stage_move_runs_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "stage_move_runs_bookingId_rule_date_key" ON "stage_move_runs"("bookingId", "rule", "date");

-- AddForeignKey
ALTER TABLE "stage_automation" ADD CONSTRAINT "stage_automation_checkInStageId_fkey" FOREIGN KEY ("checkInStageId") REFERENCES "stages"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stage_automation" ADD CONSTRAINT "stage_automation_checkedInStageId_fkey" FOREIGN KEY ("checkedInStageId") REFERENCES "stages"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stage_automation" ADD CONSTRAINT "stage_automation_checkOutSoonStageId_fkey" FOREIGN KEY ("checkOutSoonStageId") REFERENCES "stages"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stage_automation" ADD CONSTRAINT "stage_automation_checkedOutStageId_fkey" FOREIGN KEY ("checkedOutStageId") REFERENCES "stages"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stage_move_runs" ADD CONSTRAINT "stage_move_runs_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES "bookings"("id") ON DELETE CASCADE ON UPDATE CASCADE;


-- Настройки — одна строка.
ALTER TABLE "stage_automation" ADD CONSTRAINT "stage_automation_single_row" CHECK ("id" = 1);

-- Автоперенос сразу включён и привязан к воронке, куда попадают сделки по броням (первая по порядку):
-- «Заезд сегодня» и «Выезд завтра» — по названию, «Заселён» и «Выехал» — этапы прежнего автопереноса.
-- Этапа нет — правило выключено, этап выбирают в настройках.
INSERT INTO "stage_automation" ("id", "enabled", "checkInStageId", "checkedInStageId", "checkOutSoonStageId", "checkedOutStageId", "updatedAt")
SELECT
    1,
    true,
    (SELECT s."id" FROM "stages" s WHERE s."pipelineId" = p."id" AND s."kind" = 'OPEN' AND btrim(s."name") = 'Заезд сегодня' ORDER BY s."position" LIMIT 1),
    (SELECT s."id" FROM "stages" s WHERE s."pipelineId" = p."id" AND s."kind" = 'OPEN' AND s."systemKey" = 'CHECKED_IN'),
    (SELECT s."id" FROM "stages" s WHERE s."pipelineId" = p."id" AND s."kind" = 'OPEN' AND btrim(s."name") = 'Выезд завтра' ORDER BY s."position" LIMIT 1),
    (SELECT s."id" FROM "stages" s WHERE s."pipelineId" = p."id" AND s."kind" = 'OPEN' AND s."systemKey" = 'CHECKED_OUT'),
    CURRENT_TIMESTAMP
FROM (SELECT "id" FROM "pipelines" ORDER BY "position", "createdAt" LIMIT 1) AS p;
