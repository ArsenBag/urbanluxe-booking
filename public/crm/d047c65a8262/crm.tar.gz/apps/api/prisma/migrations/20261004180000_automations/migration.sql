-- AlterTable
ALTER TABLE "reply_templates" ADD COLUMN     "automation" TEXT;

-- CreateTable
CREATE TABLE "automation_runs" (
    "id" UUID NOT NULL,
    "kind" TEXT NOT NULL,
    "bookingId" UUID NOT NULL,
    "messageId" UUID,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "automation_runs_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "automation_runs_kind_bookingId_key" ON "automation_runs"("kind", "bookingId");

-- CreateIndex
CREATE UNIQUE INDEX "reply_templates_automation_key" ON "reply_templates"("automation");

-- AddForeignKey
ALTER TABLE "automation_runs" ADD CONSTRAINT "automation_runs_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES "bookings"("id") ON DELETE CASCADE ON UPDATE CASCADE;


-- Служебные роли этапов для автоматического переноса по датам брони
UPDATE "stages" SET "systemKey" = 'CHECKED_IN' WHERE "name" = 'Заселён' AND "systemKey" IS NULL;
UPDATE "stages" SET "systemKey" = 'CHECKED_OUT' WHERE "name" = 'Выехал' AND "systemKey" IS NULL;
