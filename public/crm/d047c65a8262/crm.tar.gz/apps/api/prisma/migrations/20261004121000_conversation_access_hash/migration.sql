-- AlterTable
ALTER TABLE "conversations" ADD COLUMN     "externalAccessHash" TEXT;

