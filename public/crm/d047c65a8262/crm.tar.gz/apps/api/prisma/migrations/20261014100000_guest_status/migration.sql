-- Метки гостя: VIP и чёрный список (причина, кто и когда добавил).
-- AlterTable
ALTER TABLE "contacts" ADD COLUMN     "blacklistReason" TEXT,
ADD COLUMN     "blacklistedAt" TIMESTAMP(3),
ADD COLUMN     "blacklistedById" UUID,
ADD COLUMN     "vip" BOOLEAN NOT NULL DEFAULT false;

-- CreateIndex
CREATE INDEX "contacts_blacklistedAt_idx" ON "contacts"("blacklistedAt");

-- AddForeignKey
ALTER TABLE "contacts" ADD CONSTRAINT "contacts_blacklistedById_fkey" FOREIGN KEY ("blacklistedById") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

