-- Лента уведомлений ищет новые сообщения по времени появления в CRM.
CREATE INDEX "messages_createdAt_idx" ON "messages"("createdAt");
