-- Фото профиля клиента из Telegram или WhatsApp; проверка — по каждому диалогу.
ALTER TABLE "contacts" ADD COLUMN     "avatarFileId" UUID,
ADD COLUMN     "avatarHash" TEXT,
ADD COLUMN     "avatarSource" "ChannelType";

ALTER TABLE "conversations" ADD COLUMN     "avatarCheckedAt" TIMESTAMP(3);
