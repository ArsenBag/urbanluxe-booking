-- AlterTable
ALTER TABLE "reply_templates" ADD COLUMN     "fileId" UUID;

-- CreateIndex
CREATE UNIQUE INDEX "reply_templates_fileId_key" ON "reply_templates"("fileId");

-- AddForeignKey
ALTER TABLE "reply_templates" ADD CONSTRAINT "reply_templates_fileId_fkey" FOREIGN KEY ("fileId") REFERENCES "stored_files"("id") ON DELETE SET NULL ON UPDATE CASCADE;

