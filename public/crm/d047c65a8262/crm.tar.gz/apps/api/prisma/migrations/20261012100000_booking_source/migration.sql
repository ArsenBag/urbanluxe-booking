-- CreateEnum
CREATE TYPE "BookingSource" AS ENUM ('REALTYCALENDAR', 'CRM');

-- AlterTable
ALTER TABLE "bookings" ADD COLUMN     "source" "BookingSource" NOT NULL DEFAULT 'REALTYCALENDAR';

