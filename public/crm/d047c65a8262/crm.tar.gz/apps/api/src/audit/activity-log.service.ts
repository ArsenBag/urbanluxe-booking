import { Injectable } from '@nestjs/common';
import type { ActivityDto } from '@crm/shared';
import type { SessionUser } from '../auth/session-user.js';
import { toEntityRef, USER_REF_SELECT } from '../common/entity-refs.js';
import type { Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';

export type AuditEntityType = 'user' | 'contact' | 'deal' | 'task' | 'pipeline' | 'stage' | 'channel' | 'template' | 'custom-field' | 'rates' | 'channel-listing';

export interface AuditEntry {
  action: string;
  entityType: AuditEntityType;
  entityId: string;
  payload?: Prisma.InputJsonObject;
}

type Db = Pick<Prisma.TransactionClient, 'activityLog'>;

/** Сколько последних событий показываем в истории карточки. */
const HISTORY_LIMIT = 100;

/** Журнал действий. Вызывайте внутри транзакции изменения, передавая её клиент. */
@Injectable()
export class ActivityLogService {
  constructor(private readonly prisma: PrismaService) {}

  /** actor = null — действие системы (например, входящее сообщение создало клиента). */
  async record(actor: SessionUser | null, entry: AuditEntry, db: Db = this.prisma): Promise<void> {
    await db.activityLog.create({
      data: {
        actorId: actor?.id ?? null,
        action: entry.action,
        entityType: entry.entityType,
        entityId: entry.entityId,
        payload: entry.payload,
      },
    });
  }

  /** История клиента: события по самому клиенту и по всем его сделкам. */
  async historyForContact(contactId: string): Promise<ActivityDto[]> {
    const deals = await this.prisma.deal.findMany({ where: { contactId }, select: { id: true } });
    return this.history([
      { entityType: 'contact', entityId: contactId },
      { entityType: 'deal', entityId: { in: deals.map((deal) => deal.id) } },
    ]);
  }

  async historyForDeal(dealId: string): Promise<ActivityDto[]> {
    return this.history([{ entityType: 'deal', entityId: dealId }]);
  }

  private async history(conditions: Prisma.ActivityLogWhereInput[]): Promise<ActivityDto[]> {
    const logs = await this.prisma.activityLog.findMany({
      where: { OR: conditions },
      include: { actor: USER_REF_SELECT },
      orderBy: { createdAt: 'desc' },
      take: HISTORY_LIMIT,
    });
    return logs.map((log) => ({
      id: log.id,
      action: log.action,
      entityType: log.entityType,
      entityId: log.entityId,
      actor: toEntityRef(log.actor),
      payload: (log.payload as Record<string, unknown> | null) ?? null,
      createdAt: log.createdAt.toISOString(),
    }));
  }
}
