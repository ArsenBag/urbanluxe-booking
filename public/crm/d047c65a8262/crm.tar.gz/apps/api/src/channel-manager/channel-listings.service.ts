import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import type {
  ChannelListingDto,
  ChannelListingInput,
  ChannelRatePlanDto,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import type {
  ChannelListing,
  ChannelRatePlan,
  Prisma,
} from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';

type Tx = Prisma.TransactionClient;
type ListingWithPlans = ChannelListing & { ratePlans: ChannelRatePlan[] };

const WITH_PLANS = {
  ratePlans: { orderBy: { position: 'asc' } },
} as const satisfies Prisma.ChannelListingInclude;

function toRatePlanDto(plan: ChannelRatePlan): ChannelRatePlanDto {
  return {
    id: plan.id,
    name: plan.name,
    parentId: plan.parentId,
    markupKind: plan.markupKind,
    markupValue: plan.markupValue.toFixed(2),
    minNights: plan.minNights,
    maxNights: plan.maxNights,
    closed: plan.closed,
  };
}

function toListingDto(listing: ListingWithPlans): ChannelListingDto {
  return {
    id: listing.id,
    propertyId: listing.propertyId,
    channel: listing.channel,
    enabled: listing.enabled,
    externalHotelId: listing.externalHotelId,
    externalRoomId: listing.externalRoomId,
    commissionPercent: listing.commissionPercent?.toFixed(2) ?? null,
    ratePlans: listing.ratePlans.map(toRatePlanDto),
    updatedAt: listing.updatedAt.toISOString(),
  };
}

/**
 * Площадки квартир в менеджере каналов, как в RealtyCalendar: объект → площадка → ID на площадке, комиссия
 * и тарифы с наценкой. По тарифам менеджер каналов считает цену площадки от базовой цены ночи.
 */
@Injectable()
export class ChannelListingsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
  ) {}

  async list(): Promise<ChannelListingDto[]> {
    const listings = await this.prisma.channelListing.findMany({
      include: WITH_PLANS,
      orderBy: { createdAt: 'asc' },
    });
    return listings.map(toListingDto);
  }

  /**
   * Площадка квартиры целиком: создаётся или заменяется вместе со списком тарифов.
   * actor = null — загрузка скриптом (переезд из RealtyCalendar).
   */
  async save(
    input: ChannelListingInput,
    actor: SessionUser | null,
  ): Promise<ChannelListingDto> {
    // Площадка — только у квартиры: у строк ЖК из старой выгрузки (rcId = null) квартира не определена.
    const property = await this.prisma.property.findFirst({
      where: { id: input.propertyId, rcId: { not: null } },
      select: { id: true },
    });
    if (!property) {
      throw new BadRequestException('Квартира не найдена — обновите страницу');
    }
    const listing = await this.prisma.$transaction(async (tx) => {
      const fields = {
        enabled: input.enabled,
        externalHotelId: input.externalHotelId,
        externalRoomId: input.externalRoomId,
        commissionPercent: input.commissionPercent,
      };
      const saved = await tx.channelListing.upsert({
        where: {
          propertyId_channel: {
            propertyId: input.propertyId,
            channel: input.channel,
          },
        },
        create: { propertyId: input.propertyId, channel: input.channel, ...fields },
        update: fields,
      });
      await this.replaceRatePlans(tx, saved.id, input.ratePlans);
      await this.audit.record(
        actor,
        {
          action: 'channel-listing.saved',
          entityType: 'channel-listing',
          entityId: saved.id,
          // Наценки и комиссия определяют цены на площадках — в журнале видно, кто и как их менял.
          payload: {
            propertyId: input.propertyId,
            channel: input.channel,
            enabled: input.enabled,
            commissionPercent: input.commissionPercent,
            ratePlans: input.ratePlans.map((plan) => ({
              name: plan.name,
              parentIndex: plan.parentIndex,
              markupKind: plan.markupKind,
              markupValue: plan.markupValue,
              minNights: plan.minNights,
              maxNights: plan.maxNights,
              closed: plan.closed,
            })),
          },
        },
        tx,
      );
      return tx.channelListing.findUniqueOrThrow({
        where: { id: saved.id },
        include: WITH_PLANS,
      });
    });
    return toListingDto(listing);
  }

  async remove(id: string, actor: SessionUser): Promise<void> {
    await this.prisma.$transaction(async (tx) => {
      const listing = await tx.channelListing.findUnique({ where: { id } });
      if (!listing) throw new NotFoundException('Площадка не найдена');
      await tx.channelListing.delete({ where: { id } });
      await this.audit.record(
        actor,
        {
          action: 'channel-listing.removed',
          entityType: 'channel-listing',
          entityId: id,
          payload: { propertyId: listing.propertyId, channel: listing.channel },
        },
        tx,
      );
    });
  }

  /**
   * Тарифы по списку из окна: сохранённые (с id) обновляются и сохраняют id — по нему тариф связан с тарифом
   * на площадке, — новые создаются, остальные удаляются. Родителей ставим последними: сначала все тарифы
   * становятся основными, иначе удаление прежнего родителя каскадом унесло бы тариф, который оставили.
   */
  private async replaceRatePlans(
    tx: Tx,
    listingId: string,
    plans: ChannelListingInput['ratePlans'],
  ): Promise<void> {
    const keptIds = plans.flatMap((plan) => (plan.id ? [plan.id] : []));
    const owned = await tx.channelRatePlan.count({
      where: { id: { in: keptIds }, listingId },
    });
    if (owned !== keptIds.length || new Set(keptIds).size !== keptIds.length) {
      throw new BadRequestException('Тариф не найден — обновите страницу');
    }
    const ids: string[] = [];
    // По одному: внутри транзакции Prisma запросы идут через одно соединение.
    for (const [position, plan] of plans.entries()) {
      const data = {
        name: plan.name,
        markupKind: plan.markupKind,
        markupValue: plan.markupValue,
        minNights: plan.minNights,
        maxNights: plan.maxNights,
        closed: plan.closed,
        position,
        parentId: null,
      };
      const row = plan.id
        ? await tx.channelRatePlan.update({ where: { id: plan.id }, data })
        : await tx.channelRatePlan.create({ data: { ...data, listingId } });
      ids.push(row.id);
    }
    await tx.channelRatePlan.deleteMany({
      where: { listingId, id: { notIn: ids } },
    });
    for (const [index, plan] of plans.entries()) {
      if (plan.parentIndex === null) continue;
      await tx.channelRatePlan.update({
        where: { id: ids[index] },
        data: { parentId: ids[plan.parentIndex] },
      });
    }
  }
}
