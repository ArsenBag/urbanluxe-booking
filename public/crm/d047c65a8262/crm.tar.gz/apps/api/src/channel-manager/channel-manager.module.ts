import { Module } from '@nestjs/common';
import { ChannelListingsController } from './channel-listings.controller.js';
import { ChannelListingsService } from './channel-listings.service.js';

@Module({
  controllers: [ChannelListingsController],
  providers: [ChannelListingsService],
})
export class ChannelManagerModule {}
