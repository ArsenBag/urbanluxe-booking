import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseUUIDPipe,
  Put,
} from '@nestjs/common';
import {
  channelListingInputSchema,
  type ChannelListingDto,
  type ChannelListingInput,
} from '@crm/shared';
import { CurrentUser, Roles } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { ChannelListingsService } from './channel-listings.service.js';

/** Менеджер каналов: площадки квартир и их тарифы. Только администратор — от них зависят цены на площадках. */
@Controller('channel-listings')
@Roles('ADMIN')
export class ChannelListingsController {
  constructor(private readonly listings: ChannelListingsService) {}

  @Get()
  list(): Promise<ChannelListingDto[]> {
    return this.listings.list();
  }

  @Put()
  save(
    @Body(new ZodValidationPipe(channelListingInputSchema))
    input: ChannelListingInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<ChannelListingDto> {
    return this.listings.save(input, actor);
  }

  @Delete(':id')
  remove(
    @Param('id', new ParseUUIDPipe()) id: string,
    @CurrentUser() actor: SessionUser,
  ): Promise<void> {
    return this.listings.remove(id, actor);
  }
}
