import { BadRequestException, ConflictException, NotFoundException } from '@nestjs/common';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { PasswordService } from '../auth/password.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { Prisma } from '../generated/prisma/client.js';
import type { PrismaService } from '../prisma/prisma.service.js';
import { UsersService } from './users.service.js';

const admin: SessionUser = { id: 'admin-id', email: 'a@hl.uz', name: 'Админ', role: 'ADMIN' };

const dbUser = {
  id: 'user-id',
  email: 'm@hl.uz',
  name: 'Менеджер',
  role: 'MANAGER' as const,
  passwordHash: 'secret-hash',
  isActive: true,
  createdAt: new Date('2026-10-01T10:00:00Z'),
  updatedAt: new Date('2026-10-01T10:00:00Z'),
};

function prismaError(code: string) {
  return new Prisma.PrismaClientKnownRequestError('db error', { code, clientVersion: 'test' });
}

function setup() {
  const prisma = {
    user: {
      findMany: vi.fn().mockResolvedValue([dbUser]),
      create: vi.fn().mockResolvedValue(dbUser),
      update: vi.fn().mockResolvedValue(dbUser),
      count: vi.fn().mockResolvedValue(1),
    },
    activityLog: { create: vi.fn().mockResolvedValue({}) },
    $transaction: vi.fn(),
  };
  // Транзакция в тестах выполняет колбэк на том же моке.
  prisma.$transaction.mockImplementation((callback: (tx: typeof prisma) => unknown) => callback(prisma));
  const passwords = { hash: vi.fn().mockResolvedValue('new-hash') };
  const audit = new ActivityLogService(prisma as unknown as PrismaService);
  const service = new UsersService(
    prisma as unknown as PrismaService,
    passwords as unknown as PasswordService,
    audit,
  );
  return { service, prisma, passwords };
}

describe('UsersService', () => {
  it('never exposes password hashes', async () => {
    const { service } = setup();

    const [user] = await service.list();

    expect(user).not.toHaveProperty('passwordHash');
    expect(user.createdAt).toBe('2026-10-01T10:00:00.000Z');
  });

  it('hashes password on create and writes an audit entry', async () => {
    const { service, prisma } = setup();

    await service.create({ email: dbUser.email, name: dbUser.name, password: 'longpassword', role: 'MANAGER' }, admin);

    expect(prisma.user.create.mock.calls[0][0].data).toMatchObject({ passwordHash: 'new-hash' });
    expect(prisma.user.create.mock.calls[0][0].data).not.toHaveProperty('password');
    expect(prisma.activityLog.create).toHaveBeenCalledWith({
      data: expect.objectContaining({ actorId: admin.id, action: 'user.created', entityId: dbUser.id }),
    });
  });

  it('maps duplicate email to a field-level conflict', async () => {
    const { service, prisma } = setup();
    prisma.user.create.mockRejectedValue(prismaError('P2002'));

    const attempt = service.create({ email: dbUser.email, name: 'X', password: 'longpassword', role: 'MANAGER' }, admin);

    await expect(attempt).rejects.toBeInstanceOf(ConflictException);
  });

  it('does not log the new password when it changes', async () => {
    const { service, prisma } = setup();

    await service.update(dbUser.id, { password: 'anotherpassword' }, admin);

    const payload = prisma.activityLog.create.mock.calls[0][0].data.payload;
    expect(payload).toEqual({ passwordChanged: true });
  });

  it('revokes sessions when password changes or user is blocked', async () => {
    const { service, prisma } = setup();

    await service.update(dbUser.id, { password: 'anotherpassword' }, admin);
    await service.update(dbUser.id, { isActive: false }, admin);
    await service.update(dbUser.id, { name: 'Новое имя' }, admin);

    const updates = prisma.user.update.mock.calls.map((call) => call[0].data);
    expect(updates[0]).toMatchObject({ tokenVersion: { increment: 1 } });
    expect(updates[1]).toMatchObject({ tokenVersion: { increment: 1 } });
    expect(updates[2]).not.toHaveProperty('tokenVersion');
  });

  it('refuses to demote or block the last active admin', async () => {
    const { service, prisma } = setup();
    prisma.user.count.mockResolvedValue(0);

    await expect(service.update('other-admin', { role: 'MANAGER' }, admin)).rejects.toThrow(
      'Нельзя убрать последнего активного администратора',
    );
    await expect(service.update('other-admin', { isActive: false }, admin)).rejects.toBeInstanceOf(
      BadRequestException,
    );
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('returns 404 for unknown user', async () => {
    const { service, prisma } = setup();
    prisma.user.update.mockRejectedValue(prismaError('P2025'));

    await expect(service.update('missing', { name: 'X' }, admin)).rejects.toBeInstanceOf(NotFoundException);
  });

  it('prevents admin from deactivating themselves', async () => {
    const { service } = setup();

    await expect(service.update(admin.id, { isActive: false }, admin)).rejects.toBeInstanceOf(BadRequestException);
  });

  it('prevents admin from demoting themselves', async () => {
    const { service } = setup();

    await expect(service.update(admin.id, { role: 'MANAGER' }, admin)).rejects.toBeInstanceOf(BadRequestException);
  });
});
