import type { UserDto } from '@crm/shared';
import type { User } from '../generated/prisma/client.js';

/** Превращает запись БД в DTO без хэша пароля. */
export function toUserDto(user: User): UserDto {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    isActive: user.isActive,
    createdAt: user.createdAt.toISOString(),
  };
}
