import { Body, Controller, Get, Param, ParseUUIDPipe, Patch, Post } from '@nestjs/common';
import {
  createUserSchema,
  updateUserSchema,
  type CreateUserInput,
  type UpdateUserInput,
  type UserDto,
  type UserOptionDto,
} from '@crm/shared';
import { CurrentUser, Roles } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { UsersService } from './users.service.js';

@Controller('users')
@Roles('ADMIN')
export class UsersController {
  constructor(private readonly users: UsersService) {}

  /** Список для выпадающих меню «ответственный» — нужен всем сотрудникам. */
  @Get('options')
  @Roles('ADMIN', 'MANAGER')
  listOptions(): Promise<UserOptionDto[]> {
    return this.users.listOptions();
  }

  @Get()
  list(): Promise<UserDto[]> {
    return this.users.list();
  }

  @Post()
  create(
    @Body(new ZodValidationPipe(createUserSchema)) input: CreateUserInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<UserDto> {
    return this.users.create(input, actor);
  }

  @Patch(':id')
  update(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body(new ZodValidationPipe(updateUserSchema)) input: UpdateUserInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<UserDto> {
    return this.users.update(id, input, actor);
  }
}
