import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import type { CreateUserInput, UpdateUserInput, UserDto, UserOptionDto } from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import { PasswordService } from '../auth/password.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { isPrismaError, PrismaErrorCode } from '../common/prisma-errors.js';
import { Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { toUserDto } from './user.mapper.js';

type Tx = Prisma.TransactionClient;

/** Меняет ли правка то, что должно разлогинить пользователя на всех устройствах. */
function revokesSessions(input: UpdateUserInput): boolean {
  return input.password !== undefined || input.isActive === false;
}

@Injectable()
export class UsersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly passwords: PasswordService,
    private readonly audit: ActivityLogService,
  ) {}

  async listOptions(): Promise<UserOptionDto[]> {
    return this.prisma.user.findMany({
      where: { isActive: true },
      select: { id: true, name: true },
      orderBy: { name: 'asc' },
    });
  }

  async list(): Promise<UserDto[]> {
    const users = await this.prisma.user.findMany({ orderBy: { createdAt: 'asc' } });
    return users.map(toUserDto);
  }

  async create(input: CreateUserInput, actor: SessionUser): Promise<UserDto> {
    const passwordHash = await this.passwords.hash(input.password);
    try {
      const user = await this.prisma.$transaction(async (tx) => {
        const created = await tx.user.create({
          data: { email: input.email, name: input.name, role: input.role, passwordHash },
        });
        await this.audit.record(
          actor,
          { action: 'user.created', entityType: 'user', entityId: created.id, payload: { email: created.email, role: created.role } },
          tx,
        );
        return created;
      });
      return toUserDto(user);
    } catch (error) {
      if (isPrismaError(error, PrismaErrorCode.UniqueViolation)) {
        throw new ConflictException({
          message: 'Пользователь с таким email уже существует',
          fields: { email: 'Email уже занят' },
        });
      }
      throw error;
    }
  }

  async update(id: string, input: UpdateUserInput, actor: SessionUser): Promise<UserDto> {
    this.assertNotLockingSelfOut(id, input, actor);

    const { password, ...fields } = input;
    const passwordHash = password ? await this.passwords.hash(password) : undefined;
    const data: Prisma.UserUpdateInput = {
      ...fields,
      ...(passwordHash && { passwordHash }),
      ...(revokesSessions(input) && { tokenVersion: { increment: 1 } }),
    };

    try {
      const user = await this.prisma.$transaction(
        async (tx) => {
          await this.assertAdminRemains(tx, id, input);
          const updated = await tx.user.update({ where: { id }, data });
          await this.audit.record(
            actor,
            { action: 'user.updated', entityType: 'user', entityId: id, payload: { ...fields, passwordChanged: Boolean(password) } },
            tx,
          );
          return updated;
        },
        // Serializable: два админа не смогут одновременно разжаловать друг друга.
        { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
      );
      return toUserDto(user);
    } catch (error) {
      if (isPrismaError(error, PrismaErrorCode.RecordNotFound)) {
        throw new NotFoundException('Пользователь не найден');
      }
      throw error;
    }
  }

  /** Админ не может сам себя заблокировать или понизить. */
  private assertNotLockingSelfOut(id: string, input: UpdateUserInput, actor: SessionUser): void {
    if (id !== actor.id) {
      return;
    }
    if (input.isActive === false) {
      throw new BadRequestException('Нельзя заблокировать собственную учётную запись');
    }
    if (input.role !== undefined && input.role !== actor.role) {
      throw new BadRequestException('Нельзя изменить собственную роль');
    }
  }

  /** В системе всегда должен оставаться хотя бы один активный администратор. */
  private async assertAdminRemains(tx: Tx, id: string, input: UpdateUserInput): Promise<void> {
    const removesAdmin = input.isActive === false || (input.role !== undefined && input.role !== 'ADMIN');
    if (!removesAdmin) {
      return;
    }
    const otherActiveAdmins = await tx.user.count({
      where: { role: 'ADMIN', isActive: true, id: { not: id } },
    });
    if (otherActiveAdmins === 0) {
      throw new BadRequestException('Нельзя убрать последнего активного администратора');
    }
  }
}
