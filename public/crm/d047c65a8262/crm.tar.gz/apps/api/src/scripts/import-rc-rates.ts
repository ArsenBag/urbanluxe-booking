/**
 * Перенос цен и площадок из RealtyCalendar в CRM (переезд с RC на свой менеджер каналов).
 *
 *   pnpm --filter @crm/api import:rc-rates <путь к rc-rates.json> [--dry-run]
 *
 * Файл собирает агент в браузере владельца (только чтение RC): цены по ночам на год вперёд, ограничения
 * (минимум ночей, закрыто, нет заезда/выезда) и площадки квартир — Booking, Ostrovok, Airbnb — с ID на площадке,
 * комиссией и тарифами. Квартиры сопоставляются по id RealtyCalendar (properties.rcId).
 * Ночи с сегодняшнего дня заменяются целиком; площадки из файла создаются или заменяются со всеми тарифами,
 * остальные площадки CRM не трогаются. --dry-run только показывает, что будет загружено.
 * В выводе нет данных гостей — только коды квартир и количества.
 */
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { channelListingInputSchema } from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import { tashkentToday } from '../automations/automation-schedule.js';
import { ChannelListingsService } from '../channel-manager/channel-listings.service.js';
import { loadEnv } from '../config/env.js';
import { loadRootEnv } from '../config/load-root-env.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { RatesService } from '../rates/rates.service.js';
import {
  parseRcRatesFile,
  planRcRatesImport,
  type PlannedApartment,
} from '../realtycalendar/rc-rates-file.js';

const USAGE =
  'Укажите путь к файлу: pnpm --filter @crm/api import:rc-rates ../../imports/rc-rates.json [--dry-run]';
/** Выгрузка старше суток — цены в RC могли поменяться; предупреждаем, но не запрещаем. */
const STALE_EXPORT_MS = 24 * 60 * 60 * 1000;

/** Ошибку печатаем без подробностей Prisma: в них бывают значения полей. */
function describeError(error: unknown): string {
  if (!(error instanceof Error)) return 'неизвестная ошибка';
  const code = (error as { code?: unknown }).code;
  if (error.name.startsWith('Prisma')) return `${error.name}${typeof code === 'string' ? ` ${code}` : ''}`;
  return error.message.slice(0, 300);
}

function countBy<T>(items: T[], key: (item: T) => string): string {
  const counts = new Map<string, number>();
  for (const item of items) counts.set(key(item), (counts.get(key(item)) ?? 0) + 1);
  return [...counts].map(([name, count]) => `${name} ${count}`).join(', ') || 'нет';
}

function printPlan(plan: PlannedApartment[], missing: PlannedApartment[]): void {
  const found = plan.filter((apartment) => !missing.includes(apartment));
  const nights = found.flatMap((apartment) => apartment.nights);
  const restricted = nights.filter(
    (night) => night.minStay !== null || night.closed || night.closedToArrival || night.closedToDeparture,
  );
  console.info(`Квартир в файле: ${plan.length}, найдено в CRM: ${found.length}.`);
  if (missing.length > 0) {
    console.info(`Нет в CRM (пропущены): ${missing.map((apartment) => `${apartment.title} (RC ${apartment.rcId})`).join(', ')}`);
  }
  const dates = nights.map((night) => night.date).sort();
  console.info(
    `Ночей с ценой: ${nights.length}${dates.length ? ` (${dates[0]} — ${dates[dates.length - 1]})` : ''}, из них с ограничениями: ${restricted.length}.`,
  );
  const channels = found.flatMap((apartment) => apartment.channels);
  console.info(`Площадки: ${countBy(channels, (channel) => channel.channel)}; тарифов: ${channels.reduce((sum, channel) => sum + channel.ratePlans.length, 0)}.`);
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const path = args.find((arg) => !arg.startsWith('--'));
  if (!path) throw new Error(USAGE);
  // Опечатка в --dry-run не должна превращаться в настоящую загрузку.
  const unknown = args.filter((arg) => arg.startsWith('--') && arg !== '--dry-run');
  if (unknown.length > 0) throw new Error(`Неизвестный флаг ${unknown.join(', ')}. ${USAGE}`);
  const dryRun = args.includes('--dry-run');
  loadRootEnv();
  const env = loadEnv();
  const file = parseRcRatesFile(JSON.parse(readFileSync(resolve(path), 'utf8')));
  if (file.currency !== env.RC_CURRENCY) {
    throw new Error(`Цены в файле в ${file.currency}, а базовая валюта CRM — ${env.RC_CURRENCY}`);
  }
  const plan = planRcRatesImport(file, tashkentToday(new Date()));
  if (Date.now() - Date.parse(file.exportedAt) > STALE_EXPORT_MS) {
    console.info(`Внимание: выгрузка сделана ${file.exportedAt} — больше суток назад, цены в RealtyCalendar могли измениться.`);
  }

  const prisma = new PrismaService(env);
  await prisma.$connect();
  try {
    const properties = await prisma.property.findMany({
      where: { rcId: { in: plan.map((apartment) => apartment.rcId) } },
      select: { id: true, rcId: true },
    });
    const propertyByRcId = new Map(properties.map((property) => [property.rcId, property.id]));
    const missing = plan.filter((apartment) => !propertyByRcId.has(apartment.rcId));
    printPlan(plan, missing);
    if (dryRun) {
      console.info('\nПробный запуск: в базу ничего не записано. Для загрузки запустите без --dry-run.');
      return;
    }

    const audit = new ActivityLogService(prisma);
    const rates = new RatesService(prisma, audit, env);
    const listings = new ChannelListingsService(prisma, audit);
    let nights = 0;
    let channels = 0;
    const failed: string[] = [];
    for (const apartment of plan) {
      const propertyId = propertyByRcId.get(apartment.rcId);
      if (!propertyId) continue;
      try {
        nights += await rates.replaceNights(propertyId, apartment.nights, null);
        for (const channel of apartment.channels) {
          await listings.save(channelListingInputSchema.parse({ ...channel, propertyId }), null);
          channels++;
        }
      } catch (error) {
        failed.push(`${apartment.title}: ${describeError(error)}`);
      }
    }
    console.info(`\nГотово: ночей записано ${nights}, площадок сохранено ${channels}, ошибок ${failed.length}.`);
    failed.forEach((line) => console.info(`  ошибка — ${line}`));
    if (failed.length > 0) process.exitCode = 1;
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((error: unknown) => {
  console.error(describeError(error));
  process.exit(1);
});
