/**
 * Сверка и импорт броней из выгрузки RealtyCalendar (Excel 2003 XML).
 *
 *   pnpm --filter @crm/api import:rc-excel <путь к .xls> [--dry-run] [--since=ГГГГ-ММ-ДД]
 *
 * Сначала сверяет выгрузку с CRM: какие брони уже есть (пришли вебхуком или прежней выгрузкой),
 * какие отменены в CRM, каких в CRM нет и какие брони CRM не нашлись в выгрузке. --dry-run на этом
 * останавливается. Без него добавляет недостающие брони и обновляет строки прежней выгрузки; брони из
 * вебхуков и отменённые не трогает (в выгрузке нет статуса — отменённые в ней выглядят действующими).
 * --since — с какой даты выезда сверять (по умолчанию сегодня: текущие и будущие брони).
 * В выводе нет имён и телефонов гостей — только количества и номера броней RealtyCalendar.
 */
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { ActivityLogService } from '../audit/activity-log.service.js';
import { tashkentToday } from '../automations/automation-schedule.js';
import { dateOnlyFromDb, dateOnlyToDb } from '../common/dates.js';
import { loadEnv } from '../config/env.js';
import { loadRootEnv } from '../config/load-root-env.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { BookingEffectsService } from '../realtycalendar/booking-effects.service.js';
import { complexOfProperty } from '../realtycalendar/complexes.js';
import type { BookingSnapshot } from '../realtycalendar/rc-mapper.js';
import {
  parseSpreadsheetMl,
  toImportSnapshots,
} from '../realtycalendar/rc-excel.js';
import {
  reconcileExcel,
  type CrmBookingRef,
  type MatchBasis,
  type ReconciledRow,
  type ReconcileResult,
} from '../realtycalendar/rc-reconcile.js';
import { RealtyCalendarSyncService } from '../realtycalendar/realtycalendar-sync.service.js';
import { StageAutomationSettingsService } from '../stage-automation/stage-automation-settings.service.js';
import { StageAutomationService } from '../stage-automation/stage-automation.service.js';

const DIRECT = 'вручную / не указан';
/** Сколько броней «есть в CRM, нет в выгрузке» печатать списком — остальные только числом. */
const MAX_LISTED = 30;
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const MAX_LABEL = 60;

/** Текст из выгрузки или вебхука для печати: без управляющих символов терминала и не длиннее строки. */
const printable = (value: string) => value.replace(/[\p{Cc}\p{Cf}]/gu, ' ').slice(0, MAX_LABEL);

/** Ошибку печатаем без подробностей Prisma: в них бывают значения полей, то есть данные гостей. */
function describeError(error: unknown): string {
  if (!(error instanceof Error)) return 'неизвестная ошибка';
  const code = (error as { code?: unknown }).code;
  if (error.name.startsWith('Prisma')) return `${error.name}${typeof code === 'string' ? ` ${code}` : ''}`;
  return error.message.slice(0, 300);
}

interface Options {
  file: string;
  dryRun: boolean;
  since: string;
}

function parseOptions(argv: string[]): Options {
  const file = argv.find((arg) => !arg.startsWith('--'));
  if (!file) {
    throw new Error(
      'Укажите путь к файлу: pnpm --filter @crm/api import:rc-excel ../../imports/bookings.xls [--dry-run] [--since=ГГГГ-ММ-ДД]',
    );
  }
  const since =
    argv.find((arg) => arg.startsWith('--since='))?.slice('--since='.length) ??
    tashkentToday(new Date());
  if (!DATE.test(since)) throw new Error('--since — дата в формате ГГГГ-ММ-ДД');
  return { file, dryRun: argv.includes('--dry-run'), since };
}

function countBy<T>(
  items: T[],
  key: (item: T) => string,
): Array<[string, number]> {
  const counts = new Map<string, number>();
  for (const item of items)
    counts.set(key(item), (counts.get(key(item)) ?? 0) + 1);
  return [...counts.entries()].sort((a, b) => b[1] - a[1]);
}

const printCounts = (title: string, counts: Array<[string, number]>) => {
  console.info(title);
  for (const [label, count] of counts)
    console.info(`  ${count.toString().padStart(4)}  ${label}`);
};

/** Брони CRM любого статуса с выездом не раньше since и заездом не позже последнего в выгрузке. */
async function loadCrmBookings(
  prisma: PrismaService,
  since: string,
  lastCheckIn: string,
): Promise<CrmBookingRef[]> {
  const bookings = await prisma.booking.findMany({
    where: {
      checkOut: { gte: dateOnlyToDb(since) },
      checkIn: { lte: dateOnlyToDb(lastCheckIn) },
      // Брони, внесённые в CRM и ещё не пришедшие из RealtyCalendar, в выгрузке быть не может:
      // иначе строка пропущенной брони RC сошлась бы с ними по ЖК и датам и не загрузилась.
      NOT: { source: 'CRM', rcId: null },
    },
    include: {
      property: { select: { title: true, address: true, rcId: true } },
    },
    orderBy: [{ checkIn: 'asc' }, { rcId: 'asc' }],
  });
  return bookings.map((booking) => ({
    id: booking.id,
    rcId: booking.rcId,
    importKey: booking.importKey,
    checkIn: dateOnlyFromDb(booking.checkIn),
    checkOut: dateOnlyFromDb(booking.checkOut),
    guestPhone: booking.guestPhone,
    complex: booking.property ? complexOfProperty(booking.property) : null,
    origin: booking.origin,
    status: booking.status,
  }));
}

const BASIS_LABEL: Record<MatchBasis, string> = {
  key: 'та же строка',
  phone: 'тот же телефон',
  complex: 'только ЖК и даты — проверьте',
};

/** Бронь без данных гостя: даты, ЖК, площадка — по ним её находят в шахматке RealtyCalendar. */
const describeRow = (snapshot: BookingSnapshot) =>
  `${snapshot.checkIn} → ${snapshot.checkOut}  ${printable(snapshot.property?.title ?? 'ЖК не указан')}  ${printable(snapshot.origin ?? DIRECT)}`;

const upcomingOf = (rows: ReconciledRow[], today: string) =>
  rows
    .filter((row) => row.snapshot.checkOut >= today)
    .toSorted((a, b) => a.snapshot.checkIn.localeCompare(b.snapshot.checkIn));

function printList(title: string, rows: ReconciledRow[], line: (row: ReconciledRow) => string): void {
  if (rows.length === 0) return;
  console.info(title);
  for (const row of rows.slice(0, MAX_LISTED)) console.info(`  ${line(row)}`);
  if (rows.length > MAX_LISTED) console.info(`  …и ещё ${rows.length - MAX_LISTED}`);
}

/** Недостающие брони: уехавшие — числом, текущие и будущие — списком, чтобы сверить их с RealtyCalendar. */
function printMissing(missing: ReconciledRow[], today: string): void {
  const upcoming = upcomingOf(missing, today);
  console.info(
    `Из них уже выехали ${missing.length - upcoming.length}, живут сейчас или заедут ${upcoming.length}.`,
  );
  printCounts(
    'Нет в CRM, по площадкам:',
    countBy(missing, (row) => printable(row.snapshot.origin ?? DIRECT)),
  );
  printList('Живут сейчас или заедут (заезд → выезд, ЖК, площадка):', upcoming, (row) => describeRow(row.snapshot));
}

/**
 * Строки, совпавшие с отменённой бронью CRM: не загружаются. Текущие и будущие — списком с признаком
 * совпадения: «только ЖК и даты» — слабый признак, такую бронь стоит проверить в RealtyCalendar.
 */
function printCanceled(canceled: ReconciledRow[], today: string): void {
  console.info('Отменённые не загружаются: в выгрузке нет статуса, отменённые брони в ней выглядят действующими.');
  printList(
    'Отменены в CRM, живут сейчас или заедут (заезд → выезд, ЖК, площадка, совпадение):',
    upcomingOf(canceled, today),
    (row) => `${describeRow(row.snapshot)}  (${row.basis ? BASIS_LABEL[row.basis] : '—'})`,
  );
}

function printReconciliation(result: ReconcileResult, today: string): void {
  const missing = result.rows.filter((row) => row.kind === 'new');
  const canceled = result.rows.filter((row) => row.kind === 'canceled');
  const found = result.rows.filter((row) => row.kind === 'known' || row.kind === 'matched');
  const viaWebhook = found.filter((row) => row.viaWebhook).length;
  console.info(
    `\nСверка с CRM: уже есть ${found.length} (по вебхуку ${viaWebhook}, из прежней выгрузки ${found.length - viaWebhook}), ` +
      `отменены в CRM ${canceled.length}, нет в CRM ${missing.length}.`,
  );
  if (canceled.length > 0) printCanceled(canceled, today);
  if (missing.length > 0) printMissing(missing, today);
  if (result.missingInExcel.length === 0) return;
  console.info(
    `\nЕсть в CRM, но нет в выгрузке: ${result.missingInExcel.length} (возможно, отменены в RealtyCalendar, а вебхук не дошёл).`,
  );
  printCounts(
    'По площадкам:',
    countBy(result.missingInExcel, (booking) => printable(booking.origin ?? DIRECT)),
  );
  for (const booking of result.missingInExcel.slice(0, MAX_LISTED)) {
    console.info(
      `  RC ${booking.rcId ?? '— (выгрузка)'}  ${booking.checkIn} → ${booking.checkOut}  ${printable(booking.complex ?? 'ЖК не определён')}`,
    );
  }
  if (result.missingInExcel.length > MAX_LISTED)
    console.info(`  …и ещё ${result.missingInExcel.length - MAX_LISTED}`);
}

/** Добавляет недостающие брони и обновляет строки прежней выгрузки; брони из вебхуков пропускает. */
async function applyRows(
  sync: RealtyCalendarSyncService,
  snapshots: BookingSnapshot[],
): Promise<void> {
  const outcomes = { created: 0, updated: 0, stale: 0, matched: 0, failed: 0 };
  for (const [index, snapshot] of snapshots.entries()) {
    try {
      outcomes[await sync.apply(snapshot)] += 1;
    } catch (error) {
      // Одна бронь не должна останавливать сверку: даты, ЖК и площадка — чтобы найти её в RealtyCalendar.
      outcomes.failed += 1;
      console.error(`  ${describeRow(snapshot)}: ${describeError(error)}`);
    }
    if ((index + 1) % 50 === 0)
      console.info(`  загружено ${index + 1} из ${snapshots.length}…`);
  }
  console.info(
    `\nГотово: новых броней ${outcomes.created}, обновлено ${outcomes.updated}, уже вели вебхуки или отменены ${outcomes.matched}, ошибок ${outcomes.failed}.`,
  );
}

async function main(): Promise<void> {
  const options = parseOptions(process.argv.slice(2));
  loadRootEnv();
  const env = loadEnv();
  const rows = parseSpreadsheetMl(readFileSync(resolve(options.file), 'utf8'));
  const snapshots = toImportSnapshots(rows, options.since, new Date());
  console.info(
    `Строк в файле: ${rows.length}. С выездом ${options.since} или позже: ${snapshots.length}.`,
  );
  printCounts(
    'По площадкам:',
    countBy(snapshots, (s) => printable(s.origin ?? DIRECT)),
  );
  if (snapshots.length === 0) return;

  const prisma = new PrismaService(env);
  await prisma.$connect();
  try {
    const lastCheckIn = snapshots
      .map((s) => s.checkIn)
      .reduce((max, day) => (day > max ? day : max));
    const result = reconcileExcel(
      snapshots,
      await loadCrmBookings(prisma, options.since, lastCheckIn),
    );
    printReconciliation(result, tashkentToday(new Date()));
    if (options.dryRun) {
      console.info(
        '\nПробный запуск: в базу ничего не записано. Для загрузки запустите без --dry-run.',
      );
      return;
    }
    const toApply = result.rows
      .filter((row) => row.kind === 'known' || row.kind === 'new')
      .map((row) => row.snapshot);
    const audit = new ActivityLogService(prisma);
    await applyRows(
      new RealtyCalendarSyncService(
        prisma,
        new BookingEffectsService(audit, env),
        new StageAutomationService(
          prisma,
          audit,
          new StageAutomationSettingsService(prisma, audit),
          env,
        ),
      ),
      toApply,
    );
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((error: unknown) => {
  console.error(describeError(error));
  process.exit(1);
});
