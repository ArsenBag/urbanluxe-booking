import { Injectable, Logger } from '@nestjs/common';
import {
  canFetchAttachment,
  CHANNEL_TYPE_LABELS,
  isAnsweredCall,
  isMissedCall,
  messagePreview,
  POSITION_STEP,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import { PREFER_BLACKLISTED_ORDER } from '../contacts/guest-blacklist.js';
import type { Channel, Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { AttachmentFetchService } from './attachment-fetch.service.js';
import { AvatarService } from './avatar.service.js';
import { lockPeer } from './peer-lock.js';
import type {
  IncomingMessage,
  IngestOptions,
  MessengerPeer,
} from './messenger.types.js';
import { displayNameOf, phonesOf } from './peer-name.js';

type Tx = Prisma.TransactionClient;

/** Окно, в котором исходящее «эхо» из мессенджера сопоставляется с сообщением, отправленным из CRM. */
const ECHO_MATCH_WINDOW_MS = 2 * 60_000;
const MAX_ECHO_CANDIDATES = 20;
/** Не больше стольких автоматических сделок за окно — защита от спама в Telegram. */
const MAX_AUTO_DEALS_PER_WINDOW = 30;
const AUTO_DEAL_WINDOW_MS = 60 * 60_000;
/** Задача «Перезвонить» на пропущенный звонок: autoKind и срок от времени звонка. */
const CALLBACK_TASK_KIND = 'callback';
const CALLBACK_DUE_MS = 60 * 60_000;
/** Не больше стольких задач «Перезвонить» за окно — защита от обзвона спамерами с разных номеров. */
const MAX_CALLBACK_TASKS_PER_WINDOW = 30;
const CALLBACK_WINDOW_MS = 60 * 60_000;

export interface IngestResult {
  conversationId: string;
  /** false — такое сообщение уже было (повтор события). */
  isNew: boolean;
  contactCreated: boolean;
  dealCreated: boolean;
}

/** Приём сообщений из мессенджеров: клиент, диалог, сообщение и (для новых клиентов) сделка. */
@Injectable()
export class InboxIngestService {
  private readonly logger = new Logger(InboxIngestService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
    private readonly attachments: AttachmentFetchService,
    private readonly avatars: AvatarService,
  ) {}

  async ingest(
    message: IncomingMessage,
    options: IngestOptions,
  ): Promise<IngestResult> {
    const { result, messageId } = await this.store(message, options);
    // Файл качаем после коммита: долгая загрузка не держит транзакцию и блокировку собеседника.
    // Не скачался или ссылки в событии не было — повторяем в фоне по id сообщения в мессенджере.
    if (
      messageId &&
      !options.history &&
      canFetchAttachment(message.attachment)
    ) {
      const settled = message.download
        ? await this.attachFile(messageId, message)
        : false;
      if (!settled) this.attachments.retryLater(messageId);
    }
    // Фото профиля — в фоне, через общую очередь: ответ вебхуку и приём сообщений его не ждут.
    if (result.isNew && !options.history) {
      void this.avatars.refresh(result.conversationId);
    }
    return result;
  }

  private async store(
    message: IncomingMessage,
    options: IngestOptions,
  ): Promise<{ result: IngestResult; messageId: string | null }> {
    return this.prisma.$transaction(async (tx) => {
      // Сообщения одного собеседника обрабатываем строго по очереди: иначе два первых сообщения
      // нового клиента одновременно создают клиента/диалог и второе падает на уникальном ключе.
      await lockPeer(tx, message.peer.externalId);
      const channel = await tx.channel.findUniqueOrThrow({
        where: { id: message.channelId },
      });
      const { contactId, contactCreated } = await this.resolveContact(
        tx,
        channel,
        message,
      );
      const conversation = await tx.conversation.upsert({
        where: {
          channelId_externalChatId: {
            channelId: channel.id,
            externalChatId: message.externalChatId,
          },
        },
        create: {
          channelId: channel.id,
          contactId,
          externalChatId: message.externalChatId,
          externalAccessHash: message.peer.accessHash ?? null,
        },
        update: message.peer.accessHash
          ? { externalAccessHash: message.peer.accessHash }
          : {},
      });

      const messageId = await this.storeMessage(tx, conversation.id, message);
      const isNew = messageId !== null;
      if (!isNew) {
        return {
          result: {
            conversationId: conversation.id,
            isNew,
            contactCreated,
            dealCreated: false,
          },
          messageId,
        };
      }
      await this.touchConversation(tx, conversation, message, options);
      const dealCreated =
        contactCreated &&
        !options.history &&
        message.direction === 'IN' &&
        (await this.createInboundDeal(tx, contactId));
      if (
        !options.history &&
        isMissedCall(message.direction, message.attachment)
      ) {
        await this.createCallbackTask(
          tx,
          channel,
          conversation,
          contactId,
          message.sentAt,
        );
      }
      return {
        result: {
          conversationId: conversation.id,
          isNew,
          contactCreated,
          dealCreated,
        },
        messageId,
      };
    });
  }

  /**
   * Скачивает вложение и привязывает файл к сообщению. Ошибка не мешает приёму: сообщение уже
   * сохранено и показывается с отметкой о вложении. false — не скачалось, стоит повторить;
   * true — сохранено или файл больше 20 МБ (повтор не поможет).
   */
  private async attachFile(
    messageId: string,
    message: IncomingMessage,
  ): Promise<boolean> {
    try {
      const media = await message.download?.();
      if (media && message.attachment) {
        await this.attachments.attach(messageId, message.attachment, media);
      }
      return true;
    } catch (error) {
      this.logger.warn(
        `Не удалось сохранить вложение сообщения ${messageId}: ${error instanceof Error ? error.message : String(error)}`,
      );
      return false;
    }
  }

  private async resolveContact(
    tx: Tx,
    channel: Channel,
    message: IncomingMessage,
  ) {
    const existing = await tx.contactChannel.findUnique({
      where: {
        type_externalId: {
          type: channel.type,
          externalId: message.peer.externalId,
        },
      },
    });
    if (existing) {
      if (
        message.peer.username &&
        message.peer.username !== existing.username
      ) {
        await tx.contactChannel.update({
          where: { id: existing.id },
          data: { username: message.peer.username },
        });
      }
      await this.replacePhoneName(tx, existing.contactId, message.peer);
      return { contactId: existing.contactId, contactCreated: false };
    }

    // Клиент уже есть в CRM с этим телефоном (из брони, другого мессенджера, вручную) —
    // привязываем к нему новый аккаунт, а не заводим дубль.
    const [phone] = phonesOf(message.peer);
    const knownByPhone = phone
      ? await tx.contact.findFirst({
          where: { phones: { has: phone } },
          orderBy: PREFER_BLACKLISTED_ORDER,
          select: { id: true },
        })
      : null;
    if (knownByPhone) {
      await tx.contactChannel.create({
        data: {
          contactId: knownByPhone.id,
          type: channel.type,
          externalId: message.peer.externalId,
          username: message.peer.username ?? null,
          displayName: displayNameOf(message.peer),
        },
      });
      return { contactId: knownByPhone.id, contactCreated: false };
    }

    const contact = await tx.contact.create({
      data: {
        name: displayNameOf(message.peer),
        phones: phonesOf(message.peer),
        source: channel.type,
        channels: {
          create: {
            type: channel.type,
            externalId: message.peer.externalId,
            username: message.peer.username ?? null,
            displayName: displayNameOf(message.peer),
          },
        },
      },
    });
    await this.audit.record(
      null,
      {
        action: 'contact.created',
        entityType: 'contact',
        entityId: contact.id,
        payload: { via: channel.type },
      },
      tx,
    );
    return { contactId: contact.id, contactCreated: true };
  }

  /**
   * Клиент, заведённый по звонку WhatsApp, получает вместо имени номер: имени звонящего Green-API
   * не сообщает. Когда мессенджер пришлёт имя, ставим его в карточку и автосделку. Имя, которое
   * сотрудник уже поменял, не трогаем.
   */
  private async replacePhoneName(
    tx: Tx,
    contactId: string,
    peer: MessengerPeer,
  ): Promise<void> {
    const realName = displayNameOf(peer);
    const phoneName = displayNameOf({
      externalId: peer.externalId,
      ...(peer.phone && { phone: peer.phone }),
    });
    if (realName === phoneName) return;
    const renamed = await tx.contact.updateMany({
      where: { id: contactId, name: phoneName },
      data: { name: realName },
    });
    if (renamed.count === 0) return;
    await tx.deal.updateMany({
      where: { contactId, title: phoneName },
      data: { title: realName },
    });
  }

  /** Сохраняет сообщение и возвращает его id. null — дубликат (повтор события или эхо отправленного из CRM). */
  private async storeMessage(
    tx: Tx,
    conversationId: string,
    message: IncomingMessage,
  ): Promise<string | null> {
    const duplicate = await tx.message.findUnique({
      where: {
        conversationId_externalId: {
          conversationId,
          externalId: message.externalMessageId,
        },
      },
      select: { id: true },
    });
    if (duplicate) return null;

    // Звонок не может быть эхом сообщения, отправленного из CRM.
    if (
      message.direction === 'OUT' &&
      message.attachment?.kind !== 'call' &&
      (await this.attachEcho(tx, conversationId, message))
    ) {
      return null;
    }

    const created = await tx.message.create({
      data: {
        conversationId,
        direction: message.direction,
        status: message.direction === 'IN' ? 'RECEIVED' : 'SENT',
        externalId: message.externalMessageId,
        text: message.text,
        attachment: message.attachment
          ? ({ ...message.attachment } satisfies Prisma.InputJsonObject)
          : undefined,
        sentAt: message.sentAt,
      },
      select: { id: true },
    });
    return created.id;
  }

  /**
   * Мессенджер присылает событие и о сообщениях, которые мы сами отправили из CRM.
   * Если такое сообщение ещё ждёт свой внешний id — привязываем, а не создаём копию.
   */
  private async attachEcho(
    tx: Tx,
    conversationId: string,
    message: IncomingMessage,
  ): Promise<boolean> {
    const candidates = await tx.message.findMany({
      where: {
        conversationId,
        direction: 'OUT',
        externalId: null,
        createdAt: { gte: new Date(Date.now() - ECHO_MATCH_WINDOW_MS) },
      },
      orderBy: { createdAt: 'asc' },
      take: MAX_ECHO_CANDIDATES,
    });
    // Telegram может убрать пробелы по краям — сравниваем без них.
    const echoText = message.text?.trim() ?? '';
    // Файл без подписи не должен совпасть с текстом или стикером без подписи, отправленным с телефона.
    const pending = candidates.find(
      (candidate) =>
        (candidate.text?.trim() ?? '') === echoText &&
        Boolean(candidate.attachment) === Boolean(message.attachment),
    );
    if (!pending) return false;
    await tx.message.update({
      where: { id: pending.id },
      data: {
        externalId: message.externalMessageId,
        status: 'SENT',
        error: null,
        sentAt: message.sentAt,
      },
    });
    return true;
  }

  private async touchConversation(
    tx: Tx,
    conversation: { id: string; lastMessageAt: Date | null; status: string },
    message: IncomingMessage,
    options: IngestOptions,
  ): Promise<void> {
    const isLatest =
      !conversation.lastMessageAt ||
      message.sentAt >= conversation.lastMessageAt;
    // Принятый звонок внимания не требует: с клиентом уже поговорили.
    const needsAttention =
      message.direction === 'IN' &&
      !options.history &&
      !isAnsweredCall(message.attachment);
    await tx.conversation.update({
      where: { id: conversation.id },
      data: {
        ...(isLatest && {
          lastMessageAt: message.sentAt,
          lastMessagePreview: messagePreview(message.text, message.attachment, {
            direction: message.direction,
          }),
        }),
        ...(needsAttention && {
          unreadCount: { increment: 1 },
          status: 'OPEN',
        }),
      },
    });
  }

  /**
   * Задача «Перезвонить» на пропущенный звонок. Пока она открыта, новые пропущенные того же
   * клиента задач не множат. Исполнитель — ответственный за диалог, иначе — за открытую сделку.
   */
  private async createCallbackTask(
    tx: Tx,
    channel: Channel,
    conversation: { assigneeId: string | null },
    contactId: string,
    calledAt: Date,
  ): Promise<void> {
    const open = await tx.task.findFirst({
      where: { contactId, autoKind: CALLBACK_TASK_KIND, isDone: false },
      select: { id: true },
    });
    if (open || (await this.callbackLimitReached(tx))) return;
    const contact = await tx.contact.findUniqueOrThrow({
      where: { id: contactId },
      select: { name: true },
    });
    const deal = await tx.deal.findFirst({
      where: { contactId, closedAt: null },
      orderBy: { createdAt: 'desc' },
      select: { id: true, ownerId: true },
    });
    const task = await tx.task.create({
      data: {
        title: `Перезвонить в ${CHANNEL_TYPE_LABELS[channel.type]}: ${contact.name}`,
        dueAt: new Date(calledAt.getTime() + CALLBACK_DUE_MS),
        assigneeId: conversation.assigneeId ?? deal?.ownerId ?? null,
        contactId,
        dealId: deal?.id ?? null,
        autoKind: CALLBACK_TASK_KIND,
      },
    });
    await this.audit.record(
      null,
      {
        action: 'task.created',
        ...(deal
          ? { entityType: 'deal' as const, entityId: deal.id }
          : { entityType: 'contact' as const, entityId: contactId }),
        payload: { taskId: task.id, title: task.title, auto: true },
      },
      tx,
    );
  }

  private async callbackLimitReached(tx: Tx): Promise<boolean> {
    const recent = await tx.task.count({
      where: {
        autoKind: CALLBACK_TASK_KIND,
        createdAt: { gte: new Date(Date.now() - CALLBACK_WINDOW_MS) },
      },
    });
    if (recent < MAX_CALLBACK_TASKS_PER_WINDOW) return false;
    this.logger.warn(
      'Лимит задач «Перезвонить» за час исчерпан — задача на пропущенный звонок не создана',
    );
    return true;
  }

  /** Сделка для нового клиента — в первом этапе первой воронки («Новое обращение»). */
  private async createInboundDeal(tx: Tx, contactId: string): Promise<boolean> {
    // Защита от спама: при наплыве новых «клиентов» клиенты создаются, а канбан не засоряется.
    const recentAutoDeals = await tx.activityLog.count({
      where: {
        action: 'deal.created',
        // Именно флаг auto: у записей удалённых сотрудников actorId тоже становится null.
        payload: { path: ['auto'], equals: true },
        createdAt: { gte: new Date(Date.now() - AUTO_DEAL_WINDOW_MS) },
      },
    });
    if (recentAutoDeals >= MAX_AUTO_DEALS_PER_WINDOW) {
      this.logger.warn(
        'Лимит автоматических сделок за час исчерпан — сделка для нового клиента не создана',
      );
      return false;
    }
    const stage = await tx.stage.findFirst({
      where: { kind: 'OPEN' },
      orderBy: [{ pipeline: { position: 'asc' } }, { position: 'asc' }],
    });
    if (!stage) {
      this.logger.warn(
        'Нет открытого этапа в воронках — сделка для нового клиента не создана',
      );
      return false;
    }
    const contact = await tx.contact.findUniqueOrThrow({
      where: { id: contactId },
      select: { name: true },
    });
    const last = await tx.deal.findFirst({
      where: { stageId: stage.id },
      orderBy: { position: 'desc' },
      select: { position: true },
    });
    const deal = await tx.deal.create({
      data: {
        title: contact.name,
        pipelineId: stage.pipelineId,
        stageId: stage.id,
        contactId,
        position: (last?.position ?? 0) + POSITION_STEP,
      },
    });
    await this.audit.record(
      null,
      {
        action: 'deal.created',
        entityType: 'deal',
        entityId: deal.id,
        payload: { title: deal.title, contactId, auto: true },
      },
      tx,
    );
    return true;
  }
}
