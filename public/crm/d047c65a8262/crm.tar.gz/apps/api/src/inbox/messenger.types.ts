import type { AttachmentKind, MessageAttachment } from '@crm/shared';
import type { ChannelType } from '../generated/prisma/client.js';

/** Собеседник (клиент) в мессенджере. */
export interface MessengerPeer {
  externalId: string;
  firstName?: string;
  lastName?: string;
  username?: string;
  /** Телефон, если мессенджер его отдаёт (в Telegram — только для контактов). */
  phone?: string;
  /** Ключ доступа к собеседнику для отправки после перезапуска (Telegram access_hash). */
  accessHash?: string;
}

/**
 * Сообщение, приведённое к общему виду из любого мессенджера.
 * OUT — исходящее, отправленное с телефона или другого устройства, не из CRM.
 */
export interface IncomingMessage {
  channelId: string;
  externalChatId: string;
  externalMessageId: string;
  direction: 'IN' | 'OUT';
  text: string | null;
  attachment: MessageAttachment | null;
  sentAt: Date;
  peer: MessengerPeer;
  /**
   * Скачивание вложения из мессенджера. Вызывается только для новых живых сообщений
   * (не при импорте истории) и только после сохранения сообщения.
   */
  download?: () => Promise<DownloadedMedia | null>;
}

/** Скачанный файл вложения. null из download — файл слишком большой или недоступен. */
export interface DownloadedMedia {
  buffer: Buffer;
  mimeType: string | null;
  fileName: string | null;
}

export interface IngestOptions {
  /** Импорт истории: не создаём сделки, не увеличиваем счётчик непрочитанных. */
  history: boolean;
}

export interface OutboundMessage {
  channelId: string;
  externalChatId: string;
  externalAccessHash: string | null;
  /** Текст сообщения или подпись к файлу (может быть пустой у файла). */
  text: string;
  file: OutboundFile | null;
}

export interface OutboundFile {
  buffer: Buffer;
  fileName: string;
  mimeType: string;
  kind: AttachmentKind;
}

export interface SentMessage {
  externalMessageId: string;
  sentAt: Date;
}

/** Собеседник, чьё фото профиля запрашиваем. */
export interface AvatarTarget {
  channelId: string;
  externalChatId: string;
  externalAccessHash: string | null;
}

/** Кому пишем первыми: телефон из карточки клиента или @username в Telegram. */
export interface RecipientQuery {
  channelId: string;
  phone: string | null;
  username: string | null;
}

/** Собеседник, найденный в мессенджере по телефону или @username. */
export interface Recipient {
  externalChatId: string;
  externalAccessHash: string | null;
  peer: MessengerPeer;
}

/** Сохранённое сообщение, файл которого скачиваем из мессенджера заново. */
export interface AttachmentTarget {
  channelId: string;
  externalChatId: string;
  externalAccessHash: string | null;
  externalMessageId: string;
  attachment: MessageAttachment;
}

/** Отправка сообщений и фото профиля в конкретном мессенджере. Реализуется модулем мессенджера. */
export interface MessengerSender {
  readonly type: ChannelType;
  send(message: OutboundMessage): Promise<SentMessage>;
  /** Маленькое фото профиля собеседника. null — фото нет или его скрыли настройками приватности. */
  fetchAvatar(target: AvatarTarget): Promise<DownloadedMedia | null>;
  /**
   * Файл вложения уже сохранённого сообщения — по его id в мессенджере. null — файл больше 20 МБ.
   * Ошибка — мессенджер не отдал файл (не подключён, файл удалён или ещё не готов).
   */
  fetchAttachment?(target: AttachmentTarget): Promise<DownloadedMedia | null>;
  /** Находит собеседника, чтобы написать ему первыми. Не нашли — MessengerSendError с понятным текстом. */
  findRecipient(query: RecipientQuery): Promise<Recipient>;
}

/** Ошибка отправки с понятным сотруднику текстом. */
export class MessengerSendError extends Error {
  constructor(userMessage: string) {
    super(userMessage);
    this.name = 'MessengerSendError';
  }
}

/**
 * Мессенджер сейчас не отдаёт файлы: не подключён, просит подождать (флуд-контроль Telegram) или
 * занят другими загрузками. Повторять сразу бесполезно; текст — для сотрудника.
 */
export class MessengerUnavailableError extends Error {
  constructor(userMessage: string) {
    super(userMessage);
    this.name = 'MessengerUnavailableError';
  }
}

/** Мессенджер сейчас не может ответить (не подключён): запрос фото нужно повторить позже. */
export class AvatarSourceUnavailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AvatarSourceUnavailableError';
  }
}
