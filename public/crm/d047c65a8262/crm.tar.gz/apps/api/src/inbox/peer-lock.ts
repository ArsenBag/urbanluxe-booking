import type { Prisma } from '../generated/prisma/client.js';

/**
 * Сообщения и диалоги одного собеседника меняем строго по очереди: замок держится до конца
 * транзакции. Общий для приёма сообщений и «Написать», иначе они создадут два диалога.
 */
export async function lockPeer(
  tx: Prisma.TransactionClient,
  externalId: string,
): Promise<void> {
  await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${`ingest:${externalId}`}))::text AS locked`;
}
