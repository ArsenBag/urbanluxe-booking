/// <reference types="multer" />
import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { Throttle } from '@nestjs/throttler';
import {
  conversationListQuerySchema,
  messageListQuerySchema,
  sendFileSchema,
  sendMessageSchema,
  sendTemplateFileSchema,
  startConversationSchema,
  updateConversationSchema,
  type ConversationDto,
  type ConversationListQuery,
  type MessageDto,
  type MessageListQuery,
  type Paginated,
  type SendFileInput,
  type SendMessageInput,
  type SendTemplateFileInput,
  type StartConversationInput,
  type StartConversationResult,
  type UpdateConversationInput,
} from '@crm/shared';
import { CurrentUser } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { UPLOAD_OPTIONS, uploadedFile } from '../files/upload.js';
import { AttachmentFetchService } from './attachment-fetch.service.js';
import { ConversationStarterService } from './conversation-starter.service.js';
import { type InboxCounters, InboxService } from './inbox.service.js';

const uuid = () => new ParseUUIDPipe();

/** Запасной лимит частоты для «Написать» (по адресу IP; основной — на сотрудника в сервисе). */
const START_REQUESTS_PER_MINUTE = 10;
/** Каждая загрузка файла — запрос к мессенджеру; личный аккаунт Telegram не должен выглядеть как бот. */
const FETCH_ATTACHMENTS_PER_MINUTE = 30;
/** Файл шаблона уходит без загрузки из браузера — лимит не даёт засыпать клиентов видео по кругу. */
const TEMPLATE_FILES_PER_MINUTE = 30;
const ONE_MINUTE_MS = 60_000;

@Controller()
export class InboxController {
  constructor(
    private readonly inbox: InboxService,
    private readonly starter: ConversationStarterService,
    private readonly attachments: AttachmentFetchService,
  ) {}

  @Get('conversations')
  list(
    @Query(new ZodValidationPipe(conversationListQuerySchema))
    query: ConversationListQuery,
    @CurrentUser() actor: SessionUser,
  ): Promise<Paginated<ConversationDto>> {
    return this.inbox.list(query, actor);
  }

  @Get('conversations/counters')
  counters(@CurrentUser() actor: SessionUser): Promise<InboxCounters> {
    return this.inbox.counters(actor);
  }

  @Get('conversations/:id')
  get(@Param('id', uuid()) id: string): Promise<ConversationDto> {
    return this.inbox.get(id);
  }

  @Get('contacts/:id/conversations')
  listByContact(
    @Param('id', uuid()) contactId: string,
  ): Promise<ConversationDto[]> {
    return this.inbox.listByContact(contactId);
  }

  @Get('conversations/:id/messages')
  messages(
    @Param('id', uuid()) id: string,
    @Query(new ZodValidationPipe(messageListQuerySchema))
    query: MessageListQuery,
  ): Promise<MessageDto[]> {
    return this.inbox.messages(id, query);
  }

  /** Написать клиенту первыми из его карточки: WhatsApp или Telegram. Основной лимит — в сервисе. */
  @Post('contacts/:id/conversations')
  @Throttle({
    default: { limit: START_REQUESTS_PER_MINUTE, ttl: ONE_MINUTE_MS },
  })
  start(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(startConversationSchema))
    input: StartConversationInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<StartConversationResult> {
    return this.starter.start(id, input, actor);
  }

  @Post('conversations/:id/messages')
  send(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(sendMessageSchema)) input: SendMessageInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<MessageDto> {
    return this.inbox.send(id, input.text, actor);
  }

  @Post('conversations/:id/files')
  @UseInterceptors(FileInterceptor('file', UPLOAD_OPTIONS))
  sendFile(
    @Param('id', uuid()) id: string,
    @UploadedFile() file: Express.Multer.File | undefined,
    @Body(new ZodValidationPipe(sendFileSchema)) input: SendFileInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<MessageDto> {
    return this.inbox.sendFile(id, uploadedFile(file), input.caption, actor);
  }

  /** Файл быстрого ответа (видео входа, фото дома) с текстом шаблона, поправленным менеджером, как подписью. */
  @Post('conversations/:id/template-file')
  @Throttle({
    default: { limit: TEMPLATE_FILES_PER_MINUTE, ttl: ONE_MINUTE_MS },
  })
  sendTemplateFile(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(sendTemplateFileSchema))
    input: SendTemplateFileInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<MessageDto> {
    return this.inbox.sendTemplateFile(id, input, actor);
  }

  @Post('messages/:id/retry')
  @HttpCode(HttpStatus.OK)
  retry(@Param('id', uuid()) id: string): Promise<MessageDto> {
    return this.inbox.retry(id);
  }

  /** Загрузить из мессенджера файл, который не сохранился при приёме или при импорте истории. */
  @Post('messages/:id/attachment')
  @HttpCode(HttpStatus.OK)
  @Throttle({
    default: { limit: FETCH_ATTACHMENTS_PER_MINUTE, ttl: ONE_MINUTE_MS },
  })
  fetchAttachment(@Param('id', uuid()) id: string): Promise<MessageDto> {
    return this.attachments.fetch(id);
  }

  @Post('conversations/:id/read')
  @HttpCode(HttpStatus.OK)
  markRead(@Param('id', uuid()) id: string): Promise<null> {
    return this.inbox.markRead(id);
  }

  @Patch('conversations/:id')
  update(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(updateConversationSchema))
    input: UpdateConversationInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<ConversationDto> {
    return this.inbox.update(id, input, actor);
  }
}
