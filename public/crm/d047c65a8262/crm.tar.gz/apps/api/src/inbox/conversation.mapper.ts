import type { ConversationDto, MessageAttachment, MessageDto } from '@crm/shared';
import { toEntityRef, USER_REF_SELECT } from '../common/entity-refs.js';
import {
  BLACKLIST_SELECT,
  toGuestBlacklist,
  type BlacklistFields,
} from '../contacts/guest-blacklist.js';
import type { Conversation, Message } from '../generated/prisma/client.js';

export const CONVERSATION_INCLUDE = {
  channel: { select: { id: true, type: true, name: true } },
  contact: {
    select: {
      id: true,
      name: true,
      phones: true,
      avatarFileId: true,
      vip: true,
      ...BLACKLIST_SELECT,
      channels: { select: { type: true, username: true } },
    },
  },
  assignee: USER_REF_SELECT,
} as const;

type ConversationWithRelations = Conversation & {
  channel: { id: string; type: ConversationDto['channel']['type']; name: string };
  contact: BlacklistFields & {
    id: string;
    name: string;
    phones: string[];
    avatarFileId: string | null;
    vip: boolean;
    channels: Array<{ type: string; username: string | null }>;
  };
  assignee: { id: string; name: string } | null;
};

export function toConversationDto(conversation: ConversationWithRelations): ConversationDto {
  const handle = conversation.contact.channels.find((link) => link.type === conversation.channel.type)?.username;
  return {
    id: conversation.id,
    channel: conversation.channel,
    contact: {
      id: conversation.contact.id,
      name: conversation.contact.name,
      phones: conversation.contact.phones,
      avatarFileId: conversation.contact.avatarFileId,
      vip: conversation.contact.vip,
      blacklist: toGuestBlacklist(conversation.contact),
    },
    handle: handle ? `@${handle}` : null,
    assignee: toEntityRef(conversation.assignee),
    status: conversation.status,
    unreadCount: conversation.unreadCount,
    lastMessageAt: conversation.lastMessageAt?.toISOString() ?? null,
    lastMessagePreview: conversation.lastMessagePreview,
  };
}

export const MESSAGE_INCLUDE = { sender: USER_REF_SELECT } as const;

export function toMessageDto(message: Message & { sender: { id: string; name: string } | null }): MessageDto {
  return {
    id: message.id,
    direction: message.direction,
    status: message.status,
    text: message.text,
    attachment: (message.attachment as MessageAttachment | null) ?? null,
    sender: toEntityRef(message.sender),
    error: message.error,
    sentAt: message.sentAt.toISOString(),
  };
}
