import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  CHANNEL_TYPE_LABELS,
  type StartConversationInput,
  type StartConversationResult,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import type { Channel } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { ChannelRegistry } from './channel-registry.js';
import { InboxService } from './inbox.service.js';
import { MessengerSendError, type Recipient } from './messenger.types.js';
import { displayNameOf } from './peer-name.js';
import { lockPeer } from './peer-lock.js';

/**
 * Новых диалогов за час — не больше стольких на сотрудника и на мессенджер: массовые сообщения
 * незнакомым людям с личного Telegram и рабочего WhatsApp ведут к блокировке аккаунтов.
 */
const MAX_STARTS_PER_USER_PER_HOUR = 20;
const MAX_STARTS_PER_CHANNEL_PER_HOUR = 20;
const HOUR_MS = 60 * 60_000;
const START_ACTION = 'conversation.start';

/** Первое сообщение клиенту из CRM: находим его в мессенджере, заводим диалог и пишем. */
@Injectable()
export class ConversationStarterService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly registry: ChannelRegistry,
    private readonly inbox: InboxService,
    private readonly audit: ActivityLogService,
  ) {}

  async start(
    contactId: string,
    input: StartConversationInput,
    actor: SessionUser,
  ): Promise<StartConversationResult> {
    const contact = await this.prisma.contact.findUnique({
      where: { id: contactId },
      select: { id: true, phones: true },
    });
    if (!contact) throw new NotFoundException('Клиент не найден');
    // Пишем только на номера из карточки: телефон сначала сохраняют в клиенте.
    if (input.phone && !contact.phones.includes(input.phone)) {
      throw new BadRequestException('Выберите телефон из карточки клиента');
    }
    const channel = await this.prisma.channel.findFirst({
      where: { type: input.channel, status: 'CONNECTED' },
      orderBy: { updatedAt: 'desc' },
    });
    const sender = this.registry.find(input.channel);
    if (!channel || !sender) {
      throw new BadRequestException(
        `${CHANNEL_TYPE_LABELS[input.channel]} не подключён. Проверьте канал в разделе «Каналы».`,
      );
    }
    // Чат с этим номером в WhatsApp уже есть — это продолжение переписки: не ищем и не считаем в лимит.
    const existingId = await this.existingWhatsAppChat(channel, input);
    if (existingId) {
      return {
        conversationId: existingId,
        message: await this.inbox.send(existingId, input.text, actor),
      };
    }
    await this.recordAttempt(actor, contact.id, input);
    let recipient: Recipient;
    try {
      recipient = await sender.findRecipient({
        channelId: channel.id,
        phone: input.phone ?? null,
        username:
          input.channel === 'TELEGRAM' ? (input.username ?? null) : null,
      });
    } catch (error) {
      if (error instanceof MessengerSendError)
        throw new BadRequestException(error.message);
      throw error;
    }
    const conversationId = await this.ensureConversation(
      channel,
      contact.id,
      recipient,
    );
    const message = await this.inbox.send(conversationId, input.text, actor);
    return { conversationId, message };
  }

  private async existingWhatsAppChat(
    channel: Channel,
    input: StartConversationInput,
  ): Promise<string | null> {
    if (channel.type !== 'WHATSAPP' || !input.phone) return null;
    const conversation = await this.prisma.conversation.findUnique({
      where: {
        channelId_externalChatId: {
          channelId: channel.id,
          externalChatId: input.phone.replace(/\D/g, ''),
        },
      },
      select: { id: true },
    });
    return conversation?.id ?? null;
  }

  /** Попытка написать первыми — в историю клиента (кто и когда), с лимитом на сотрудника и мессенджер. */
  private async recordAttempt(
    actor: SessionUser,
    contactId: string,
    input: StartConversationInput,
  ): Promise<void> {
    await this.prisma.$transaction(async (tx) => {
      // Подсчёт и запись — под одним замком: параллельные запросы не проскочат лимит.
      await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${START_ACTION}))::text AS locked`;
      const since = new Date(Date.now() - HOUR_MS);
      const byUser = await tx.activityLog.count({
        where: {
          action: START_ACTION,
          actorId: actor.id,
          createdAt: { gte: since },
        },
      });
      if (byUser >= MAX_STARTS_PER_USER_PER_HOUR) {
        throw new HttpException(
          'Слишком много новых диалогов за час. Попробуйте позже.',
          HttpStatus.TOO_MANY_REQUESTS,
        );
      }
      const byChannel = await tx.activityLog.count({
        where: {
          action: START_ACTION,
          createdAt: { gte: since },
          payload: { path: ['channel'], equals: input.channel },
        },
      });
      if (byChannel >= MAX_STARTS_PER_CHANNEL_PER_HOUR) {
        const label = CHANNEL_TYPE_LABELS[input.channel];
        throw new HttpException(
          `За час в ${label} уже начато ${MAX_STARTS_PER_CHANNEL_PER_HOUR} новых диалогов — это предел, чтобы ${label} не заблокировал аккаунт. Попробуйте позже.`,
          HttpStatus.TOO_MANY_REQUESTS,
        );
      }
      const by =
        input.channel === 'TELEGRAM' && input.username ? 'username' : 'phone';
      await this.audit.record(
        actor,
        {
          action: START_ACTION,
          entityType: 'contact',
          entityId: contactId,
          payload: { channel: input.channel, by },
        },
        tx,
      );
    });
  }

  /**
   * Диалог с этим собеседником, если он уже есть, иначе новый. Аккаунт мессенджера, уже
   * привязанный к другому клиенту, остаётся у него: диалог откроется в его карточке.
   */
  private async ensureConversation(
    channel: Channel,
    contactId: string,
    recipient: Recipient,
  ): Promise<string> {
    return this.prisma.$transaction(async (tx) => {
      // Тот же замок, что у приёма сообщений: входящее от этого собеседника не создаст второй диалог.
      await lockPeer(tx, recipient.peer.externalId);
      const existing = await tx.conversation.findUnique({
        where: {
          channelId_externalChatId: {
            channelId: channel.id,
            externalChatId: recipient.externalChatId,
          },
        },
        select: { id: true },
      });
      if (existing) {
        // Свежий ключ доступа Telegram — как при приёме сообщений: отправка работает и после перезапуска.
        if (recipient.externalAccessHash) {
          await tx.conversation.update({
            where: { id: existing.id },
            data: { externalAccessHash: recipient.externalAccessHash },
          });
        }
        return existing.id;
      }
      const link =
        (await tx.contactChannel.findUnique({
          where: {
            type_externalId: {
              type: channel.type,
              externalId: recipient.peer.externalId,
            },
          },
          select: { contactId: true },
        })) ??
        (await tx.contactChannel.create({
          data: {
            contactId,
            type: channel.type,
            externalId: recipient.peer.externalId,
            username: recipient.peer.username ?? null,
            displayName: displayNameOf(recipient.peer),
          },
          select: { contactId: true },
        }));
      const conversation = await tx.conversation.create({
        data: {
          channelId: channel.id,
          contactId: link.contactId,
          externalChatId: recipient.externalChatId,
          externalAccessHash: recipient.externalAccessHash,
        },
        select: { id: true },
      });
      return conversation.id;
    });
  }
}
