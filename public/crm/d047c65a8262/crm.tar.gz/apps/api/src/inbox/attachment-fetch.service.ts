import {
  BadGatewayException,
  BadRequestException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  ServiceUnavailableException,
  type OnModuleDestroy,
} from '@nestjs/common';
import {
  canFetchAttachment,
  CHANNEL_TYPE_LABELS,
  type MessageAttachment,
  type MessageDto,
} from '@crm/shared';
import { ENV, type Env } from '../config/env.js';
import { FileStorageService } from '../files/file-storage.service.js';
import type { Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { ChannelRegistry } from './channel-registry.js';
import { MESSAGE_INCLUDE, toMessageDto } from './conversation.mapper.js';
import { imageTypeOf } from './image-type.js';
import {
  MessengerUnavailableError,
  type DownloadedMedia,
} from './messenger.types.js';

/** Сообщение с тем, что нужно, чтобы попросить файл у мессенджера (без секретов канала). */
const WITH_CHAT = {
  conversation: {
    select: {
      channelId: true,
      externalChatId: true,
      externalAccessHash: true,
      channel: { select: { type: true } },
    },
  },
} as const;
type MessageWithChat = Prisma.MessageGetPayload<{ include: typeof WITH_CHAT }>;

/** saved — файл привязан к сообщению; too-large — больше 20 МБ, повтор не поможет. */
type FetchOutcome = 'saved' | 'too-large';

const errorText = (error: unknown) =>
  error instanceof Error ? error.message : String(error);

/**
 * Файлы вложений, которые не сохранились при приёме сообщения: ссылка не сработала, мессенджер ещё
 * не выложил файл, или сообщение пришло с импортом истории (тогда файлы не качаются). Повторяет
 * скачивание в фоне и загружает файл по запросу сотрудника — по id сообщения в мессенджере.
 */
@Injectable()
export class AttachmentFetchService implements OnModuleDestroy {
  private readonly logger = new Logger(AttachmentFetchService.name);
  private readonly timers = new Set<NodeJS.Timeout>();
  /** Идущие загрузки: повтор в фоне и кнопка сотрудника не качают один файл дважды. */
  private readonly inFlight = new Map<string, Promise<FetchOutcome>>();
  private stopped = false;

  constructor(
    private readonly prisma: PrismaService,
    private readonly registry: ChannelRegistry,
    private readonly files: FileStorageService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  onModuleDestroy(): void {
    this.stopped = true;
    for (const timer of this.timers) clearTimeout(timer);
    this.timers.clear();
  }

  /**
   * Сохраняет скачанный файл и привязывает к сообщению, если файла у него ещё нет. Тип фото — по
   * содержимому: хранилища мессенджеров иногда отдают картинку как двоичный файл.
   */
  async attach(
    messageId: string,
    attachment: MessageAttachment,
    media: DownloadedMedia,
  ): Promise<void> {
    // Пустой ответ — файла больше нет (например, фото «на один просмотр»), а не файл в 0 байт.
    if (media.buffer.length === 0) {
      throw new Error('Мессенджер вернул пустой файл');
    }
    const photoType =
      attachment.kind === 'photo' ? imageTypeOf(media.buffer) : null;
    const stored = await this.files.save({
      buffer: media.buffer,
      fileName: media.fileName ?? attachment.fileName,
      mimeType: photoType?.mimeType ?? media.mimeType,
    });
    const next = {
      ...attachment,
      fileId: stored.id,
      mimeType: stored.mimeType,
      size: stored.size,
    } satisfies Prisma.InputJsonObject;
    let updated = 0;
    try {
      // Атомарно: файл привязывается, только если его ещё нет (иначе — второй, лишний).
      updated = await this.prisma.$executeRaw`
        UPDATE "messages" SET "attachment" = ${JSON.stringify(next)}::jsonb
        WHERE "id" = ${messageId}::uuid AND "attachment"->>'fileId' IS NULL`;
    } finally {
      if (updated === 0) await this.files.remove([stored.id]);
    }
  }

  /** Загрузить файл по запросу сотрудника (кнопка «Загрузить» у вложения без файла). */
  async fetch(messageId: string): Promise<MessageDto> {
    const message = await this.load(messageId);
    if (!message) throw new NotFoundException('Сообщение не найдено');
    const attachment = message.attachment as MessageAttachment | null;
    if (attachment?.fileId) return this.dto(messageId);
    if (!attachment || !canFetchAttachment(attachment) || !message.externalId) {
      throw new BadRequestException(
        'В этом сообщении нет файла, который можно загрузить',
      );
    }
    const messenger = CHANNEL_TYPE_LABELS[message.conversation.channel.type];
    let outcome: FetchOutcome;
    try {
      outcome = await this.download(message, attachment);
    } catch (error) {
      if (error instanceof MessengerUnavailableError) {
        throw new ServiceUnavailableException(error.message);
      }
      this.logger.warn(
        `Не удалось загрузить файл сообщения ${messageId}: ${errorText(error)}`,
      );
      throw new BadGatewayException(
        `Не удалось загрузить файл из ${messenger}. Попробуйте позже; если не выйдет — файл, ` +
          'вероятно, удалён из мессенджера: попросите клиента прислать его ещё раз.',
      );
    }
    if (outcome === 'too-large') {
      throw new BadRequestException(
        `Файл больше 20 МБ — откройте его в ${messenger}`,
      );
    }
    return this.dto(messageId);
  }

  /** Файл не скачался при приёме сообщения — повторяем в фоне через паузы из настроек. */
  retryLater(messageId: string, attempt = 0): void {
    if (this.stopped) return;
    const delay = this.env.ATTACHMENT_RETRY_DELAYS_MS[attempt];
    if (delay === undefined) {
      this.logger.warn(
        `Файл сообщения ${messageId} не скачался и после повторов — его можно загрузить кнопкой в чате`,
      );
      return;
    }
    const timer = setTimeout(() => {
      this.timers.delete(timer);
      void this.retry(messageId, attempt);
    }, delay);
    timer.unref();
    this.timers.add(timer);
  }

  private async retry(messageId: string, attempt: number): Promise<void> {
    try {
      const message = await this.load(messageId);
      const attachment = message?.attachment as MessageAttachment | null;
      // Уже скачан (например, кнопкой) или сообщение удалено — повторять нечего.
      if (
        !message?.externalId ||
        !attachment ||
        !canFetchAttachment(attachment)
      )
        return;
      await this.download(message, attachment);
    } catch (error) {
      // Мессенджер не подключён или просит подождать — не нагружаем его, остаётся кнопка.
      if (error instanceof MessengerUnavailableError) {
        this.logger.warn(
          `Файл сообщения ${messageId} не скачан: ${error.message} — повторы остановлены`,
        );
        return;
      }
      this.logger.warn(
        `Повтор ${attempt + 1}: файл сообщения ${messageId} не скачался: ${errorText(error)}`,
      );
      this.retryLater(messageId, attempt + 1);
    }
  }

  /** Одна загрузка на сообщение за раз: одновременные запросы получают общий результат. */
  private download(
    message: MessageWithChat,
    attachment: MessageAttachment,
  ): Promise<FetchOutcome> {
    const running = this.inFlight.get(message.id);
    if (running) return running;
    const task = this.downloadNow(message, attachment).finally(() =>
      this.inFlight.delete(message.id),
    );
    this.inFlight.set(message.id, task);
    return task;
  }

  private async downloadNow(
    message: MessageWithChat,
    attachment: MessageAttachment,
  ): Promise<FetchOutcome> {
    const { conversation } = message;
    const messenger = this.registry.find(conversation.channel.type);
    if (!messenger?.fetchAttachment || !message.externalId) {
      throw new MessengerUnavailableError(
        `${CHANNEL_TYPE_LABELS[conversation.channel.type]} не подключён на сервере`,
      );
    }
    const media = await messenger.fetchAttachment({
      channelId: conversation.channelId,
      externalChatId: conversation.externalChatId,
      externalAccessHash: conversation.externalAccessHash,
      externalMessageId: message.externalId,
      attachment,
    });
    if (!media) return 'too-large';
    await this.attach(message.id, attachment, media);
    return 'saved';
  }

  private load(messageId: string): Promise<MessageWithChat | null> {
    return this.prisma.message.findUnique({
      where: { id: messageId },
      include: WITH_CHAT,
    });
  }

  private async dto(messageId: string): Promise<MessageDto> {
    const message = await this.prisma.message.findUniqueOrThrow({
      where: { id: messageId },
      include: MESSAGE_INCLUDE,
    });
    return toMessageDto(message);
  }
}
