import { normalizePhone } from '@crm/shared';
import type { MessengerPeer } from './messenger.types.js';

/** Имя нового клиента из данных мессенджера: имя и фамилия, иначе @username, телефон или id. */
export function displayNameOf(peer: MessengerPeer): string {
  const fullName = [peer.firstName, peer.lastName].filter(Boolean).join(' ').trim();
  if (fullName) return fullName;
  if (peer.username) return `@${peer.username}`;
  if (peer.phone) return normalizePhone(peer.phone) ?? peer.phone;
  return `Telegram ${peer.externalId}`;
}

export function phonesOf(peer: MessengerPeer): string[] {
  // Telegram отдаёт номер без «+»: 998901234567.
  const normalized = peer.phone ? normalizePhone(`+${peer.phone.replace(/^\+/, '')}`) : null;
  return normalized ? [normalized] : [];
}
