import {
  BadRequestException,
  ConflictException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import {
  attachmentKindForMime,
  messagePreview,
  type ConversationDto,
  type MessageAttachment,
  type ConversationListQuery,
  type MessageDto,
  type MessageListQuery,
  type Paginated,
  type UpdateConversationInput,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { isPrismaError, PrismaErrorCode } from '../common/prisma-errors.js';
import {
  FileStorageService,
  type NewFile,
} from '../files/file-storage.service.js';
import type { Prisma, StoredFile } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { ChannelRegistry } from './channel-registry.js';
import {
  CONVERSATION_INCLUDE,
  MESSAGE_INCLUDE,
  toConversationDto,
  toMessageDto,
} from './conversation.mapper.js';
import { conversationListWhere } from './conversation-list-filter.js';
import {
  MessengerSendError,
  type OutboundFile,
  type SentMessage,
} from './messenger.types.js';

const SEND_FAILED_MESSAGE =
  'Не удалось отправить сообщение. Попробуйте ещё раз.';
/** PENDING дольше этого считается зависшим (сервер перезапустился во время отправки). */
const STUCK_PENDING_MS = 2 * 60_000;

/** Вложение исходящего сообщения с сохранённым в CRM файлом. */
const fileAttachment = (stored: StoredFile): MessageAttachment => ({
  kind: attachmentKindForMime(stored.mimeType),
  fileName: stored.fileName,
  fileId: stored.id,
  mimeType: stored.mimeType,
  size: stored.size,
});

export interface InboxCounters {
  unassigned: number;
  mineUnread: number;
}

@Injectable()
export class InboxService {
  private readonly logger = new Logger(InboxService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly registry: ChannelRegistry,
    private readonly audit: ActivityLogService,
    private readonly files: FileStorageService,
  ) {}

  async list(
    query: ConversationListQuery,
    actor: SessionUser,
  ): Promise<Paginated<ConversationDto>> {
    const where = await conversationListWhere(this.prisma, query, actor);
    const [total, conversations] = await Promise.all([
      this.prisma.conversation.count({ where }),
      this.prisma.conversation.findMany({
        where,
        include: CONVERSATION_INCLUDE,
        orderBy: [
          { lastMessageAt: { sort: 'desc', nulls: 'last' } },
          { id: 'asc' },
        ],
        skip: (query.page - 1) * query.limit,
        take: query.limit,
      }),
    ]);
    return {
      items: conversations.map(toConversationDto),
      total,
      page: query.page,
      limit: query.limit,
    };
  }

  async counters(actor: SessionUser): Promise<InboxCounters> {
    const [unassigned, mineUnread] = await Promise.all([
      // Только с непрочитанными: импорт истории оставил сотни открытых неназначенных диалогов.
      this.prisma.conversation.count({
        where: { status: 'OPEN', assigneeId: null, unreadCount: { gt: 0 } },
      }),
      this.prisma.conversation.count({
        where: { status: 'OPEN', assigneeId: actor.id, unreadCount: { gt: 0 } },
      }),
    ]);
    return { unassigned, mineUnread };
  }

  async get(id: string): Promise<ConversationDto> {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id },
      include: CONVERSATION_INCLUDE,
    });
    if (!conversation) {
      throw new NotFoundException('Диалог не найден');
    }
    return toConversationDto(conversation);
  }

  async listByContact(contactId: string): Promise<ConversationDto[]> {
    const conversations = await this.prisma.conversation.findMany({
      where: { contactId },
      include: CONVERSATION_INCLUDE,
      orderBy: { lastMessageAt: { sort: 'desc', nulls: 'last' } },
    });
    return conversations.map(toConversationDto);
  }

  /**
   * Сообщения диалога в хронологическом порядке. Для подгрузки старых — курсор (before, beforeId):
   * у импортированных сообщений время с точностью до секунды и часто совпадает, поэтому id добивает порядок.
   */
  async messages(
    conversationId: string,
    query: MessageListQuery,
  ): Promise<MessageDto[]> {
    await this.get(conversationId);
    const messages = await this.prisma.message.findMany({
      where: {
        conversationId,
        ...(await this.olderThan(conversationId, query)),
      },
      include: MESSAGE_INCLUDE,
      // Полный порядок: время сообщения, затем порядок поступления, затем id.
      orderBy: [{ sentAt: 'desc' }, { createdAt: 'desc' }, { id: 'desc' }],
      take: query.limit,
    });
    return messages.reverse().map(toMessageDto);
  }

  /** Условие «старше курсора» в том же порядке, что и сортировка. */
  private async olderThan(
    conversationId: string,
    query: MessageListQuery,
  ): Promise<Prisma.MessageWhereInput> {
    const anchor = query.beforeId
      ? await this.prisma.message.findFirst({
          where: { id: query.beforeId, conversationId },
          select: { id: true, sentAt: true, createdAt: true },
        })
      : null;
    if (anchor) {
      return {
        OR: [
          { sentAt: { lt: anchor.sentAt } },
          { sentAt: anchor.sentAt, createdAt: { lt: anchor.createdAt } },
          {
            sentAt: anchor.sentAt,
            createdAt: anchor.createdAt,
            id: { lt: anchor.id },
          },
        ],
      };
    }
    return query.before ? { sentAt: { lt: new Date(query.before) } } : {};
  }

  async markRead(id: string): Promise<null> {
    await this.prisma.conversation.updateMany({
      where: { id },
      data: { unreadCount: 0 },
    });
    return null;
  }

  async update(
    id: string,
    input: UpdateConversationInput,
    actor: SessionUser,
  ): Promise<ConversationDto> {
    try {
      const conversation = await this.prisma.$transaction(async (tx) => {
        const updated = await tx.conversation.update({
          where: { id },
          data: input,
          include: CONVERSATION_INCLUDE,
        });
        const action =
          input.status === 'CLOSED'
            ? 'conversation.closed'
            : input.status === 'OPEN'
              ? 'conversation.reopened'
              : 'conversation.assigned';
        await this.audit.record(
          actor,
          {
            action,
            entityType: 'contact',
            entityId: updated.contactId,
            payload: {
              conversationId: id,
              assignee: updated.assignee?.name ?? null,
            },
          },
          tx,
        );
        return updated;
      });
      return toConversationDto(conversation);
    } catch (error) {
      if (isPrismaError(error, PrismaErrorCode.RecordNotFound)) {
        throw new NotFoundException('Диалог не найден');
      }
      if (isPrismaError(error, PrismaErrorCode.ForeignKeyViolation)) {
        throw new BadRequestException('Сотрудник не найден');
      }
      throw error;
    }
  }

  /**
   * Отправка ответа клиенту. Сообщение сохраняется до отправки (статус PENDING),
   * при ошибке остаётся со статусом FAILED — его можно отправить повторно.
   * Неназначенный диалог закрепляется за ответившим сотрудником.
   * actor = null — автоматическое сообщение: без автора, диалог не назначается и не считается прочитанным.
   */
  async send(
    conversationId: string,
    text: string,
    actor: SessionUser | null,
  ): Promise<MessageDto> {
    const messageId = await this.createPending(
      conversationId,
      { text, attachment: null },
      actor,
    );
    return this.deliver(messageId);
  }

  /**
   * Файл шаблона с подписью. Шаблон могли изменить, пока менеджер писал: файла нет или он уже другой —
   * просим выбрать шаблон заново, а не отправляем клиенту не тот файл.
   */
  async sendTemplateFile(
    conversationId: string,
    input: { templateId: string; fileId: string; caption: string | null },
    actor: SessionUser,
  ): Promise<MessageDto> {
    const template = await this.prisma.replyTemplate.findUnique({
      where: { id: input.templateId },
      select: { fileId: true },
    });
    if (!template) {
      throw new NotFoundException('Шаблон не найден');
    }
    if (!template.fileId) {
      throw new BadRequestException(
        'У шаблона больше нет файла — выберите шаблон заново',
      );
    }
    if (template.fileId !== input.fileId) {
      throw new ConflictException(
        'Файл шаблона заменили — выберите шаблон заново',
      );
    }
    return this.sendStoredFile(
      conversationId,
      template.fileId,
      input.caption,
      actor,
    );
  }

  /**
   * Отправка уже сохранённого файла (файла шаблона) без копии: видео не дублируется на диске и в бэкапах
   * при каждой отправке. Сообщение ссылается на файл шаблона, поэтому прежний файл шаблона после замены
   * удаляется, только если его ещё никому не отправляли (TemplateFileCleanup).
   */
  async sendStoredFile(
    conversationId: string,
    fileId: string,
    caption: string | null,
    actor: SessionUser | null,
  ): Promise<MessageDto> {
    await this.get(conversationId);
    const stored = await this.files.find(fileId);
    const messageId = await this.createPending(
      conversationId,
      { text: caption, attachment: fileAttachment(stored) },
      actor,
    );
    return this.deliver(messageId);
  }

  /**
   * Отправка файла (с необязательной подписью). Файл сохраняется в CRM до отправки — повтор не требует загрузки заново.
   * actor = null — автоматическое сообщение (как у send).
   */
  async sendFile(
    conversationId: string,
    upload: NewFile,
    caption: string | null,
    actor: SessionUser | null,
  ): Promise<MessageDto> {
    await this.get(conversationId);
    const stored = await this.files.save(upload);
    let messageId: string;
    try {
      messageId = await this.createPending(
        conversationId,
        { text: caption, attachment: fileAttachment(stored) },
        actor,
      );
    } catch (error) {
      // Сообщение не создано (например, диалог удалили) — файл больше ни к чему не привязан.
      await this.files.remove([stored.id]);
      throw error;
    }
    return this.deliver(messageId);
  }

  private async createPending(
    conversationId: string,
    content: { text: string | null; attachment: MessageAttachment | null },
    actor: SessionUser | null,
  ): Promise<string> {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
    });
    if (!conversation) {
      throw new NotFoundException('Диалог не найден');
    }
    const message = await this.prisma.$transaction(async (tx) => {
      const created = await tx.message.create({
        data: {
          conversationId,
          direction: 'OUT',
          status: 'PENDING',
          text: content.text,
          attachment: content.attachment
            ? ({ ...content.attachment } satisfies Prisma.InputJsonObject)
            : undefined,
          senderId: actor?.id ?? null,
          sentAt: new Date(),
        },
      });
      await tx.conversation.update({
        where: { id: conversationId },
        data: {
          lastMessageAt: created.sentAt,
          lastMessagePreview: messagePreview(content.text, content.attachment),
          ...(actor && { unreadCount: 0 }),
          ...(actor &&
            conversation.assigneeId === null && { assigneeId: actor.id }),
        },
      });
      return created;
    });
    return message.id;
  }

  /**
   * Повторная отправка неотправленного сообщения. Атомарная смена статуса гарантирует,
   * что двойной клик или два сотрудника не отправят его дважды. Зависшее в PENDING
   * (например, после перезапуска сервера) тоже можно отправить повторно.
   */
  async retry(messageId: string): Promise<MessageDto> {
    const stuckBefore = new Date(Date.now() - STUCK_PENDING_MS);
    const claimed = await this.prisma.message.updateMany({
      where: {
        id: messageId,
        direction: 'OUT',
        OR: [
          { status: 'FAILED' },
          { status: 'PENDING', createdAt: { lt: stuckBefore } },
        ],
      },
      data: { status: 'PENDING', error: null },
    });
    if (claimed.count === 0) {
      const exists = await this.prisma.message.count({
        where: { id: messageId },
      });
      if (!exists) {
        throw new NotFoundException('Сообщение не найдено');
      }
      throw new BadRequestException(
        'Сообщение уже отправлено или отправляется',
      );
    }
    return this.deliver(messageId);
  }

  private async deliver(messageId: string): Promise<MessageDto> {
    const message = await this.prisma.message.findUniqueOrThrow({
      where: { id: messageId },
      include: { conversation: { include: { channel: true } } },
    });
    const { conversation } = message;
    let sent: SentMessage;
    try {
      if (conversation.channel.status !== 'CONNECTED') {
        throw new MessengerSendError(
          'Канал не подключён. Администратор может подключить его в разделе «Каналы».',
        );
      }
      sent = await this.registry.senderFor(conversation.channel.type).send({
        channelId: conversation.channelId,
        externalChatId: conversation.externalChatId,
        externalAccessHash: conversation.externalAccessHash,
        text: message.text ?? '',
        file: await this.outboundFile(
          message.attachment as MessageAttachment | null,
        ),
      });
    } catch (error) {
      const userMessage =
        error instanceof MessengerSendError
          ? error.message
          : SEND_FAILED_MESSAGE;
      if (!(error instanceof MessengerSendError)) {
        this.logger.error(
          `Сбой отправки сообщения ${messageId}`,
          error instanceof Error ? error.stack : error,
        );
      }
      const failed = await this.prisma.message.update({
        where: { id: messageId },
        data: { status: 'FAILED', error: userMessage },
        include: MESSAGE_INCLUDE,
      });
      return toMessageDto(failed);
    }
    // Сообщение ушло клиенту: дальше оно не может стать «неотправленным», что бы ни случилось с записью.
    return this.markSent(messageId, conversation.id, sent);
  }

  private async outboundFile(
    attachment: MessageAttachment | null,
  ): Promise<OutboundFile | null> {
    if (!attachment?.fileId) return null;
    const { file, buffer } = await this.files.read(attachment.fileId);
    return {
      buffer,
      fileName: file.fileName,
      mimeType: file.mimeType,
      kind: attachment.kind,
    };
  }

  /**
   * Эхо из мессенджера могло прийти раньше ответа и создать отдельную запись с тем же внешним id
   * (если не совпал текст). Тогда убираем дубликат и оставляем наше сообщение с автором.
   */
  private async markSent(
    messageId: string,
    conversationId: string,
    sent: SentMessage,
  ): Promise<MessageDto> {
    const duplicateWhere = {
      conversationId,
      externalId: sent.externalMessageId,
      id: { not: messageId },
    };
    const duplicates = await this.prisma.message.findMany({
      where: duplicateWhere,
      select: { attachment: true },
    });
    const updated = await this.prisma.$transaction(async (tx) => {
      await tx.message.deleteMany({ where: duplicateWhere });
      return tx.message.update({
        where: { id: messageId },
        data: {
          status: 'SENT',
          externalId: sent.externalMessageId,
          sentAt: sent.sentAt,
          error: null,
        },
        include: MESSAGE_INCLUDE,
      });
    });
    // Дубликат мог успеть скачать копию нашего же файла — убираем её.
    await this.files
      .remove(
        duplicates.flatMap(
          (duplicate) =>
            (duplicate.attachment as MessageAttachment | null)?.fileId ?? [],
        ),
      )
      .catch((error: unknown) =>
        this.logger.warn(`Не удалось удалить копию файла: ${String(error)}`),
      );
    return toMessageDto(updated);
  }
}
