/** Форматы фото профиля, которые сохраняем: тип и расширение файла. */
export interface ImageType {
  mimeType: 'image/jpeg' | 'image/png' | 'image/webp';
  extension: 'jpg' | 'png' | 'webp';
}

const JPEG = [0xff, 0xd8, 0xff];
const PNG = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];
const RIFF = 'RIFF';
const WEBP = 'WEBP';
const WEBP_TAG_OFFSET = 8;

const startsWith = (buffer: Buffer, bytes: number[]) =>
  bytes.every((byte, index) => buffer[index] === byte);

/**
 * Формат картинки по первым байтам. Заголовку Content-Type не верим: сохраняем только то,
 * что действительно JPEG, PNG или WebP. null — не картинка.
 */
export function imageTypeOf(buffer: Buffer): ImageType | null {
  if (startsWith(buffer, JPEG))
    return { mimeType: 'image/jpeg', extension: 'jpg' };
  if (startsWith(buffer, PNG))
    return { mimeType: 'image/png', extension: 'png' };
  const isWebp =
    buffer.toString('ascii', 0, RIFF.length) === RIFF &&
    buffer.toString('ascii', WEBP_TAG_OFFSET, WEBP_TAG_OFFSET + WEBP.length) ===
      WEBP;
  return isWebp ? { mimeType: 'image/webp', extension: 'webp' } : null;
}
