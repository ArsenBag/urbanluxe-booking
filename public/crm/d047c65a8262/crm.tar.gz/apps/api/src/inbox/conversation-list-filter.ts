import type { ConversationListQuery } from '@crm/shared';
import type { SessionUser } from '../auth/session-user.js';
import { contactIdsByPhoneDigits } from '../contacts/contact-phone-search.js';
import type { Prisma } from '../generated/prisma/client.js';
import type { PrismaService } from '../prisma/prisma.service.js';

/** Сколько свежих неотвеченных диалогов учитываем: список всё равно показывает сотню самых новых. */
const MAX_UNANSWERED = 5000;

function assigneeCondition(
  query: ConversationListQuery,
  actor: SessionUser,
): Prisma.ConversationWhereInput {
  if (query.assigneeId) return { assigneeId: query.assigneeId };
  if (query.filter === 'mine') return { assigneeId: actor.id };
  if (query.filter === 'unassigned') return { assigneeId: null };
  return {};
}

async function searchCondition(
  prisma: PrismaService,
  search: string,
): Promise<Prisma.ConversationWhereInput> {
  const phoneMatches = await contactIdsByPhoneDigits(prisma, search);
  return {
    contact: {
      OR: [
        { name: { contains: search, mode: 'insensitive' } },
        {
          channels: {
            some: {
              username: {
                contains: search.replace(/^@/, ''),
                mode: 'insensitive',
              },
            },
          },
        },
        ...(phoneMatches.length > 0 ? [{ id: { in: phoneMatches } }] : []),
      ],
    },
  };
}

/**
 * Диалоги, где последнее слово за гостем. Ответом не считаются автосообщения и неотправленные
 * сообщения; принятый звонок считается: с гостем уже поговорили.
 */
async function unansweredIds(
  prisma: PrismaService,
  status: ConversationListQuery['status'],
): Promise<string[]> {
  const rows = await prisma.$queryRaw<Array<{ id: string }>>`
    SELECT c.id
    FROM conversations c
    JOIN LATERAL (
      SELECT m.direction, m.attachment
      FROM messages m
      WHERE m."conversationId" = c.id
        AND m.status IN ('RECEIVED', 'SENT')
        AND NOT EXISTS (SELECT 1 FROM automation_runs ar WHERE ar."messageId" = m.id)
      ORDER BY m."sentAt" DESC, m."createdAt" DESC, m.id DESC
      LIMIT 1
    ) last ON true
    WHERE c.status = ${status}::"ConversationStatus"
      AND last.direction = 'IN'
      AND NOT coalesce(last.attachment->>'kind' = 'call' AND last.attachment->'call'->>'outcome' = 'answered', false)
    ORDER BY c."lastMessageAt" DESC NULLS LAST
    LIMIT ${MAX_UNANSWERED}
  `;
  return rows.map((row) => row.id);
}

/** Условие для списка диалогов во «Входящих»: статус, ответственный, мессенджер, поиск, «без ответа». */
export async function conversationListWhere(
  prisma: PrismaService,
  query: ConversationListQuery,
  actor: SessionUser,
): Promise<Prisma.ConversationWhereInput> {
  const conditions: Prisma.ConversationWhereInput[] = [
    { status: query.status },
    assigneeCondition(query, actor),
    ...(query.channelType ? [{ channel: { type: query.channelType } }] : []),
    ...(query.search ? [await searchCondition(prisma, query.search)] : []),
    ...(query.unanswered
      ? [{ id: { in: await unansweredIds(prisma, query.status) } }]
      : []),
  ];
  return { AND: conditions };
}
