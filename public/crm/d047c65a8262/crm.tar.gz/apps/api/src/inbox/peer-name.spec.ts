import { displayNameOf, phonesOf } from './peer-name.js';

describe('displayNameOf', () => {
  it('prefers first and last name', () => {
    expect(displayNameOf({ externalId: '1', firstName: 'Дилноза', lastName: 'Каримова', username: 'dk' })).toBe('Дилноза Каримова');
  });

  it('falls back to username, then phone, then id', () => {
    expect(displayNameOf({ externalId: '1', username: 'guest' })).toBe('@guest');
    expect(displayNameOf({ externalId: '1', phone: '998901234567' })).toBe('+998901234567');
    expect(displayNameOf({ externalId: '42' })).toBe('Telegram 42');
  });
});

describe('phonesOf', () => {
  it('normalizes a Telegram phone without plus', () => {
    expect(phonesOf({ externalId: '1', phone: '998901234567' })).toEqual(['+998901234567']);
  });

  it('returns nothing when the phone is hidden', () => {
    expect(phonesOf({ externalId: '1' })).toEqual([]);
  });
});
