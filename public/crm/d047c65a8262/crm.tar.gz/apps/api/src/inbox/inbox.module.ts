import { Module } from '@nestjs/common';
import { FilesModule } from '../files/files.module.js';
import { AttachmentFetchService } from './attachment-fetch.service.js';
import { AvatarScheduler } from './avatar.scheduler.js';
import { AvatarService } from './avatar.service.js';
import { ChannelRegistry } from './channel-registry.js';
import { ConversationStarterService } from './conversation-starter.service.js';
import { InboxIngestService } from './inbox-ingest.service.js';
import { InboxController } from './inbox.controller.js';
import { InboxService } from './inbox.service.js';

@Module({
  imports: [FilesModule],
  controllers: [InboxController],
  providers: [
    InboxService,
    InboxIngestService,
    AttachmentFetchService,
    ChannelRegistry,
    AvatarService,
    AvatarScheduler,
    ConversationStarterService,
  ],
  exports: [InboxService, InboxIngestService, ChannelRegistry],
})
export class InboxModule {}
