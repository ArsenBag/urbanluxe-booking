import { createHash } from 'node:crypto';
import { setTimeout as sleep } from 'node:timers/promises';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { ENV, type Env } from '../config/env.js';
import { FileStorageService } from '../files/file-storage.service.js';
import type { ChannelType } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { ChannelRegistry } from './channel-registry.js';
import { imageTypeOf, type ImageType } from './image-type.js';
import {
  AvatarSourceUnavailableError,
  type DownloadedMedia,
} from './messenger.types.js';

/** Фото собеседника спрашиваем у мессенджера не чаще раза в сутки на диалог. */
const AVATAR_REFRESH_MS = 24 * 60 * 60_000;
/** Фото профиля — десятки КБ; больше мегабайта — не аватар. */
const MAX_AVATAR_BYTES = 1024 * 1024;
/** Запросы ждут в очереди; при наплыве новых собеседников лишнее подберёт фоновая дозагрузка. */
const MAX_QUEUED = 50;
const HASH_LENGTH = 32;

/**
 * saved — сохранено новое фото; unchanged — спросили, нового фото нет;
 * skipped — не спрашивали (недавно проверяли, очередь полна); failed — спросить не удалось.
 */
export type AvatarRefreshResult = 'saved' | 'unchanged' | 'skipped' | 'failed';

export interface AvatarBackfillResult {
  checked: number;
  saved: number;
}

interface AvatarConversation {
  id: string;
  channelId: string;
  contactId: string;
  externalChatId: string;
  externalAccessHash: string | null;
  avatarCheckedAt: Date | null;
  channel: { type: ChannelType };
}

/**
 * Фото профиля клиентов из Telegram и WhatsApp: показываются в диалогах вместо инициалов.
 * Все запросы к мессенджерам идут по одному с паузой — и для новых сообщений, и для дозагрузки.
 */
@Injectable()
export class AvatarService {
  private readonly logger = new Logger(AvatarService.name);
  private queue: Promise<unknown> = Promise.resolve();
  private queued = 0;

  constructor(
    private readonly prisma: PrismaService,
    private readonly files: FileStorageService,
    private readonly registry: ChannelRegistry,
    @Inject(ENV) private readonly env: Env,
  ) {}

  /** Ставит обновление фото собеседника диалога в очередь. Не бросает исключений. */
  refresh(conversationId: string): Promise<AvatarRefreshResult> {
    if (this.queued >= MAX_QUEUED) return Promise.resolve('skipped');
    this.queued += 1;
    const result = this.queue.then(() => this.refreshSafely(conversationId));
    this.queue = result
      .then(async (outcome) => {
        if (outcome !== 'skipped') await sleep(this.env.AVATAR_REQUEST_GAP_MS);
      })
      .finally(() => {
        this.queued -= 1;
      });
    return result;
  }

  /**
   * Фото для диалогов, где его ещё не спрашивали, — от свежих к старым. При первой неудаче
   * проход останавливается: если мессенджер недоступен или просит подождать, не настаиваем.
   */
  async backfill(limit: number): Promise<AvatarBackfillResult> {
    const conversations = await this.prisma.conversation.findMany({
      where: {
        avatarCheckedAt: null,
        channel: { status: 'CONNECTED', type: { in: this.registry.types() } },
      },
      orderBy: { lastMessageAt: { sort: 'desc', nulls: 'last' } },
      take: limit,
      select: { id: true },
    });
    let checked = 0;
    let saved = 0;
    for (const conversation of conversations) {
      const outcome = await this.refresh(conversation.id);
      if (outcome === 'failed') break;
      if (outcome !== 'skipped') checked += 1;
      if (outcome === 'saved') saved += 1;
    }
    return { checked, saved };
  }

  private async refreshSafely(
    conversationId: string,
  ): Promise<AvatarRefreshResult> {
    try {
      return await this.refreshConversation(conversationId);
    } catch (error) {
      this.logger.warn(
        `Не удалось обновить фото клиента (диалог ${conversationId}): ${error instanceof Error ? error.name : 'Error'}`,
      );
      return 'failed';
    }
  }

  private async refreshConversation(
    conversationId: string,
  ): Promise<AvatarRefreshResult> {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
      select: {
        id: true,
        channelId: true,
        contactId: true,
        externalChatId: true,
        externalAccessHash: true,
        avatarCheckedAt: true,
        channel: { select: { type: true } },
      },
    });
    const source =
      conversation && this.registry.find(conversation.channel.type);
    if (!conversation || !source || !(await this.claim(conversation.id)))
      return 'skipped';
    let media: DownloadedMedia | null;
    try {
      media = await source.fetchAvatar({
        channelId: conversation.channelId,
        externalChatId: conversation.externalChatId,
        externalAccessHash: conversation.externalAccessHash,
      });
    } catch (error) {
      // Мессенджер ещё не подключился — вернём отметку, чтобы спросить позже. Прочие ошибки
      // (лимиты Telegram, сбой сети, удалённый аккаунт) засчитываем как проверку на сутки.
      if (error instanceof AvatarSourceUnavailableError)
        await this.release(conversation);
      throw error;
    }
    const image =
      media && media.buffer.length <= MAX_AVATAR_BYTES
        ? imageTypeOf(media.buffer)
        : null;
    // Скрытое или удалённое фото не стираем: у клиента может быть фото из другого мессенджера.
    if (!media || !image) return 'unchanged';
    return (await this.store(conversation, media.buffer, image))
      ? 'saved'
      : 'unchanged';
  }

  /** Отмечаем проверку до запроса: два сообщения собеседника подряд не спросят мессенджер дважды. */
  private async claim(conversationId: string): Promise<boolean> {
    const claimed = await this.prisma.conversation.updateMany({
      where: {
        id: conversationId,
        OR: [
          { avatarCheckedAt: null },
          { avatarCheckedAt: { lt: new Date(Date.now() - AVATAR_REFRESH_MS) } },
        ],
      },
      data: { avatarCheckedAt: new Date() },
    });
    return claimed.count > 0;
  }

  private async release(conversation: AvatarConversation): Promise<void> {
    await this.prisma.conversation.updateMany({
      where: { id: conversation.id },
      data: { avatarCheckedAt: conversation.avatarCheckedAt },
    });
  }

  private async store(
    conversation: AvatarConversation,
    buffer: Buffer,
    image: ImageType,
  ): Promise<boolean> {
    const hash = createHash('sha256')
      .update(buffer)
      .digest('hex')
      .slice(0, HASH_LENGTH);
    const contact = await this.prisma.contact.findUnique({
      where: { id: conversation.contactId },
      select: { avatarFileId: true, avatarHash: true, avatarSource: true },
    });
    if (!contact || contact.avatarHash === hash) return false;
    // Фото из другого мессенджера не перезаписываем: при двух разных фото оно бы скакало.
    if (
      contact.avatarFileId &&
      contact.avatarSource &&
      contact.avatarSource !== conversation.channel.type
    )
      return false;
    const stored = await this.files.save({
      buffer,
      fileName: `avatar.${image.extension}`,
      mimeType: image.mimeType,
    });
    try {
      await this.prisma.contact.update({
        where: { id: conversation.contactId },
        data: {
          avatarFileId: stored.id,
          avatarHash: hash,
          avatarSource: conversation.channel.type,
        },
      });
    } catch (error) {
      await this.files.remove([stored.id]);
      throw error;
    }
    if (contact.avatarFileId) await this.files.remove([contact.avatarFileId]);
    return true;
  }
}
