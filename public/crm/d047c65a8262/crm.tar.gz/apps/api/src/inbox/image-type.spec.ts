import { imageTypeOf } from './image-type.js';

describe('imageTypeOf', () => {
  it('recognizes JPEG, PNG and WebP by their signatures', () => {
    expect(imageTypeOf(Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00]))).toEqual({
      mimeType: 'image/jpeg',
      extension: 'jpg',
    });
    expect(
      imageTypeOf(
        Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00]),
      ),
    ).toEqual({
      mimeType: 'image/png',
      extension: 'png',
    });
    expect(
      imageTypeOf(
        Buffer.concat([
          Buffer.from('RIFF'),
          Buffer.alloc(4),
          Buffer.from('WEBPVP8 '),
        ]),
      ),
    ).toEqual({
      mimeType: 'image/webp',
      extension: 'webp',
    });
  });

  it('rejects anything that is not one of these images', () => {
    expect(
      imageTypeOf(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"/>')),
    ).toBeNull();
    expect(
      imageTypeOf(Buffer.from('<html><script>alert(1)</script>')),
    ).toBeNull();
    expect(imageTypeOf(Buffer.from('RIFF....WAVE'))).toBeNull();
    expect(imageTypeOf(Buffer.alloc(0))).toBeNull();
  });
});
