import {
  Injectable,
  Logger,
  type OnApplicationBootstrap,
  type OnModuleDestroy,
} from '@nestjs/common';
import { AvatarService } from './avatar.service.js';

/** Фото уже существующих диалогов дозагружаем понемногу: частые запросы личного аккаунта Telegram подозрительны. */
const RUN_INTERVAL_MS = 10 * 60_000;
const FIRST_RUN_DELAY_MS = 60_000;
/** Паузу между запросами держит очередь AvatarService (AVATAR_REQUEST_GAP_MS). */
const BATCH_SIZE = 20;

/** Периодическая дозагрузка фото профиля клиентов, у которых его ещё не спрашивали. */
@Injectable()
export class AvatarScheduler
  implements OnApplicationBootstrap, OnModuleDestroy
{
  private readonly logger = new Logger(AvatarScheduler.name);
  private timer: NodeJS.Timeout | null = null;
  private firstRun: NodeJS.Timeout | null = null;
  private running = false;

  constructor(private readonly avatars: AvatarService) {}

  onApplicationBootstrap(): void {
    this.firstRun = setTimeout(() => void this.tick(), FIRST_RUN_DELAY_MS);
    this.firstRun.unref();
    this.timer = setInterval(() => void this.tick(), RUN_INTERVAL_MS);
    this.timer.unref();
  }

  onModuleDestroy(): void {
    if (this.firstRun) clearTimeout(this.firstRun);
    if (this.timer) clearInterval(this.timer);
  }

  /** Ошибки прохода логируются и не роняют процесс; следующий проход продолжит. */
  private async tick(): Promise<void> {
    if (this.running) return;
    this.running = true;
    try {
      const result = await this.avatars.backfill(BATCH_SIZE);
      if (result.checked > 0) {
        this.logger.log(
          `Фото клиентов: проверено ${result.checked}, сохранено ${result.saved}`,
        );
      }
    } catch (error) {
      this.logger.error(
        'Дозагрузка фото клиентов прервана',
        error instanceof Error ? error.stack : error,
      );
    } finally {
      this.running = false;
    }
  }
}
