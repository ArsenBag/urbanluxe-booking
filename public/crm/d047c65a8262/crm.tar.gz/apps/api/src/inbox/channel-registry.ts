import { Injectable } from '@nestjs/common';
import type { ChannelType } from '../generated/prisma/client.js';
import { MessengerSendError, type MessengerSender } from './messenger.types.js';

/** Реестр отправщиков: модули мессенджеров регистрируют себя при старте. */
@Injectable()
export class ChannelRegistry {
  private readonly senders = new Map<ChannelType, MessengerSender>();

  register(sender: MessengerSender): void {
    this.senders.set(sender.type, sender);
  }

  /** Мессенджер, если он настроен на сервере; без исключения — для фоновых задач. */
  find(type: ChannelType): MessengerSender | undefined {
    return this.senders.get(type);
  }

  /** Мессенджеры, настроенные на сервере. */
  types(): ChannelType[] {
    return [...this.senders.keys()];
  }

  senderFor(type: ChannelType): MessengerSender {
    const sender = this.senders.get(type);
    if (!sender) {
      throw new MessengerSendError(
        'Канал не подключён на сервере. Обратитесь к администратору.',
      );
    }
    return sender;
  }
}
