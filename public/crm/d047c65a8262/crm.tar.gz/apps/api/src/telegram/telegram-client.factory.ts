import { Inject, Injectable } from '@nestjs/common';
import { TelegramClient } from 'telegram';
import { LogLevel } from 'telegram/extensions/Logger.js';
import { StringSession } from 'telegram/sessions/index.js';
import { ENV, type Env } from '../config/env.js';

const CONNECTION_RETRIES = 5;
/** FloodWait короче этого GramJS переждёт сам; длиннее — вернёт ошибку. */
const FLOOD_SLEEP_THRESHOLD_SECONDS = 60;

export interface TelegramApiCredentials {
  apiId: number;
  apiHash: string;
}

/** Создание клиентов GramJS. Вынесено отдельно, чтобы в тестах подменять фейком. */
@Injectable()
export class TelegramClientFactory {
  constructor(@Inject(ENV) private readonly env: Env) {}

  get isConfigured(): boolean {
    return Boolean(this.env.TELEGRAM_API_ID && this.env.TELEGRAM_API_HASH);
  }

  get credentials(): TelegramApiCredentials {
    if (!this.env.TELEGRAM_API_ID || !this.env.TELEGRAM_API_HASH) {
      throw new Error('Telegram не настроен: TELEGRAM_API_ID и TELEGRAM_API_HASH не заданы');
    }
    return { apiId: this.env.TELEGRAM_API_ID, apiHash: this.env.TELEGRAM_API_HASH };
  }

  create(session = ''): TelegramClient {
    const { apiId, apiHash } = this.credentials;
    const client = new TelegramClient(new StringSession(session), apiId, apiHash, {
      connectionRetries: CONNECTION_RETRIES,
      floodSleepThreshold: FLOOD_SLEEP_THRESHOLD_SECONDS,
      autoReconnect: true,
      deviceModel: 'High Life CRM',
      appVersion: '1.0',
    });
    client.setLogLevel(LogLevel.ERROR);
    return client;
  }
}
