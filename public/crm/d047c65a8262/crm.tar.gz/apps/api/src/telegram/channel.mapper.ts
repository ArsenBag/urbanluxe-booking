import type { ChannelDto } from '@crm/shared';
import type { Channel } from '../generated/prisma/client.js';

/** Канал без сессии: зашифрованные данные наружу не отдаём. */
export function toChannelDto(channel: Channel): ChannelDto {
  return {
    id: channel.id,
    type: channel.type,
    name: channel.name,
    status: channel.status,
    phone: channel.phone,
    username: channel.username,
    lastError: channel.lastError,
    historyImportedAt: channel.historyImportedAt?.toISOString() ?? null,
  };
}
