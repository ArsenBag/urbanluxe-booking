import {
  FILE_ATTACHMENT_KINDS,
  type AttachmentKind,
  type CallOutcome,
  type MessageAttachment,
} from '@crm/shared';
import type {
  IncomingMessage,
  MessengerPeer,
} from '../inbox/messenger.types.js';

/** id служебного аккаунта Telegram (коды входа, уведомления безопасности). */
const TELEGRAM_SERVICE_USER_ID = '777000';
const MS_PER_SECOND = 1000;

interface Stringable {
  toString(): string;
}

/** Минимум полей пользователя GramJS (Api.User), которые нам нужны. */
export interface TelegramUserLike {
  className: string;
  id: Stringable;
  accessHash?: Stringable | null;
  firstName?: string | null;
  lastName?: string | null;
  username?: string | null;
  phone?: string | null;
  bot?: boolean | null;
  self?: boolean | null;
}

/** Минимум полей сообщения GramJS (Api.Message). */
export interface TelegramMessageLike {
  id: number;
  out?: boolean;
  message?: string | null;
  date: number;
  media?: unknown;
}

interface MediaLike {
  className?: string;
  document?: {
    mimeType?: string | null;
    size?: Stringable | null;
    attributes?: Array<{
      className?: string;
      voice?: boolean;
      fileName?: string;
    }>;
  };
}

/** Вложения, которые сохраняем файлом (общий список CRM): стикеры, геолокацию и контакты — нет. */
const DOWNLOADABLE_KINDS = new Set<AttachmentKind>(FILE_ATTACHMENT_KINDS);
const PHOTO_MIME_TYPE = 'image/jpeg';

/**
 * Что известно о файле вложения до скачивания. null — вложение не сохраняем.
 * У фото Telegram не сообщает размер заранее, но они всегда небольшие (сжатые JPEG).
 */
export function mediaFileInfo(
  media: unknown,
  attachment: MessageAttachment | null,
): { size: number | null; mimeType: string | null } | null {
  if (!attachment || !DOWNLOADABLE_KINDS.has(attachment.kind)) return null;
  const value = media as MediaLike | undefined;
  if (value?.className === 'MessageMediaPhoto')
    return { size: null, mimeType: PHOTO_MIME_TYPE };
  const size = Number(value?.document?.size?.toString());
  return {
    size: Number.isFinite(size) ? size : null,
    mimeType: value?.document?.mimeType ?? null,
  };
}

/** Клиентский чат — личная переписка с живым человеком, а не бот, группа или «Избранное». */
export function isClientChat(
  chat:
    | {
        className?: string;
        id?: Stringable;
        bot?: boolean | null;
        self?: boolean | null;
      }
    | null
    | undefined,
): chat is TelegramUserLike {
  return Boolean(
    chat &&
    chat.className === 'User' &&
    !chat.bot &&
    !chat.self &&
    chat.id?.toString() !== TELEGRAM_SERVICE_USER_ID,
  );
}

export function attachmentOf(media: unknown): MessageAttachment | null {
  const value = media as MediaLike | undefined;
  switch (value?.className) {
    case undefined:
    case 'MessageMediaEmpty':
    case 'MessageMediaWebPage':
      return null;
    case 'MessageMediaPhoto':
      return { kind: 'photo' };
    case 'MessageMediaGeo':
    case 'MessageMediaGeoLive':
    case 'MessageMediaVenue':
      return { kind: 'location' };
    case 'MessageMediaContact':
      return { kind: 'contact' };
    case 'MessageMediaDocument':
      return documentAttachment(value.document?.attributes ?? []);
    default:
      return { kind: 'other' };
  }
}

function documentAttachment(
  attributes: NonNullable<NonNullable<MediaLike['document']>['attributes']>,
): MessageAttachment {
  const byClass = (name: string) =>
    attributes.find((attribute) => attribute.className === name);
  const audio = byClass('DocumentAttributeAudio');
  if (audio) return { kind: audio.voice ? 'voice' : 'audio' };
  if (byClass('DocumentAttributeSticker')) return { kind: 'sticker' };
  if (byClass('DocumentAttributeVideo')) return { kind: 'video' };
  const fileName = byClass('DocumentAttributeFilename')?.fileName;
  return fileName ? { kind: 'document', fileName } : { kind: 'document' };
}

/** Собеседник в общем формате CRM из пользователя GramJS. */
export function peerOf(chat: TelegramUserLike): MessengerPeer {
  return {
    externalId: chat.id.toString(),
    ...(chat.firstName && { firstName: chat.firstName }),
    ...(chat.lastName && { lastName: chat.lastName }),
    ...(chat.username && { username: chat.username }),
    ...(chat.phone && { phone: chat.phone }),
    ...(chat.accessHash && { accessHash: chat.accessHash.toString() }),
  };
}

/** Сообщение личного чата в общем формате CRM. chat — собеседник (клиент). */
export function toIncomingMessage(
  channelId: string,
  message: TelegramMessageLike,
  chat: TelegramUserLike,
): IncomingMessage {
  const peer = peerOf(chat);
  return {
    channelId,
    externalChatId: peer.externalId,
    externalMessageId: String(message.id),
    direction: message.out ? 'OUT' : 'IN',
    text: message.message?.trim() ? message.message : null,
    attachment: attachmentOf(message.media),
    sentAt: new Date(message.date * MS_PER_SECOND),
    peer,
  };
}

/** Минимум полей служебного сообщения GramJS (Api.MessageService). */
export interface TelegramServiceMessageLike {
  id: number;
  out?: boolean;
  date: number;
  action?: {
    className?: string;
    video?: boolean | null;
    duration?: number | null;
    reason?: { className?: string } | null;
  };
}

const PHONE_CALL_ACTION = 'MessageActionPhoneCall';
/** Так Telegram завершает звонок, который собеседник сбросил. */
const DECLINED_REASON = 'PhoneCallDiscardReasonBusy';

function callOutcomeOf(
  durationSec: number,
  reason: string | undefined,
): CallOutcome {
  if (durationSec > 0) return 'answered';
  return reason === DECLINED_REASON ? 'declined' : 'missed';
}

/**
 * Звонок в личном чате → отметка о звонке в переписке. null — служебное сообщение не о звонке.
 * Был разговор — есть длительность; иначе звонок сбросили (Busy) или не взяли трубку.
 */
export function toCallMessage(
  channelId: string,
  message: TelegramServiceMessageLike,
  chat: TelegramUserLike,
): IncomingMessage | null {
  const action = message.action;
  if (action?.className !== PHONE_CALL_ACTION) return null;
  const durationSec = action.duration ?? 0;
  const peer = peerOf(chat);
  return {
    channelId,
    externalChatId: peer.externalId,
    externalMessageId: String(message.id),
    direction: message.out ? 'OUT' : 'IN',
    text: null,
    attachment: {
      kind: 'call',
      call: {
        outcome: callOutcomeOf(durationSec, action.reason?.className),
        ...(durationSec > 0 && { durationSec }),
        ...(action.video && { video: true }),
      },
    },
    sentAt: new Date(message.date * MS_PER_SECOND),
    peer,
  };
}
