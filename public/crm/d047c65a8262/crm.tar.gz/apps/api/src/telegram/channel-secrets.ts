import { Inject, Injectable } from '@nestjs/common';
import { SecretBox } from '../common/secret-box.js';
import { ENV, type Env } from '../config/env.js';

/** Шифрование сессий каналов ключом CHANNEL_SECRET_KEY. */
@Injectable()
export class ChannelSecrets {
  private readonly box: SecretBox | null;

  constructor(@Inject(ENV) env: Env) {
    this.box = env.CHANNEL_SECRET_KEY ? new SecretBox(env.CHANNEL_SECRET_KEY) : null;
  }

  encrypt(value: string): string {
    return this.require().encrypt(value);
  }

  decrypt(value: string): string {
    return this.require().decrypt(value);
  }

  private require(): SecretBox {
    if (!this.box) {
      throw new Error('CHANNEL_SECRET_KEY не задан: хранить сессии мессенджеров нельзя');
    }
    return this.box;
  }
}
