import { telegramErrorMessage } from './telegram-errors.js';

const rpc = (errorMessage: string) =>
  Object.assign(new Error(errorMessage), { errorMessage });

describe('telegramErrorMessage', () => {
  it.each([
    ['PHONE_CODE_INVALID', 'Неверный код'],
    ['PHONE_CODE_EXPIRED', 'Код устарел'],
    ['PASSWORD_HASH_INVALID', 'Неверный облачный пароль'],
    ['PHONE_NUMBER_INVALID', 'Неверный номер'],
    ['USER_IS_BLOCKED', 'заблокировал'],
    ['AUTH_KEY_UNREGISTERED', 'Сессия Telegram завершена'],
  ])('translates %s', (code, expected) => {
    expect(telegramErrorMessage(rpc(code))).toContain(expected);
  });

  it('includes the wait time for flood errors', () => {
    expect(
      telegramErrorMessage(
        Object.assign(rpc('FLOOD_WAIT_X'), { seconds: 125 }),
      ),
    ).toContain('3 мин');
    // Так выглядит настоящая FloodWaitError из GramJS.
    expect(
      telegramErrorMessage(Object.assign(rpc('FLOOD'), { seconds: 600 })),
    ).toContain('10 мин');
  });

  it('explains privacy refusals instead of asking to retry', () => {
    expect(telegramErrorMessage(rpc('USER_PRIVACY_RESTRICTED'))).toContain(
      'WhatsApp',
    );
  });

  it('falls back to a generic message without leaking internals', () => {
    expect(telegramErrorMessage(new Error('socket hang up at 10.0.0.1'))).toBe(
      'Ошибка Telegram. Попробуйте ещё раз.',
    );
  });
});
