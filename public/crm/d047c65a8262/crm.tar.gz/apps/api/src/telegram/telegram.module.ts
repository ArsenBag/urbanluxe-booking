import { Module } from '@nestjs/common';
import { InboxModule } from '../inbox/inbox.module.js';
import { ChannelSecrets } from './channel-secrets.js';
import { ChannelsController } from './channels.controller.js';
import { TelegramAuthService } from './telegram-auth.service.js';
import { TelegramClientFactory } from './telegram-client.factory.js';
import { TelegramRuntime } from './telegram-runtime.service.js';

@Module({
  imports: [InboxModule],
  controllers: [ChannelsController],
  providers: [TelegramClientFactory, ChannelSecrets, TelegramRuntime, TelegramAuthService],
})
export class TelegramModule {}
