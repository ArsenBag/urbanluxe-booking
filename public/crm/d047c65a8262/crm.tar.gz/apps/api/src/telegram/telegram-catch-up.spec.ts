import type { TelegramClient } from 'telegram';
import {
  floodWaitSeconds,
  TelegramCatchUp,
  type CatchUpMessage,
  type DeliveryResult,
} from './telegram-catch-up.js';

const nowSeconds = () => Math.floor(Date.now() / 1000);
const HOUR = 3600;

const user = (id: string, extra: Record<string, unknown> = {}) => ({
  className: 'User',
  id: { toString: () => id },
  bot: false,
  self: false,
  ...extra,
});

interface StubDialog {
  entity: ReturnType<typeof user>;
  date: number;
  pinned: boolean;
  messages: CatchUpMessage[];
}

function setup(
  dialogs: StubDialog[],
  deliver: (message: CatchUpMessage, chatId: string) => DeliveryResult = () =>
    'new',
) {
  const delivered: Array<{ chat: string; date: number }> = [];
  const getMessages = vi.fn(async (entity: { id: { toString(): string } }) => {
    const dialog = dialogs.find(
      (item) => item.entity.id.toString() === entity.id.toString(),
    );
    const failure = (dialog?.entity as { failWith?: unknown } | undefined)
      ?.failWith;
    if (failure) throw failure;
    return [...(dialog?.messages ?? [])].sort((a, b) => b.date - a.date);
  });
  const getDialogs = vi.fn(async () =>
    dialogs.map(({ entity, date, pinned }) => ({ entity, date, pinned })),
  );
  const logger = { log: vi.fn(), warn: vi.fn() };
  const onError = vi.fn();
  const catchUp = new TelegramCatchUp(
    { getDialogs, getMessages } as unknown as TelegramClient,
    {
      lookbackMs: 6 * HOUR * 1000,
      deliver: async (message, chat) => {
        delivered.push({ chat: chat.id.toString(), date: message.date });
        return deliver(message, chat.id.toString());
      },
      onError,
      logger,
    },
  );
  return { catchUp, delivered, getMessages, getDialogs, logger, onError };
}

const message = (date: number): CatchUpMessage => ({
  className: 'Message',
  date,
});

describe('TelegramCatchUp', () => {
  it('delivers fresh messages of client chats oldest first and stops at old dialogs', async () => {
    const now = nowSeconds();
    const { catchUp, delivered, getMessages } = setup([
      {
        entity: user('pinned-old'),
        date: now - 48 * HOUR,
        pinned: true,
        messages: [message(now - 48 * HOUR)],
      },
      {
        entity: user('client'),
        date: now - 10,
        pinned: false,
        messages: [
          message(now - 7 * HOUR),
          message(now - 300),
          message(now - 10),
        ],
      },
      {
        entity: user('bot', { bot: true }),
        date: now - 20,
        pinned: false,
        messages: [message(now - 20)],
      },
      {
        entity: { ...user('group'), className: 'Channel' },
        date: now - 30,
        pinned: false,
        messages: [message(now - 30)],
      },
      {
        entity: user('stale'),
        date: now - 24 * HOUR,
        pinned: false,
        messages: [message(now - 24 * HOUR)],
      },
    ]);

    await catchUp.run();

    expect(delivered).toEqual([
      { chat: 'client', date: now - 300 },
      { chat: 'client', date: now - 10 },
    ]);
    expect(getMessages).toHaveBeenCalledTimes(1);
  });

  it('retries a message that could not be saved on the next pass', async () => {
    const now = nowSeconds();
    let attempts = 0;
    const { catchUp, delivered } = setup(
      [
        {
          entity: user('client'),
          date: now - 60,
          pinned: false,
          messages: [message(now - 1800)],
        },
      ],
      () => (++attempts === 1 ? 'failed' : 'new'),
    );

    await catchUp.run();
    await catchUp.run();
    await catchUp.run();

    expect(delivered).toHaveLength(2);
  });

  it('skips a broken dialog and keeps syncing the others', async () => {
    const now = nowSeconds();
    const { catchUp, delivered, logger } = setup([
      {
        entity: user('broken', { failWith: new Error('PEER_ID_INVALID') }),
        date: now - 5,
        pinned: false,
        messages: [],
      },
      {
        entity: user('client'),
        date: now - 10,
        pinned: false,
        messages: [message(now - 10)],
      },
    ]);

    await catchUp.run();

    expect(delivered).toEqual([{ chat: 'client', date: now - 10 }]);
    expect(logger.warn).toHaveBeenCalled();
  });

  it('stops and waits when Telegram asks to slow down', async () => {
    const now = nowSeconds();
    const flood = Object.assign(
      new Error('A wait of 120 seconds is required'),
      { errorMessage: 'FLOOD', seconds: 120 },
    );
    const { catchUp, delivered, getDialogs } = setup([
      {
        entity: user('limited', { failWith: flood }),
        date: now - 5,
        pinned: false,
        messages: [],
      },
      {
        entity: user('client'),
        date: now - 10,
        pinned: false,
        messages: [message(now - 10)],
      },
    ]);

    await catchUp.run();
    await catchUp.run();

    expect(delivered).toEqual([]);
    expect(getDialogs).toHaveBeenCalledTimes(1);
  });

  it('reports a failed pass, e.g. a revoked session', async () => {
    const { catchUp, getDialogs, onError } = setup([]);
    const revoked = Object.assign(new Error('AUTH_KEY_UNREGISTERED'), {
      errorMessage: 'AUTH_KEY_UNREGISTERED',
    });
    getDialogs.mockRejectedValueOnce(revoked);

    await catchUp.run();

    expect(onError).toHaveBeenCalledWith(revoked);
  });

  it('merges repeated requests into one delayed pass and cancels it on stop', async () => {
    vi.useFakeTimers();
    try {
      const { catchUp, getDialogs } = setup([]);
      catchUp.requestSoon();
      catchUp.requestSoon();
      await vi.advanceTimersByTimeAsync(5_000);
      expect(getDialogs).toHaveBeenCalledTimes(1);

      catchUp.requestSoon();
      catchUp.stop();
      await vi.advanceTimersByTimeAsync(5_000);
      expect(getDialogs).toHaveBeenCalledTimes(1);
    } finally {
      vi.useRealTimers();
    }
  });
});

describe('floodWaitSeconds', () => {
  it('reads the wait only from flood errors', () => {
    expect(floodWaitSeconds({ errorMessage: 'FLOOD', seconds: 30 })).toBe(30);
    expect(
      floodWaitSeconds({ errorMessage: 'FLOOD_WAIT_30', seconds: 30 }),
    ).toBe(30);
    expect(floodWaitSeconds(new Error('timeout'))).toBeNull();
    expect(floodWaitSeconds(null)).toBeNull();
  });
});
