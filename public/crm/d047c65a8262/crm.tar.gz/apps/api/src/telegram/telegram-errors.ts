const SECONDS_PER_MINUTE = 60;

const MESSAGES: Record<string, string> = {
  PHONE_NUMBER_INVALID:
    'Неверный номер телефона. Укажите номер в международном формате, например +998 93 206 28 91.',
  PHONE_NUMBER_BANNED: 'Этот номер заблокирован в Telegram.',
  PHONE_CODE_INVALID:
    'Неверный код. Проверьте сообщение от Telegram и попробуйте ещё раз.',
  PHONE_CODE_EXPIRED: 'Код устарел. Запросите новый.',
  PHONE_CODE_EMPTY: 'Введите код из Telegram.',
  PASSWORD_HASH_INVALID: 'Неверный облачный пароль (двухэтапная проверка).',
  SESSION_PASSWORD_NEEDED: 'Нужен облачный пароль (двухэтапная проверка).',
  AUTH_KEY_UNREGISTERED:
    'Сессия Telegram завершена (возможно, её закрыли в настройках Telegram). Подключите аккаунт заново.',
  SESSION_REVOKED:
    'Сессия Telegram завершена (возможно, её закрыли в настройках Telegram). Подключите аккаунт заново.',
  USER_DEACTIVATED: 'Аккаунт Telegram удалён или заблокирован.',
  USER_IS_BLOCKED: 'Клиент заблокировал аккаунт компании в Telegram.',
  INPUT_USER_DEACTIVATED: 'Аккаунт клиента в Telegram удалён.',
  PEER_FLOOD:
    'Telegram временно ограничил отправку сообщений с аккаунта. Подождите и не пишите новым людям массово.',
  PEER_ID_INVALID:
    'Telegram не узнаёт этого собеседника. Попросите клиента написать ещё раз.',
  MESSAGE_TOO_LONG: 'Сообщение слишком длинное для Telegram.',
  PRIVACY_PREMIUM_REQUIRED:
    'Клиент принимает сообщения только от контактов или Telegram Premium. Напишите ему в WhatsApp.',
  USER_PRIVACY_RESTRICTED:
    'Клиент запретил писать ему незнакомым. Напишите ему в WhatsApp.',
};

const GENERIC = 'Ошибка Telegram. Попробуйте ещё раз.';

/** Понятный сотруднику текст ошибки Telegram. Технические детали не показываем. */
export function telegramErrorMessage(error: unknown): string {
  const { errorMessage, seconds } = (error ?? {}) as {
    errorMessage?: string;
    seconds?: number;
  };
  if (!errorMessage) return GENERIC;
  // GramJS отдаёт FloodWaitError с кодом «FLOOD» и полем seconds; в сыром виде код — FLOOD_WAIT_N.
  if (errorMessage === 'FLOOD' || errorMessage.startsWith('FLOOD_WAIT')) {
    const minutes = Math.max(
      1,
      Math.ceil((seconds ?? SECONDS_PER_MINUTE) / SECONDS_PER_MINUTE),
    );
    return `Telegram просит подождать ${minutes} мин перед следующей попыткой.`;
  }
  return MESSAGES[errorMessage] ?? GENERIC;
}

export function isTelegramError(error: unknown, code: string): boolean {
  return (error as { errorMessage?: string } | null)?.errorMessage === code;
}

/** Ошибки, после которых сессия недействительна и аккаунт нужно подключать заново. */
export function isSessionRevoked(error: unknown): boolean {
  return [
    'AUTH_KEY_UNREGISTERED',
    'SESSION_REVOKED',
    'USER_DEACTIVATED',
    'AUTH_KEY_DUPLICATED',
  ].some((code) => isTelegramError(error, code));
}
