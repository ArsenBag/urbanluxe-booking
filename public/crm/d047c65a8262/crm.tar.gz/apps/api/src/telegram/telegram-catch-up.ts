import { setTimeout as sleep } from 'node:timers/promises';
import type { Logger } from '@nestjs/common';
import type { TelegramClient } from 'telegram';
import { isClientChat, type TelegramUserLike } from './telegram-mapper.js';

/** Регулярная сверка: события Telegram иногда не доходят (обрыв связи, перезапуск CRM). */
const SYNC_INTERVAL_MS = 2 * 60_000;
/** Первая сверка — вскоре после подключения: догружаем пропущенное за время перезапуска. */
const FIRST_SYNC_DELAY_MS = 15_000;
/** Сообщение без данных собеседника — сверяемся через несколько секунд, собрав соседние. */
const REQUESTED_SYNC_DELAY_MS = 5_000;
/** Запас назад: сообщение могло прийти в Telegram чуть раньше, чем закончилась прошлая сверка. */
const OVERLAP_MS = 60_000;
/** Неудавшееся сообщение повторяем, но не дольше этого срока: одна битая запись не держит сверку. */
const MAX_RETRY_MS = 6 * 60 * 60_000;
const DIALOG_LIMIT = 50;
const MESSAGES_PER_DIALOG = 50;
/** Пауза между диалогами: личный аккаунт не должен заваливать Telegram запросами. */
const PAUSE_BETWEEN_DIALOGS_MS = 500;
const MS_PER_SECOND = 1000;

/** Сообщение из истории диалога (Api.Message или Api.MessageService). */
export interface CatchUpMessage {
  className?: string;
  date: number;
}

/** new — сообщения в CRM не было; duplicate — уже было; failed — сохранить не удалось. */
export type DeliveryResult = 'new' | 'duplicate' | 'failed';

export interface TelegramCatchUpOptions {
  /** Насколько назад смотреть при первой сверке; 0 — только новое (историю грузит импорт). */
  lookbackMs: number;
  /** Передаёт сообщение в общий приём; повторы приём отбрасывает сам. */
  deliver: (
    message: CatchUpMessage,
    chat: TelegramUserLike,
  ) => Promise<DeliveryResult>;
  /** Ошибка всего прохода (не одного диалога) — например, отозванная сессия. */
  onError?: (error: unknown) => Promise<void> | void;
  logger: Pick<Logger, 'log' | 'warn'>;
}

/** Telegram просит подождать (FLOOD_WAIT): сколько секунд. null — это другая ошибка. */
export function floodWaitSeconds(error: unknown): number | null {
  const value = error as { seconds?: unknown; errorMessage?: unknown } | null;
  const isFlood =
    typeof value?.errorMessage === 'string' &&
    value.errorMessage.startsWith('FLOOD');
  return isFlood && typeof value.seconds === 'number' ? value.seconds : null;
}

const errorText = (error: unknown) =>
  error instanceof Error ? error.message : String(error);

type Dialogs = Awaited<ReturnType<TelegramClient['getDialogs']>>;
/** Собеседник-клиент: сущность GramJS, прошедшая isClientChat. */
type ClientChat = NonNullable<Dialogs[number]['entity']> & TelegramUserLike;

/**
 * Сверка свежих диалогов Telegram с CRM. Нужна, потому что событие о новом сообщении приходит
 * не всегда: новый собеседник бывает без данных о себе, а обрыв связи и перезапуск CRM
 * библиотека не догоняет. Свежие диалоги перечитываются, недостающее догружается.
 */
export class TelegramCatchUp {
  private syncedUntil: number;
  private pausedUntil = 0;
  private isStopped = false;
  private isRerunRequested = false;
  private interval: NodeJS.Timeout | null = null;
  private delayed: NodeJS.Timeout | null = null;
  private running: Promise<void> | null = null;

  constructor(
    private readonly client: TelegramClient,
    private readonly options: TelegramCatchUpOptions,
  ) {
    this.syncedUntil = Date.now() - options.lookbackMs;
  }

  start(): void {
    this.requestSoon(FIRST_SYNC_DELAY_MS);
    this.interval = setInterval(() => void this.run(), SYNC_INTERVAL_MS);
    this.interval.unref();
  }

  /** Останавливает таймеры и идущий проход (он дойдёт до ближайшей проверки и выйдет). */
  stop(): void {
    this.isStopped = true;
    if (this.interval) clearInterval(this.interval);
    if (this.delayed) clearTimeout(this.delayed);
    this.interval = null;
    this.delayed = null;
  }

  /** Сверка вскоре; повторные просьбы до её начала сливаются в одну. */
  requestSoon(delayMs = REQUESTED_SYNC_DELAY_MS): void {
    if (this.delayed || this.isStopped) return;
    this.delayed = setTimeout(() => {
      this.delayed = null;
      void this.run();
    }, delayMs);
    this.delayed.unref();
  }

  /**
   * Один проход за раз. Просьба во время прохода — ещё один проход после него: текущий мог
   * прочитать список диалогов до нового сообщения. Ошибки логируются, следующая сверка повторит.
   */
  run(): Promise<void> {
    if (this.running) {
      this.isRerunRequested = true;
      return this.running;
    }
    this.running = this.sync()
      .catch(async (error: unknown) => {
        this.options.logger.warn(
          `Сверка с Telegram не удалась: ${errorText(error)}`,
        );
        await this.options.onError?.(error);
      })
      .finally(() => {
        this.running = null;
        if (this.isRerunRequested && !this.isStopped) {
          this.isRerunRequested = false;
          void this.run();
        }
      });
    return this.running;
  }

  private async sync(): Promise<void> {
    if (this.isStopped || Date.now() < this.pausedUntil) return;
    const startedAt = Date.now();
    const sinceSeconds = (this.syncedUntil - OVERLAP_MS) / MS_PER_SECOND;
    const chats = this.freshClientChats(
      await this.client.getDialogs({ limit: DIALOG_LIMIT }),
      sinceSeconds,
    );
    let restored = 0;
    /** Время самого раннего несохранённого сообщения (секунды); Infinity — сбоев не было. */
    let oldestFailure = Infinity;
    for (const [index, chat] of chats.entries()) {
      if (this.isStopped) return;
      if (index > 0) await sleep(PAUSE_BETWEEN_DIALOGS_MS);
      try {
        const result = await this.syncChat(chat, sinceSeconds);
        restored += result.restored;
        oldestFailure = Math.min(oldestFailure, result.oldestFailure);
      } catch (error) {
        const waitSeconds = floodWaitSeconds(error);
        if (waitSeconds !== null) {
          // Telegram просит подождать — прекращаем проход и ждём, окно сверки не сдвигаем.
          this.pausedUntil = Date.now() + waitSeconds * MS_PER_SECOND;
          this.options.logger.warn(
            `Сверка с Telegram приостановлена на ${waitSeconds} с по просьбе Telegram`,
          );
          return;
        }
        this.options.logger.warn(
          `Сверка с Telegram: диалог пропущен — ${errorText(error)}`,
        );
        oldestFailure = Math.min(oldestFailure, sinceSeconds);
      }
    }
    this.syncedUntil = this.nextSyncedUntil(startedAt, oldestFailure);
    if (restored > 0)
      this.options.logger.log(
        `Сверка с Telegram: догружено сообщений — ${restored}`,
      );
  }

  /** Диалоги с клиентами, где было что-то новое; от свежих к старым, закреплённые — вне порядка. */
  private freshClientChats(
    dialogs: Dialogs,
    sinceSeconds: number,
  ): ClientChat[] {
    const chats: ClientChat[] = [];
    for (const dialog of dialogs) {
      if (dialog.date < sinceSeconds) {
        if (dialog.pinned) continue;
        return chats;
      }
      const entity = dialog.entity;
      if (isClientChat(entity)) chats.push(entity);
    }
    if (dialogs.length >= DIALOG_LIMIT) {
      this.options.logger.warn(
        `Сверка с Telegram: все ${DIALOG_LIMIT} диалогов свежие — более старые не проверены`,
      );
    }
    return chats;
  }

  private async syncChat(
    chat: ClientChat,
    sinceSeconds: number,
  ): Promise<{ restored: number; oldestFailure: number }> {
    const messages: CatchUpMessage[] = await this.client.getMessages(chat, {
      limit: MESSAGES_PER_DIALOG,
    });
    // Telegram отдаёт от новых к старым; в CRM кладём по порядку, чтобы первое сообщение создало сделку.
    const fresh = messages
      .filter((message) => message.date >= sinceSeconds)
      .reverse();
    if (fresh.length >= MESSAGES_PER_DIALOG) {
      this.options.logger.warn(
        `Сверка с Telegram: в диалоге больше ${MESSAGES_PER_DIALOG} новых сообщений — ранние не догружены`,
      );
    }
    let restored = 0;
    let oldestFailure = Infinity;
    for (const message of fresh) {
      if (this.isStopped) break;
      const result = await this.options.deliver(message, chat);
      if (result === 'new') restored += 1;
      if (result === 'failed')
        oldestFailure = Math.min(oldestFailure, message.date);
    }
    return { restored, oldestFailure };
  }

  /** Неудавшееся повторим следующим проходом, но не старше MAX_RETRY_MS. */
  private nextSyncedUntil(
    startedAt: number,
    oldestFailureSeconds: number,
  ): number {
    if (!Number.isFinite(oldestFailureSeconds)) return startedAt;
    return Math.max(
      Math.min(startedAt, oldestFailureSeconds * MS_PER_SECOND),
      startedAt - MAX_RETRY_MS,
    );
  }
}
