import { attachmentOf, isClientChat, mediaFileInfo, toCallMessage, toIncomingMessage } from './telegram-mapper.js';

const user = (overrides: Record<string, unknown> = {}) => ({
  className: 'User',
  id: { toString: () => '555' },
  accessHash: { toString: () => '-777' },
  firstName: 'Азиз',
  lastName: 'Рахимов',
  username: 'aziz_r',
  phone: '998901234567',
  bot: false,
  self: false,
  ...overrides,
});

describe('isClientChat', () => {
  it('accepts a regular user', () => {
    expect(isClientChat(user())).toBe(true);
  });

  it.each([
    ['bots', { bot: true }],
    ['own account (Saved Messages)', { self: true }],
    ['Telegram service notifications', { id: { toString: () => '777000' } }],
    ['groups and channels', { className: 'Channel' }],
  ])('rejects %s', (_label, overrides) => {
    expect(isClientChat(user(overrides))).toBe(false);
  });
});

describe('attachmentOf', () => {
  const doc = (attributes: unknown[]) => ({ className: 'MessageMediaDocument', document: { attributes } });

  it.each([
    [{ className: 'MessageMediaPhoto' }, { kind: 'photo' }],
    [doc([{ className: 'DocumentAttributeAudio', voice: true }]), { kind: 'voice' }],
    [doc([{ className: 'DocumentAttributeAudio', voice: false }]), { kind: 'audio' }],
    [doc([{ className: 'DocumentAttributeVideo' }]), { kind: 'video' }],
    [doc([{ className: 'DocumentAttributeSticker' }]), { kind: 'sticker' }],
    [doc([{ className: 'DocumentAttributeFilename', fileName: 'паспорт.pdf' }]), { kind: 'document', fileName: 'паспорт.pdf' }],
    [{ className: 'MessageMediaGeo' }, { kind: 'location' }],
    [{ className: 'MessageMediaContact' }, { kind: 'contact' }],
    [{ className: 'MessageMediaWebPage' }, null],
    [undefined, null],
  ])('maps %o', (media, expected) => {
    expect(attachmentOf(media)).toEqual(expected);
  });
});

describe('toIncomingMessage', () => {
  it('normalizes an incoming text message', () => {
    const result = toIncomingMessage('channel-1', { id: 42, out: false, message: 'Есть свободная студия?', date: 1_790_000_000 }, user());

    expect(result).toEqual({
      channelId: 'channel-1',
      externalChatId: '555',
      externalMessageId: '42',
      direction: 'IN',
      text: 'Есть свободная студия?',
      attachment: null,
      sentAt: new Date(1_790_000_000_000),
      peer: { externalId: '555', firstName: 'Азиз', lastName: 'Рахимов', username: 'aziz_r', phone: '998901234567', accessHash: '-777' },
    });
  });

  it('marks messages sent from the phone as outgoing and keeps empty text as null', () => {
    const result = toIncomingMessage('c', { id: 1, out: true, message: '', date: 1, media: { className: 'MessageMediaPhoto' } }, user());

    expect(result).toMatchObject({ direction: 'OUT', text: null, attachment: { kind: 'photo' } });
  });
});

describe('mediaFileInfo', () => {
  it('knows photos are JPEG without a size', () => {
    expect(mediaFileInfo({ className: 'MessageMediaPhoto' }, { kind: 'photo' })).toEqual({ size: null, mimeType: 'image/jpeg' });
  });

  it('reads size and type of a document', () => {
    const media = { className: 'MessageMediaDocument', document: { mimeType: 'application/pdf', size: { toString: () => '2048' } } };
    expect(mediaFileInfo(media, { kind: 'document', fileName: 'a.pdf' })).toEqual({ size: 2048, mimeType: 'application/pdf' });
  });

  it('skips stickers, locations and messages without attachments', () => {
    expect(mediaFileInfo({ className: 'MessageMediaDocument' }, { kind: 'sticker' })).toBeNull();
    expect(mediaFileInfo({ className: 'MessageMediaGeo' }, { kind: 'location' })).toBeNull();
    expect(mediaFileInfo(undefined, null)).toBeNull();
  });
});

describe('toCallMessage', () => {
  const caller = user();
  const service = (action: Record<string, unknown>, out = false) => ({ id: 77, out, date: 1700000000, action });

  it('marks an incoming call without a conversation as missed', () => {
    const result = toCallMessage('c', service({ className: 'MessageActionPhoneCall', reason: { className: 'PhoneCallDiscardReasonMissed' } }), caller);
    expect(result).toMatchObject({
      externalMessageId: '77',
      direction: 'IN',
      text: null,
      attachment: { kind: 'call', call: { outcome: 'missed' } },
      sentAt: new Date(1700000000 * 1000),
    });
  });

  it('treats a dropped call as declined and a call with duration as answered', () => {
    const declined = toCallMessage('c', service({ className: 'MessageActionPhoneCall', reason: { className: 'PhoneCallDiscardReasonBusy' } }), caller);
    expect(declined?.attachment).toEqual({ kind: 'call', call: { outcome: 'declined' } });
    const answered = toCallMessage('c', service({ className: 'MessageActionPhoneCall', duration: 95, video: true }, true), caller);
    expect(answered?.direction).toBe('OUT');
    expect(answered?.attachment).toEqual({ kind: 'call', call: { outcome: 'answered', durationSec: 95, video: true } });
  });

  it('ignores other service messages', () => {
    expect(toCallMessage('c', service({ className: 'MessageActionHistoryClear' }), caller)).toBeNull();
  });
});
