import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Inject,
  Param,
  ParseUUIDPipe,
  Post,
} from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import {
  startTelegramLoginSchema,
  telegramCodeSchema,
  telegramPasswordSchema,
  type ChannelDto,
  type ChannelsOverviewDto,
} from '@crm/shared';
import { CurrentUser, Roles } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { ENV, type Env } from '../config/env.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { toChannelDto } from './channel.mapper.js';
import { TelegramAuthService } from './telegram-auth.service.js';
import { TelegramClientFactory } from './telegram-client.factory.js';

const uuid = () => new ParseUUIDPipe();

/** Каждый вход открывает соединение с Telegram и шлёт код — ограничиваем частоту. */
const LOGIN_ATTEMPTS_PER_MINUTE = 5;
const ONE_MINUTE_MS = 60_000;
const LoginThrottle = () =>
  Throttle({
    default: { limit: LOGIN_ATTEMPTS_PER_MINUTE, ttl: ONE_MINUTE_MS },
  });

/** Подключение мессенджеров — только администратор. */
@Controller('channels')
@Roles('ADMIN')
export class ChannelsController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly factory: TelegramClientFactory,
    private readonly telegramAuth: TelegramAuthService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  @Get()
  async overview(): Promise<ChannelsOverviewDto> {
    const channels = await this.prisma.channel.findMany({
      orderBy: { createdAt: 'asc' },
    });
    const base = this.env.PUBLIC_API_URL?.replace(/\/$/, '');
    return {
      telegramConfigured: this.factory.isConfigured,
      whatsappConfigured: Boolean(this.env.GREEN_API_ID_INSTANCE && this.env.GREEN_API_TOKEN),
      whatsappWebhookUrl: base ? `${base}/api/webhooks/whatsapp` : null,
      channels: channels.map(toChannelDto),
    };
  }

  @Post('telegram/login')
  @LoginThrottle()
  @HttpCode(HttpStatus.OK)
  startTelegramLogin(
    @Body(new ZodValidationPipe(startTelegramLoginSchema))
    input: { phone: string },
    @CurrentUser() actor: SessionUser,
  ): Promise<ChannelDto> {
    return this.telegramAuth.startLogin(input.phone, actor);
  }

  @Post(':id/login/code')
  @LoginThrottle()
  @HttpCode(HttpStatus.OK)
  submitCode(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(telegramCodeSchema)) input: { code: string },
    @CurrentUser() actor: SessionUser,
  ): Promise<ChannelDto> {
    return this.telegramAuth.submitCode(id, input.code, actor);
  }

  @Post(':id/login/password')
  @LoginThrottle()
  @HttpCode(HttpStatus.OK)
  submitPassword(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(telegramPasswordSchema))
    input: { password: string },
    @CurrentUser() actor: SessionUser,
  ): Promise<ChannelDto> {
    return this.telegramAuth.submitPassword(id, input.password, actor);
  }

  @Post(':id/disconnect')
  @HttpCode(HttpStatus.OK)
  disconnect(
    @Param('id', uuid()) id: string,
    @CurrentUser() actor: SessionUser,
  ): Promise<ChannelDto> {
    return this.telegramAuth.disconnect(id, actor);
  }
}
