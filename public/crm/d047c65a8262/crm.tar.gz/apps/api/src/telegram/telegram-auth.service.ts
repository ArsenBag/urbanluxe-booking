import {
  BadRequestException,
  Injectable,
  Logger,
  NotFoundException,
  type OnModuleDestroy,
} from '@nestjs/common';
import { formatPhone, normalizePhone, type ChannelDto } from '@crm/shared';
import { Api, type TelegramClient } from 'telegram';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { toChannelDto } from './channel.mapper.js';
import { ChannelSecrets } from './channel-secrets.js';
import { TelegramClientFactory } from './telegram-client.factory.js';
import { isTelegramError, telegramErrorMessage } from './telegram-errors.js';
import { TelegramRuntime } from './telegram-runtime.service.js';

/** Сколько ждём ввода кода, прежде чем забыть незавершённый вход. */
const PENDING_LOGIN_TTL_MS = 10 * 60_000;
/** Одновременно незавершённых входов: каждый держит открытое соединение с Telegram. */
const MAX_PENDING_LOGINS = 3;

interface PendingLogin {
  client: TelegramClient;
  phone: string;
  phoneCodeHash: string;
  timer: NodeJS.Timeout;
}

/**
 * Подключение личного аккаунта Telegram как ещё одного устройства:
 * номер → код из Telegram → облачный пароль (если включена двухэтапная проверка).
 * Код и пароль вводит владелец аккаунта; CRM их не хранит.
 */
@Injectable()
export class TelegramAuthService implements OnModuleDestroy {
  private readonly logger = new Logger(TelegramAuthService.name);
  private readonly pending = new Map<string, PendingLogin>();

  constructor(
    private readonly prisma: PrismaService,
    private readonly factory: TelegramClientFactory,
    private readonly runtime: TelegramRuntime,
    private readonly secrets: ChannelSecrets,
    private readonly audit: ActivityLogService,
  ) {}

  async onModuleDestroy(): Promise<void> {
    await Promise.all(
      [...this.pending.keys()].map((channelId) => this.dropPending(channelId)),
    );
  }

  async startLogin(rawPhone: string, actor: SessionUser): Promise<ChannelDto> {
    if (!this.factory.isConfigured) {
      throw new BadRequestException(
        'Telegram не настроен на сервере: добавьте TELEGRAM_API_ID и TELEGRAM_API_HASH в .env.',
      );
    }
    const phone = normalizePhone(rawPhone);
    if (!phone) {
      throw new BadRequestException({
        message: 'Неверный номер телефона',
        fields: { phone: 'Неверный номер телефона' },
      });
    }
    const channel = await this.prisma.channel.upsert({
      where: { type_phone: { type: 'TELEGRAM', phone } },
      create: {
        type: 'TELEGRAM',
        phone,
        name: `Telegram ${formatPhone(phone)}`,
        status: 'DISCONNECTED',
      },
      update: {},
    });
    if (channel.status === 'CONNECTED') {
      throw new BadRequestException('Этот аккаунт уже подключён');
    }

    await this.dropPending(channel.id);
    if (this.pending.size >= MAX_PENDING_LOGINS) {
      throw new BadRequestException(
        'Слишком много незавершённых подключений. Подождите 10 минут.',
      );
    }
    const client = this.factory.create();
    try {
      await client.connect();
      const { phoneCodeHash } = await client.sendCode(
        this.factory.credentials,
        phone,
      );
      this.remember(channel.id, { client, phone, phoneCodeHash });
    } catch (error) {
      await client.destroy().catch(() => undefined);
      throw new BadRequestException(telegramErrorMessage(error));
    }
    await this.audit.record(actor, {
      action: 'channel.login_started',
      entityType: 'channel',
      entityId: channel.id,
    });
    return this.setStatus(channel.id, 'AWAITING_CODE', null);
  }

  async submitCode(
    channelId: string,
    code: string,
    actor: SessionUser,
  ): Promise<ChannelDto> {
    const login = this.requirePending(channelId);
    try {
      const result = await login.client.invoke(
        new Api.auth.SignIn({
          phoneNumber: login.phone,
          phoneCodeHash: login.phoneCodeHash,
          phoneCode: code,
        }),
      );
      if (result instanceof Api.auth.AuthorizationSignUpRequired) {
        await this.dropPending(channelId);
        throw new BadRequestException(
          'Этот номер не зарегистрирован в Telegram',
        );
      }
      return await this.complete(channelId, login.client, actor);
    } catch (error) {
      if (error instanceof BadRequestException) throw error;
      if (isTelegramError(error, 'SESSION_PASSWORD_NEEDED')) {
        return this.setStatus(channelId, 'AWAITING_PASSWORD', null);
      }
      throw new BadRequestException({
        message: telegramErrorMessage(error),
        fields: { code: telegramErrorMessage(error) },
      });
    }
  }

  async submitPassword(
    channelId: string,
    password: string,
    actor: SessionUser,
  ): Promise<ChannelDto> {
    const login = this.requirePending(channelId);
    let failure: unknown = null;
    try {
      await login.client.signInWithPassword(this.factory.credentials, {
        password: async () => password,
        // true — прекратить попытки: иначе GramJS будет повторять тот же неверный пароль бесконечно.
        onError: async (error) => {
          failure = error;
          return true;
        },
      });
      return await this.complete(channelId, login.client, actor);
    } catch (error) {
      const cause = failure ?? error;
      throw new BadRequestException({
        message: telegramErrorMessage(cause),
        fields: { password: telegramErrorMessage(cause) },
      });
    }
  }

  /** Выход из аккаунта: сессия завершается и в Telegram («Устройства»), и в CRM. */
  async disconnect(channelId: string, actor: SessionUser): Promise<ChannelDto> {
    const channel = await this.prisma.channel.findUnique({
      where: { id: channelId },
    });
    if (!channel) {
      throw new NotFoundException('Канал не найден');
    }
    await this.dropPending(channelId);
    if (channel.sessionEncrypted && this.factory.isConfigured) {
      await this.logOutRemotely(channel.sessionEncrypted);
    }
    await this.runtime.stop(channelId);
    await this.prisma.channel.update({
      where: { id: channelId },
      data: { status: 'DISCONNECTED', sessionEncrypted: null, lastError: null },
    });
    await this.audit.record(actor, {
      action: 'channel.disconnected',
      entityType: 'channel',
      entityId: channelId,
    });
    return this.channelDto(channelId);
  }

  private async complete(
    channelId: string,
    client: TelegramClient,
    actor: SessionUser,
  ): Promise<ChannelDto> {
    const me = await client.getMe();
    const session = client.session.save() as unknown as string;
    this.forget(channelId);
    try {
      await this.prisma.channel.update({
        where: { id: channelId },
        data: {
          status: 'CONNECTED',
          sessionEncrypted: this.secrets.encrypt(session),
          externalAccountId: me.id.toString(),
          username: me.username ?? null,
          lastError: null,
        },
      });
      await this.runtime.start(channelId, client);
    } catch (error) {
      // Сессию не удалось сохранить: закрываем клиент, чтобы не осталось «висящего» устройства.
      await client.destroy().catch(() => undefined);
      throw error;
    }
    await this.audit.record(actor, {
      action: 'channel.connected',
      entityType: 'channel',
      entityId: channelId,
    });
    return this.channelDto(channelId);
  }

  private async logOutRemotely(sessionEncrypted: string): Promise<void> {
    const client = this.factory.create(this.secrets.decrypt(sessionEncrypted));
    try {
      await client.connect();
      await client.invoke(new Api.auth.LogOut());
    } catch (error) {
      // Сессию могли уже закрыть в самом Telegram — локально всё равно отключаем.
      this.logger.warn(
        `Выход из Telegram не подтверждён: ${telegramErrorMessage(error)}`,
      );
    } finally {
      await client.destroy().catch(() => undefined);
    }
  }

  private requirePending(channelId: string): PendingLogin {
    const login = this.pending.get(channelId);
    if (!login) {
      throw new BadRequestException(
        'Подключение не начато или истекло. Начните заново: введите номер телефона.',
      );
    }
    return login;
  }

  private remember(
    channelId: string,
    login: Omit<PendingLogin, 'timer'>,
  ): void {
    const timer = setTimeout(() => {
      // Ошибка в таймере не должна ронять процесс (необработанный rejection).
      this.dropPending(channelId)
        .then(() => this.setStatus(channelId, 'DISCONNECTED', null))
        .catch((error: unknown) =>
          this.logger.error(
            `Не удалось сбросить истёкший вход ${channelId}`,
            error instanceof Error ? error.stack : error,
          ),
        );
    }, PENDING_LOGIN_TTL_MS);
    timer.unref();
    this.pending.set(channelId, { ...login, timer });
  }

  /** Убирает незавершённый вход, не закрывая клиент (он передан в работу). */
  private forget(channelId: string): void {
    const login = this.pending.get(channelId);
    if (login) clearTimeout(login.timer);
    this.pending.delete(channelId);
  }

  private async dropPending(channelId: string): Promise<void> {
    const login = this.pending.get(channelId);
    this.forget(channelId);
    if (login) {
      await login.client.destroy().catch(() => undefined);
    }
  }

  private async setStatus(
    channelId: string,
    status: 'AWAITING_CODE' | 'AWAITING_PASSWORD' | 'DISCONNECTED',
    lastError: string | null,
  ) {
    await this.prisma.channel.update({
      where: { id: channelId },
      data: { status, lastError },
    });
    return this.channelDto(channelId);
  }

  private async channelDto(channelId: string): Promise<ChannelDto> {
    return toChannelDto(
      await this.prisma.channel.findUniqueOrThrow({ where: { id: channelId } }),
    );
  }
}
