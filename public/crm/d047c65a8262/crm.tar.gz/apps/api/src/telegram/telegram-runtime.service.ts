import { setTimeout as sleep } from 'node:timers/promises';
import {
  Injectable,
  Logger,
  type OnApplicationBootstrap,
  type OnModuleDestroy,
} from '@nestjs/common';
import {
  MAX_FILE_BYTES,
  TELEGRAM_USERNAME_PATTERN,
  type MessageAttachment,
} from '@crm/shared';
import { Api, type TelegramClient } from 'telegram';
import { CustomFile } from 'telegram/client/uploads.js';
import {
  NewMessage,
  Raw,
  type NewMessageEvent,
} from 'telegram/events/index.js';
import { returnBigInt } from 'telegram/Helpers.js';
import { ChannelRegistry } from '../inbox/channel-registry.js';
import { InboxIngestService } from '../inbox/inbox-ingest.service.js';
import {
  AvatarSourceUnavailableError,
  MessengerSendError,
  MessengerUnavailableError,
  type AttachmentTarget,
  type AvatarTarget,
  type DownloadedMedia,
  type Recipient,
  type RecipientQuery,
  type IncomingMessage,
  type MessengerSender,
  type OutboundMessage,
  type SentMessage,
} from '../inbox/messenger.types.js';
import type { Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { ChannelSecrets } from './channel-secrets.js';
import { TelegramClientFactory } from './telegram-client.factory.js';
import {
  floodWaitSeconds,
  TelegramCatchUp,
  type CatchUpMessage,
  type DeliveryResult,
} from './telegram-catch-up.js';
import { isSessionRevoked, telegramErrorMessage } from './telegram-errors.js';
import {
  isClientChat,
  mediaFileInfo,
  peerOf as messengerPeerOf,
  toCallMessage,
  toIncomingMessage,
  type TelegramMessageLike,
  type TelegramServiceMessageLike,
  type TelegramUserLike,
} from './telegram-mapper.js';

/** Собеседник для запросов к Telegram: с ключом доступа работает и после перезапуска. */
function peerOf(
  externalChatId: string,
  accessHash: string | null,
): Api.InputPeerUser | string {
  return accessHash
    ? new Api.InputPeerUser({
        userId: returnBigInt(externalChatId),
        accessHash: returnBigInt(accessHash),
      })
    : externalChatId;
}

/** Ошибки Telegram «такого пользователя нет» при поиске собеседника. */
const NOT_FOUND_ERRORS = new Set([
  'PHONE_NOT_OCCUPIED',
  'USERNAME_NOT_OCCUPIED',
  'USERNAME_INVALID',
]);

/** Так GramJS сообщает, что имени нет (обычная ошибка без кода Telegram). */
const ENTITY_NOT_FOUND = /^(No user has|Cannot find any entity)/;
/** После PEER_FLOOD Telegram ограничивает новые диалоги надолго — не спрашиваем полчаса. */
const PEER_FLOOD_PAUSE_MS = 30 * 60_000;

function recipientErrorMessage(error: unknown, byUsername: boolean): string {
  const code = (error as { errorMessage?: string } | null)?.errorMessage;
  const isNotFound =
    (code && NOT_FOUND_ERRORS.has(code)) ||
    (byUsername &&
      error instanceof Error &&
      ENTITY_NOT_FOUND.test(error.message));
  if (!isNotFound) return telegramErrorMessage(error);
  return byUsername
    ? 'В Telegram нет пользователя с таким именем.'
    : 'Не нашли номер в Telegram: аккаунта нет или клиент скрыл поиск по номеру. Попробуйте @username или WhatsApp.';
}

/** Сколько дней истории импортируем при подключении (решение владельца). */
const HISTORY_DAYS = 90;
/** Потолок сообщений на один диалог при импорте: защита от очень длинных переписок. */
const HISTORY_MAX_MESSAGES_PER_CHAT = 500;
const MS_PER_DAY = 86_400_000;
/** После подключения (в том числе после перезапуска CRM) догружаем пропущенное за этот срок. */
const CATCH_UP_LOOKBACK_MS = 6 * 60 * 60_000;
const MS_PER_SECOND = 1000;
/** Пауза между загрузками файлов по запросу сотрудников. */
const FILE_REQUEST_GAP_MS = 1500;
/** Больше ждущих загрузок не принимаем: сотрудник увидит «попробуйте через минуту». */
const MAX_QUEUED_FILE_REQUESTS = 10;

/** Подключённые аккаунты Telegram: приём сообщений, отправка, импорт истории. */
@Injectable()
export class TelegramRuntime
  implements MessengerSender, OnApplicationBootstrap, OnModuleDestroy
{
  readonly type = 'TELEGRAM' as const;
  private readonly logger = new Logger(TelegramRuntime.name);
  private readonly clients = new Map<string, TelegramClient>();
  /** Каналы, для которых сейчас идёт импорт истории (защита от двойного запуска). */
  private readonly importing = new Set<string>();
  /** Сверка свежих диалогов по каждому подключённому каналу. */
  private readonly catchUps = new Map<string, TelegramCatchUp>();
  /** До какого момента не искать новых собеседников (Telegram попросил подождать). */
  private readonly lookupBlockedUntil = new Map<string, number>();
  /** Очередь загрузок файлов по запросу (inFileQueue) и число ждущих в ней. */
  private fileRequests: Promise<unknown> = Promise.resolve();
  private queuedFileRequests = 0;

  constructor(
    private readonly prisma: PrismaService,
    private readonly ingest: InboxIngestService,
    private readonly registry: ChannelRegistry,
    private readonly factory: TelegramClientFactory,
    private readonly secrets: ChannelSecrets,
  ) {}

  async onApplicationBootstrap(): Promise<void> {
    if (!this.factory.isConfigured) {
      this.logger.log(
        'Telegram не настроен (нет TELEGRAM_API_ID/HASH) — канал отключён',
      );
      return;
    }
    this.registry.register(this);
    const channels = await this.prisma.channel.findMany({
      where: {
        type: 'TELEGRAM',
        status: 'CONNECTED',
        sessionEncrypted: { not: null },
      },
    });
    // Подключаемся в фоне: недоступность Telegram не должна мешать запуску CRM.
    for (const channel of channels) {
      void this.resume(channel.id, channel.sessionEncrypted as string);
    }
  }

  async onModuleDestroy(): Promise<void> {
    await Promise.all(
      [...this.clients.keys()].map((channelId) => this.stop(channelId)),
    );
  }

  /** Начинает слушать уже авторизованный клиент (после входа или при запуске). */
  async start(channelId: string, client: TelegramClient): Promise<void> {
    await this.stop(channelId);
    this.clients.set(channelId, client);
    client.addEventHandler(
      (event: NewMessageEvent) => this.onNewMessage(channelId, event),
      new NewMessage({}),
    );
    // Звонки приходят служебными сообщениями, а NewMessage их не передаёт.
    client.addEventHandler(
      (update: Api.UpdateNewMessage) =>
        this.onServiceMessage(channelId, client, update),
      new Raw({ types: [Api.UpdateNewMessage] }),
    );

    const channel = await this.prisma.channel.findUnique({
      where: { id: channelId },
      select: { historyImportedAt: true },
    });
    const catchUp = new TelegramCatchUp(client, {
      // Первое подключение: историю грузит импорт (без сделок и непрочитанных) — сверка только с «сейчас».
      lookbackMs: channel?.historyImportedAt ? CATCH_UP_LOOKBACK_MS : 0,
      deliver: (message, chat) =>
        this.deliverCaughtUp(channelId, message, chat),
      onError: async (error) => {
        if (isSessionRevoked(error)) await this.markRevoked(channelId, error);
      },
      logger: this.logger,
    });
    this.catchUps.set(channelId, catchUp);
    catchUp.start();

    if (!channel?.historyImportedAt && !this.importing.has(channelId)) {
      this.importing.add(channelId);
      // importHistory сам ловит все ошибки; finally снимает флаг, чтобы импорт можно было повторить.
      void this.importHistory(channelId, client).finally(() =>
        this.importing.delete(channelId),
      );
    }
  }

  async stop(channelId: string): Promise<void> {
    const client = this.clients.get(channelId);
    this.clients.delete(channelId);
    this.catchUps.get(channelId)?.stop();
    this.catchUps.delete(channelId);
    if (client) {
      await client
        .destroy()
        .catch((error: unknown) =>
          this.logger.warn(
            `Ошибка отключения клиента Telegram: ${String(error)}`,
          ),
        );
    }
  }

  async send(message: OutboundMessage): Promise<SentMessage> {
    const client = this.clients.get(message.channelId);
    if (!client) {
      throw new MessengerSendError(
        'Telegram сейчас не подключён. Проверьте канал в разделе «Каналы».',
      );
    }
    const peer = peerOf(message.externalChatId, message.externalAccessHash);
    try {
      const sent = message.file
        ? await client.sendFile(peer, {
            file: new CustomFile(
              message.file.fileName,
              message.file.buffer.length,
              '',
              message.file.buffer,
            ),
            caption: message.text,
            // Фото и видео — как медиа (с превью), остальное — документом с исходным именем.
            forceDocument:
              message.file.kind !== 'photo' && message.file.kind !== 'video',
          })
        : await client.sendMessage(peer, { message: message.text });
      return {
        externalMessageId: String(sent.id),
        sentAt: new Date(sent.date * MS_PER_SECOND),
      };
    } catch (error) {
      if (isSessionRevoked(error)) {
        await this.markRevoked(message.channelId, error);
      }
      throw new MessengerSendError(telegramErrorMessage(error));
    }
  }

  /** Вызывается без await при запуске: все ошибки обрабатываются внутри и не роняют процесс. */
  private async resume(
    channelId: string,
    sessionEncrypted: string,
  ): Promise<void> {
    let client: TelegramClient | null = null;
    try {
      client = this.factory.create(this.secrets.decrypt(sessionEncrypted));
      await client.connect();
      // Проверяем, что сессия жива: иначе Telegram вернёт AUTH_KEY_UNREGISTERED.
      await client.getMe();
      await this.start(channelId, client);
      this.logger.log(`Telegram-канал ${channelId} подключён`);
    } catch (error) {
      this.logger.error(
        `Не удалось подключить Telegram-канал ${channelId}`,
        error instanceof Error ? error.stack : error,
      );
      // Клиент, не переданный в работу, закрываем: иначе он будет переподключаться в фоне.
      if (client && this.clients.get(channelId) !== client) {
        await client.destroy().catch(() => undefined);
      }
      if (isSessionRevoked(error)) {
        await this.markRevoked(channelId, error);
      } else {
        await this.saveChannelState(channelId, {
          lastError: telegramErrorMessage(error),
        });
      }
    }
  }

  private async markRevoked(channelId: string, error: unknown): Promise<void> {
    await this.stop(channelId);
    await this.saveChannelState(channelId, {
      status: 'ERROR',
      sessionEncrypted: null,
      lastError: telegramErrorMessage(error),
    });
  }

  /** Запись состояния канала из фоновых задач: ошибка БД логируется, а не роняет процесс. */
  private async saveChannelState(
    channelId: string,
    data: Prisma.ChannelUpdateInput,
  ): Promise<void> {
    try {
      await this.prisma.channel.update({ where: { id: channelId }, data });
    } catch (error) {
      this.logger.error(
        `Не удалось сохранить состояние канала ${channelId}`,
        error instanceof Error ? error.stack : error,
      );
    }
  }

  private async onNewMessage(
    channelId: string,
    event: NewMessageEvent,
  ): Promise<void> {
    try {
      if (!event.isPrivate) return;
      const chat = await event.message.getChat();
      if (!chat) {
        // Новый собеседник прислал сообщение без данных о себе — его догрузит сверка диалогов.
        this.logger.warn(
          `Сообщение Telegram без данных собеседника — сверяю свежие диалоги (канал ${channelId})`,
        );
        this.catchUps.get(channelId)?.requestSoon();
        return;
      }
      if (!isClientChat(chat)) return;
      const incoming = toIncomingMessage(
        channelId,
        event.message as TelegramMessageLike,
        chat,
      );
      await this.ingest.ingest(
        this.withDownload(channelId, incoming, event.message),
        { history: false },
      );
    } catch (error) {
      this.logger.error(
        `Не удалось сохранить сообщение Telegram (канал ${channelId})`,
        error instanceof Error ? error.stack : error,
      );
    }
  }

  /**
   * Собеседник по @username или по номеру (contacts.ResolvePhone — без добавления в контакты).
   * По номеру Telegram находит человека, только если тот не скрыл поиск по номеру.
   */
  async findRecipient(query: RecipientQuery): Promise<Recipient> {
    const client = this.clients.get(query.channelId);
    if (!client) {
      throw new MessengerSendError(
        'Telegram сейчас не подключён. Проверьте канал в разделе «Каналы».',
      );
    }
    const blockedUntil = this.lookupBlockedUntil.get(query.channelId) ?? 0;
    if (Date.now() < blockedUntil) {
      const minutes = Math.ceil((blockedUntil - Date.now()) / 60_000);
      throw new MessengerSendError(
        `Telegram временно ограничил поиск новых собеседников. Попробуйте через ${minutes} мин.`,
      );
    }
    const username = query.username?.replace(/^@/, '');
    const digits = query.phone?.replace(/\D/g, '');
    if (!username && !digits) {
      throw new MessengerSendError(
        'Укажите телефон клиента или его @username в Telegram.',
      );
    }
    // Только настоящее имя: строка из цифр для GramJS — id собеседника из кэша аккаунта.
    if (username && !TELEGRAM_USERNAME_PATTERN.test(username)) {
      throw new MessengerSendError(
        'Имя в Telegram начинается с буквы: 5–32 латинские буквы, цифры или _.',
      );
    }
    let user: unknown;
    try {
      user = username
        ? await client.getEntity(username)
        : (
            await client.invoke(
              new Api.contacts.ResolvePhone({ phone: digits }),
            )
          ).users[0];
    } catch (error) {
      if (isSessionRevoked(error))
        await this.markRevoked(query.channelId, error);
      this.pauseLookupsOnFlood(query.channelId, error);
      throw new MessengerSendError(
        recipientErrorMessage(error, Boolean(username)),
      );
    }
    if (!isClientChat(user as Parameters<typeof isClientChat>[0])) {
      throw new MessengerSendError(
        'Это не личный аккаунт (бот или канал) — написать нельзя.',
      );
    }
    const peer = messengerPeerOf(user as TelegramUserLike);
    return {
      externalChatId: peer.externalId,
      externalAccessHash: peer.accessHash ?? null,
      peer,
    };
  }

  /** Telegram просит подождать — следующие поиски собеседников сразу отказываются, не дёргая Telegram. */
  private pauseLookupsOnFlood(channelId: string, error: unknown): void {
    const waitSeconds = floodWaitSeconds(error);
    const isPeerFlood =
      (error as { errorMessage?: string } | null)?.errorMessage ===
      'PEER_FLOOD';
    if (waitSeconds === null && !isPeerFlood) return;
    const pauseMs =
      waitSeconds !== null ? waitSeconds * MS_PER_SECOND : PEER_FLOOD_PAUSE_MS;
    this.lookupBlockedUntil.set(channelId, Date.now() + pauseMs);
  }

  /** Маленькое фото профиля (JPEG); скрытое настройками приватности Telegram не отдаёт. */
  async fetchAvatar(target: AvatarTarget): Promise<DownloadedMedia | null> {
    const client = this.clients.get(target.channelId);
    if (!client)
      throw new AvatarSourceUnavailableError('Telegram ещё не подключён');
    const user = await client.getEntity(
      peerOf(target.externalChatId, target.externalAccessHash),
    );
    const data = await client.downloadProfilePhoto(user, { isBig: false });
    if (!Buffer.isBuffer(data) || data.length === 0) return null;
    return { buffer: data, mimeType: 'image/jpeg', fileName: 'avatar.jpg' };
  }

  /** Служебное сообщение личного чата: сохраняем только звонки. */
  private async onServiceMessage(
    channelId: string,
    client: TelegramClient,
    update: Api.UpdateNewMessage,
  ): Promise<void> {
    const message = update.message;
    // Проверяем до getEntity: каждый запрос собеседника — обращение к Telegram от личного аккаунта.
    if (
      message.className !== 'MessageService' ||
      message.action.className !== 'MessageActionPhoneCall' ||
      message.peerId.className !== 'PeerUser'
    ) {
      return;
    }
    try {
      const chat = await client.getEntity(message.peerId);
      if (!isClientChat(chat)) return;
      const incoming = toCallMessage(
        channelId,
        message as TelegramServiceMessageLike,
        chat,
      );
      if (incoming) await this.ingest.ingest(incoming, { history: false });
    } catch (error) {
      this.logger.error(
        `Не удалось сохранить звонок Telegram (канал ${channelId})`,
        error instanceof Error ? error.stack : error,
      );
      // Собеседник мог быть неизвестен клиенту — звонок догрузит сверка диалогов.
      this.catchUps.get(channelId)?.requestSoon();
    }
  }

  /** Сверка свежих диалогов сейчас (после неё недостающие сообщения уже в CRM). */
  syncNow(channelId: string): Promise<void> {
    return this.catchUps.get(channelId)?.run() ?? Promise.resolve();
  }

  /** Сообщение из сверки — в общий приём как живое; failed — сверка повторит его позже. */
  private async deliverCaughtUp(
    channelId: string,
    message: CatchUpMessage,
    chat: TelegramUserLike,
  ): Promise<DeliveryResult> {
    try {
      let incoming: IncomingMessage | null = null;
      if (message.className === 'Message') {
        incoming = this.withDownload(
          channelId,
          toIncomingMessage(channelId, message as TelegramMessageLike, chat),
          message as Api.Message,
        );
      } else if (message.className === 'MessageService') {
        incoming = toCallMessage(
          channelId,
          message as TelegramServiceMessageLike,
          chat,
        );
      }
      if (!incoming) return 'duplicate';
      const result = await this.ingest.ingest(incoming, { history: false });
      return result.isNew ? 'new' : 'duplicate';
    } catch (error) {
      this.logger.error(
        `Не удалось догрузить сообщение Telegram (канал ${channelId})`,
        error instanceof Error ? error.stack : error,
      );
      return 'failed';
    }
  }

  /** Добавляет скачивание вложения: файл качается, только если сообщение новое (решает приём). */
  private withDownload(
    channelId: string,
    incoming: IncomingMessage,
    message: Api.Message,
  ): IncomingMessage {
    if (!mediaFileInfo(message.media, incoming.attachment)) return incoming;
    return {
      ...incoming,
      download: async () => {
        const client = this.clients.get(channelId);
        return client
          ? this.downloadMessageMedia(client, message, incoming.attachment)
          : null;
      },
    };
  }

  /**
   * Файл сообщения Telegram. null — файла нет или он больше 20 МБ. Пустой ответ — ошибка:
   * так Telegram отдаёт удалённое фото (например, «на один просмотр»), это не файл в 0 байт.
   */
  private async downloadMessageMedia(
    client: TelegramClient,
    message: Api.Message,
    attachment: MessageAttachment | null,
  ): Promise<DownloadedMedia | null> {
    const info = mediaFileInfo(message.media, attachment);
    if (!info || (info.size !== null && info.size > MAX_FILE_BYTES))
      return null;
    const data = await client.downloadMedia(message, {});
    if (!Buffer.isBuffer(data) || data.length === 0) {
      throw new Error('Telegram не отдал файл — возможно, он удалён');
    }
    if (data.length > MAX_FILE_BYTES) return null;
    return {
      buffer: data,
      mimeType: info.mimeType,
      fileName: attachment?.fileName ?? null,
    };
  }

  /**
   * Файл сохранённого сообщения: Telegram отдаёт сообщение по id, файл качаем заново.
   * Так загружаются и файлы из импортированной истории, которые при импорте не скачивались.
   */
  async fetchAttachment(
    target: AttachmentTarget,
  ): Promise<DownloadedMedia | null> {
    const client = this.clients.get(target.channelId);
    if (!client) {
      throw new MessengerUnavailableError('Telegram сейчас не подключён');
    }
    return this.inFileQueue(async () => {
      try {
        return await this.fetchMessageFile(client, target);
      } catch (error) {
        if (isSessionRevoked(error)) {
          await this.markRevoked(target.channelId, error);
          throw new MessengerUnavailableError(
            'Telegram отключён — переподключите его в разделе «Каналы»',
          );
        }
        const seconds = floodWaitSeconds(error);
        if (seconds !== null) {
          throw new MessengerUnavailableError(
            `Telegram просит подождать ${seconds} с — попробуйте позже`,
          );
        }
        throw error;
      }
    });
  }

  private async fetchMessageFile(
    client: TelegramClient,
    target: AttachmentTarget,
  ): Promise<DownloadedMedia | null> {
    const [message] = await client.getMessages(
      peerOf(target.externalChatId, target.externalAccessHash),
      { ids: [Number(target.externalMessageId)] },
    );
    if (
      message?.className !== 'Message' ||
      !mediaFileInfo(message.media, target.attachment)
    ) {
      throw new Error('Сообщение или файл удалены в Telegram');
    }
    return this.downloadMessageMedia(client, message, target.attachment);
  }

  /**
   * Загрузки по запросу идут по одной, с паузой между ними: личный аккаунт не должен выглядеть
   * как бот. Если ждущих слишком много — отказ, сотрудник попробует позже.
   */
  private inFileQueue<T>(task: () => Promise<T>): Promise<T> {
    if (this.queuedFileRequests >= MAX_QUEUED_FILE_REQUESTS) {
      return Promise.reject(
        new MessengerUnavailableError(
          'Telegram загружает другие файлы — попробуйте через минуту',
        ),
      );
    }
    this.queuedFileRequests += 1;
    const result = this.fileRequests.then(task);
    this.fileRequests = result
      .catch(() => undefined)
      .then(() => sleep(FILE_REQUEST_GAP_MS))
      .finally(() => {
        this.queuedFileRequests -= 1;
      });
    return result;
  }

  /** Импорт переписки за последние HISTORY_DAYS дней из личных чатов с клиентами. */
  private async importHistory(
    channelId: string,
    client: TelegramClient,
  ): Promise<void> {
    const cutoffSeconds =
      (Date.now() - HISTORY_DAYS * MS_PER_DAY) / MS_PER_SECOND;
    let chats = 0;
    let messages = 0;
    // Канал отключили или переподключили — этот импорт больше не актуален.
    const isCurrent = () => this.clients.get(channelId) === client;
    try {
      for await (const dialog of client.iterDialogs({})) {
        if (!isCurrent()) return;
        // Диалоги идут от свежих к старым; закреплённые стоят первыми вне порядка.
        if (!dialog.pinned && dialog.date < cutoffSeconds) break;
        if (!isClientChat(dialog.entity)) continue;
        const batch: IncomingMessage[] = [];
        for await (const message of client.iterMessages(dialog.entity, {
          limit: HISTORY_MAX_MESSAGES_PER_CHAT,
        })) {
          if (message.date < cutoffSeconds) break;
          if (message.className !== 'Message') continue;
          batch.push(
            toIncomingMessage(
              channelId,
              message as TelegramMessageLike,
              dialog.entity,
            ),
          );
        }
        for (const incoming of batch.reverse()) {
          const result = await this.ingest.ingest(incoming, { history: true });
          if (result.isNew) messages += 1;
        }
        chats += 1;
      }
      if (!isCurrent()) return;
      await this.saveChannelState(channelId, { historyImportedAt: new Date() });
      this.logger.log(
        `Импорт истории Telegram завершён: ${chats} чатов, ${messages} сообщений`,
      );
    } catch (error) {
      if (!isCurrent()) return;
      this.logger.error(
        `Импорт истории Telegram прерван (канал ${channelId})`,
        error instanceof Error ? error.stack : error,
      );
      await this.saveChannelState(channelId, {
        lastError: `Импорт истории прерван: ${telegramErrorMessage(error)}`,
      });
    }
  }
}
