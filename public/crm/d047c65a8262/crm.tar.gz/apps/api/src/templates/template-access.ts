import type { Role, TemplateAutomation } from '@crm/shared';

/**
 * Быстрые команды правят все сотрудники, но автоотправка уходит гостям без проверки человеком —
 * её и шаблоны с ней меняет только администратор. null — можно; иначе — объяснение для сотрудника.
 * current — автоотправка шаблона сейчас (null у нового), next — после сохранения (null при удалении).
 */
export function automationLockReason(
  role: Role,
  current: TemplateAutomation | null,
  next: TemplateAutomation | null,
): string | null {
  if (role === 'ADMIN') return null;
  if (current) return 'Шаблон с автоотправкой меняет администратор';
  if (next) return 'Автоотправку настраивает администратор';
  return null;
}
