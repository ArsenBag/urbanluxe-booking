import {
  BadRequestException,
  ForbiddenException,
  NotFoundException,
} from '@nestjs/common';
import {
  templateFileBodyError,
  type ReplyTemplateDto,
  type TemplateAutomation,
  type TemplateFileDto,
} from '@crm/shared';
import type { SessionUser } from '../auth/session-user.js';
import type { Prisma } from '../generated/prisma/client.js';
import { automationLockReason } from './template-access.js';

/** Общее для правки шаблона и его файла: выборка, блокировка, права и проверки. */

export const TEMPLATE_SELECT = {
  id: true,
  title: true,
  body: true,
  shortcut: true,
  automation: true,
  file: { select: { id: true, fileName: true, mimeType: true, size: true } },
} as const;

export type TemplateRow = {
  id: string;
  title: string;
  body: string;
  shortcut: string | null;
  automation: string | null;
  file: TemplateFileDto | null;
};

export const toTemplateDto = (row: TemplateRow): ReplyTemplateDto => ({
  ...row,
  automation: row.automation as TemplateAutomation | null,
});

/** Содержимое шаблона для журнала: видно, кто что поменял, и удалённый текст можно вернуть. */
export const templateSnapshot = ({
  title,
  body,
  shortcut,
  automation,
  file,
}: TemplateRow): Prisma.InputJsonObject => ({
  title,
  body,
  shortcut,
  automation,
  fileName: file?.fileName ?? null,
});

/** Сотрудник не меняет автоотправку и шаблоны с ней (template-access.ts). */
export function assertMayChange(
  actor: SessionUser,
  current: string | null,
  next: TemplateAutomation | null,
): void {
  const reason = automationLockReason(
    actor.role,
    current as TemplateAutomation | null,
    next,
  );
  if (reason) throw new ForbiddenException(reason);
}

/** Правка файла шаблона не меняет автоотправку, но шаблон с ней — по-прежнему решение администратора. */
export function assertMayChangeFile(
  actor: SessionUser,
  automation: string | null,
): void {
  assertMayChange(actor, automation, automation as TemplateAutomation | null);
}

/** С файлом текст уходит подписью — проверяем её лимит до сохранения. */
export function assertBodyFitsFile(hasFile: boolean, body: string): void {
  const error = hasFile ? templateFileBodyError(body) : null;
  if (error) {
    throw new BadRequestException({ message: error, fields: { body: error } });
  }
}

/**
 * Шаблон перед правкой. Правки одного шаблона идут по очереди (блокировка до конца транзакции),
 * поэтому проверка автоотправки не разойдётся с одновременной правкой администратора. Нет шаблона — 404.
 */
export async function lockForChange(
  tx: Prisma.TransactionClient,
  id: string,
): Promise<TemplateRow> {
  await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${`template:${id}`}))::text AS locked`;
  const template = await tx.replyTemplate.findUnique({
    where: { id },
    select: TEMPLATE_SELECT,
  });
  if (!template) throw new NotFoundException('Шаблон не найден');
  return template;
}
