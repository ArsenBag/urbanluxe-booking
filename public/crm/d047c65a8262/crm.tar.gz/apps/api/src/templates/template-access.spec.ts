import { automationLockReason } from './template-access.js';

describe('automationLockReason', () => {
  it('lets a manager add, edit and delete templates without automatic sending', () => {
    expect(automationLockReason('MANAGER', null, null)).toBeNull();
  });

  it('keeps automatic sending with the administrator', () => {
    expect(automationLockReason('MANAGER', null, 'BEFORE_CHECK_IN')).toBe(
      'Автоотправку настраивает администратор',
    );
  });

  it('does not let a manager touch a template that is sent automatically', () => {
    expect(
      automationLockReason('MANAGER', 'AFTER_CHECK_OUT', 'AFTER_CHECK_OUT'),
    ).toBe('Шаблон с автоотправкой меняет администратор');
    expect(automationLockReason('MANAGER', 'AFTER_CHECK_OUT', null)).toBe(
      'Шаблон с автоотправкой меняет администратор',
    );
  });

  it('lets an administrator change anything', () => {
    expect(automationLockReason('ADMIN', 'BEFORE_CHECK_IN', null)).toBeNull();
    expect(automationLockReason('ADMIN', null, 'AFTER_CHECK_OUT')).toBeNull();
  });
});
