import { Module } from '@nestjs/common';
import { FilesModule } from '../files/files.module.js';
import { TemplateFileCleanup } from './template-file-cleanup.js';
import { TemplateFilesController } from './template-files.controller.js';
import { TemplatesController } from './templates.controller.js';

@Module({
  imports: [FilesModule],
  controllers: [TemplatesController, TemplateFilesController],
  providers: [TemplateFileCleanup],
})
export class TemplatesModule {}
