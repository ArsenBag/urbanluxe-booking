/// <reference types="multer" />
import {
  Controller,
  Delete,
  NotFoundException,
  Param,
  ParseUUIDPipe,
  Put,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import type { ReplyTemplateDto } from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import { CurrentUser } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { FileStorageService } from '../files/file-storage.service.js';
import { UPLOAD_OPTIONS, uploadedFile } from '../files/upload.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { TemplateFileCleanup } from './template-file-cleanup.js';
import {
  assertBodyFitsFile,
  assertMayChangeFile,
  lockForChange,
  TEMPLATE_SELECT,
  type TemplateRow,
  toTemplateDto,
} from './template-rows.js';

/**
 * Файл шаблона (видео входа, фото дома): прикрепить, заменить, убрать. Права — как у правки шаблона.
 * Сообщения ссылаются на файл шаблона (InboxService.sendStoredFile); прежний файл убирает TemplateFileCleanup.
 */
@Controller('templates/:id/file')
export class TemplateFilesController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
    private readonly files: FileStorageService,
    private readonly fileCleanup: TemplateFileCleanup,
  ) {}

  /** Новый файл сохраняется до транзакции; не удалось привязать — убираем его, удалось — убираем прежний. */
  @Put()
  @UseInterceptors(FileInterceptor('file', UPLOAD_OPTIONS))
  async attach(
    @Param('id', new ParseUUIDPipe()) id: string,
    @UploadedFile() upload: Express.Multer.File | undefined,
    @CurrentUser() actor: SessionUser,
  ): Promise<ReplyTemplateDto> {
    const file = uploadedFile(upload);
    await this.precheck(id, actor);
    const stored = await this.files.save(file);
    let result: { template: TemplateRow; previousFileId: string | null };
    try {
      result = await this.prisma.$transaction(async (tx) => {
        const before = await lockForChange(tx, id);
        assertMayChangeFile(actor, before.automation);
        assertBodyFitsFile(true, before.body);
        const template = await tx.replyTemplate.update({
          where: { id },
          data: { fileId: stored.id },
          select: TEMPLATE_SELECT,
        });
        await this.audit.record(
          actor,
          {
            action: 'template.file_attached',
            entityType: 'template',
            entityId: id,
            payload: {
              fileName: stored.fileName,
              replaced: before.file?.fileName ?? null,
            },
          },
          tx,
        );
        return { template, previousFileId: before.file?.id ?? null };
      });
    } catch (error) {
      await this.fileCleanup.discard(stored.id, id);
      throw error;
    }
    await this.fileCleanup.discard(result.previousFileId, id);
    return toTemplateDto(result.template);
  }

  @Delete()
  async detach(
    @Param('id', new ParseUUIDPipe()) id: string,
    @CurrentUser() actor: SessionUser,
  ): Promise<ReplyTemplateDto> {
    const { template, previousFileId } = await this.prisma.$transaction(
      async (tx) => {
        const before = await lockForChange(tx, id);
        assertMayChangeFile(actor, before.automation);
        const after = await tx.replyTemplate.update({
          where: { id },
          data: { fileId: null },
          select: TEMPLATE_SELECT,
        });
        if (before.file) {
          await this.audit.record(
            actor,
            {
              action: 'template.file_removed',
              entityType: 'template',
              entityId: id,
              payload: { fileName: before.file.fileName },
            },
            tx,
          );
        }
        return { template: after, previousFileId: before.file?.id ?? null };
      },
    );
    await this.fileCleanup.discard(previousFileId, id);
    return toTemplateDto(template);
  }

  /** Быстрая проверка до записи файла на диск; окончательная — в транзакции под блокировкой шаблона. */
  private async precheck(id: string, actor: SessionUser): Promise<void> {
    const template = await this.prisma.replyTemplate.findUnique({
      where: { id },
      select: { automation: true, body: true },
    });
    if (!template) throw new NotFoundException('Шаблон не найден');
    assertMayChangeFile(actor, template.automation);
    assertBodyFitsFile(true, template.body);
  }
}
