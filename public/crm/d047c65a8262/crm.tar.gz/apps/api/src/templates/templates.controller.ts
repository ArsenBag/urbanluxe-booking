import {
  Body,
  ConflictException,
  Controller,
  Delete,
  Get,
  NotFoundException,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
} from '@nestjs/common';
import {
  replyTemplateSchema,
  type ReplyTemplateDto,
  type ReplyTemplateInput,
  type TemplateAutomation,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import { CurrentUser } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { isPrismaError, PrismaErrorCode } from '../common/prisma-errors.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import type { Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { TemplateFileCleanup } from './template-file-cleanup.js';
import {
  assertBodyFitsFile,
  assertMayChange,
  lockForChange,
  TEMPLATE_SELECT,
  templateSnapshot,
  toTemplateDto,
} from './template-rows.js';

const shortcutConflict = (shortcut: string) =>
  new ConflictException({
    message: `Команда /${shortcut} уже есть у другого шаблона`,
    fields: { shortcut: 'Команда уже занята' },
  });

/** Нарушение уникальности именно команды (а не автоотправки) — понятная ошибка для формы. */
function shortcutTaken(error: unknown, shortcut: string | null): unknown {
  const onShortcut =
    isPrismaError(error, PrismaErrorCode.UniqueViolation) &&
    JSON.stringify((error as { meta?: unknown }).meta ?? {}).includes(
      'shortcut',
    );
  return onShortcut && shortcut ? shortcutConflict(shortcut) : error;
}

/**
 * Шаблоны ответов (быстрые команды): пользуются и правят все сотрудники, автоотправку — только администратор.
 * Логика простая — без отдельного сервиса. Файл шаблона — template-files.controller.ts.
 */
@Controller('templates')
export class TemplatesController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
    private readonly fileCleanup: TemplateFileCleanup,
  ) {}

  @Get()
  async list(): Promise<ReplyTemplateDto[]> {
    const templates = await this.prisma.replyTemplate.findMany({
      select: TEMPLATE_SELECT,
      orderBy: { createdAt: 'asc' },
    });
    return templates.map(toTemplateDto);
  }

  @Post()
  async create(
    @Body(new ZodValidationPipe(replyTemplateSchema)) input: ReplyTemplateInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<ReplyTemplateDto> {
    assertMayChange(actor, null, input.automation);
    const template = await this.prisma
      .$transaction(async (tx) => {
        await this.releaseAutomation(tx, input.automation, null);
        await this.assertShortcutFree(tx, input.shortcut, null);
        const created = await tx.replyTemplate.create({
          data: { ...input, createdById: actor.id },
          select: TEMPLATE_SELECT,
        });
        await this.audit.record(
          actor,
          {
            action: 'template.created',
            entityType: 'template',
            entityId: created.id,
            payload: templateSnapshot(created),
          },
          tx,
        );
        return created;
      })
      .catch((error: unknown) => {
        throw shortcutTaken(error, input.shortcut);
      });
    return toTemplateDto(template);
  }

  @Patch(':id')
  async update(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body(new ZodValidationPipe(replyTemplateSchema)) input: ReplyTemplateInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<ReplyTemplateDto> {
    try {
      const template = await this.prisma.$transaction(async (tx) => {
        const before = await lockForChange(tx, id);
        assertMayChange(actor, before.automation, input.automation);
        assertBodyFitsFile(before.file !== null, input.body);
        await this.releaseAutomation(tx, input.automation, id);
        await this.assertShortcutFree(tx, input.shortcut, id);
        const after = await tx.replyTemplate.update({
          where: { id },
          data: input,
          select: TEMPLATE_SELECT,
        });
        await this.audit.record(
          actor,
          {
            action: 'template.updated',
            entityType: 'template',
            entityId: id,
            payload: {
              before: templateSnapshot(before),
              after: templateSnapshot(after),
            },
          },
          tx,
        );
        return after;
      });
      return toTemplateDto(template);
    } catch (error) {
      throw isPrismaError(error, PrismaErrorCode.RecordNotFound)
        ? new NotFoundException('Шаблон не найден')
        : shortcutTaken(error, input.shortcut);
    }
  }

  @Delete(':id')
  async remove(
    @Param('id', new ParseUUIDPipe()) id: string,
    @CurrentUser() actor: SessionUser,
  ): Promise<null> {
    let fileId: string | null;
    try {
      fileId = await this.prisma.$transaction(async (tx) => {
        const template = await lockForChange(tx, id);
        // Удаление шаблона с автоотправкой выключило бы её — это тоже решение администратора.
        assertMayChange(actor, template.automation, null);
        await tx.replyTemplate.delete({ where: { id } });
        await this.audit.record(
          actor,
          {
            action: 'template.deleted',
            entityType: 'template',
            entityId: id,
            payload: templateSnapshot(template),
          },
          tx,
        );
        return template.file?.id ?? null;
      });
    } catch (error) {
      throw isPrismaError(error, PrismaErrorCode.RecordNotFound)
        ? new NotFoundException('Шаблон не найден')
        : error;
    }
    await this.fileCleanup.discard(fileId, id);
    return null;
  }

  /** У каждого вида автоотправки один шаблон: выбранный вид снимается с прежнего шаблона. */
  private async releaseAutomation(
    tx: Prisma.TransactionClient,
    automation: TemplateAutomation | null,
    keepId: string | null,
  ) {
    if (!automation) return;
    await tx.replyTemplate.updateMany({
      where: { automation, ...(keepId && { id: { not: keepId } }) },
      data: { automation: null },
    });
  }

  /** Проверка до записи; гонку двух одновременных сохранений ловит уникальный индекс (shortcutTaken). */
  private async assertShortcutFree(
    tx: Prisma.TransactionClient,
    shortcut: string | null,
    exceptId: string | null,
  ): Promise<void> {
    if (!shortcut) return;
    const taken = await tx.replyTemplate.findFirst({
      where: { shortcut, ...(exceptId && { id: { not: exceptId } }) },
      select: { id: true },
    });
    if (taken) throw shortcutConflict(shortcut);
  }
}
