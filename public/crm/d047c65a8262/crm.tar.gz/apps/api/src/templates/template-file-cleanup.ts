import { Injectable, Logger } from '@nestjs/common';
import { FileStorageService } from '../files/file-storage.service.js';
import { PrismaService } from '../prisma/prisma.service.js';

/**
 * Прежний файл шаблона после замены, удаления файла или самого шаблона. Отправленные сообщения ссылаются
 * на файл шаблона (InboxService.sendStoredFile), поэтому файл, который уже уходил клиентам, остаётся у
 * переписки; удаляется только файл, который никому не отправляли.
 */
@Injectable()
export class TemplateFileCleanup {
  private readonly logger = new Logger(TemplateFileCleanup.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly files: FileStorageService,
  ) {}

  /** Сбой удаления не отменяет уже сохранённую правку шаблона — только запись в журнал. */
  async discard(fileId: string | null, templateId: string): Promise<void> {
    if (!fileId) return;
    try {
      const sent = await this.prisma.message.findFirst({
        where: { attachment: { path: ['fileId'], equals: fileId } },
        select: { id: true },
      });
      if (!sent) await this.files.remove([fileId]);
    } catch (error) {
      this.logger.warn(
        `Не удалось удалить файл шаблона ${templateId}: ${String(error)}`,
      );
    }
  }
}
