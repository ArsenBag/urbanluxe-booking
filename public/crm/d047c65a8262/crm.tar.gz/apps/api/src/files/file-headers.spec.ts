import { decodeUploadedName, fileResponseHeaders, isInlineSafe, normalizeMimeType, sanitizeFileName } from './file-headers.js';

describe('normalizeMimeType', () => {
  it('drops parameters and lowercases', () => {
    expect(normalizeMimeType('Audio/OGG; codecs=opus')).toBe('audio/ogg');
  });

  it('falls back to octet-stream for garbage', () => {
    expect(normalizeMimeType('not a mime')).toBe('application/octet-stream');
    expect(normalizeMimeType(null)).toBe('application/octet-stream');
  });
});

describe('isInlineSafe', () => {
  it('allows only media and PDF', () => {
    expect(['image/jpeg', 'image/png', 'audio/ogg', 'video/mp4', 'application/pdf'].every(isInlineSafe)).toBe(true);
    expect(['image/svg+xml', 'text/html', 'application/xhtml+xml', 'text/plain'].some(isInlineSafe)).toBe(false);
  });
});

describe('sanitizeFileName', () => {
  it('strips directories, quotes and control characters', () => {
    expect(sanitizeFileName('../../etc/"pass\nwd".txt', 'file')).toBe('passwd.txt');
    expect(sanitizeFileName('C:\\Users\\doc.pdf', 'file')).toBe('doc.pdf');
  });

  it('uses the fallback for an empty name and limits the length', () => {
    expect(sanitizeFileName('   ', 'file')).toBe('file');
    expect(sanitizeFileName('a'.repeat(500), 'file')).toHaveLength(200);
  });
});

describe('decodeUploadedName', () => {
  it('restores a UTF-8 name that multer read as latin1', () => {
    const mangled = Buffer.from('Договор.pdf', 'utf8').toString('latin1');
    expect(decodeUploadedName(mangled)).toBe('Договор.pdf');
  });

  it('keeps names that are already correct', () => {
    expect(decodeUploadedName('report.pdf')).toBe('report.pdf');
    expect(decodeUploadedName('Договор.pdf')).toBe('Договор.pdf');
    expect(decodeUploadedName('café.txt')).toBe('café.txt');
  });
});

describe('fileResponseHeaders', () => {
  it('shows images inline', () => {
    const headers = fileResponseHeaders({ fileName: 'Фото.jpg', mimeType: 'image/jpeg' });
    expect(headers['Content-Type']).toBe('image/jpeg');
    expect(headers['Content-Disposition']).toBe(`inline; filename="____.jpg"; filename*=UTF-8''${encodeURIComponent('Фото.jpg')}`);
    expect(headers['X-Content-Type-Options']).toBe('nosniff');
  });

  it('forces a download of anything a browser could execute', () => {
    const headers = fileResponseHeaders({ fileName: 'x.svg', mimeType: 'image/svg+xml' });
    expect(headers['Content-Type']).toBe('application/octet-stream');
    expect(headers['Content-Disposition']).toMatch(/^attachment;/);
    expect(headers['Content-Security-Policy']).toContain('sandbox');
  });
});
