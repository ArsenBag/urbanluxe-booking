/**
 * Заголовки выдачи файлов из переписки. Файлы присылают клиенты, поэтому браузеру нельзя
 * доверять их содержимое: прямо в браузере открываются только картинки, аудио, видео и PDF,
 * всё остальное — скачивается как поток байтов (HTML или SVG не исполнится на нашем домене).
 */

const MIME_PATTERN =
  /^[a-z0-9][a-z0-9!#$&^_.+-]*\/[a-z0-9][a-z0-9!#$&^_.+-]*$/i;
const INLINE_MIME =
  /^(image\/(jpeg|png|gif|webp)|audio\/[a-z0-9.+-]+|video\/[a-z0-9.+-]+|application\/pdf)$/i;
const BINARY = 'application/octet-stream';
const PDF = 'application/pdf';
const MAX_FILE_NAME_LENGTH = 200;
const LATIN1_MAX_CODE = 0xff;
/** Символ, которым UTF-8 декодер заменяет битые байты. */
const REPLACEMENT_CHAR = String.fromCharCode(0xfffd);

/** MIME из мессенджера или браузера: параметры (;codecs=…) отбрасываем, мусор — в octet-stream. */
export function normalizeMimeType(value: string | null | undefined): string {
  const base = value?.split(';')[0]?.trim().toLowerCase() ?? '';
  return MIME_PATTERN.test(base) ? base : BINARY;
}

export function isInlineSafe(mimeType: string): boolean {
  return INLINE_MIME.test(mimeType);
}

/** Имя файла без путей и управляющих символов, не длиннее разумного. */
export function sanitizeFileName(
  value: string | null | undefined,
  fallback: string,
): string {
  const base = (value ?? '').split(/[/\\]/).pop() ?? '';
  // eslint-disable-next-line no-control-regex
  const cleaned = base.replace(/[\u0000-\u001f\u007f"]/g, '').trim();
  return (cleaned || fallback).slice(0, MAX_FILE_NAME_LENGTH);
}

/**
 * Браузер передаёт имя файла в multipart в UTF-8, а multer читает его как latin1:
 * «Договор.pdf» превращается в «Ð”Ð¾Ð³...». Возвращаем исходную строку, если это именно такой случай.
 */
export function decodeUploadedName(value: string): string {
  for (let index = 0; index < value.length; index += 1) {
    if (value.charCodeAt(index) > LATIN1_MAX_CODE) return value;
  }
  const decoded = Buffer.from(value, 'latin1').toString('utf8');
  return decoded.includes(REPLACEMENT_CHAR) ? value : decoded;
}

export interface FileResponseHeaders {
  'Content-Type': string;
  'Content-Disposition': string;
  'X-Content-Type-Options': 'nosniff';
  'Content-Security-Policy': string;
  'Cache-Control': string;
}

export function fileResponseHeaders(file: {
  fileName: string;
  mimeType: string;
}): FileResponseHeaders {
  const inline = isInlineSafe(file.mimeType);
  const asciiName = file.fileName
    .replace(/[^\x20-\x7e]/g, '_')
    .replace(/[\\"]/g, '_');
  return {
    'Content-Type': inline ? file.mimeType : BINARY,
    'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(file.fileName)}`,
    'X-Content-Type-Options': 'nosniff',
    // Даже если браузер всё же отрисует документ, скрипты в нём не выполнятся. Для PDF sandbox
    // не ставим: встроенный просмотрщик Chrome в песочнице не открывается.
    'Content-Security-Policy': `default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'${file.mimeType === PDF ? '' : '; sandbox'}`,
    // Файл по id не меняется; кэш только в браузере сотрудника.
    'Cache-Control': 'private, max-age=86400, immutable',
  };
}
