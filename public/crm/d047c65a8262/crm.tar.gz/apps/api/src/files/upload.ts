/// <reference types="multer" />
import { BadRequestException } from '@nestjs/common';
import { MAX_FILE_BYTES } from '@crm/shared';
import { decodeUploadedName } from './file-headers.js';
import type { NewFile } from './file-storage.service.js';

/** Подпись — до 1024 символов, в UTF-8 до 4 КБ; больше текстовым полям не нужно. */
const MAX_FIELD_BYTES = 8 * 1024;

/**
 * Файл держим в памяти: он сразу уходит на диск (и в мессенджер), лимит — 20 МБ. Кроме файла — не больше
 * одного короткого поля (подпись): запрос не может держать в памяти мегабайты текстовых полей.
 */
export const UPLOAD_OPTIONS = {
  limits: {
    fileSize: MAX_FILE_BYTES,
    files: 1,
    fields: 1,
    parts: 2,
    fieldSize: MAX_FIELD_BYTES,
  },
};

/** Загруженный через форму файл для хранилища; запрос без файла — понятная ошибка. */
export function uploadedFile(file: Express.Multer.File | undefined): NewFile {
  if (!file || file.size === 0) {
    throw new BadRequestException('Выберите файл');
  }
  return {
    buffer: file.buffer,
    fileName: decodeUploadedName(file.originalname),
    mimeType: file.mimetype,
  };
}
