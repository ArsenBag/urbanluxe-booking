import {
  Controller,
  Get,
  Logger,
  Param,
  ParseUUIDPipe,
  Res,
} from '@nestjs/common';
import type { Response } from 'express';
import { fileResponseHeaders } from './file-headers.js';
import { FileStorageService } from './file-storage.service.js';

/**
 * Выдача файлов переписки сотрудникам (по сессии, как и остальное API).
 * res.sendFile поддерживает запросы диапазонов (Range): без них Safari не воспроизводит аудио и видео.
 */
@Controller('files')
export class FilesController {
  private readonly logger = new Logger(FilesController.name);

  constructor(private readonly storage: FileStorageService) {}

  @Get(':id')
  async download(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Res() response: Response,
  ): Promise<void> {
    const { file, path } = await this.storage.locate(id);
    // Заголовки ставим заранее: sendFile не перезаписывает уже заданные Content-Type и Cache-Control.
    response.set({ ...fileResponseHeaders(file) });
    response.sendFile(path, { dotfiles: 'deny' }, (error) => {
      if (error && !response.headersSent) {
        this.logger.error(`Не удалось отдать файл ${id}: ${error.message}`);
        response
          .status(500)
          .json({
            success: false,
            data: null,
            error: { message: 'Не удалось открыть файл' },
          });
      }
    });
  }
}
