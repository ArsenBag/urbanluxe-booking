import { Module } from '@nestjs/common';
import { FileStorageService } from './file-storage.service.js';
import { FilesController } from './files.controller.js';

@Module({
  controllers: [FilesController],
  providers: [FileStorageService],
  exports: [FileStorageService],
})
export class FilesModule {}
