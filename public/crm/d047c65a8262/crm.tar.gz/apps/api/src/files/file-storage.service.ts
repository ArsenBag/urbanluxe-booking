import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  PayloadTooLargeException,
} from '@nestjs/common';
import { MAX_FILE_BYTES } from '@crm/shared';
import { randomBytes } from 'node:crypto';
import { access, mkdir, readFile, unlink, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { ENV, type Env } from '../config/env.js';
import type { StoredFile } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { normalizeMimeType, sanitizeFileName } from './file-headers.js';

const STORAGE_KEY_BYTES = 24;
const DEFAULT_FILE_NAME = 'file';

export interface NewFile {
  buffer: Buffer;
  fileName: string | null | undefined;
  mimeType: string | null | undefined;
}

/**
 * Файлы переписки на локальном диске (FILES_DIR). Имя на диске случайное и не зависит от того,
 * что прислал клиент, — так путь нельзя подобрать или подменить через имя файла.
 */
@Injectable()
export class FileStorageService {
  private readonly logger = new Logger(FileStorageService.name);
  private readonly root: string;

  constructor(
    private readonly prisma: PrismaService,
    @Inject(ENV) env: Env,
  ) {
    this.root = resolve(env.FILES_DIR);
  }

  async save(file: NewFile): Promise<StoredFile> {
    if (file.buffer.length > MAX_FILE_BYTES) {
      throw new PayloadTooLargeException('Файл больше 20 МБ');
    }
    const storageKey = randomBytes(STORAGE_KEY_BYTES).toString('hex');
    await mkdir(this.root, { recursive: true });
    // wx: никогда не перезаписываем существующий файл.
    await writeFile(this.pathOf(storageKey), file.buffer, { flag: 'wx' });
    try {
      return await this.prisma.storedFile.create({
        data: {
          storageKey,
          fileName: sanitizeFileName(file.fileName, DEFAULT_FILE_NAME),
          mimeType: normalizeMimeType(file.mimeType),
          size: file.buffer.length,
        },
      });
    } catch (error) {
      await this.removeFromDisk(storageKey);
      throw error;
    }
  }

  async find(id: string): Promise<StoredFile> {
    const file = await this.prisma.storedFile.findUnique({ where: { id } });
    if (!file) {
      throw new NotFoundException('Файл не найден');
    }
    return file;
  }

  async read(id: string): Promise<{ file: StoredFile; buffer: Buffer }> {
    const file = await this.find(id);
    return { file, buffer: await readFile(this.pathOf(file.storageKey)) };
  }

  /** Путь к файлу для выдачи; отсутствие файла на диске (потеря тома) — 404, а не 500. */
  async locate(id: string): Promise<{ file: StoredFile; path: string }> {
    const file = await this.find(id);
    const path = this.pathOf(file.storageKey);
    await access(path).catch((error: unknown) => {
      this.logger.error(
        `Файл ${id} есть в базе, но не найден на диске: ${String(error)}`,
      );
      throw new NotFoundException('Файл не найден');
    });
    return { file, path };
  }

  /** Удаляет файлы, на которые больше ничего не ссылается (дубликат эха, несостоявшаяся отправка). */
  async remove(ids: string[]): Promise<void> {
    if (ids.length === 0) return;
    const files = await this.prisma.storedFile.findMany({
      where: { id: { in: ids } },
      select: { storageKey: true },
    });
    await this.prisma.storedFile.deleteMany({ where: { id: { in: ids } } });
    await Promise.all(
      files.map((file) => this.removeFromDisk(file.storageKey)),
    );
  }

  private pathOf(storageKey: string): string {
    return resolve(this.root, storageKey);
  }

  private async removeFromDisk(storageKey: string): Promise<void> {
    await unlink(this.pathOf(storageKey)).catch((error: unknown) =>
      this.logger.warn(
        `Не удалось удалить файл ${storageKey}: ${String(error)}`,
      ),
    );
  }
}
