import type { INestApplication } from '@nestjs/common';
import { json, type RequestHandler, urlencoded } from 'express';
import { ENV, type Env } from '../config/env.js';
import { webhookTokenMatches } from '../whatsapp/webhook-token.js';

/** Тело запросов CRM и вебхука RealtyCalendar — как у Express по умолчанию. */
const DEFAULT_BODY_LIMIT = '100kb';
/**
 * Green-API кладёт в уведомление превью картинки или ссылки в base64, и оно бывает больше 100 КБ.
 * Отказ на таком уведомлении останавливает всю очередь Green-API: он повторяет его раз в минуту,
 * а следующие сообщения ждут. Сами файлы приходят ссылкой, не в теле.
 */
const WHATSAPP_WEBHOOK_BODY_LIMIT = '5mb';
const WHATSAPP_WEBHOOK_PATH = '/api/webhooks/whatsapp';
/** Вебхук PMS Urban Luxe подписан HMAC по сырому телу — сохраняем его до разбора JSON. */
const PMS_WEBHOOK_PATH = '/api/webhooks/urbanluxe';

/**
 * Большой лимит — только запросам с токеном Green-API: тело читается до контроллера, и без этой
 * проверки любой мог бы заставить сервер разбирать мегабайты (в gzip — из нескольких КБ).
 * Чужой запрос идёт к обычному парсеру, контроллер ответит ему 404, как и раньше.
 */
function whatsappWebhookParser(token: string | undefined): RequestHandler {
  const parse = json({ limit: WHATSAPP_WEBHOOK_BODY_LIMIT });
  return (req, res, next) => {
    if (token && webhookTokenMatches(token, req.headers.authorization)) {
      parse(req, res, next);
      return;
    }
    next();
  };
}

/**
 * Разбор тела запросов вместо встроенного в Nest (приложение создаётся с bodyParser: false).
 * Порядок важен: тело, уже прочитанное парсером вебхука, следующие парсеры пропускают.
 */
export function useBodyParsers(app: INestApplication): void {
  const env = app.get<Env>(ENV);
  app.use(
    WHATSAPP_WEBHOOK_PATH,
    whatsappWebhookParser(env.GREEN_API_WEBHOOK_TOKEN),
  );
  app.use(
    PMS_WEBHOOK_PATH,
    json({
      limit: DEFAULT_BODY_LIMIT,
      verify: (req, _res, buf) => {
        (req as { rawBody?: Buffer }).rawBody = Buffer.from(buf);
      },
    }),
  );
  app.use(json({ limit: DEFAULT_BODY_LIMIT }));
  app.use(urlencoded({ extended: true, limit: DEFAULT_BODY_LIMIT }));
}
