import { BadRequestException } from '@nestjs/common';
import { createUserSchema } from '@crm/shared';
import { ZodValidationPipe } from './zod-validation.pipe.js';

describe('ZodValidationPipe', () => {
  const pipe = new ZodValidationPipe(createUserSchema);

  it('returns parsed and normalized data', () => {
    const result = pipe.transform({ email: ' M@HL.UZ ', name: 'Азиз', password: 'longpassword', role: 'MANAGER' });

    expect(result.email).toBe('m@hl.uz');
  });

  it('reports errors per field', () => {
    try {
      pipe.transform({ email: 'bad', name: '', password: 'x', role: 'MANAGER' });
      expect.unreachable();
    } catch (error) {
      expect(error).toBeInstanceOf(BadRequestException);
      const body = (error as BadRequestException).getResponse() as { fields: Record<string, string> };
      expect(Object.keys(body.fields).sort()).toEqual(['email', 'name', 'password']);
    }
  });
});
