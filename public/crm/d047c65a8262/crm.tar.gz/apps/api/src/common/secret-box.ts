import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';

const ALGORITHM = 'aes-256-gcm';
const KEY_BYTES = 32;
const IV_BYTES = 12;
const FORMAT_VERSION = 'v1';
const AUTH_TAG_BYTES = 16;
const BASE64_PATTERN = /^[A-Za-z0-9+/]+={0,2}$/;

/**
 * Шифрование секретов в БД (сессии мессенджеров). Формат: v1.<iv>.<tag>.<данные> в base64.
 * GCM проверяет целостность: подменённые данные не расшифруются.
 */
export class SecretBox {
  private readonly key: Buffer;

  constructor(base64Key: string) {
    // Buffer.from молча выбрасывает недопустимые символы — проверяем формат явно.
    if (!BASE64_PATTERN.test(base64Key)) {
      throw new Error(
        'Ключ шифрования должен быть в base64 (openssl rand -base64 32)',
      );
    }
    this.key = Buffer.from(base64Key, 'base64');
    if (this.key.length !== KEY_BYTES) {
      throw new Error(
        `Ключ шифрования должен быть ${KEY_BYTES} байта в base64 (openssl rand -base64 32)`,
      );
    }
  }

  encrypt(plaintext: string): string {
    const iv = randomBytes(IV_BYTES);
    const cipher = createCipheriv(ALGORITHM, this.key, iv);
    const data = Buffer.concat([
      cipher.update(plaintext, 'utf8'),
      cipher.final(),
    ]);
    return [FORMAT_VERSION, iv, cipher.getAuthTag(), data]
      .map((part) =>
        typeof part === 'string' ? part : part.toString('base64'),
      )
      .join('.');
  }

  decrypt(payload: string): string {
    const [version, iv, tag, data] = payload.split('.');
    if (version !== FORMAT_VERSION || !iv || !tag || !data) {
      throw new Error('Неизвестный формат зашифрованных данных');
    }
    const authTag = Buffer.from(tag, 'base64');
    // Укороченный тег ослабляет проверку целостности — принимаем только полный.
    if (authTag.length !== AUTH_TAG_BYTES) {
      throw new Error('Повреждённые зашифрованные данные');
    }
    const decipher = createDecipheriv(
      ALGORITHM,
      this.key,
      Buffer.from(iv, 'base64'),
      { authTagLength: AUTH_TAG_BYTES },
    );
    decipher.setAuthTag(authTag);
    return Buffer.concat([
      decipher.update(Buffer.from(data, 'base64')),
      decipher.final(),
    ]).toString('utf8');
  }
}
