import { Prisma } from '../generated/prisma/client.js';

export const PrismaErrorCode = {
  UniqueViolation: 'P2002',
  ForeignKeyViolation: 'P2003',
  RecordNotFound: 'P2025',
} as const;

type PrismaErrorCodeValue = (typeof PrismaErrorCode)[keyof typeof PrismaErrorCode];

export function isPrismaError(error: unknown, code: PrismaErrorCodeValue): boolean {
  return error instanceof Prisma.PrismaClientKnownRequestError && error.code === code;
}
