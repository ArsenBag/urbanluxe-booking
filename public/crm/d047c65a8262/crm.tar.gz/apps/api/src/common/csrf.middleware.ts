import { ForbiddenException } from '@nestjs/common';
import type { NextFunction, Request, Response } from 'express';

export const CSRF_HEADER = 'x-requested-with';
export const CSRF_HEADER_VALUE = 'crm-web';

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);
/**
 * Вебхуки внешних систем: без cookie сессии и со своей защитой (секрет в адресе).
 * Перечисляем конкретные пути, чтобы новый вебхук не получил исключение случайно.
 */
const WEBHOOK_PREFIXES = ['/api/webhooks/realtycalendar/', '/api/webhooks/whatsapp', '/api/webhooks/urbanluxe'];   // urbanluxe — подпись HMAC (PMS_WEBHOOK_SECRET)

/**
 * Изменяющие запросы обязаны нести кастомный заголовок. Браузер не даст чужому сайту
 * отправить его без CORS-preflight, а preflight с чужого origin мы не разрешаем.
 * Вебхуки идут мимо этой проверки: CSRF опасен только для запросов с cookie сессии.
 */
export function csrfMiddleware(
  req: Request,
  _res: Response,
  next: NextFunction,
): void {
  // Путь без строки запроса: префикс с «/» на конце — подпути, без — только точный адрес.
  const path = req.originalUrl.split('?')[0];
  const isWebhook = WEBHOOK_PREFIXES.some((prefix) =>
    prefix.endsWith('/') ? path.startsWith(prefix) : path === prefix,
  );
  if (
    isWebhook ||
    SAFE_METHODS.has(req.method) ||
    req.get(CSRF_HEADER) === CSRF_HEADER_VALUE
  ) {
    next();
    return;
  }
  // Бросаем, а не передаём в next(): так ошибку обработает глобальный фильтр Nest.
  throw new ForbiddenException(
    'Запрос отклонён: отсутствует заголовок защиты от CSRF',
  );
}
