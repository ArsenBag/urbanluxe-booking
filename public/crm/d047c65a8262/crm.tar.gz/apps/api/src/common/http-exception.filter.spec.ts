import { type ArgumentsHost, Logger } from '@nestjs/common';
import { HttpExceptionFilter, routeArea } from './http-exception.filter.js';

const SECRET = 'rc-secret-0123456789';

/** Ошибка body-parser (http-errors): код, expose, тип и текст по-английски. */
function bodyError(status: number, type: string, message: string) {
  return Object.assign(new Error(message), { status, type, expose: true });
}

function hostFor(path: string) {
  const json = vi.fn();
  const status = vi.fn(() => ({ json }));
  const request = { path, headers: { 'content-length': '312000' } };
  const host = {
    switchToHttp: () => ({
      getResponse: () => ({ status }),
      getRequest: () => request,
    }),
  } as unknown as ArgumentsHost;
  return { host, status, json };
}

describe('routeArea', () => {
  it('cuts the RealtyCalendar secret off the webhook address', () => {
    expect(routeArea(`/api/webhooks/realtycalendar/${SECRET}`)).toBe(
      '/api/webhooks/realtycalendar',
    );
  });

  it('keeps short addresses as they are', () => {
    expect(routeArea('/api/webhooks/whatsapp')).toBe('/api/webhooks/whatsapp');
  });
});

describe('HttpExceptionFilter', () => {
  const filter = new HttpExceptionFilter();

  afterEach(() => vi.restoreAllMocks());

  it('answers a too large body with 413 and logs no secret', () => {
    const warn = vi
      .spyOn(Logger.prototype, 'warn')
      .mockImplementation(() => {});
    const { host, status, json } = hostFor(
      `/api/webhooks/realtycalendar/${SECRET}`,
    );

    filter.catch(
      bodyError(413, 'entity.too.large', 'request entity too large'),
      host,
    );

    expect(status).toHaveBeenCalledWith(413);
    expect(json).toHaveBeenCalledWith({
      success: false,
      data: null,
      error: { message: 'Запрос слишком большой' },
    });
    expect(warn).toHaveBeenCalledTimes(1);
    const logged = String(warn.mock.calls[0]?.[0]);
    expect(logged).toContain('/api/webhooks/realtycalendar');
    expect(logged).toContain('entity.too.large');
    expect(logged).not.toContain(SECRET);
  });

  it('keeps other unexpected errors internal (500)', () => {
    vi.spyOn(Logger.prototype, 'error').mockImplementation(() => {});
    const { host, status } = hostFor('/api/deals');

    filter.catch(new Error('database is down'), host);

    expect(status).toHaveBeenCalledWith(500);
  });
});
