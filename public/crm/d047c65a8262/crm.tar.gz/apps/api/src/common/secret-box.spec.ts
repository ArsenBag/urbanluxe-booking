import { randomBytes } from 'node:crypto';
import { SecretBox } from './secret-box.js';

const key = randomBytes(32).toString('base64');

describe('SecretBox', () => {
  it('decrypts what it encrypted', () => {
    const box = new SecretBox(key);

    expect(box.decrypt(box.encrypt('telegram-session-string'))).toBe('telegram-session-string');
  });

  it('produces a different ciphertext each time (random IV)', () => {
    const box = new SecretBox(key);

    expect(box.encrypt('same')).not.toBe(box.encrypt('same'));
  });

  it('rejects tampered ciphertext', () => {
    const box = new SecretBox(key);
    const [version, iv, tag, data] = box.encrypt('secret').split('.');
    const tampered = [version, iv, tag, Buffer.from('x' + Buffer.from(data, 'base64').toString('latin1')).toString('base64')].join('.');

    expect(() => box.decrypt(tampered)).toThrow();
  });

  it('rejects a ciphertext made with another key', () => {
    const other = new SecretBox(randomBytes(32).toString('base64'));

    expect(() => new SecretBox(key).decrypt(other.encrypt('secret'))).toThrow();
  });

  it('requires a 32-byte key', () => {
    expect(() => new SecretBox(randomBytes(16).toString('base64'))).toThrow(/32/);
  });
});
