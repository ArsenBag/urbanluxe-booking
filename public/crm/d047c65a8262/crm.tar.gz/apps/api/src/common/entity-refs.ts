import type { EntityRef } from '@crm/shared';

/** Выборка Prisma для связанного пользователя: только то, что показываем в интерфейсе. */
export const USER_REF_SELECT = { select: { id: true, name: true } } as const;

export function toEntityRef(value: { id: string; name: string } | null): EntityRef | null {
  return value ? { id: value.id, name: value.name } : null;
}
