/** Ташкент живёт в UTC+5 без перехода на летнее время. */
const TASHKENT_OFFSET = '+05:00';
const MS_PER_DAY = 86_400_000;

/** Начало дня YYYY-MM-DD по Ташкенту — для фильтров по времени создания, закрытия, сообщений. */
export function tashkentDayStart(date: string): Date {
  return new Date(`${date}T00:00:00${TASHKENT_OFFSET}`);
}

/** Конец дня по Ташкенту, не включительно: полночь следующего дня. */
export function tashkentDayEnd(date: string): Date {
  return new Date(tashkentDayStart(date).getTime() + MS_PER_DAY);
}

/** Момент «дата YYYY-MM-DD, время ЧЧ:ММ» по Ташкенту. */
export function tashkentAt(date: string, time: string): Date {
  return new Date(`${date}T${time}:00${TASHKENT_OFFSET}`);
}

/** Дата YYYY-MM-DD, сдвинутая на days дней (назад — отрицательным числом). */
export function shiftDate(date: string, days: number): string {
  return new Date(Date.parse(`${date}T00:00:00Z`) + days * MS_PER_DAY).toISOString().slice(0, 10);
}

/** Дата без времени (колонка @db.Date) ↔ строка YYYY-MM-DD. Храним как полночь UTC. */
export function dateOnlyToDb(value: string): Date {
  return new Date(`${value}T00:00:00.000Z`);
}

export function dateOnlyFromDb(value: Date): string {
  return value.toISOString().slice(0, 10);
}

export function nullableDateOnlyToDb(
  value: string | null | undefined,
): Date | null | undefined {
  return value === undefined || value === null ? value : dateOnlyToDb(value);
}
