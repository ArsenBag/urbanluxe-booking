import type { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
import type { ApiResponse } from '@crm/shared';
import { map, type Observable } from 'rxjs';

/** Оборачивает успешные ответы в единый формат { success, data, error }. */
export class ApiResponseInterceptor<T> implements NestInterceptor<T, ApiResponse<T>> {
  intercept(_context: ExecutionContext, next: CallHandler<T>): Observable<ApiResponse<T>> {
    return next
      .handle()
      .pipe(map((data) => ({ success: true as const, data: data ?? null, error: null }) as ApiResponse<T>));
  }
}
