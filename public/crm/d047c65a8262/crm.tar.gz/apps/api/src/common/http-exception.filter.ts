import {
  type ArgumentsHost,
  Catch,
  type ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { ThrottlerException } from '@nestjs/throttler';
import type { ApiError, ApiResponse } from '@crm/shared';
import type { Request, Response } from 'express';

const INTERNAL_ERROR_MESSAGE = 'Внутренняя ошибка сервера';
const TOO_MANY_REQUESTS_MESSAGE =
  'Слишком много запросов. Подождите минуту и попробуйте снова.';
/** multer отвечает на превышение лимита по-английски («File too large»). */
const PAYLOAD_TOO_LARGE_MESSAGE = 'Файл больше 20 МБ';
const BODY_TOO_LARGE_MESSAGE = 'Запрос слишком большой';
const BAD_BODY_MESSAGE = 'Некорректный запрос';
/**
 * В журнал — только первые сегменты адреса (/api/webhooks/realtycalendar): следующим сегментом
 * в адресе вебхука RealtyCalendar идёт секрет.
 */
const LOGGED_PATH_SEGMENTS = 3;
/** Заголовок content-length задаёт клиент — в журнал не больше этого числа символов. */
const MAX_LOGGED_SIZE_LENGTH = 12;

/**
 * Ошибка чтения тела запроса (body-parser: слишком большое, чужая кодировка) — это ошибка клиента
 * с кодом 4xx, а не внутренняя. Битый JSON сюда не доходит: Nest сам отвечает на него 400.
 * null — другая ошибка.
 */
function bodyParserStatus(exception: unknown): number | null {
  if (typeof exception !== 'object' || exception === null) return null;
  const { status, expose } = exception as {
    status?: unknown;
    expose?: unknown;
  };
  return expose === true &&
    typeof status === 'number' &&
    status >= 400 &&
    status < 500
    ? status
    : null;
}

/** Начало адреса без секретов: '/api/webhooks/realtycalendar/<секрет>' → '/api/webhooks/realtycalendar'. */
export function routeArea(path: string): string {
  const segments = path.split('/').filter(Boolean);
  return `/${segments.slice(0, LOGGED_PATH_SEGMENTS).join('/')}`;
}

function toApiError(exception: HttpException): ApiError {
  // Лимит запросов (throttler) отвечает по-английски; свои 429 приходят уже с понятным текстом.
  if (exception instanceof ThrottlerException) {
    return { message: TOO_MANY_REQUESTS_MESSAGE };
  }
  if (exception.getStatus() === HttpStatus.PAYLOAD_TOO_LARGE) {
    return { message: PAYLOAD_TOO_LARGE_MESSAGE };
  }
  const body = exception.getResponse();
  if (typeof body === 'string') {
    return { message: body };
  }
  const { message, fields } = body as {
    message?: unknown;
    fields?: Record<string, string>;
  };
  const text = Array.isArray(message)
    ? message.join(', ')
    : typeof message === 'string'
      ? message
      : exception.message;
  return fields ? { message: text, fields } : { message: text };
}

/** Приводит все ошибки к единому формату и не раскрывает детали внутренних ошибок клиенту. */
@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(HttpExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const response = host.switchToHttp().getResponse<Response>();

    if (exception instanceof HttpException) {
      const payload: ApiResponse<never> = {
        success: false,
        data: null,
        error: toApiError(exception),
      };
      response.status(exception.getStatus()).json(payload);
      return;
    }

    const bodyStatus = bodyParserStatus(exception);
    if (bodyStatus !== null) {
      const request = host.switchToHttp().getRequest<Request>();
      // Тип ошибки, а не текст: текст body-parser может содержать кусок тела (телефоны гостей).
      const size = (request.headers['content-length'] ?? '?').slice(
        0,
        MAX_LOGGED_SIZE_LENGTH,
      );
      const { type } = exception as { type?: unknown };
      this.logger.warn(
        `Тело запроса отклонено (${bodyStatus}) на ${routeArea(request.path)}, размер ${size} байт: ` +
          (typeof type === 'string' ? type : 'unknown'),
      );
      const message =
        bodyStatus === HttpStatus.PAYLOAD_TOO_LARGE
          ? BODY_TOO_LARGE_MESSAGE
          : BAD_BODY_MESSAGE;
      const payload: ApiResponse<never> = {
        success: false,
        data: null,
        error: { message },
      };
      response.status(bodyStatus).json(payload);
      return;
    }

    this.logger.error(
      'Unhandled exception',
      exception instanceof Error ? exception.stack : exception,
    );
    const payload: ApiResponse<never> = {
      success: false,
      data: null,
      error: { message: INTERNAL_ERROR_MESSAGE },
    };
    response.status(HttpStatus.INTERNAL_SERVER_ERROR).json(payload);
  }
}
