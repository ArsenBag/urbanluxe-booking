import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import {
  checkCustomFieldValue,
  MAX_CUSTOM_FIELDS_PER_ENTITY,
  type CreateCustomFieldInput,
  type CustomFieldDto,
  type CustomFieldEntity,
  type CustomFieldValues,
  type ReorderCustomFieldsInput,
  type UpdateCustomFieldInput,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { isPrismaError, PrismaErrorCode } from '../common/prisma-errors.js';
import type { CustomField, Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';

const FIELD_NOT_FOUND = 'Поле не найдено';

const toDto = (field: CustomField): CustomFieldDto => ({
  id: field.id,
  entity: field.entity,
  label: field.label,
  type: field.type,
  options: field.options,
  position: field.position,
});

/** Значения полей из JSON-колонки карточки (на случай мусора в БД — только примитивы). */
export function customFieldValuesOf(raw: Prisma.JsonValue): CustomFieldValues {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  return Object.fromEntries(
    Object.entries(raw).filter(
      (entry): entry is [string, string | number | boolean] =>
        typeof entry[1] === 'string' || typeof entry[1] === 'number' || typeof entry[1] === 'boolean',
    ),
  );
}

/** Настраиваемые поля карточек: определения (администратор) и значения в карточках (все сотрудники). */
@Injectable()
export class CustomFieldsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
  ) {}

  async list(entity?: CustomFieldEntity): Promise<CustomFieldDto[]> {
    const fields = await this.prisma.customField.findMany({
      where: entity ? { entity } : {},
      orderBy: [{ entity: 'asc' }, { position: 'asc' }, { createdAt: 'asc' }],
    });
    return fields.map(toDto);
  }

  async create(input: CreateCustomFieldInput, actor: SessionUser): Promise<CustomFieldDto> {
    const field = await this.prisma.$transaction(async (tx) => {
      // Позиции внутри сущности назначаем по очереди: два одновременных создания не получат одну.
      await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${`custom-fields:${input.entity}`}))::text AS locked`;
      const count = await tx.customField.count({ where: { entity: input.entity } });
      if (count >= MAX_CUSTOM_FIELDS_PER_ENTITY) {
        throw new BadRequestException(`Не больше ${MAX_CUSTOM_FIELDS_PER_ENTITY} полей в карточке`);
      }
      const last = await tx.customField.findFirst({ where: { entity: input.entity }, orderBy: { position: 'desc' } });
      return tx.customField.create({ data: { ...input, position: (last?.position ?? -1) + 1 } });
    });
    await this.audit.record(actor, {
      action: 'custom-field.created',
      entityType: 'custom-field',
      entityId: field.id,
      payload: { label: field.label },
    });
    return toDto(field);
  }

  async update(id: string, input: UpdateCustomFieldInput, actor: SessionUser): Promise<CustomFieldDto> {
    const current = await this.findField(id);
    if (input.options && current.type === 'SELECT' && input.options.length === 0) {
      throw new BadRequestException({ message: 'Добавьте хотя бы один вариант', fields: { options: 'Добавьте хотя бы один вариант' } });
    }
    // Варианты бывают только у списка; у остальных типов их игнорируем.
    const data = current.type === 'SELECT' ? input : { label: input.label };
    const field = await this.prisma.customField.update({ where: { id }, data });
    await this.audit.record(actor, {
      action: 'custom-field.updated',
      entityType: 'custom-field',
      entityId: id,
      payload: { label: field.label },
    });
    return toDto(field);
  }

  /** Удаление поля стирает и его значения во всех карточках. */
  async remove(id: string, actor: SessionUser): Promise<null> {
    const field = await this.findField(id);
    await this.prisma.$transaction(async (tx) => {
      await tx.customField.delete({ where: { id } });
      if (field.entity === 'CONTACT') {
        await tx.$executeRaw`UPDATE "contacts" SET "customFields" = "customFields" - ${id} WHERE "customFields" ? ${id}`;
      } else {
        await tx.$executeRaw`UPDATE "deals" SET "customFields" = "customFields" - ${id} WHERE "customFields" ? ${id}`;
      }
    });
    await this.audit.record(actor, {
      action: 'custom-field.deleted',
      entityType: 'custom-field',
      entityId: id,
      payload: { label: field.label },
    });
    return null;
  }

  async reorder(input: ReorderCustomFieldsInput): Promise<CustomFieldDto[]> {
    await this.prisma.$transaction(async (tx) => {
      // Та же блокировка, что при создании: порядок не перемешается с параллельным добавлением.
      await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${`custom-fields:${input.entity}`}))::text AS locked`;
      const fields = await tx.customField.findMany({ where: { entity: input.entity }, select: { id: true } });
      const known = new Set(fields.map((field) => field.id));
      if (input.ids.length !== known.size || !input.ids.every((id) => known.has(id))) {
        throw new BadRequestException('Список полей устарел — обновите страницу');
      }
      for (const [position, id] of input.ids.entries()) {
        await tx.customField.update({ where: { id }, data: { position } });
      }
    });
    return this.list(input.entity);
  }

  /**
   * Изменение значений в карточке: переданные поля записываются, null — очищает.
   * Слияние делает сама БД (jsonb || и -), поэтому одновременная правка разных полей не теряет данные.
   */
  async updateValues(
    entity: CustomFieldEntity,
    recordId: string,
    values: Record<string, string | number | boolean | null>,
    actor: SessionUser,
  ): Promise<CustomFieldValues> {
    const { set, clear } = await this.validate(entity, values);
    const setJson = JSON.stringify(set);
    const updated = await this.prisma.$transaction(async (tx) => {
      const rows =
        entity === 'CONTACT'
          ? await tx.$queryRaw<Array<{ customFields: Prisma.JsonValue }>>`
              UPDATE "contacts" SET "customFields" = ("customFields" || ${setJson}::jsonb) - ${clear}::text[], "updatedAt" = (now() AT TIME ZONE 'UTC')
              WHERE "id" = ${recordId}::uuid RETURNING "customFields"`
          : await tx.$queryRaw<Array<{ customFields: Prisma.JsonValue }>>`
              UPDATE "deals" SET "customFields" = ("customFields" || ${setJson}::jsonb) - ${clear}::text[], "updatedAt" = (now() AT TIME ZONE 'UTC')
              WHERE "id" = ${recordId}::uuid RETURNING "customFields"`;
      const [row] = rows;
      if (!row) {
        throw new NotFoundException(entity === 'CONTACT' ? 'Клиент не найден' : 'Сделка не найдена');
      }
      await this.audit.record(
        actor,
        {
          action: entity === 'CONTACT' ? 'contact.updated' : 'deal.updated',
          entityType: entity === 'CONTACT' ? 'contact' : 'deal',
          entityId: recordId,
          payload: { fields: ['customFields'] },
        },
        tx,
      );
      return row.customFields;
    });
    return customFieldValuesOf(updated);
  }

  private async validate(
    entity: CustomFieldEntity,
    values: Record<string, string | number | boolean | null>,
  ): Promise<{ set: CustomFieldValues; clear: string[] }> {
    const ids = Object.keys(values);
    const fields = await this.prisma.customField.findMany({ where: { entity, id: { in: ids } } });
    const byId = new Map(fields.map((field) => [field.id, field]));
    const errors: Record<string, string> = {};
    const set: CustomFieldValues = {};
    const clear: string[] = [];
    for (const id of ids) {
      const field = byId.get(id);
      if (!field) {
        errors[id] = 'Поле удалено — обновите страницу';
        continue;
      }
      const check = checkCustomFieldValue(field, values[id]);
      if (!check.ok) errors[id] = check.error;
      else if (check.value === null) clear.push(id);
      else set[id] = check.value;
    }
    if (Object.keys(errors).length > 0) {
      throw new BadRequestException({ message: 'Проверьте значения полей', fields: errors });
    }
    return { set, clear };
  }

  private async findField(id: string): Promise<CustomField> {
    try {
      return await this.prisma.customField.findUniqueOrThrow({ where: { id } });
    } catch (error) {
      throw isPrismaError(error, PrismaErrorCode.RecordNotFound) ? new NotFoundException(FIELD_NOT_FOUND) : error;
    }
  }
}
