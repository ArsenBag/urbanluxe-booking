import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import {
  createCustomFieldSchema,
  CUSTOM_FIELD_ENTITIES,
  customFieldValuesSchema,
  reorderCustomFieldsSchema,
  updateCustomFieldSchema,
  type CreateCustomFieldInput,
  type CustomFieldDto,
  type CustomFieldValues,
  type CustomFieldValuesInput,
  type ReorderCustomFieldsInput,
  type UpdateCustomFieldInput,
} from '@crm/shared';
import { z } from 'zod';
import { CurrentUser, Roles } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { CustomFieldsService } from './custom-fields.service.js';

const uuid = () => new ParseUUIDPipe();
const listQuerySchema = z.object({ entity: z.enum(CUSTOM_FIELD_ENTITIES).optional() });

/** Определения полей видят все (для карточек), меняет администратор. Значения в карточках правят все. */
@Controller()
export class CustomFieldsController {
  constructor(private readonly fields: CustomFieldsService) {}

  @Get('custom-fields')
  list(@Query(new ZodValidationPipe(listQuerySchema)) query: z.infer<typeof listQuerySchema>): Promise<CustomFieldDto[]> {
    return this.fields.list(query.entity);
  }

  @Post('custom-fields')
  @Roles('ADMIN')
  create(
    @Body(new ZodValidationPipe(createCustomFieldSchema)) input: CreateCustomFieldInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<CustomFieldDto> {
    return this.fields.create(input, actor);
  }

  @Post('custom-fields/reorder')
  @Roles('ADMIN')
  @HttpCode(HttpStatus.OK)
  reorder(@Body(new ZodValidationPipe(reorderCustomFieldsSchema)) input: ReorderCustomFieldsInput): Promise<CustomFieldDto[]> {
    return this.fields.reorder(input);
  }

  @Patch('custom-fields/:id')
  @Roles('ADMIN')
  update(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(updateCustomFieldSchema)) input: UpdateCustomFieldInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<CustomFieldDto> {
    return this.fields.update(id, input, actor);
  }

  @Delete('custom-fields/:id')
  @Roles('ADMIN')
  remove(@Param('id', uuid()) id: string, @CurrentUser() actor: SessionUser): Promise<null> {
    return this.fields.remove(id, actor);
  }

  @Patch('contacts/:id/custom-fields')
  updateContactValues(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(customFieldValuesSchema)) input: CustomFieldValuesInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<CustomFieldValues> {
    return this.fields.updateValues('CONTACT', id, input.values, actor);
  }

  @Patch('deals/:id/custom-fields')
  updateDealValues(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(customFieldValuesSchema)) input: CustomFieldValuesInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<CustomFieldValues> {
    return this.fields.updateValues('DEAL', id, input.values, actor);
  }
}
