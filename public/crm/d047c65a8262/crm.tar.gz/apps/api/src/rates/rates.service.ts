import { BadRequestException, Inject, Injectable } from '@nestjs/common';
import {
  nightsOfRateUpdate,
  type RateDayDto,
  type RateRangeQuery,
  type RatesDto,
  type RateUpdateInput,
  type RateUpdateResultDto,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { dateOnlyFromDb, dateOnlyToDb } from '../common/dates.js';
import { ENV, type Env } from '../config/env.js';
import type { RateDay } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';

/** Цена и все ограничения квартиры на одну ночь — так их записывает replaceNights (переезд из RealtyCalendar). */
export interface RateNight {
  date: string;
  price: number;
  minStay: number | null;
  closed: boolean;
  closedToArrival: boolean;
  closedToDeparture: boolean;
}

function toRateDayDto(day: RateDay): RateDayDto {
  return {
    propertyId: day.propertyId,
    date: dateOnlyFromDb(day.date),
    price: day.price?.toFixed(2) ?? null,
    minStay: day.minStay,
    closed: day.closed,
    closedToArrival: day.closedToArrival,
    closedToDeparture: day.closedToDeparture,
  };
}

/**
 * Цены и ограничения квартир по ночам — базовый тариф CRM, от которого менеджер каналов считает цены площадок.
 * Каждое изменение записывается в журнал rate_changes: на площадки уйдут только изменившиеся ночи.
 */
@Injectable()
export class RatesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  async range(query: RateRangeQuery): Promise<RatesDto> {
    const days = await this.prisma.rateDay.findMany({
      where: {
        date: { gte: dateOnlyToDb(query.from), lte: dateOnlyToDb(query.to) },
      },
      orderBy: [{ propertyId: 'asc' }, { date: 'asc' }],
    });
    return { currency: this.env.RC_CURRENCY, days: days.map(toRateDayDto) };
  }

  /**
   * Одним запросом в базу: все выбранные квартиры × ночи. Поле, которого нет во входе, у существующей ночи
   * не меняется (у новой — пусто); ночи, где после изменения не осталось ничего, удаляются.
   */
  async update(
    input: RateUpdateInput,
    actor: SessionUser | null,
  ): Promise<RateUpdateResultDto> {
    // Цены — только у квартир: у строк ЖК из старой выгрузки (rcId = null) квартира не определена.
    const found = await this.prisma.property.count({
      where: { id: { in: input.propertyIds }, rcId: { not: null } },
    });
    if (found !== input.propertyIds.length) {
      throw new BadRequestException('Квартира не найдена — обновите страницу');
    }
    const nights = nightsOfRateUpdate(input);
    if (nights.length === 0) return { nights: 0 };

    return this.prisma.$transaction(async (tx) => {
      const written = await tx.$executeRaw`
        INSERT INTO rate_days ("propertyId", "date", "price", "minStay", "closed", "closedToArrival", "closedToDeparture", "updatedAt")
        SELECT property_id, night, ${input.price ?? null}::numeric, ${input.minStay ?? null}::int,
               ${input.closed ?? false}::boolean, ${input.closedToArrival ?? false}::boolean,
               ${input.closedToDeparture ?? false}::boolean, now()
        FROM unnest(${input.propertyIds}::uuid[]) AS property_id
        CROSS JOIN unnest(${nights}::date[]) AS night
        ON CONFLICT ("propertyId", "date") DO UPDATE SET
          "price" = CASE WHEN ${input.price !== undefined}::boolean THEN EXCLUDED."price" ELSE rate_days."price" END,
          "minStay" = CASE WHEN ${input.minStay !== undefined}::boolean THEN EXCLUDED."minStay" ELSE rate_days."minStay" END,
          "closed" = CASE WHEN ${input.closed !== undefined}::boolean THEN EXCLUDED."closed" ELSE rate_days."closed" END,
          "closedToArrival" = CASE WHEN ${input.closedToArrival !== undefined}::boolean THEN EXCLUDED."closedToArrival" ELSE rate_days."closedToArrival" END,
          "closedToDeparture" = CASE WHEN ${input.closedToDeparture !== undefined}::boolean THEN EXCLUDED."closedToDeparture" ELSE rate_days."closedToDeparture" END,
          "updatedAt" = now()`;
      await tx.$executeRaw`
        DELETE FROM rate_days
        WHERE "propertyId" = ANY(${input.propertyIds}::uuid[]) AND "date" = ANY(${nights}::date[])
          AND "price" IS NULL AND "minStay" IS NULL
          AND NOT "closed" AND NOT "closedToArrival" AND NOT "closedToDeparture"`;
      const from = dateOnlyToDb(nights[0]);
      const to = dateOnlyToDb(nights[nights.length - 1]);
      await tx.rateChange.createMany({
        data: input.propertyIds.map((propertyId) => ({ propertyId, from, to })),
      });
      await this.audit.record(
        actor,
        {
          action: 'rates.updated',
          entityType: 'rates',
          entityId: `${input.from}..${input.to}`,
          payload: {
            propertyIds: input.propertyIds,
            weekdays: input.weekdays,
            nights: written,
            price: input.price,
            minStay: input.minStay,
            closed: input.closed,
            closedToArrival: input.closedToArrival,
            closedToDeparture: input.closedToDeparture,
          },
        },
        tx,
      );
      return { nights: written };
    });
  }

  /**
   * Ночи квартиры целиком — цена и все ограничения, — как при переезде из RealtyCalendar: что было на эти ночи,
   * заменяется. Одним запросом в базу, одна запись в журнал изменений и в журнал действий.
   * actor = null — загрузка скриптом. Даты не повторяются: одна ночь дважды в одном INSERT … ON CONFLICT — ошибка.
   */
  async replaceNights(
    propertyId: string,
    nights: readonly RateNight[],
    actor: SessionUser | null,
  ): Promise<number> {
    if (nights.length === 0) return 0;
    const dates = nights.map((night) => night.date);
    return this.prisma.$transaction(async (tx) => {
      const written = await tx.$executeRaw`
        INSERT INTO rate_days ("propertyId", "date", "price", "minStay", "closed", "closedToArrival", "closedToDeparture", "updatedAt")
        SELECT ${propertyId}::uuid, night.date, night.price, night.min_stay, night.closed, night.cta, night.ctd, now()
        FROM unnest(
          ${dates}::date[],
          ${nights.map((night) => night.price)}::numeric[],
          ${nights.map((night) => night.minStay)}::int[],
          ${nights.map((night) => night.closed)}::boolean[],
          ${nights.map((night) => night.closedToArrival)}::boolean[],
          ${nights.map((night) => night.closedToDeparture)}::boolean[]
        ) AS night(date, price, min_stay, closed, cta, ctd)
        ON CONFLICT ("propertyId", "date") DO UPDATE SET
          "price" = EXCLUDED."price",
          "minStay" = EXCLUDED."minStay",
          "closed" = EXCLUDED."closed",
          "closedToArrival" = EXCLUDED."closedToArrival",
          "closedToDeparture" = EXCLUDED."closedToDeparture",
          "updatedAt" = now()`;
      const sorted = [...dates].sort();
      const from = sorted[0];
      const to = sorted[sorted.length - 1];
      await tx.rateChange.create({
        data: { propertyId, from: dateOnlyToDb(from), to: dateOnlyToDb(to) },
      });
      await this.audit.record(
        actor,
        {
          action: 'rates.imported',
          entityType: 'rates',
          entityId: `${from}..${to}`,
          payload: { propertyId, nights: written },
        },
        tx,
      );
      return written;
    });
  }
}
