import { Body, Controller, Get, Put, Query } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import {
  rateRangeQuerySchema,
  rateUpdateSchema,
  type RateRangeQuery,
  type RatesDto,
  type RateUpdateInput,
  type RateUpdateResultDto,
} from '@crm/shared';
import { CurrentUser, Roles } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { RatesService } from './rates.service.js';

/** Цены меняют руками из окна шахматки; чаще — это скрипт или зацикленная форма. */
const RATE_CHANGES_PER_MINUTE = 30;
const ONE_MINUTE_MS = 60_000;

@Controller('rates')
export class RatesController {
  constructor(private readonly rates: RatesService) {}

  /** Цены видят все сотрудники — по ним отвечают гостям. */
  @Get()
  range(
    @Query(new ZodValidationPipe(rateRangeQuerySchema)) query: RateRangeQuery,
  ): Promise<RatesDto> {
    return this.rates.range(query);
  }

  @Put()
  @Roles('ADMIN')
  @Throttle({
    default: { limit: RATE_CHANGES_PER_MINUTE, ttl: ONE_MINUTE_MS },
  })
  update(
    @Body(new ZodValidationPipe(rateUpdateSchema)) input: RateUpdateInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<RateUpdateResultDto> {
    return this.rates.update(input, actor);
  }
}
