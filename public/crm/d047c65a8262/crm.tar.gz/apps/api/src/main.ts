import { NestFactory } from '@nestjs/core';
import type { NestExpressApplication } from '@nestjs/platform-express';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { AppModule } from './app.module.js';
import { useBodyParsers } from './common/body-parsers.js';
import { CSRF_HEADER } from './common/csrf.middleware.js';
import { ENV, type Env } from './config/env.js';
import { loadRootEnv } from './config/load-root-env.js';

loadRootEnv();

async function bootstrap(): Promise<void> {
  // Тело запросов разбираем сами: у вебхуков лимит больше, чем у остального API.
  const app = await NestFactory.create<NestExpressApplication>(AppModule, {
    bodyParser: false,
  });
  const env = app.get<Env>(ENV);

  // API стоит за прокси (Next.js в разработке, Caddy в проде): реальный IP клиента
  // берём из X-Forwarded-For, иначе лимит входов будет общим на всех.
  const hops = Number(env.TRUST_PROXY);
  app.set('trust proxy', Number.isInteger(hops) ? hops : env.TRUST_PROXY);
  app.use(helmet());
  app.use(cookieParser());
  app.enableCors({
    origin: env.WEB_ORIGIN,
    credentials: true,
    allowedHeaders: ['Content-Type', CSRF_HEADER],
  });
  useBodyParsers(app);
  app.setGlobalPrefix('api');
  app.enableShutdownHooks();

  await app.listen(env.API_PORT);
}

await bootstrap();
