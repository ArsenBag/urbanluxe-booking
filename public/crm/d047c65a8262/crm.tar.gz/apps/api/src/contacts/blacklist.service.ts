import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import type {
  BlacklistEntryDto,
  BlacklistInput,
  ContactDto,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import type { Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { CONTACT_INCLUDE, toContactDto } from './contact.mapper.js';
import { BLACKLIST_SELECT, toGuestBlacklist } from './guest-blacklist.js';

/** Список небольшой (единицы-десятки гостей); потолок — от случайной выдачи всей базы. */
const MAX_BLACKLIST_ENTRIES = 1000;
const NOT_FOUND = 'Клиент не найден';

type Tx = Prisma.TransactionClient;

/**
 * Чёрный список гостей. Отметка живёт в карточке клиента: её видно в диалогах, уведомлениях
 * о сообщениях и бронях. Причину в журнал не пишем — после удаления карточки она не должна остаться.
 */
@Injectable()
export class BlacklistService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
  ) {}

  async list(): Promise<BlacklistEntryDto[]> {
    const contacts = await this.prisma.contact.findMany({
      where: { blacklistedAt: { not: null } },
      select: { id: true, name: true, phones: true, ...BLACKLIST_SELECT },
      orderBy: { blacklistedAt: 'desc' },
      take: MAX_BLACKLIST_ENTRIES,
    });
    return contacts.flatMap((contact) => {
      const blacklist = toGuestBlacklist(contact);
      if (!blacklist) return [];
      const { id, name, phones } = contact;
      return [{ contact: { id, name, phones }, blacklist }];
    });
  }

  /** Повторно внести нельзя: причину, автора и дату внесения не перепишешь. */
  async add(
    contactId: string,
    input: BlacklistInput,
    actor: SessionUser,
  ): Promise<ContactDto> {
    const contact = await this.prisma.$transaction(async (tx) => {
      // Условие в самом UPDATE: одновременные внесение и снятие не перемешают автора и причину.
      const { count } = await tx.contact.updateMany({
        where: { id: contactId, blacklistedAt: null },
        data: {
          blacklistedAt: new Date(),
          blacklistReason: input.reason,
          blacklistedById: actor.id,
        },
      });
      if (count === 0) await refuse(tx, contactId, 'Гость уже в чёрном списке');
      return this.recorded(tx, contactId, 'contact.blacklisted', actor);
    });
    return toContactDto(contact);
  }

  async remove(contactId: string, actor: SessionUser): Promise<ContactDto> {
    const contact = await this.prisma.$transaction(async (tx) => {
      const { count } = await tx.contact.updateMany({
        where: { id: contactId, blacklistedAt: { not: null } },
        data: {
          blacklistedAt: null,
          blacklistReason: null,
          blacklistedById: null,
        },
      });
      if (count === 0) await refuse(tx, contactId, 'Гость не в чёрном списке');
      return this.recorded(tx, contactId, 'contact.unblacklisted', actor);
    });
    return toContactDto(contact);
  }

  private async recorded(
    tx: Tx,
    contactId: string,
    action: 'contact.blacklisted' | 'contact.unblacklisted',
    actor: SessionUser,
  ) {
    await this.audit.record(
      actor,
      { action, entityType: 'contact', entityId: contactId },
      tx,
    );
    return tx.contact.findUniqueOrThrow({
      where: { id: contactId },
      include: CONTACT_INCLUDE,
    });
  }
}

/** Ничего не изменилось: клиента нет (404) или отметка уже в нужном состоянии (409). */
async function refuse(
  tx: Tx,
  contactId: string,
  conflict: string,
): Promise<never> {
  const exists = await tx.contact.count({ where: { id: contactId } });
  throw exists > 0
    ? new ConflictException(conflict)
    : new NotFoundException(NOT_FOUND);
}
