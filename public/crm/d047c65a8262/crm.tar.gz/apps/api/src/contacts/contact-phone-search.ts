import type { PrismaService } from '../prisma/prisma.service.js';

/** Поиск по телефону включается, если в запросе хотя бы столько цифр. */
export const MIN_PHONE_SEARCH_DIGITS = 4;
/** Ограничение на число совпадений по телефону, чтобы короткий запрос не тянул всю базу. */
const MAX_PHONE_MATCHES = 500;

/**
 * id клиентов, в номерах которых есть цифры из запроса («90 123-45» найдёт +998901234567).
 * Пустой список — в запросе слишком мало цифр или совпадений нет.
 */
export async function contactIdsByPhoneDigits(
  prisma: PrismaService,
  search: string,
): Promise<string[]> {
  const digits = search.replace(/\D/g, '');
  if (digits.length < MIN_PHONE_SEARCH_DIGITS) return [];
  const matches = await prisma.$queryRaw<Array<{ id: string }>>`
    SELECT id FROM contacts
    WHERE array_to_string(phones, ' ') LIKE ${`%${digits}%`}
    ORDER BY id
    LIMIT ${MAX_PHONE_MATCHES}
  `;
  return matches.map((match) => match.id);
}
