import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import type {
  ContactDto,
  ContactListItemDto,
  ContactListQuery,
  CreateContactInput,
  Paginated,
  UpdateContactInput,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { isPrismaError, PrismaErrorCode } from '../common/prisma-errors.js';
import { FileStorageService } from '../files/file-storage.service.js';
import type { Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { CONTACT_INCLUDE, toContactDto } from './contact.mapper.js';
import { weakensGuestMatch } from './guest-blacklist.js';
import { contactIdsByPhoneDigits } from './contact-phone-search.js';

const OWNER_NOT_FOUND = {
  message: 'Ответственный не найден',
  fields: { ownerId: 'Пользователь не найден' },
};

@Injectable()
export class ContactsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
    private readonly files: FileStorageService,
  ) {}

  async list(query: ContactListQuery): Promise<Paginated<ContactListItemDto>> {
    const where = await this.buildSearchWhere(query.search);
    const [total, contacts] = await Promise.all([
      this.prisma.contact.count({ where }),
      this.prisma.contact.findMany({
        where,
        include: {
          ...CONTACT_INCLUDE,
          _count: { select: { deals: { where: { closedAt: null } } } },
        },
        orderBy: { createdAt: 'desc' },
        skip: (query.page - 1) * query.limit,
        take: query.limit,
      }),
    ]);
    return {
      items: contacts.map((contact) => ({
        ...toContactDto(contact),
        openDealsCount: contact._count.deals,
      })),
      total,
      page: query.page,
      limit: query.limit,
    };
  }

  async get(id: string): Promise<ContactDto> {
    const contact = await this.prisma.contact.findUnique({
      where: { id },
      include: CONTACT_INCLUDE,
    });
    if (!contact) {
      throw new NotFoundException('Клиент не найден');
    }
    return toContactDto(contact);
  }

  async create(
    input: CreateContactInput,
    actor: SessionUser,
  ): Promise<ContactDto> {
    const { ownerId, ...fields } = input;
    const contact = await this.prisma
      .$transaction(async (tx) => {
        const created = await tx.contact.create({
          data: {
            ...fields,
            ownerId: ownerId === undefined ? actor.id : ownerId,
          },
          include: CONTACT_INCLUDE,
        });
        await this.audit.record(
          actor,
          {
            action: 'contact.created',
            entityType: 'contact',
            entityId: created.id,
            payload: { name: created.name },
          },
          tx,
        );
        return created;
      })
      .catch((error: unknown) => {
        throw isPrismaError(error, PrismaErrorCode.ForeignKeyViolation)
          ? new BadRequestException(OWNER_NOT_FOUND)
          : error;
      });
    return toContactDto(contact);
  }

  async update(
    id: string,
    input: UpdateContactInput,
    actor: SessionUser,
  ): Promise<ContactDto> {
    try {
      const contact = await this.prisma.$transaction(async (tx) => {
        await assertKeepsBlacklistMatch(tx, id, input, actor);
        const updated = await tx.contact.update({
          where: { id },
          data: input,
          include: CONTACT_INCLUDE,
        });
        await this.audit.record(
          actor,
          {
            action: 'contact.updated',
            entityType: 'contact',
            entityId: id,
            // VIP — со значением: в истории видно, поставили отметку или сняли.
            payload: {
              fields: Object.keys(input),
              ...(input.vip !== undefined && { vip: input.vip }),
            },
          },
          tx,
        );
        return updated;
      });
      return toContactDto(contact);
    } catch (error) {
      if (isPrismaError(error, PrismaErrorCode.RecordNotFound)) {
        throw new NotFoundException('Клиент не найден');
      }
      if (isPrismaError(error, PrismaErrorCode.ForeignKeyViolation)) {
        throw new BadRequestException(OWNER_NOT_FOUND);
      }
      throw error;
    }
  }

  async remove(id: string, actor: SessionUser): Promise<null> {
    try {
      const avatarFileId = await this.prisma.$transaction(async (tx) => {
        // Удалённая карточка унесла бы с собой отметку: гость написал бы снова «чистым».
        const listed = await tx.contact.findUnique({
          where: { id },
          select: { blacklistedAt: true },
        });
        if (listed?.blacklistedAt) {
          throw new ConflictException(
            'Гость в чёрном списке. Сначала уберите его из списка.',
          );
        }
        const deleted = await tx.contact.delete({
          where: { id },
          select: { avatarFileId: true },
        });
        // Имя удалённого клиента в журнал не пишем: персональные данные не должны пережить удаление.
        await this.audit.record(
          actor,
          { action: 'contact.deleted', entityType: 'contact', entityId: id },
          tx,
        );
        return deleted.avatarFileId;
      });
      // Фото профиля — тоже персональные данные: удаляем после коммита.
      if (avatarFileId) await this.files.remove([avatarFileId]);
      return null;
    } catch (error) {
      if (isPrismaError(error, PrismaErrorCode.RecordNotFound)) {
        throw new NotFoundException('Клиент не найден');
      }
      if (isPrismaError(error, PrismaErrorCode.ForeignKeyViolation)) {
        throw new ConflictException(
          'У клиента есть сделки. Сначала удалите или перенесите их.',
        );
      }
      throw error;
    }
  }

  /** Имя или email содержат строку, либо телефон содержит введённые цифры (например, последние 4). */
  private async buildSearchWhere(
    search: string | undefined,
  ): Promise<Prisma.ContactWhereInput> {
    if (!search) {
      return {};
    }
    const conditions: Prisma.ContactWhereInput[] = [
      { name: { contains: search, mode: 'insensitive' } },
      { email: { contains: search, mode: 'insensitive' } },
    ];
    const phoneMatches = await contactIdsByPhoneDigits(this.prisma, search);
    if (phoneMatches.length > 0) {
      conditions.push({ id: { in: phoneMatches } });
    }
    return { OR: conditions };
  }
}

/** Телефоны и email гостя из чёрного списка урезает только администратор — иначе отметку обойдут. */
async function assertKeepsBlacklistMatch(
  tx: Prisma.TransactionClient,
  id: string,
  input: UpdateContactInput,
  actor: SessionUser,
): Promise<void> {
  if (actor.role === 'ADMIN') return;
  if (input.phones === undefined && input.email === undefined) return;
  const current = await tx.contact.findUnique({
    where: { id },
    select: { phones: true, email: true, blacklistedAt: true },
  });
  if (current?.blacklistedAt && weakensGuestMatch(current, input)) {
    throw new ForbiddenException(
      'Гость в чёрном списке: убрать телефон или сменить email может только администратор',
    );
  }
}
