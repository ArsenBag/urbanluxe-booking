import type { ContactDto } from '@crm/shared';
import { toEntityRef, USER_REF_SELECT } from '../common/entity-refs.js';
import { customFieldValuesOf } from '../custom-fields/custom-fields.service.js';
import type { Contact } from '../generated/prisma/client.js';
import { toGuestBlacklist } from './guest-blacklist.js';

export const CONTACT_INCLUDE = {
  owner: USER_REF_SELECT,
  blacklistedBy: USER_REF_SELECT,
} as const;

export type ContactWithOwner = Contact & {
  owner: { id: string; name: string } | null;
  blacklistedBy: { id: string; name: string } | null;
};

export function toContactDto(contact: ContactWithOwner): ContactDto {
  return {
    id: contact.id,
    name: contact.name,
    phones: contact.phones,
    email: contact.email,
    source: contact.source,
    tags: contact.tags,
    notes: contact.notes,
    owner: toEntityRef(contact.owner),
    customFields: customFieldValuesOf(contact.customFields),
    vip: contact.vip,
    blacklist: toGuestBlacklist(contact),
    createdAt: contact.createdAt.toISOString(),
    updatedAt: contact.updatedAt.toISOString(),
  };
}
