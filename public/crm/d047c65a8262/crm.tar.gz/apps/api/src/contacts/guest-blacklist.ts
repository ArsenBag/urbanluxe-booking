import type { GuestBlacklistDto } from '@crm/shared';
import { toEntityRef, USER_REF_SELECT } from '../common/entity-refs.js';
import type { Prisma } from '../generated/prisma/client.js';

/** Поля клиента для отметки «в чёрном списке» — для select и include Prisma. */
export const BLACKLIST_SELECT = {
  blacklistedAt: true,
  blacklistReason: true,
  blacklistedBy: USER_REF_SELECT,
} as const;

export interface BlacklistFields {
  blacklistedAt: Date | null;
  blacklistReason: string | null;
  blacklistedBy: { id: string; name: string } | null;
}

export function toGuestBlacklist(
  contact: BlacklistFields,
): GuestBlacklistDto | null {
  if (!contact.blacklistedAt) return null;
  return {
    reason: contact.blacklistReason ?? '',
    at: contact.blacklistedAt.toISOString(),
    by: toEntityRef(contact.blacklistedBy),
  };
}

/**
 * Поиск клиента по телефону или email при дублях: сначала карточка из чёрного списка (дубль не должен
 * спрятать гостя от отметки), затем самая старая — чтобы выбор был предсказуемым.
 */
export const PREFER_BLACKLISTED_ORDER: Prisma.ContactOrderByWithRelationInput[] =
  [{ blacklistedAt: { sort: 'desc', nulls: 'last' } }, { createdAt: 'asc' }];

interface GuestIdentity {
  phones: string[];
  email: string | null;
}

/**
 * Правка убирает телефон или меняет email: новая бронь или сообщение гостя уже не найдут его карточку.
 * У гостя из чёрного списка это обходило бы правило «убирает только администратор».
 */
export function weakensGuestMatch(
  current: GuestIdentity,
  input: Partial<GuestIdentity>,
): boolean {
  const removesPhone =
    input.phones !== undefined &&
    current.phones.some((phone) => !input.phones?.includes(phone));
  const changesEmail =
    input.email !== undefined &&
    current.email !== null &&
    input.email !== current.email;
  return removesPhone || changesEmail;
}
