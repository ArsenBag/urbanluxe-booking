import { weakensGuestMatch } from './guest-blacklist.js';

const current = { phones: ['+998900000001'], email: 'guest@example.com' };

describe('weakensGuestMatch', () => {
  it('allows saving the card unchanged or adding a phone', () => {
    expect(weakensGuestMatch(current, { ...current })).toBe(false);
    expect(weakensGuestMatch(current, {})).toBe(false);
    expect(
      weakensGuestMatch(current, { phones: [...current.phones, '+998900000002'] }),
    ).toBe(false);
  });

  it('flags removing a phone or changing the email: the guest would no longer be found', () => {
    expect(weakensGuestMatch(current, { phones: [] })).toBe(true);
    expect(weakensGuestMatch(current, { email: null })).toBe(true);
    expect(weakensGuestMatch(current, { email: 'other@example.com' })).toBe(true);
  });

  it('allows adding an email to a card without one', () => {
    expect(
      weakensGuestMatch({ ...current, email: null }, { email: 'guest@example.com' }),
    ).toBe(false);
  });
});
