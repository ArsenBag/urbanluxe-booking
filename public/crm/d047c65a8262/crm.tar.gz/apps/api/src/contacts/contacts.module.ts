import { Module } from '@nestjs/common';
import { FilesModule } from '../files/files.module.js';
import { BlacklistController } from './blacklist.controller.js';
import { BlacklistService } from './blacklist.service.js';
import { ContactsController } from './contacts.controller.js';
import { ContactsService } from './contacts.service.js';

@Module({
  imports: [FilesModule],
  controllers: [ContactsController, BlacklistController],
  providers: [ContactsService, BlacklistService],
  exports: [ContactsService],
})
export class ContactsModule {}
