import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Put } from '@nestjs/common';
import { blacklistInputSchema, type BlacklistEntryDto, type BlacklistInput, type ContactDto } from '@crm/shared';
import { CurrentUser, Roles } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { BlacklistService } from './blacklist.service.js';

/** Чёрный список: внести гостя может любой сотрудник (прямо из диалога), убрать — только администратор. */
@Controller('blacklist')
export class BlacklistController {
  constructor(private readonly blacklist: BlacklistService) {}

  @Get()
  list(): Promise<BlacklistEntryDto[]> {
    return this.blacklist.list();
  }

  @Put(':contactId')
  add(
    @Param('contactId', new ParseUUIDPipe()) contactId: string,
    @Body(new ZodValidationPipe(blacklistInputSchema)) input: BlacklistInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<ContactDto> {
    return this.blacklist.add(contactId, input, actor);
  }

  @Delete(':contactId')
  @Roles('ADMIN')
  remove(@Param('contactId', new ParseUUIDPipe()) contactId: string, @CurrentUser() actor: SessionUser): Promise<ContactDto> {
    return this.blacklist.remove(contactId, actor);
  }
}
