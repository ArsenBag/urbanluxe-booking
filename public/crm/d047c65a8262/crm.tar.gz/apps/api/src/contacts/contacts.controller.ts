import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import {
  contactListQuerySchema,
  createContactSchema,
  updateContactSchema,
  type ActivityDto,
  type ContactDto,
  type ContactListItemDto,
  type ContactListQuery,
  type CreateContactInput,
  type Paginated,
  type UpdateContactInput,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import { CurrentUser, Roles } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { ContactsService } from './contacts.service.js';

@Controller('contacts')
export class ContactsController {
  constructor(
    private readonly contacts: ContactsService,
    private readonly audit: ActivityLogService,
  ) {}

  @Get()
  list(@Query(new ZodValidationPipe(contactListQuerySchema)) query: ContactListQuery): Promise<Paginated<ContactListItemDto>> {
    return this.contacts.list(query);
  }

  @Get(':id')
  get(@Param('id', new ParseUUIDPipe()) id: string): Promise<ContactDto> {
    return this.contacts.get(id);
  }

  @Get(':id/activity')
  activity(@Param('id', new ParseUUIDPipe()) id: string): Promise<ActivityDto[]> {
    return this.audit.historyForContact(id);
  }

  @Post()
  create(
    @Body(new ZodValidationPipe(createContactSchema)) input: CreateContactInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<ContactDto> {
    return this.contacts.create(input, actor);
  }

  @Patch(':id')
  update(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body(new ZodValidationPipe(updateContactSchema)) input: UpdateContactInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<ContactDto> {
    return this.contacts.update(id, input, actor);
  }

  @Delete(':id')
  @Roles('ADMIN')
  remove(@Param('id', new ParseUUIDPipe()) id: string, @CurrentUser() actor: SessionUser): Promise<null> {
    return this.contacts.remove(id, actor);
  }
}
