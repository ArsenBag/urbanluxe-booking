import { ForbiddenException, UnauthorizedException, type ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuthGuard } from './auth.guard.js';
import type { AuthService } from './auth.service.js';
import { IS_PUBLIC_KEY, ROLES_KEY } from './decorators.js';
import { SESSION_COOKIE, sessionCookieName, type SessionUser } from './session-user.js';

const manager: SessionUser = { id: 'u1', email: 'm@hl.uz', name: 'Менеджер', role: 'MANAGER' };

function contextWith(request: Record<string, unknown>): ExecutionContext {
  return {
    getHandler: () => undefined,
    getClass: () => undefined,
    switchToHttp: () => ({ getRequest: () => request }),
  } as unknown as ExecutionContext;
}

function setup(metadata: Record<string, unknown>, sessionUser: SessionUser | null) {
  const reflector = new Reflector();
  vi.spyOn(reflector, 'getAllAndOverride').mockImplementation((key) => metadata[key as string]);
  const auth = { resolveSession: vi.fn().mockResolvedValue(sessionUser), sessionCookie: SESSION_COOKIE };
  return { guard: new AuthGuard(auth as unknown as AuthService, reflector), auth };
}

describe('AuthGuard', () => {
  it('lets public routes through without a session', async () => {
    const { guard, auth } = setup({ [IS_PUBLIC_KEY]: true }, null);

    await expect(guard.canActivate(contextWith({}))).resolves.toBe(true);
    expect(auth.resolveSession).not.toHaveBeenCalled();
  });

  it('rejects requests without a session cookie', async () => {
    const { guard } = setup({}, manager);

    await expect(guard.canActivate(contextWith({ cookies: {} }))).rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('attaches the session user to the request', async () => {
    const { guard } = setup({}, manager);
    const request: Record<string, unknown> = { cookies: { [SESSION_COOKIE]: 'token' } };

    await guard.canActivate(contextWith(request));

    expect(request.user).toEqual(manager);
  });

  it('forbids a manager on an admin-only route', async () => {
    const { guard } = setup({ [ROLES_KEY]: ['ADMIN'] }, manager);
    const request = { cookies: { [SESSION_COOKIE]: 'token' } };

    await expect(guard.canActivate(contextWith(request))).rejects.toBeInstanceOf(ForbiddenException);
  });
});

describe('sessionCookieName', () => {
  it('uses the __Host- prefix only in production', () => {
    expect(sessionCookieName('production')).toBe('__Host-crm_session');
    expect(sessionCookieName('development')).toBe('crm_session');
    expect(sessionCookieName('test')).toBe('crm_session');
  });
});
