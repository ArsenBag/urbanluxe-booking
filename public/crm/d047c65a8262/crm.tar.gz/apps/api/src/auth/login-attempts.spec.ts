import {
  DEVICE_WINDOW_MS,
  LoginAttempts,
  MAX_FAILED_PER_DEVICE,
  MAX_FAILED_PER_EMAIL,
  TooManyLoginAttemptsException,
  TRUSTED_DEVICE_MS,
} from './login-attempts.js';

const EMAIL = 'admin@hl.uz';
const OFFICE = '203.0.113.7';

/** n неудачных попыток: begin без succeed — так выглядит неверный пароль. */
function fail(attempts: LoginAttempts, ip: string, times: number, email = EMAIL) {
  for (let i = 0; i < times; i += 1) attempts.begin(email, ip);
}

describe('LoginAttempts', () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it('closes login from a device after repeated failures', () => {
    const attempts = new LoginAttempts();
    fail(attempts, OFFICE, MAX_FAILED_PER_DEVICE);

    expect(() => attempts.begin(EMAIL, OFFICE)).toThrow(TooManyLoginAttemptsException);
    // С другого адреса тот же email ещё можно (общий потолок не достигнут).
    expect(() => attempts.begin(EMAIL, '198.51.100.1')).not.toThrow();
  });

  it('opens the device again once failures leave the window', () => {
    const attempts = new LoginAttempts();
    fail(attempts, OFFICE, MAX_FAILED_PER_DEVICE);
    vi.advanceTimersByTime(DEVICE_WINDOW_MS + 1);
    expect(() => attempts.begin(EMAIL, OFFICE)).not.toThrow();
  });

  it('a successful login clears the counters', () => {
    const attempts = new LoginAttempts();
    fail(attempts, OFFICE, MAX_FAILED_PER_DEVICE - 1);
    attempts.begin(EMAIL, OFFICE);
    attempts.succeed(EMAIL, OFFICE);
    expect(() => fail(attempts, OFFICE, MAX_FAILED_PER_DEVICE)).not.toThrow();
  });

  it('caps failures per email across many addresses', () => {
    const attempts = new LoginAttempts();
    for (let i = 0; i < MAX_FAILED_PER_EMAIL; i += 1) attempts.begin(EMAIL, `10.0.${Math.floor(i / 5)}.${i % 5}`);

    expect(() => attempts.begin(EMAIL, '198.51.100.1')).toThrow(TooManyLoginAttemptsException);
    expect(() => attempts.begin('other@hl.uz', '198.51.100.1')).not.toThrow();
  });

  it('does not lock a staff member out of their usual device during an attack on their email', () => {
    const attempts = new LoginAttempts();
    attempts.begin(EMAIL, OFFICE);
    attempts.succeed(EMAIL, OFFICE);
    for (let i = 0; i < MAX_FAILED_PER_EMAIL; i += 1) attempts.begin(EMAIL, `10.1.${Math.floor(i / 5)}.${i % 5}`);

    expect(() => attempts.begin(EMAIL, OFFICE)).not.toThrow();
    expect(() => attempts.begin(EMAIL, '198.51.100.1')).toThrow(TooManyLoginAttemptsException);
  });

  it('forgets a trusted device after a month', () => {
    const attempts = new LoginAttempts();
    attempts.begin(EMAIL, OFFICE);
    attempts.succeed(EMAIL, OFFICE);
    vi.advanceTimersByTime(TRUSTED_DEVICE_MS + 1);
    for (let i = 0; i < MAX_FAILED_PER_EMAIL; i += 1) attempts.begin(EMAIL, `10.2.${Math.floor(i / 5)}.${i % 5}`);

    expect(() => attempts.begin(EMAIL, OFFICE)).toThrow(TooManyLoginAttemptsException);
  });

  it('treats email case and spaces as the same account', () => {
    const attempts = new LoginAttempts();
    fail(attempts, OFFICE, MAX_FAILED_PER_DEVICE, ' Admin@HL.uz ');
    expect(() => attempts.begin(EMAIL, OFFICE)).toThrow(TooManyLoginAttemptsException);
  });

  it('answers with status 429 and a readable message', () => {
    const error = new TooManyLoginAttemptsException();
    expect(error.getStatus()).toBe(429);
    expect(error.message).toContain('Слишком много неудачных попыток');
  });
});
