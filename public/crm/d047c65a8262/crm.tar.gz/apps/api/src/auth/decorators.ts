import { createParamDecorator, type ExecutionContext, SetMetadata } from '@nestjs/common';
import type { Role } from '@crm/shared';
import type { AuthenticatedRequest, SessionUser } from './session-user.js';

export const IS_PUBLIC_KEY = 'isPublic';
export const ROLES_KEY = 'roles';

/** Маршрут доступен без входа. */
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);

/** Маршрут доступен только указанным ролям. */
export const Roles = (...roles: Role[]) => SetMetadata(ROLES_KEY, roles);

/** Текущий пользователь из сессии. */
export const CurrentUser = createParamDecorator(
  (_data: unknown, context: ExecutionContext): SessionUser =>
    context.switchToHttp().getRequest<AuthenticatedRequest>().user,
);
