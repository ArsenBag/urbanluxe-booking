import { UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import type { Env } from '../config/env.js';
import type { PrismaService } from '../prisma/prisma.service.js';
import { AuthService } from './auth.service.js';
import { LoginAttempts, MAX_FAILED_PER_DEVICE, TooManyLoginAttemptsException } from './login-attempts.js';
import type { PasswordService } from './password.service.js';

const env = { JWT_SECRET: 'x'.repeat(32), SESSION_TTL_HOURS: 1 } as Env;

const activeUser = {
  id: '11111111-1111-1111-1111-111111111111',
  email: 'admin@hl.uz',
  name: 'Админ',
  role: 'ADMIN' as const,
  passwordHash: 'hash',
  isActive: true,
  tokenVersion: 3,
};

function setup(user: typeof activeUser | null, passwordMatches = true, attempts = new LoginAttempts()) {
  const prisma = { user: { findUnique: vi.fn().mockResolvedValue(user) } };
  const passwords = {
    verify: vi.fn().mockResolvedValue(passwordMatches),
    verifyAgainstDummy: vi.fn().mockResolvedValue(false),
  };
  const jwt = new JwtService({ secret: env.JWT_SECRET });
  const service = new AuthService(
    prisma as unknown as PrismaService,
    passwords as unknown as PasswordService,
    jwt,
    attempts,
    env,
  );
  return { service, prisma, passwords, jwt, attempts };
}

const credentials = { email: activeUser.email, password: 'secret-password' };
const IP = '203.0.113.7';

describe('AuthService.validateCredentials', () => {
  it('returns session user without password hash for valid credentials', async () => {
    const { service } = setup(activeUser);

    const result = await service.validateCredentials(credentials, IP);

    expect(result).toEqual({
      id: activeUser.id,
      email: activeUser.email,
      name: 'Админ',
      role: 'ADMIN',
      tokenVersion: 3,
    });
  });

  it('rejects wrong password', async () => {
    const { service } = setup(activeUser, false);

    await expect(service.validateCredentials(credentials, IP)).rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('rejects unknown email and still spends time on a dummy hash check', async () => {
    const { service, passwords } = setup(null);

    await expect(service.validateCredentials(credentials, IP)).rejects.toBeInstanceOf(UnauthorizedException);
    expect(passwords.verifyAgainstDummy).toHaveBeenCalledWith(credentials.password);
  });

  it('rejects deactivated user with the same generic message', async () => {
    const { service } = setup({ ...activeUser, isActive: false });

    await expect(service.validateCredentials(credentials, IP)).rejects.toThrow('Неверный email или пароль');
  });
});

describe('AuthService.resolveSession', () => {
  it('resolves user from a token it issued', async () => {
    const { service } = setup(activeUser);
    const token = await service.issueToken(activeUser);

    const result = await service.resolveSession(token);

    expect(result?.id).toBe(activeUser.id);
  });

  it('returns null for a tampered token', async () => {
    const { service } = setup(activeUser);
    const token = await service.issueToken(activeUser);

    expect(await service.resolveSession(`${token}x`)).toBeNull();
  });

  it('returns null for a token signed with another secret', async () => {
    const { service } = setup(activeUser);
    const foreign = await new JwtService({ secret: 'y'.repeat(32) }).signAsync({ sub: activeUser.id, ver: 3 });

    expect(await service.resolveSession(foreign)).toBeNull();
  });

  it('returns null after sessions were revoked (token version bumped)', async () => {
    const { service, prisma } = setup(activeUser);
    const token = await service.issueToken(activeUser);
    prisma.user.findUnique.mockResolvedValue({ ...activeUser, tokenVersion: activeUser.tokenVersion + 1 });

    expect(await service.resolveSession(token)).toBeNull();
  });

  it('rejects tokens signed with a different algorithm', async () => {
    const { service } = setup(activeUser);
    const hs512 = await new JwtService({ secret: env.JWT_SECRET }).signAsync(
      { sub: activeUser.id, ver: activeUser.tokenVersion },
      { algorithm: 'HS512' },
    );

    expect(await service.resolveSession(hs512)).toBeNull();
  });

  it('returns null when user was deactivated after login', async () => {
    const { service, prisma } = setup(activeUser);
    const token = await service.issueToken(activeUser);
    prisma.user.findUnique.mockResolvedValue({ ...activeUser, isActive: false });

    expect(await service.resolveSession(token)).toBeNull();
  });
});

describe('AuthService login attempts', () => {
  it('closes login from a device after repeated failures, even with the right password', async () => {
    const attempts = new LoginAttempts();
    const { service: failing } = setup(activeUser, false, attempts);
    for (let i = 0; i < MAX_FAILED_PER_DEVICE; i += 1) {
      await expect(failing.validateCredentials(credentials, IP)).rejects.toBeInstanceOf(UnauthorizedException);
    }

    const { service: correct, passwords } = setup(activeUser, true, attempts);
    await expect(correct.validateCredentials(credentials, IP)).rejects.toBeInstanceOf(TooManyLoginAttemptsException);
    // Пароль даже не проверяется: перебор не получает сигнала «угадал».
    expect(passwords.verify).not.toHaveBeenCalled();
  });

  it('resets the counter after a successful login', async () => {
    const attempts = new LoginAttempts();
    const { service: failing } = setup(activeUser, false, attempts);
    for (let i = 0; i < MAX_FAILED_PER_DEVICE - 1; i += 1) {
      await expect(failing.validateCredentials(credentials, IP)).rejects.toBeInstanceOf(UnauthorizedException);
    }
    const { service: correct } = setup(activeUser, true, attempts);
    await correct.validateCredentials(credentials, IP);

    await expect(failing.validateCredentials(credentials, IP)).rejects.toBeInstanceOf(UnauthorizedException);
  });
});
