import type { Role } from '@crm/shared';
import type { Request } from 'express';

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: Role;
}

export interface AuthenticatedRequest extends Request {
  user: SessionUser;
}

export interface SessionTokenPayload {
  sub: string;
  /** Версия токенов пользователя на момент входа (User.tokenVersion). */
  ver: number;
}

export const SESSION_COOKIE = 'crm_session';

/**
 * В проде cookie с префиксом __Host-: браузер примет её только по HTTPS, с Path=/ и без Domain,
 * поэтому её нельзя подложить или перехватить с другого поддомена.
 */
export function sessionCookieName(nodeEnv: string): string {
  return nodeEnv === 'production' ? `__Host-${SESSION_COOKIE}` : SESSION_COOKIE;
}
