import { Body, Controller, Get, HttpCode, HttpStatus, Post, Req, Res } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { loginSchema, type LoginInput } from '@crm/shared';
import type { CookieOptions, Request, Response } from 'express';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { AuthService } from './auth.service.js';
import { CurrentUser, Public } from './decorators.js';
import type { SessionUser } from './session-user.js';

const MS_PER_SECOND = 1000;
const LOGIN_ATTEMPTS_PER_MINUTE = 5;
const ONE_MINUTE_MS = 60_000;

@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Public()
  @Throttle({ default: { limit: LOGIN_ATTEMPTS_PER_MINUTE, ttl: ONE_MINUTE_MS } })
  @Post('login')
  @HttpCode(HttpStatus.OK)
  async login(
    @Body(new ZodValidationPipe(loginSchema)) input: LoginInput,
    @Req() request: Request,
    @Res({ passthrough: true }) response: Response,
  ): Promise<SessionUser> {
    // request.ip учитывает TRUST_PROXY: за Caddy это адрес клиента, а не прокси.
    const { tokenVersion, ...user } = await this.auth.validateCredentials(input, request.ip ?? 'unknown');
    const token = await this.auth.issueToken({ id: user.id, tokenVersion });
    response.cookie(this.auth.sessionCookie, token, {
      ...this.cookieOptions(),
      maxAge: this.auth.sessionTtlSeconds * MS_PER_SECOND,
    });
    return user;
  }

  @Public()
  @Post('logout')
  @HttpCode(HttpStatus.OK)
  async logout(@Req() request: Request, @Res({ passthrough: true }) response: Response): Promise<null> {
    // Отзываем токен на сервере: украденная cookie после выхода тоже перестанет работать.
    const token: unknown = request.cookies?.[this.auth.sessionCookie];
    const user = typeof token === 'string' ? await this.auth.resolveSession(token) : null;
    if (user) {
      await this.auth.revokeSessions(user.id);
    }
    response.clearCookie(this.auth.sessionCookie, this.cookieOptions());
    return null;
  }

  @Get('me')
  me(@CurrentUser() user: SessionUser): SessionUser {
    return user;
  }

  private cookieOptions(): CookieOptions {
    return {
      httpOnly: true,
      sameSite: 'lax',
      // Secure обязателен для префикса __Host-, который включается в проде (см. sessionCookieName).
      secure: this.auth.sessionCookie.startsWith('__Host-'),
      path: '/',
    };
  }
}
