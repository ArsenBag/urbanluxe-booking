import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';

/** Неудачных попыток с одного адреса на один email за окно — дальше вход с этого адреса закрыт. */
export const MAX_FAILED_PER_DEVICE = 10;
export const DEVICE_WINDOW_MS = 15 * 60_000;
/** Общий потолок на email (перебор с многих адресов). На доверенные устройства не действует. */
export const MAX_FAILED_PER_EMAIL = 50;
export const EMAIL_WINDOW_MS = 60 * 60_000;
/** Устройство (email + IP), с которого был успешный вход, считается доверенным столько времени. */
export const TRUSTED_DEVICE_MS = 30 * 24 * 60 * 60_000;
/** Потолок записей в каждой таблице: перебор случайных email не должен съесть память. */
const MAX_TRACKED = 10_000;

export class TooManyLoginAttemptsException extends HttpException {
  constructor() {
    super(
      'Слишком много неудачных попыток входа. Подождите и попробуйте позже или обратитесь к администратору.',
      HttpStatus.TOO_MANY_REQUESTS,
    );
  }
}

/** Метки времени по ключу с ограничением размера: старые записи вытесняются, но не заблокированные. */
class TimestampLog {
  private readonly entries = new Map<string, number[]>();

  constructor(
    private readonly windowMs: number,
    private readonly limit: number,
  ) {}

  count(key: string): number {
    return this.recent(key).length;
  }

  isLocked(key: string): boolean {
    return this.count(key) >= this.limit;
  }

  add(key: string): void {
    const times = [...this.recent(key), Date.now()];
    this.entries.delete(key);
    this.entries.set(key, times);
    if (this.entries.size > MAX_TRACKED) this.evictOne();
  }

  clear(key: string): void {
    this.entries.delete(key);
  }

  private recent(key: string): number[] {
    const since = Date.now() - this.windowMs;
    return (this.entries.get(key) ?? []).filter((time) => time > since);
  }

  /** Сначала самая старая незаблокированная запись: перебором чужих адресов нельзя «вымыть» блокировку. */
  private evictOne(): void {
    for (const key of this.entries.keys()) {
      if (!this.isLocked(key)) {
        this.entries.delete(key);
        return;
      }
    }
    const oldest = this.entries.keys().next().value;
    if (oldest !== undefined) this.entries.delete(oldest);
  }
}

/**
 * Защита от подбора пароля, дополняет лимит запросов по IP. Два счётчика:
 * - email + IP — подбор с одного устройства (10 за 15 минут);
 * - email — подбор с многих адресов (50 за час). Чтобы злоумышленник не мог этим запереть сотрудника,
 *   счётчик не действует на устройства, с которых в этот аккаунт недавно успешно входили.
 * Попытка учитывается до проверки пароля (одновременные запросы не проскочат), успешный вход её снимает.
 * Хранится в памяти: API — один процесс, после перезапуска счётчики пусты.
 */
@Injectable()
export class LoginAttempts {
  private readonly logger = new Logger(LoginAttempts.name);
  private readonly perDevice = new TimestampLog(
    DEVICE_WINDOW_MS,
    MAX_FAILED_PER_DEVICE,
  );
  private readonly perEmail = new TimestampLog(
    EMAIL_WINDOW_MS,
    MAX_FAILED_PER_EMAIL,
  );
  private readonly trusted = new Map<string, number>();

  /** Проверяет лимиты и заранее записывает попытку как неудачную. */
  begin(email: string, ip: string): void {
    const key = normalize(email);
    const device = `${key}|${ip}`;
    if (
      this.perDevice.isLocked(device) ||
      (this.perEmail.isLocked(key) && !this.isTrusted(device))
    ) {
      throw new TooManyLoginAttemptsException();
    }
    this.perDevice.add(device);
    this.perEmail.add(key);
    if (
      this.perDevice.isLocked(device) ||
      this.perEmail.count(key) === MAX_FAILED_PER_EMAIL
    ) {
      this.logger.warn(
        `Вход для ${key} временно закрыт после неудачных попыток (IP ${ip})`,
      );
    }
  }

  /** Пароль верный: снимаем счётчики и запоминаем устройство как доверенное. */
  succeed(email: string, ip: string): void {
    const key = normalize(email);
    const device = `${key}|${ip}`;
    this.perDevice.clear(device);
    this.perEmail.clear(key);
    this.trusted.delete(device);
    this.trusted.set(device, Date.now());
    if (this.trusted.size > MAX_TRACKED) {
      const oldest = this.trusted.keys().next().value;
      if (oldest !== undefined) this.trusted.delete(oldest);
    }
  }

  private isTrusted(device: string): boolean {
    const since = this.trusted.get(device);
    return since !== undefined && Date.now() - since < TRUSTED_DEVICE_MS;
  }
}

/** Схема входа уже нормализует email; повторяем на случай другого вызывающего кода. */
const normalize = (email: string) => email.trim().toLowerCase();
