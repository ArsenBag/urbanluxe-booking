import { Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import type { LoginInput } from '@crm/shared';
import { ENV, type Env } from '../config/env.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { LoginAttempts } from './login-attempts.js';
import { PasswordService } from './password.service.js';
import { sessionCookieName, type SessionTokenPayload, type SessionUser } from './session-user.js';

const INVALID_CREDENTIALS = 'Неверный email или пароль';
export const JWT_ALGORITHM = 'HS256';
const SECONDS_PER_HOUR = 3600;

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly passwords: PasswordService,
    private readonly jwt: JwtService,
    private readonly attempts: LoginAttempts,
    @Inject(ENV) private readonly env: Env,
  ) {}

  /** Имя cookie сессии: в проде с префиксом __Host- (только HTTPS, без чужих поддоменов). */
  get sessionCookie(): string {
    return sessionCookieName(this.env.NODE_ENV);
  }

  get sessionTtlSeconds(): number {
    return this.env.SESSION_TTL_HOURS * SECONDS_PER_HOUR;
  }

  /**
   * Проверяет email и пароль. Одинаковая ошибка для «нет пользователя» и «неверный пароль».
   * ip — адрес клиента для ограничения подбора пароля (см. LoginAttempts).
   */
  async validateCredentials(input: LoginInput, ip: string): Promise<SessionUser & { tokenVersion: number }> {
    this.attempts.begin(input.email, ip);
    const user = await this.prisma.user.findUnique({ where: { email: input.email } });

    const isValid = user
      ? await this.passwords.verify(user.passwordHash, input.password)
      : await this.passwords.verifyAgainstDummy(input.password);

    if (!user || !isValid || !user.isActive) {
      throw new UnauthorizedException(INVALID_CREDENTIALS);
    }
    this.attempts.succeed(input.email, ip);
    return { id: user.id, email: user.email, name: user.name, role: user.role, tokenVersion: user.tokenVersion };
  }

  issueToken(user: { id: string; tokenVersion: number }): Promise<string> {
    const payload: SessionTokenPayload = { sub: user.id, ver: user.tokenVersion };
    return this.jwt.signAsync(payload, { expiresIn: this.sessionTtlSeconds, algorithm: JWT_ALGORITHM });
  }

  /** Завершает все сессии пользователя: ранее выданные токены перестают приниматься. */
  async revokeSessions(userId: string): Promise<void> {
    await this.prisma.user.update({ where: { id: userId }, data: { tokenVersion: { increment: 1 } } });
  }

  /** Возвращает пользователя по токену или null, если токен недействителен или пользователь заблокирован. */
  async resolveSession(token: string): Promise<SessionUser | null> {
    let payload: SessionTokenPayload;
    try {
      payload = await this.jwt.verifyAsync<SessionTokenPayload>(token, { algorithms: [JWT_ALGORITHM] });
    } catch {
      // Просроченный или подделанный токен — это обычная ситуация «не авторизован», не ошибка сервера.
      return null;
    }
    const user = await this.prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user || !user.isActive || user.tokenVersion !== payload.ver) {
      return null;
    }
    return { id: user.id, email: user.email, name: user.name, role: user.role };
  }
}
