import { Injectable, type OnModuleInit } from '@nestjs/common';
import argon2 from 'argon2';

@Injectable()
export class PasswordService implements OnModuleInit {
  /** Хэш для сравнения, когда пользователь не найден: выравнивает время ответа. */
  private dummyHash: Promise<string> | null = null;

  /** Считаем заранее: иначе первый вход с несуществующим email после запуска заметно дольше остальных. */
  onModuleInit(): void {
    this.dummyHash ??= this.hash('dummy-password-for-timing');
  }

  hash(password: string): Promise<string> {
    return argon2.hash(password, { type: argon2.argon2id });
  }

  verify(hash: string, password: string): Promise<boolean> {
    return argon2.verify(hash, password);
  }

  /** Тратит столько же времени, сколько настоящая проверка, и всегда возвращает false. */
  async verifyAgainstDummy(password: string): Promise<false> {
    this.dummyHash ??= this.hash('dummy-password-for-timing');
    await argon2.verify(await this.dummyHash, password);
    return false;
  }
}
