import {
  Injectable,
  Logger,
  type OnApplicationBootstrap,
} from '@nestjs/common';
import { formatPhone, MAX_FILE_BYTES } from '@crm/shared';
import { ChannelRegistry } from '../inbox/channel-registry.js';
import {
  MessengerSendError,
  type AttachmentTarget,
  type AvatarTarget,
  type Recipient,
  type RecipientQuery,
  type DownloadedMedia,
  type MessengerSender,
  type OutboundMessage,
  type SentMessage,
} from '../inbox/messenger.types.js';
import type { ChannelStatus } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import {
  GreenApiClient,
  GreenApiError,
  type GreenApiState,
} from './green-api.client.js';
import { whatsappChatId, type WhatsAppMedia } from './whatsapp-mapper.js';

/**
 * Состояние Green-API → статус канала. Временные состояния (запуск, предупреждение WhatsApp)
 * не блокируют отправку: показываем предупреждение, но отвечать клиентам можно.
 */
const STATUS_BY_STATE: Record<string, ChannelStatus> = {
  authorized: 'CONNECTED',
  starting: 'CONNECTED',
  yellowCard: 'CONNECTED',
  notAuthorized: 'DISCONNECTED',
};
/** Не чаще этого перепроверяем состояние, если сообщения приходят, а канал не «подключён». */
const STATE_REFRESH_INTERVAL_MS = 60_000;
/** Аватар — картинка в десятки КБ; больше мегабайта — не фото профиля. */
const MAX_AVATAR_BYTES = 1024 * 1024;

const STATE_ERRORS: Record<string, string> = {
  notAuthorized:
    'Номер не подключён: отсканируйте QR-код в личном кабинете Green-API.',
  blocked: 'WhatsApp заблокировал номер. Проверьте его в приложении WhatsApp.',
  yellowCard:
    'WhatsApp временно ограничил номер за подозрительную активность. Не делайте массовых рассылок.',
  starting: 'Инстанс Green-API запускается, подождите пару минут.',
};

/**
 * WhatsApp через Green-API. Один номер компании: канал в CRM создаётся из настроек сервера,
 * его состояние обновляется при запуске и по вебхуку stateInstanceChanged.
 */
/** Понятный текст для известных отказов Green-API (ключи, тариф); null — другая ошибка. */
function greenApiErrorText(error: unknown): string | null {
  if (!(error instanceof GreenApiError)) return null;
  if (error.status === 401 || error.status === 403) {
    return 'Green-API отклонил ключи. Проверьте GREEN_API_ID_INSTANCE и GREEN_API_TOKEN.';
  }
  if (error.status === 466) {
    return 'Исчерпан лимит тарифа Green-API. Проверьте тариф в личном кабинете.';
  }
  return null;
}

@Injectable()
export class WhatsAppService
  implements MessengerSender, OnApplicationBootstrap
{
  readonly type = 'WHATSAPP' as const;
  private readonly logger = new Logger(WhatsAppService.name);
  private lastRefreshAt = 0;

  constructor(
    private readonly prisma: PrismaService,
    private readonly registry: ChannelRegistry,
    private readonly client: GreenApiClient,
  ) {}

  get isConfigured(): boolean {
    return this.client.isConfigured;
  }

  async onApplicationBootstrap(): Promise<void> {
    if (!this.client.isConfigured) {
      this.logger.log(
        'WhatsApp не настроен (нет GREEN_API_ID_INSTANCE/TOKEN) — канал отключён',
      );
      return;
    }
    this.registry.register(this);
    // Проверка состояния в фоне: недоступность Green-API не должна мешать запуску CRM.
    void this.refreshState().catch((error: unknown) =>
      this.logger.warn(
        `Не удалось проверить состояние WhatsApp: ${error instanceof Error ? error.message : String(error)}`,
      ),
    );
  }

  /** Канал WhatsApp в БД (создаётся при первом обращении). */
  async ensureChannel(): Promise<{ id: string; status: ChannelStatus }> {
    const key = `green-api:${this.client.instanceId}`;
    const channel = await this.prisma.channel.upsert({
      where: { type_phone: { type: 'WHATSAPP', phone: key } },
      create: {
        type: 'WHATSAPP',
        phone: key,
        name: 'WhatsApp',
        status: 'DISCONNECTED',
      },
      update: {},
    });
    return { id: channel.id, status: channel.status };
  }

  async refreshState(): Promise<void> {
    this.lastRefreshAt = Date.now();
    await this.applyState(await this.client.getState());
  }

  /**
   * Сообщения приходят, а канал помечен неподключённым (проверка при запуске не удалась
   * или уведомления о состоянии выключены) — перепроверяем в фоне, не чаще раза в минуту.
   */
  refreshStateIfStale(channelStatus: ChannelStatus): void {
    if (
      channelStatus === 'CONNECTED' ||
      Date.now() - this.lastRefreshAt < STATE_REFRESH_INTERVAL_MS
    )
      return;
    void this.refreshState().catch((error: unknown) =>
      this.logger.warn(
        `Не удалось проверить состояние WhatsApp: ${error instanceof Error ? error.message : String(error)}`,
      ),
    );
  }

  /** Состояние инстанса → статус канала. wid — номер, к которому привязан инстанс. */
  async applyState(state: GreenApiState, wid?: string | null): Promise<void> {
    const { id: channelId } = await this.ensureChannel();
    const digits = wid?.replace(/@c\.us$/, '');
    await this.prisma.channel.update({
      where: { id: channelId },
      data: {
        status: STATUS_BY_STATE[state] ?? 'ERROR',
        lastError:
          state === 'authorized'
            ? null
            : (STATE_ERRORS[state] ?? `Состояние Green-API: ${state}`),
        ...(digits && {
          externalAccountId: digits,
          name: `WhatsApp ${formatPhone(`+${digits}`)}`,
        }),
      },
    });
  }

  async send(message: OutboundMessage): Promise<SentMessage> {
    try {
      const chatId = whatsappChatId(message.externalChatId);
      const result = message.file
        ? await this.client.sendFileByUpload(chatId, message.file, message.text)
        : await this.client.sendMessage(chatId, message.text);
      return { externalMessageId: result.idMessage, sentAt: new Date() };
    } catch (error) {
      const known = greenApiErrorText(error);
      if (known) throw new MessengerSendError(known);
      this.logger.error(
        `Ошибка отправки WhatsApp: ${error instanceof Error ? error.message : String(error)}`,
      );
      throw new MessengerSendError(
        'Не удалось отправить сообщение в WhatsApp. Попробуйте ещё раз.',
      );
    }
  }

  /** Собеседник по номеру: Green-API проверяет, что на номере есть WhatsApp. */
  async findRecipient(query: RecipientQuery): Promise<Recipient> {
    const digits = query.phone?.replace(/\D/g, '') ?? '';
    if (!digits) {
      throw new MessengerSendError(
        'Для WhatsApp нужен номер телефона клиента.',
      );
    }
    let exists: boolean;
    try {
      exists =
        (await this.client.checkWhatsapp(digits)).existsWhatsapp === true;
    } catch (error) {
      this.logger.warn(
        `Не удалось проверить номер в WhatsApp: ${error instanceof Error ? error.message : String(error)}`,
      );
      throw new MessengerSendError(
        greenApiErrorText(error) ??
          'Не удалось проверить номер в WhatsApp. Попробуйте ещё раз.',
      );
    }
    if (!exists) {
      throw new MessengerSendError(
        `На номере ${formatPhone(`+${digits}`)} нет WhatsApp.`,
      );
    }
    return {
      externalChatId: digits,
      externalAccessHash: null,
      peer: { externalId: digits, phone: digits },
    };
  }

  /** Фото профиля собеседника: ссылку даёт Green-API, сам файл лежит в хранилище WhatsApp. */
  async fetchAvatar(target: AvatarTarget): Promise<DownloadedMedia | null> {
    const avatar = await this.client.getAvatar(
      whatsappChatId(target.externalChatId),
    );
    if (!avatar.available || !avatar.urlAvatar) return null;
    const file = await this.client.downloadFile(
      avatar.urlAvatar,
      MAX_AVATAR_BYTES,
    );
    if (!file) return null;
    return {
      buffer: file.buffer,
      mimeType: file.mimeType,
      fileName: 'avatar.jpg',
    };
  }

  /** Файл сохранённого сообщения по свежей ссылке от Green-API. null — больше 20 МБ. */
  async fetchAttachment(
    target: AttachmentTarget,
  ): Promise<DownloadedMedia | null> {
    const url = await this.client.getDownloadUrl(
      whatsappChatId(target.externalChatId),
      target.externalMessageId,
    );
    const file = await this.client.downloadFile(url, MAX_FILE_BYTES);
    if (!file) return null;
    return {
      buffer: file.buffer,
      mimeType: target.attachment.mimeType ?? file.mimeType,
      fileName: target.attachment.fileName ?? null,
    };
  }

  /** Файл входящего сообщения по ссылке из вебхука. null — больше 20 МБ. */
  async download(media: WhatsAppMedia): Promise<DownloadedMedia | null> {
    const file = await this.client.downloadFile(
      media.downloadUrl,
      MAX_FILE_BYTES,
    );
    if (!file) return null;
    return {
      buffer: file.buffer,
      mimeType: media.mimeType ?? file.mimeType,
      fileName: media.fileName,
    };
  }
}
