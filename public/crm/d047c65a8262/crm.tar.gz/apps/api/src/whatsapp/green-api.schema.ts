import { z } from 'zod';

/**
 * Вебхук Green-API (https://green-api.com/en/docs/api/receiving/notifications-format/).
 * Описаны только используемые поля; остальные отбрасываются.
 */
const text = z.string().nullish();
/** Id сообщений и чатов Green-API короткие; длинная строка — не от Green-API. */
const MAX_ID_LENGTH = 128;
const fileData = z
  .object({ caption: text, fileName: text, downloadUrl: text, mimeType: text })
  .nullish();

export const greenApiMessageDataSchema = z.object({
  typeMessage: z.string(),
  textMessageData: z.object({ textMessage: text }).nullish(),
  extendedTextMessageData: z.object({ text }).nullish(),
  // Документация описывает подписи файлов то в fileMessageData, то в <тип>MessageData — читаем оба.
  fileMessageData: fileData,
  imageMessageData: fileData,
  videoMessageData: fileData,
  documentMessageData: fileData,
});

export const greenApiWebhookSchema = z.object({
  typeWebhook: z.string(),
  instanceData: z
    .object({ idInstance: z.union([z.number(), z.string()]), wid: text })
    .nullish(),
  timestamp: z.number().int().positive(),
  idMessage: z.string().max(MAX_ID_LENGTH).nullish(),
  stateInstance: z.string().nullish(),
  /** Звонок (incomingCall): кто звонит и чем закончилось — offer, pickUp, hungUp, declined. */
  from: z.string().max(MAX_ID_LENGTH).nullish(),
  status: z.string().max(MAX_ID_LENGTH).nullish(),
  senderData: z
    .object({
      chatId: z.string(),
      sender: text,
      chatName: text,
      senderName: text,
      senderContactName: text,
    })
    .nullish(),
  messageData: greenApiMessageDataSchema.nullish(),
});

export type GreenApiWebhook = z.infer<typeof greenApiWebhookSchema>;
export type GreenApiMessageData = z.infer<typeof greenApiMessageDataSchema>;
