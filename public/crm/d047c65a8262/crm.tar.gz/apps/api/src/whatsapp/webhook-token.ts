import { timingSafeEqual } from 'node:crypto';

/** Токен вебхука Green-API (webhookUrlToken) из заголовка Authorization; сравнение за постоянное время. */
export function webhookTokenMatches(
  expected: string,
  header: string | undefined,
): boolean {
  const received = header?.replace(/^(Bearer|Basic)\s+/i, '') ?? '';
  const a = Buffer.from(expected);
  const b = Buffer.from(received);
  return a.length === b.length && timingSafeEqual(a, b);
}
