import { Module } from '@nestjs/common';
import { InboxModule } from '../inbox/inbox.module.js';
import { GreenApiClient } from './green-api.client.js';
import { WhatsAppWebhookController } from './whatsapp-webhook.controller.js';
import { WhatsAppService } from './whatsapp.service.js';

@Module({
  imports: [InboxModule],
  controllers: [WhatsAppWebhookController],
  providers: [GreenApiClient, WhatsAppService],
  exports: [WhatsAppService],
})
export class WhatsAppModule {}
