import { greenApiWebhookSchema } from './green-api.schema.js';
import { toIncomingWhatsApp, whatsappChatId, whatsappMediaOf } from './whatsapp-mapper.js';

/** Пример из документации Green-API (incomingMessageReceived, textMessage). */
const incoming = {
  typeWebhook: 'incomingMessageReceived',
  instanceData: { idInstance: 7103000000, wid: '79876543210@c.us', typeInstance: 'whatsapp' },
  timestamp: 1588091580,
  idMessage: 'F7AEC1B7086ECDC7E6E45923F5EDB825',
  senderData: {
    chatId: '79001234567@c.us',
    sender: '79001234567@c.us',
    chatName: 'John',
    senderName: 'John',
    senderContactName: 'John Doe',
  },
  messageData: { typeMessage: 'textMessage', textMessageData: { textMessage: 'I use Green-API to send this message to you!' } },
};

const parse = (body: unknown) => greenApiWebhookSchema.parse(body);

describe('toIncomingWhatsApp', () => {
  it('maps the documented incoming text message', () => {
    expect(toIncomingWhatsApp('channel-1', parse(incoming))).toEqual({
      channelId: 'channel-1',
      externalChatId: '79001234567',
      externalMessageId: 'F7AEC1B7086ECDC7E6E45923F5EDB825',
      direction: 'IN',
      text: 'I use Green-API to send this message to you!',
      attachment: null,
      sentAt: new Date(1588091580 * 1000),
      peer: { externalId: '79001234567', firstName: 'John Doe', phone: '79001234567' },
    });
  });

  it('marks messages sent from the phone as outgoing and takes the client name from the chat', () => {
    const fromPhone = parse({
      ...incoming,
      typeWebhook: 'outgoingMessageReceived',
      senderData: { chatId: '998901112233@c.us', sender: '79876543210@c.us', chatName: 'Азиз', senderName: 'High Life' },
    });

    expect(toIncomingWhatsApp('c', fromPhone)).toMatchObject({ direction: 'OUT', peer: { externalId: '998901112233', firstName: 'Азиз' } });
  });

  it('treats messages sent through the API (our own replies) as outgoing', () => {
    expect(toIncomingWhatsApp('c', parse({ ...incoming, typeWebhook: 'outgoingAPIMessageReceived' }))?.direction).toBe('OUT');
  });

  it.each([
    [{ typeMessage: 'extendedTextMessage', extendedTextMessageData: { text: 'Ссылка: https://high-life-apartments.uz' } }, 'Ссылка: https://high-life-apartments.uz', null],
    [{ typeMessage: 'imageMessage', fileMessageData: { caption: 'Вид из окна' } }, 'Вид из окна', { kind: 'photo' }],
    [{ typeMessage: 'imageMessage', imageMessageData: { caption: 'Фасад' } }, 'Фасад', { kind: 'photo' }],
    [{ typeMessage: 'documentMessage', fileMessageData: { fileName: 'паспорт.pdf' } }, null, { kind: 'document', fileName: 'паспорт.pdf' }],
    [{ typeMessage: 'audioMessage' }, null, { kind: 'voice' }],
    [{ typeMessage: 'locationMessage' }, null, { kind: 'location' }],
    [{ typeMessage: 'stickerMessage' }, null, { kind: 'sticker' }],
    [{ typeMessage: 'pollMessage' }, null, { kind: 'other' }],
  ])('maps %o', (messageData, text, attachment) => {
    expect(toIncomingWhatsApp('c', parse({ ...incoming, messageData }))).toMatchObject({ text, attachment });
  });

  it.each([
    ['group chats', { senderData: { ...incoming.senderData, chatId: '79001234567-1581234048@g.us' } }],
    ['status updates', { senderData: { ...incoming.senderData, chatId: 'status@broadcast' } }],
    ['reactions', { messageData: { typeMessage: 'reactionMessage' } }],
    ['other webhook types', { typeWebhook: 'outgoingMessageStatus' }],
  ])('ignores %s', (_label, overrides) => {
    expect(toIncomingWhatsApp('c', parse({ ...incoming, ...overrides }))).toBeNull();
  });
});

describe('whatsappChatId', () => {
  it('turns stored digits back into a personal chat id', () => {
    expect(whatsappChatId('998901112233')).toBe('998901112233@c.us');
  });
});

describe('whatsappMediaOf', () => {
  const withFile = (typeMessage: string, fileMessageData: Record<string, unknown>) =>
    greenApiWebhookSchema.parse({ ...incoming, messageData: { typeMessage, fileMessageData } });

  it('returns the download link of a photo or document', () => {
    expect(
      whatsappMediaOf(withFile('documentMessage', { downloadUrl: 'https://cdn.example/f.pdf', mimeType: 'application/pdf', fileName: 'Счёт.pdf' })),
    ).toEqual({ downloadUrl: 'https://cdn.example/f.pdf', mimeType: 'application/pdf', fileName: 'Счёт.pdf' });
  });

  it('ignores stickers, text and attachments without a link', () => {
    expect(whatsappMediaOf(withFile('stickerMessage', { downloadUrl: 'https://cdn.example/s.webp' }))).toBeNull();
    expect(whatsappMediaOf(withFile('imageMessage', { downloadUrl: '' }))).toBeNull();
    expect(whatsappMediaOf(greenApiWebhookSchema.parse(incoming))).toBeNull();
  });
});

describe('toIncomingWhatsApp for calls', () => {
  /** Пример из документации Green-API (incomingCall). */
  const call = (status: string, from = '79001234500@c.us') =>
    parse({
      from,
      typeWebhook: 'incomingCall',
      instanceData: { idInstance: 7103000000, wid: '79876543210@c.us', typeInstance: 'whatsapp' },
      status,
      timestamp: 1617691757,
      idMessage: '104179EDB7F5328988D8834107EEBE50',
    });

  it('maps the final call status to an incoming call note', () => {
    expect(toIncomingWhatsApp('channel-1', call('declined'))).toEqual({
      channelId: 'channel-1',
      externalChatId: '79001234500',
      externalMessageId: '104179EDB7F5328988D8834107EEBE50',
      direction: 'IN',
      text: null,
      attachment: { kind: 'call', call: { outcome: 'missed' } },
      sentAt: new Date(1617691757 * 1000),
      peer: { externalId: '79001234500', phone: '79001234500' },
    });
  });

  it.each([
    ['pickUp', 'answered'],
    ['hungUp', 'declined'],
    ['missed', 'missed'],
  ])('maps %s to %s', (status, outcome) => {
    expect(toIncomingWhatsApp('c', call(status))?.attachment).toEqual({ kind: 'call', call: { outcome } });
  });

  it('waits for the final status instead of the ringing notification', () => {
    expect(toIncomingWhatsApp('c', call('offer'))).toBeNull();
  });

  it('ignores group calls', () => {
    expect(toIncomingWhatsApp('c', call('declined', '120363043968066561@g.us'))).toBeNull();
  });

  it('rejects statuses and callers that do not come from Green-API', () => {
    expect(toIncomingWhatsApp('c', call('constructor'))).toBeNull();
    expect(toIncomingWhatsApp('c', call('__proto__'))).toBeNull();
    expect(toIncomingWhatsApp('c', call('declined', 'abc@c.us'))).toBeNull();
    expect(toIncomingWhatsApp('c', call('declined', '998932062891abc@c.us'))).toBeNull();
  });
});
