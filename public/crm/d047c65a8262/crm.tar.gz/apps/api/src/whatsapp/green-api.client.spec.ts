import { isPrivateAddress, isPublicHttpsUrl } from './green-api.client.js';

describe('isPublicHttpsUrl', () => {
  it('accepts https links to a domain', () => {
    expect(isPublicHttpsUrl('https://sw-media-out.storage.greenapi.net/file.jpg')).toBe(true);
  });

  it('rejects plain http, IP addresses, localhost and credentials', () => {
    expect(isPublicHttpsUrl('http://storage.greenapi.net/file.jpg')).toBe(false);
    expect(isPublicHttpsUrl('https://169.254.169.254/latest/meta-data')).toBe(false);
    expect(isPublicHttpsUrl('https://127.0.0.1/file')).toBe(false);
    expect(isPublicHttpsUrl('https://[::1]/file')).toBe(false);
    expect(isPublicHttpsUrl('https://localhost/file')).toBe(false);
    expect(isPublicHttpsUrl('https://db.internal/file')).toBe(false);
    expect(isPublicHttpsUrl('https://user:pass@example.com/file')).toBe(false);
    expect(isPublicHttpsUrl('not a url')).toBe(false);
  });
});

describe('isPublicHttpsUrl edge cases', () => {
  it('rejects a trailing-dot localhost and explicit ports', () => {
    expect(isPublicHttpsUrl('https://localhost./file')).toBe(false);
    expect(isPublicHttpsUrl('https://metadata.google.internal./file')).toBe(false);
    expect(isPublicHttpsUrl('https://storage.greenapi.net:8443/file')).toBe(false);
  });
});

describe('isPrivateAddress', () => {
  it('flags loopback, private, link-local and mapped addresses', () => {
    for (const address of ['127.0.0.1', '10.1.2.3', '172.20.0.5', '192.168.1.1', '169.254.169.254', '100.64.0.1', '::1', 'fd00::1', 'fe80::1', '::ffff:127.0.0.1']) {
      expect(isPrivateAddress(address)).toBe(true);
    }
  });

  it('allows public addresses', () => {
    expect(isPrivateAddress('8.8.8.8')).toBe(false);
    expect(isPrivateAddress('2a00:1450:4001::200e')).toBe(false);
  });
});
