import { Inject, Injectable } from '@nestjs/common';
import { lookup } from 'node:dns/promises';
import { BlockList, isIP } from 'node:net';
import { ENV, type Env } from '../config/env.js';

/** Запрос к Green-API не должен держать отправку дольше этого. */
const REQUEST_TIMEOUT_MS = 15_000;
/** Загрузка и скачивание файлов до 20 МБ — дольше. */
const FILE_TIMEOUT_MS = 90_000;

export class GreenApiError extends Error {
  constructor(
    message: string,
    readonly status: number | null,
  ) {
    super(message);
    this.name = 'GreenApiError';
  }
}

/**
 * Состояние инстанса Green-API: authorized (номер подключён по QR), notAuthorized, blocked,
 * starting, yellowCard. Строка, а не перечисление: Green-API может добавить новые значения.
 */
export type GreenApiState = string;

/** Тонкий клиент Green-API. Вынесен отдельно, чтобы в тестах подменять фейком. */
@Injectable()
export class GreenApiClient {
  constructor(@Inject(ENV) private readonly env: Env) {}

  get isConfigured(): boolean {
    return Boolean(this.env.GREEN_API_ID_INSTANCE && this.env.GREEN_API_TOKEN);
  }

  /** Номер инстанса — он же стабильный ключ канала WhatsApp в CRM. */
  get instanceId(): string {
    return this.env.GREEN_API_ID_INSTANCE ?? '';
  }

  async sendMessage(
    chatId: string,
    message: string,
  ): Promise<{ idMessage: string }> {
    const result = await this.call<{ idMessage?: unknown }>(
      'POST',
      'sendMessage',
      { chatId, message },
    );
    if (typeof result.idMessage !== 'string' || !result.idMessage) {
      throw new GreenApiError(
        'Green-API не вернул id отправленного сообщения',
        null,
      );
    }
    return { idMessage: result.idMessage };
  }

  /** Отправка файла (multipart). Адрес — mediaUrl инстанса. */
  async sendFileByUpload(
    chatId: string,
    file: { buffer: Buffer; fileName: string; mimeType: string },
    caption: string,
  ): Promise<{ idMessage: string }> {
    const form = new FormData();
    form.append('chatId', chatId);
    form.append('fileName', file.fileName);
    if (caption) form.append('caption', caption);
    form.append(
      'file',
      new Blob([new Uint8Array(file.buffer)], { type: file.mimeType }),
      file.fileName,
    );
    const result = await this.request<{ idMessage?: unknown }>(
      this.actionUrl(
        this.env.GREEN_API_MEDIA_URL ?? this.env.GREEN_API_URL,
        'sendFileByUpload',
      ),
      { method: 'POST', body: form },
      FILE_TIMEOUT_MS,
    );
    if (typeof result.idMessage !== 'string' || !result.idMessage) {
      throw new GreenApiError(
        'Green-API не вернул id отправленного файла',
        null,
      );
    }
    return { idMessage: result.idMessage };
  }

  /**
   * Скачивание файла входящего сообщения по ссылке из вебхука. Только https и не внутренние адреса:
   * ссылка приходит извне, и сервер не должен ходить по ней в локальную сеть. null — файл больше maxBytes.
   */
  async downloadFile(
    url: string,
    maxBytes: number,
  ): Promise<{ buffer: Buffer; mimeType: string | null } | null> {
    const response = await fetchPublic(url);
    if (!response.ok || !response.body) {
      throw new GreenApiError(
        `Файл недоступен: ответ ${response.status}`,
        response.status,
      );
    }
    if (Number(response.headers.get('content-length') ?? 0) > maxBytes) {
      await response.body.cancel();
      return null;
    }
    const buffer = await readLimited(response.body, maxBytes);
    return buffer
      ? { buffer, mimeType: response.headers.get('content-type') }
      : null;
  }

  /**
   * Свежая ссылка на файл сообщения по его id: ссылка из вебхука могла не сработать или устареть.
   * Файлы хранятся, пока их держит WhatsApp; удалённый — ошибка 500 от Green-API.
   */
  async getDownloadUrl(chatId: string, idMessage: string): Promise<string> {
    const result = await this.call<{ downloadUrl?: unknown }>(
      'POST',
      'downloadFile',
      { chatId, idMessage },
    );
    if (typeof result.downloadUrl !== 'string' || !result.downloadUrl) {
      throw new GreenApiError('Green-API не вернул ссылку на файл', null);
    }
    return result.downloadUrl;
  }

  /** Есть ли WhatsApp на номере (цифры с кодом страны). */
  async checkWhatsapp(digits: string): Promise<{ existsWhatsapp?: boolean }> {
    return this.call('POST', 'checkWhatsapp', { phoneNumber: Number(digits) });
  }

  /** Ссылка на фото профиля; пустая — фото нет или скрыто («Мои контакты»). */
  async getAvatar(
    chatId: string,
  ): Promise<{ urlAvatar?: string | null; available?: boolean }> {
    return this.call('POST', 'getAvatar', { chatId });
  }

  async getState(): Promise<GreenApiState> {
    const result = await this.call<{ stateInstance: GreenApiState }>(
      'GET',
      'getStateInstance',
    );
    return result.stateInstance;
  }

  private async call<T>(
    method: 'GET' | 'POST',
    action: string,
    body?: unknown,
  ): Promise<T> {
    const url = this.actionUrl(this.env.GREEN_API_URL, action);
    const init: RequestInit =
      method === 'GET'
        ? { method: 'GET' }
        : {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify(body ?? {}),
          };
    return this.request<T>(url, init, REQUEST_TIMEOUT_MS);
  }

  private actionUrl(base: string, action: string): string {
    const { GREEN_API_ID_INSTANCE: id, GREEN_API_TOKEN: token } = this.env;
    if (!id || !token) {
      throw new GreenApiError('WhatsApp не настроен на сервере', null);
    }
    return `${base.replace(/\/$/, '')}/waInstance${id}/${action}/${token}`;
  }

  private async request<T>(
    url: string,
    init: RequestInit,
    timeoutMs: number,
  ): Promise<T> {
    let response: Response;
    try {
      response = await fetch(url, {
        ...init,
        signal: AbortSignal.timeout(timeoutMs),
      });
    } catch (error) {
      // Адрес с токеном в текст ошибки не попадает.
      throw new GreenApiError(
        `Green-API недоступен: ${error instanceof Error ? error.name : 'ошибка сети'}`,
        null,
      );
    }
    if (!response.ok) {
      throw new GreenApiError(
        `Green-API ответил ${response.status}`,
        response.status,
      );
    }
    return (await response.json()) as T;
  }
}

const PRIVATE_HOST =
  /^(localhost|.*\.local|.*\.internal|\[.*\]|\d{1,3}(\.\d{1,3}){3})$/i;

/** https на доменное имя (не IP-адрес и не localhost) — ссылки хранилища Green-API именно такие. */
export function isPublicHttpsUrl(value: string): boolean {
  try {
    const url = new URL(value);
    // «localhost.» с точкой на конце — тот же localhost.
    const host = url.hostname.replace(/\.$/, '');
    return (
      url.protocol === 'https:' &&
      !url.port &&
      !url.username &&
      !url.password &&
      !PRIVATE_HOST.test(host)
    );
  } catch {
    return false;
  }
}

/** Внутренние, служебные и зарезервированные сети: сервер не должен ходить туда по чужой ссылке. */
const PRIVATE_NETWORKS = new BlockList();
for (const [network, prefix] of [
  ['0.0.0.0', 8],
  ['10.0.0.0', 8],
  ['100.64.0.0', 10],
  ['127.0.0.0', 8],
  ['169.254.0.0', 16],
  ['172.16.0.0', 12],
  ['192.168.0.0', 16],
  ['224.0.0.0', 3],
] as const) {
  PRIVATE_NETWORKS.addSubnet(network, prefix, 'ipv4');
}
for (const [network, prefix] of [
  ['::', 127],
  ['fc00::', 7],
  ['fe80::', 10],
  ['ff00::', 8],
] as const) {
  PRIVATE_NETWORKS.addSubnet(network, prefix, 'ipv6');
}

export function isPrivateAddress(value: string): boolean {
  // IPv4 внутри IPv6 (::ffff:10.0.0.1) проверяем как IPv4. Отдельным правилом BlockList нельзя:
  // в Node подсеть ::ffff:0:0/96 совпадает с любым IPv4-адресом.
  const address = value.replace(/^::ffff:(?=\d+\.\d+\.\d+\.\d+$)/i, '');
  const family = isIP(address);
  return (
    family === 0 ||
    PRIVATE_NETWORKS.check(address, family === 4 ? 'ipv4' : 'ipv6')
  );
}

/** Имя должно указывать только на публичные адреса (иначе это попытка попасть во внутреннюю сеть). */
async function assertPublicHost(hostname: string): Promise<void> {
  let addresses: Array<{ address: string }>;
  try {
    addresses = await lookup(hostname, { all: true });
  } catch {
    throw new GreenApiError('Файл недоступен: адрес не найден', null);
  }
  if (
    addresses.length === 0 ||
    addresses.some(({ address }) => isPrivateAddress(address))
  ) {
    throw new GreenApiError('Недопустимая ссылка на файл', null);
  }
}

const MAX_REDIRECTS = 3;

/** GET с ручными редиректами: каждый адрес перехода проверяется так же, как исходный. */
async function fetchPublic(initialUrl: string): Promise<Response> {
  const signal = AbortSignal.timeout(FILE_TIMEOUT_MS);
  let url = initialUrl;
  for (let hop = 0; hop <= MAX_REDIRECTS; hop += 1) {
    if (!isPublicHttpsUrl(url)) {
      throw new GreenApiError('Недопустимая ссылка на файл', null);
    }
    await assertPublicHost(new URL(url).hostname);
    let response: Response;
    try {
      response = await fetch(url, { redirect: 'manual', signal });
    } catch (error) {
      throw new GreenApiError(
        `Файл недоступен: ${error instanceof Error ? error.name : 'ошибка сети'}`,
        null,
      );
    }
    const location = response.headers.get('location');
    if (response.status < 300 || response.status >= 400 || !location)
      return response;
    await response.body?.cancel();
    url = new URL(location, url).toString();
  }
  throw new GreenApiError(
    'Слишком много перенаправлений при скачивании файла',
    null,
  );
}

/** Читает поток не больше maxBytes; null — файл оказался больше (поток прерывается). */
async function readLimited(
  body: ReadableStream<Uint8Array>,
  maxBytes: number,
): Promise<Buffer | null> {
  const reader = body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > maxBytes) {
      await reader.cancel();
      return null;
    }
    chunks.push(value);
  }
  return Buffer.concat(chunks);
}
