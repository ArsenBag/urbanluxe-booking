import type { CallOutcome, MessageAttachment } from '@crm/shared';
import type { IncomingMessage } from '../inbox/messenger.types.js';
import type {
  GreenApiMessageData,
  GreenApiWebhook,
} from './green-api.schema.js';

const MS_PER_SECOND = 1000;
const PERSONAL_CHAT_SUFFIX = '@c.us';

/** Типы вебхуков с сообщениями: входящее, отправленное с телефона, отправленное через API (наше эхо). */
const DIRECTIONS: Record<string, 'IN' | 'OUT'> = {
  incomingMessageReceived: 'IN',
  outgoingMessageReceived: 'OUT',
  outgoingAPIMessageReceived: 'OUT',
};

/** Служебные типы, которые не являются сообщениями переписки. */
const IGNORED_TYPES = new Set([
  'reactionMessage',
  'deletedMessage',
  'editedMessage',
]);

const INCOMING_CALL = 'incomingCall';
/**
 * Итог входящего звонка. Green-API шлёт два уведомления с одним idMessage: offer (звонит) и итог —
 * сохраняем только итог. hungUp — сбросили на телефоне или включён «Не беспокоить»;
 * declined — звонящий положил трубку или WhatsApp завершил вызов по таймауту; missed — устаревший статус.
 */
const CALL_OUTCOMES = new Map<string, CallOutcome>([
  ['pickUp', 'answered'],
  ['hungUp', 'declined'],
  ['declined', 'missed'],
  ['missed', 'missed'],
]);
/** Звонящий — личный номер: только цифры и суффикс личного чата. */
const PERSONAL_CALLER = /^(\d{5,20})@c\.us$/;

const clean = (value: string | null | undefined): string | null =>
  value?.trim() ? value : null;

function fileInfo(data: GreenApiMessageData) {
  return (
    data.fileMessageData ??
    data.imageMessageData ??
    data.videoMessageData ??
    data.documentMessageData ??
    null
  );
}

function textOf(data: GreenApiMessageData): string | null {
  return (
    clean(data.textMessageData?.textMessage) ??
    clean(data.extendedTextMessageData?.text) ??
    clean(fileInfo(data)?.caption)
  );
}

function attachmentOf(data: GreenApiMessageData): MessageAttachment | null {
  switch (data.typeMessage) {
    case 'textMessage':
    case 'extendedTextMessage':
    case 'quotedMessage':
      return null;
    case 'imageMessage':
      return { kind: 'photo' };
    case 'videoMessage':
      return { kind: 'video' };
    case 'audioMessage':
      return { kind: 'voice' };
    case 'stickerMessage':
      return { kind: 'sticker' };
    case 'locationMessage':
      return { kind: 'location' };
    case 'contactMessage':
      return { kind: 'contact' };
    case 'documentMessage': {
      const fileName = clean(fileInfo(data)?.fileName);
      return fileName ? { kind: 'document', fileName } : { kind: 'document' };
    }
    default:
      return { kind: 'other' };
  }
}

/** Типы сообщений, файл которых сохраняем в CRM. */
const DOWNLOADABLE_TYPES = new Set([
  'imageMessage',
  'videoMessage',
  'audioMessage',
  'documentMessage',
]);

export interface WhatsAppMedia {
  downloadUrl: string;
  mimeType: string | null;
  fileName: string | null;
}

/** Ссылка на файл вложения из вебхука; null — вложения нет или его не сохраняем. */
export function whatsappMediaOf(
  webhook: GreenApiWebhook,
): WhatsAppMedia | null {
  const data = webhook.messageData;
  if (!data || !DOWNLOADABLE_TYPES.has(data.typeMessage)) return null;
  const info = fileInfo(data);
  const downloadUrl = clean(info?.downloadUrl);
  if (!downloadUrl) return null;
  return {
    downloadUrl,
    mimeType: clean(info?.mimeType),
    fileName: clean(info?.fileName),
  };
}

/** Личный чат WhatsApp из цифр номера (так храним externalChatId). */
export function whatsappChatId(digits: string): string {
  return `${digits}${PERSONAL_CHAT_SUFFIX}`;
}

/** Входящий звонок с личного номера → отметка о звонке в переписке. null — звонок ещё идёт или это группа. */
function toWhatsAppCall(
  channelId: string,
  webhook: GreenApiWebhook,
): IncomingMessage | null {
  const outcome = webhook.status
    ? CALL_OUTCOMES.get(webhook.status)
    : undefined;
  const digits = webhook.from?.match(PERSONAL_CALLER)?.[1];
  if (!outcome || !digits || !webhook.idMessage) return null;
  return {
    channelId,
    externalChatId: digits,
    externalMessageId: webhook.idMessage,
    direction: 'IN',
    text: null,
    attachment: { kind: 'call', call: { outcome } },
    sentAt: new Date(webhook.timestamp * MS_PER_SECOND),
    // Имени звонящего Green-API не сообщает — новый клиент получит имя по номеру.
    peer: { externalId: digits, phone: digits },
  };
}

/**
 * Вебхук Green-API → сообщение в общем формате CRM. null — не сообщение личного чата
 * (группа, статус, реакция, служебное уведомление).
 */
export function toIncomingWhatsApp(
  channelId: string,
  webhook: GreenApiWebhook,
): IncomingMessage | null {
  if (webhook.typeWebhook === INCOMING_CALL)
    return toWhatsAppCall(channelId, webhook);
  const direction = DIRECTIONS[webhook.typeWebhook];
  const sender = webhook.senderData;
  const data = webhook.messageData;
  if (!direction || !sender || !data || !webhook.idMessage) return null;
  if (
    !sender.chatId.endsWith(PERSONAL_CHAT_SUFFIX) ||
    IGNORED_TYPES.has(data.typeMessage)
  )
    return null;

  const digits = sender.chatId.slice(0, -PERSONAL_CHAT_SUFFIX.length);
  // Во входящих имя клиента — в контактах телефона или его профиле; в исходящих senderName — это мы.
  const name =
    direction === 'IN'
      ? (clean(sender.senderContactName) ??
        clean(sender.senderName) ??
        clean(sender.chatName))
      : clean(sender.chatName);

  return {
    channelId,
    externalChatId: digits,
    externalMessageId: webhook.idMessage,
    direction,
    text: textOf(data),
    attachment: attachmentOf(data),
    sentAt: new Date(webhook.timestamp * MS_PER_SECOND),
    peer: {
      externalId: digits,
      ...(name && { firstName: name }),
      phone: digits,
    },
  };
}
