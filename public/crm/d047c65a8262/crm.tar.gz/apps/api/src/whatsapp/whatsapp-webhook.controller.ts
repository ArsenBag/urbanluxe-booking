import {
  Body,
  Controller,
  Headers,
  HttpCode,
  HttpStatus,
  Inject,
  Logger,
  NotFoundException,
  Post,
} from '@nestjs/common';
import { Public } from '../auth/decorators.js';
import { ENV, type Env } from '../config/env.js';
import { InboxIngestService } from '../inbox/inbox-ingest.service.js';
import { greenApiWebhookSchema } from './green-api.schema.js';
import { toIncomingWhatsApp, whatsappMediaOf } from './whatsapp-mapper.js';
import { webhookTokenMatches } from './webhook-token.js';
import { WhatsAppService } from './whatsapp.service.js';

/**
 * Вебхуки Green-API. Защита — токен в заголовке Authorization (webhookUrlToken в настройках инстанса).
 * Чужой запрос выглядит как несуществующий адрес (404).
 */
@Controller('webhooks/whatsapp')
export class WhatsAppWebhookController {
  private readonly logger = new Logger(WhatsAppWebhookController.name);

  constructor(
    private readonly whatsapp: WhatsAppService,
    private readonly ingest: InboxIngestService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  @Public()
  @Post()
  @HttpCode(HttpStatus.OK)
  async receive(
    @Headers('authorization') authorization: string | undefined,
    @Body() body: unknown,
  ): Promise<{ result: string }> {
    if (
      !this.whatsapp.isConfigured ||
      !this.env.GREEN_API_WEBHOOK_TOKEN ||
      !webhookTokenMatches(this.env.GREEN_API_WEBHOOK_TOKEN, authorization)
    ) {
      throw new NotFoundException();
    }
    const parsed = greenApiWebhookSchema.safeParse(body);
    if (!parsed.success) {
      this.logger.warn(
        `Вебхук Green-API не распознан: ${parsed.error.issues.map((i) => i.path.join('.')).join(', ')}`,
      );
      return { result: 'ignored' };
    }
    const webhook = parsed.data;
    if (
      webhook.typeWebhook === 'stateInstanceChanged' &&
      webhook.stateInstance
    ) {
      await this.whatsapp.applyState(
        webhook.stateInstance,
        webhook.instanceData?.wid,
      );
      return { result: 'state' };
    }
    const channel = await this.whatsapp.ensureChannel();
    const message = toIncomingWhatsApp(channel.id, webhook);
    if (!message) {
      return { result: 'ignored' };
    }
    this.whatsapp.refreshStateIfStale(channel.status);
    const media = whatsappMediaOf(webhook);
    const withDownload = media
      ? { ...message, download: () => this.whatsapp.download(media) }
      : message;
    // Ошибка сохранения пробрасывается (500): Green-API повторит доставку в течение суток.
    const result = await this.ingest.ingest(withDownload, { history: false });
    return { result: result.isNew ? 'stored' : 'duplicate' };
  }
}
