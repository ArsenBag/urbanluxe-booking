import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Patch, Post, Put } from '@nestjs/common';
import {
  createPipelineSchema,
  createStageSchema,
  reorderStagesSchema,
  updatePipelineSchema,
  updateStageSchema,
  type CreatePipelineInput,
  type CreateStageInput,
  type PipelineDto,
  type ReorderStagesInput,
  type StageDto,
  type UpdateStageInput,
} from '@crm/shared';
import { CurrentUser, Roles } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { PipelinesService } from './pipelines.service.js';

const uuid = () => new ParseUUIDPipe();

@Controller()
export class PipelinesController {
  constructor(private readonly pipelines: PipelinesService) {}

  @Get('pipelines')
  list(): Promise<PipelineDto[]> {
    return this.pipelines.list();
  }

  @Post('pipelines')
  @Roles('ADMIN')
  create(
    @Body(new ZodValidationPipe(createPipelineSchema)) input: CreatePipelineInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<PipelineDto> {
    return this.pipelines.create(input, actor);
  }

  @Patch('pipelines/:id')
  @Roles('ADMIN')
  rename(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(updatePipelineSchema)) input: CreatePipelineInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<PipelineDto> {
    return this.pipelines.rename(id, input, actor);
  }

  @Delete('pipelines/:id')
  @Roles('ADMIN')
  remove(@Param('id', uuid()) id: string, @CurrentUser() actor: SessionUser): Promise<null> {
    return this.pipelines.remove(id, actor);
  }

  @Post('pipelines/:id/stages')
  @Roles('ADMIN')
  addStage(
    @Param('id', uuid()) pipelineId: string,
    @Body(new ZodValidationPipe(createStageSchema)) input: CreateStageInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<StageDto> {
    return this.pipelines.addStage(pipelineId, input, actor);
  }

  @Put('pipelines/:id/stages/order')
  @Roles('ADMIN')
  reorderStages(
    @Param('id', uuid()) pipelineId: string,
    @Body(new ZodValidationPipe(reorderStagesSchema)) input: ReorderStagesInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<PipelineDto> {
    return this.pipelines.reorderStages(pipelineId, input, actor);
  }

  @Patch('stages/:id')
  @Roles('ADMIN')
  updateStage(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(updateStageSchema)) input: UpdateStageInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<StageDto> {
    return this.pipelines.updateStage(id, input, actor);
  }

  @Delete('stages/:id')
  @Roles('ADMIN')
  removeStage(@Param('id', uuid()) id: string, @CurrentUser() actor: SessionUser): Promise<null> {
    return this.pipelines.removeStage(id, actor);
  }
}
