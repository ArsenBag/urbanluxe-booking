import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import type {
  CreatePipelineInput,
  CreateStageInput,
  PipelineDto,
  ReorderStagesInput,
  StageDto,
  UpdateStageInput,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { isPrismaError, PrismaErrorCode } from '../common/prisma-errors.js';
import type { Pipeline, Prisma, Stage, StageKind } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';

/** Этапы новой воронки: минимальный набор, дальше админ настраивает сам. */
const DEFAULT_STAGES = [
  { name: 'Новые', color: '#3b82f6', kind: 'OPEN' },
  { name: 'Успешно', color: '#22c55e', kind: 'WON' },
  { name: 'Отказ', color: '#ef4444', kind: 'LOST' },
] as const;

const STAGES_ORDERED = { stages: { orderBy: { position: 'asc' } } } as const;

function toStageDto(stage: Stage): StageDto {
  return { id: stage.id, name: stage.name, position: stage.position, color: stage.color, kind: stage.kind };
}

function toPipelineDto(pipeline: Pipeline & { stages: Stage[] }): PipelineDto {
  return {
    id: pipeline.id,
    name: pipeline.name,
    position: pipeline.position,
    stages: pipeline.stages.map(toStageDto),
  };
}

@Injectable()
export class PipelinesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
  ) {}

  async list(): Promise<PipelineDto[]> {
    const pipelines = await this.prisma.pipeline.findMany({ include: STAGES_ORDERED, orderBy: { position: 'asc' } });
    return pipelines.map(toPipelineDto);
  }

  async create(input: CreatePipelineInput, actor: SessionUser): Promise<PipelineDto> {
    const pipeline = await this.prisma.$transaction(async (tx) => {
      const last = await tx.pipeline.findFirst({ orderBy: { position: 'desc' }, select: { position: true } });
      const created = await tx.pipeline.create({
        data: {
          name: input.name,
          position: (last?.position ?? -1) + 1,
          stages: { create: DEFAULT_STAGES.map((stage, position) => ({ ...stage, position })) },
        },
        include: STAGES_ORDERED,
      });
      await this.audit.record(
        actor,
        { action: 'pipeline.created', entityType: 'pipeline', entityId: created.id, payload: { name: created.name } },
        tx,
      );
      return created;
    });
    return toPipelineDto(pipeline);
  }

  async rename(id: string, input: CreatePipelineInput, actor: SessionUser): Promise<PipelineDto> {
    try {
      const pipeline = await this.prisma.$transaction(async (tx) => {
        const updated = await tx.pipeline.update({ where: { id }, data: { name: input.name }, include: STAGES_ORDERED });
        await this.audit.record(
          actor,
          { action: 'pipeline.renamed', entityType: 'pipeline', entityId: id, payload: { name: input.name } },
          tx,
        );
        return updated;
      });
      return toPipelineDto(pipeline);
    } catch (error) {
      throw this.mapNotFound(error, 'Воронка не найдена');
    }
  }

  async remove(id: string, actor: SessionUser): Promise<null> {
    const dealsCount = await this.prisma.deal.count({ where: { pipelineId: id } });
    if (dealsCount > 0) {
      throw new ConflictException('В воронке есть сделки. Сначала перенесите или удалите их.');
    }
    const pipelinesCount = await this.prisma.pipeline.count();
    if (pipelinesCount <= 1) {
      throw new BadRequestException('Нельзя удалить единственную воронку');
    }
    try {
      await this.prisma.$transaction(async (tx) => {
        await tx.pipeline.delete({ where: { id } });
        await this.audit.record(actor, { action: 'pipeline.deleted', entityType: 'pipeline', entityId: id }, tx);
      });
      return null;
    } catch (error) {
      // Сделка могла появиться между проверкой и удалением.
      if (isPrismaError(error, PrismaErrorCode.ForeignKeyViolation)) {
        throw new ConflictException('В воронке есть сделки. Сначала перенесите или удалите их.');
      }
      throw this.mapNotFound(error, 'Воронка не найдена');
    }
  }

  async addStage(pipelineId: string, input: CreateStageInput, actor: SessionUser): Promise<StageDto> {
    try {
      const stage = await this.prisma.$transaction(async (tx) => {
        const last = await tx.stage.findFirst({
          where: { pipelineId },
          orderBy: { position: 'desc' },
          select: { position: true },
        });
        const created = await tx.stage.create({
          data: { ...input, pipelineId, position: (last?.position ?? -1) + 1 },
        });
        await this.audit.record(
          actor,
          { action: 'stage.created', entityType: 'stage', entityId: created.id, payload: { pipelineId, name: created.name } },
          tx,
        );
        return created;
      });
      return toStageDto(stage);
    } catch (error) {
      if (isPrismaError(error, PrismaErrorCode.ForeignKeyViolation)) {
        throw new NotFoundException('Воронка не найдена');
      }
      throw error;
    }
  }

  async updateStage(id: string, input: UpdateStageInput, actor: SessionUser): Promise<StageDto> {
    try {
      const stage = await this.prisma.$transaction(async (tx) => {
        if (input.kind !== undefined) {
          await this.assertKindChangeAllowed(tx, id, input.kind);
        }
        const updated = await tx.stage.update({ where: { id }, data: input });
        await this.audit.record(actor, { action: 'stage.updated', entityType: 'stage', entityId: id, payload: input }, tx);
        return updated;
      });
      return toStageDto(stage);
    } catch (error) {
      throw this.mapNotFound(error, 'Этап не найден');
    }
  }

  async removeStage(id: string, actor: SessionUser): Promise<null> {
    const stage = await this.prisma.stage.findUnique({
      where: { id },
      include: { _count: { select: { deals: true } } },
    });
    if (!stage) {
      throw new NotFoundException('Этап не найден');
    }
    if (stage._count.deals > 0) {
      throw new ConflictException('На этапе есть сделки. Сначала перенесите их на другой этап.');
    }
    const siblings = await this.prisma.stage.count({ where: { pipelineId: stage.pipelineId } });
    if (siblings <= 1) {
      throw new BadRequestException('В воронке должен остаться хотя бы один этап');
    }
    try {
      await this.prisma.$transaction(async (tx) => {
        await tx.stage.delete({ where: { id } });
        await this.audit.record(
          actor,
          { action: 'stage.deleted', entityType: 'stage', entityId: id, payload: { name: stage.name } },
          tx,
        );
      });
    } catch (error) {
      if (isPrismaError(error, PrismaErrorCode.ForeignKeyViolation)) {
        throw new ConflictException('На этапе есть сделки. Сначала перенесите их на другой этап.');
      }
      throw error;
    }
    return null;
  }

  /**
   * Тип этапа определяет, закрыты ли его сделки. Менять тип у этапа со сделками нельзя,
   * иначе их статус закрытия разойдётся с этапом.
   */
  private async assertKindChangeAllowed(tx: Prisma.TransactionClient, id: string, kind: StageKind): Promise<void> {
    const stage = await tx.stage.findUnique({
      where: { id },
      select: { kind: true, _count: { select: { deals: true } } },
    });
    if (stage && stage.kind !== kind && stage._count.deals > 0) {
      throw new ConflictException('Нельзя менять тип этапа, на котором есть сделки. Сначала перенесите их.');
    }
  }

  /** Новый порядок этапов: список должен содержать ровно все этапы воронки. */
  async reorderStages(pipelineId: string, input: ReorderStagesInput, actor: SessionUser): Promise<PipelineDto> {
    const pipeline = await this.prisma.$transaction(async (tx) => {
      const stages = await tx.stage.findMany({ where: { pipelineId }, select: { id: true } });
      const current = new Set(stages.map((stage) => stage.id));
      const requested = new Set(input.stageIds);
      const sameSet =
        current.size === requested.size &&
        requested.size === input.stageIds.length &&
        input.stageIds.every((id) => current.has(id));
      if (!sameSet) {
        throw new BadRequestException('Список этапов не совпадает с этапами воронки. Обновите страницу.');
      }
      await Promise.all(
        input.stageIds.map((id, position) => tx.stage.update({ where: { id }, data: { position } })),
      );
      await this.audit.record(
        actor,
        { action: 'stage.reordered', entityType: 'pipeline', entityId: pipelineId, payload: { stageIds: input.stageIds } },
        tx,
      );
      return tx.pipeline.findUniqueOrThrow({ where: { id: pipelineId }, include: STAGES_ORDERED });
    });
    return toPipelineDto(pipeline);
  }

  private mapNotFound(error: unknown, message: string): unknown {
    return isPrismaError(error, PrismaErrorCode.RecordNotFound) ? new NotFoundException(message) : error;
  }
}
