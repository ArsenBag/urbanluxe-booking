import {
  buildBookingsReport,
  nightsInPeriod,
  revenueInPeriod,
  type Stay,
} from './occupancy.js';

const stay = (overrides: Partial<Stay>): Stay => ({
  propertyId: 'a1',
  checkIn: '2026-10-01',
  checkOut: '2026-10-04',
  amount: 300,
  origin: null,
  ...overrides,
});

describe('nightsInPeriod', () => {
  it('counts nights of the stay that fall inside the period', () => {
    expect(nightsInPeriod(stay({}), '2026-10-01', '2026-10-31')).toBe(3);
    // Ночь на 4-е уже не входит: 4-го выезд.
    expect(nightsInPeriod(stay({}), '2026-10-03', '2026-10-31')).toBe(1);
    expect(nightsInPeriod(stay({}), '2026-10-04', '2026-10-31')).toBe(0);
    expect(
      nightsInPeriod(
        stay({ checkIn: '2026-09-29' }),
        '2026-10-01',
        '2026-10-02',
      ),
    ).toBe(2);
    expect(nightsInPeriod(stay({}), '2026-09-01', '2026-09-30')).toBe(0);
  });
});

describe('revenueInPeriod', () => {
  it('never attributes more than the booking amount to a period', () => {
    const longStay = stay({
      checkIn: '2026-09-25',
      checkOut: '2026-10-05',
      amount: 1000,
    });
    expect(
      revenueInPeriod(longStay, '2026-09-01', '2026-09-30') +
        revenueInPeriod(longStay, '2026-10-01', '2026-10-31'),
    ).toBe(1000);
  });

  it('splits the amount evenly across nights', () => {
    expect(revenueInPeriod(stay({}), '2026-10-03', '2026-10-31')).toBe(100);
    expect(
      revenueInPeriod(stay({ amount: null }), '2026-10-01', '2026-10-31'),
    ).toBe(0);
    expect(
      revenueInPeriod(
        stay({ checkOut: '2026-10-01' }),
        '2026-10-01',
        '2026-10-31',
      ),
    ).toBe(0);
  });
});

describe('buildBookingsReport', () => {
  const properties = [
    { id: 'a1', title: 'U-51', complex: 'U-Tower', isApartment: true },
    { id: 'a2', title: 'U-52', complex: 'U-Tower', isApartment: true },
    { id: 'm1', title: 'M-10', complex: 'Modera Towers', isApartment: true },
    // Строка ЖК из выгрузки Excel: ночи идут в итог и в ЖК, но это не квартира.
    { id: 'x1', title: 'U-Tower', complex: 'U-Tower', isApartment: false },
  ];

  const report = buildBookingsReport({
    from: '2026-10-01',
    to: '2026-10-10',
    currency: 'USD',
    properties,
    stays: [
      stay({ propertyId: 'a1', origin: 'Booking.com' }),
      stay({
        propertyId: 'a2',
        checkIn: '2026-10-09',
        checkOut: '2026-10-12',
        amount: 600,
        origin: ' booking.com ',
      }),
      stay({
        propertyId: 'x1',
        checkIn: '2026-10-05',
        checkOut: '2026-10-06',
        amount: null,
        origin: '',
      }),
    ],
    arrivals: 3,
    cancellations: 1,
  });

  it('sums nights, revenue and occupancy over RealtyCalendar apartments', () => {
    expect(report.apartments).toBe(3);
    expect(report.days).toBe(10);
    expect(report.totals).toEqual({
      nights: 3 + 2 + 1,
      occupancy: 6 / 30,
      revenue: 300 + 400,
      arrivals: 3,
      averageNightPrice: 140,
      cancellations: 1,
    });
  });

  it('counts occupied apartments for each night', () => {
    expect(report.byDay).toHaveLength(10);
    expect(report.byDay[0]).toEqual({ date: '2026-10-01', occupied: 1 });
    expect(report.byDay[3]).toEqual({ date: '2026-10-04', occupied: 0 });
    expect(report.byDay[4]).toEqual({ date: '2026-10-05', occupied: 1 });
    expect(report.byDay[9]).toEqual({ date: '2026-10-10', occupied: 1 });
  });

  it('groups by complex, keeping complexes without bookings', () => {
    expect(report.byComplex).toEqual([
      {
        title: 'U-Tower',
        apartments: 2,
        nights: 6,
        occupancy: 6 / 20,
        revenue: 700,
      },
      {
        title: 'Modera Towers',
        apartments: 1,
        nights: 0,
        occupancy: 0,
        revenue: 0,
      },
    ]);
  });

  it('lists every apartment, busiest first, without Excel complex rows', () => {
    expect(report.byApartment.map((row) => [row.title, row.nights])).toEqual([
      ['U-51', 3],
      ['U-52', 2],
      ['M-10', 0],
    ]);
    expect(report.byApartment[0]).toMatchObject({
      id: 'a1',
      complex: 'U-Tower',
      occupancy: 0.3,
      revenue: 300,
    });
  });

  it('groups by booking origin regardless of case, treating blanks as direct', () => {
    expect(report.byOrigin).toEqual([
      { origin: 'Booking.com', bookings: 2, nights: 5, revenue: 700 },
      { origin: null, bookings: 1, nights: 1, revenue: 0 },
    ]);
  });

  it('has no occupancy or average price without apartments and amounts', () => {
    const empty = buildBookingsReport({
      from: '2026-10-01',
      to: '2026-10-01',
      currency: 'USD',
      properties: [],
      stays: [stay({ propertyId: null, amount: null })],
      arrivals: 0,
      cancellations: 0,
    });
    expect(empty.totals.occupancy).toBeNull();
    expect(empty.totals.averageNightPrice).toBeNull();
    expect(empty.byComplex).toEqual([
      {
        title: 'Квартира не указана',
        apartments: 0,
        nights: 1,
        occupancy: null,
        revenue: 0,
      },
    ]);
  });
});
