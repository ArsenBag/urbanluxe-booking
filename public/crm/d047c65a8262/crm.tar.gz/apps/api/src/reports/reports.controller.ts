import { Controller, Get, Query } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import {
  funnelReportQuerySchema,
  reportPeriodSchema,
  type BookingsReportDto,
  type FunnelReportDto,
  type FunnelReportQuery,
  type InquiriesReportDto,
  type ReportPeriod,
  type TeamReportDto,
} from '@crm/shared';
import { Roles } from '../auth/decorators.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { BookingsReportService } from './bookings-report.service.js';
import { FunnelReportService } from './funnel-report.service.js';
import { InquiriesReportService } from './inquiries-report.service.js';
import { TeamReportService } from './team-report.service.js';

/** Одна страница — четыре запроса; лимит хватает примерно на 30 смен периода в минуту. */
const REPORT_REQUESTS_PER_MINUTE = 120;
const ONE_MINUTE_MS = 60_000;

/** Отчёты владельца: выручка и работа сотрудников — только администратору. */
@Controller('reports')
@Roles('ADMIN')
@Throttle({
  default: { limit: REPORT_REQUESTS_PER_MINUTE, ttl: ONE_MINUTE_MS },
})
export class ReportsController {
  constructor(
    private readonly inquiries: InquiriesReportService,
    private readonly funnel: FunnelReportService,
    private readonly bookings: BookingsReportService,
    private readonly team: TeamReportService,
  ) {}

  @Get('inquiries')
  inquiriesReport(
    @Query(new ZodValidationPipe(reportPeriodSchema)) period: ReportPeriod,
  ): Promise<InquiriesReportDto> {
    return this.inquiries.report(period);
  }

  @Get('funnel')
  funnelReport(
    @Query(new ZodValidationPipe(funnelReportQuerySchema))
    query: FunnelReportQuery,
  ): Promise<FunnelReportDto> {
    return this.funnel.report(query);
  }

  @Get('bookings')
  bookingsReport(
    @Query(new ZodValidationPipe(reportPeriodSchema)) period: ReportPeriod,
  ): Promise<BookingsReportDto> {
    return this.bookings.report(period);
  }

  @Get('team')
  teamReport(
    @Query(new ZodValidationPipe(reportPeriodSchema)) period: ReportPeriod,
  ): Promise<TeamReportDto> {
    return this.team.report(period);
  }
}
