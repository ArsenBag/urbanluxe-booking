import { Injectable } from '@nestjs/common';
import type {
  ReportPeriod,
  ResponseStats,
  TeamMemberRow,
  TeamReportDto,
} from '@crm/shared';
import { PrismaService } from '../prisma/prisma.service.js';
import {
  periodBounds,
  sqlUtc,
  SQL_IS_CALL,
  type PeriodBounds,
} from './report-period.js';

interface ResponseRow {
  senderId: string | null;
  /** Строка итога по всем ответам (GROUPING SETS ()). */
  isTotal: boolean;
  answered: number;
  medianMinutes: number | null;
  within15Minutes: number;
  withinHour: number;
  /** Одинаково во всех строках: ожидания без ответа не принадлежат никому из сотрудников. */
  unanswered: number;
}

interface SentRow {
  senderId: string | null;
  count: number;
}

type AssigneeCount = { assigneeId: string | null; _count: { _all: number } };

const DAY_MS = 86_400_000;
/** Ожидание, начавшееся незадолго до периода, ищем среди сообщений за этот срок до его начала. */
const LOOKBACK_MS = 30 * DAY_MS;
/** Ответ позже этого срока после конца периода не ищем: такое ожидание считается оставшимся без ответа. */
const LOOKAHEAD_MS = 30 * DAY_MS;
const NO_RESPONSES: ResponseStats = {
  answered: 0,
  medianMinutes: null,
  within15Minutes: 0,
  withinHour: 0,
};

function toStats(row: ResponseRow | undefined): ResponseStats {
  if (!row) return NO_RESPONSES;
  return {
    answered: row.answered,
    medianMinutes:
      row.medianMinutes === null ? null : Math.round(row.medianMinutes),
    within15Minutes: row.within15Minutes,
    withinHour: row.withinHour,
  };
}

const countFor = (groups: AssigneeCount[], userId: string) =>
  groups.find((group) => group.assigneeId === userId)?._count._all ?? 0;

/** Команда: скорость первого ответа, сообщения и задачи сотрудников за период. */
@Injectable()
export class TeamReportService {
  constructor(private readonly prisma: PrismaService) {}

  async report(period: ReportPeriod): Promise<TeamReportDto> {
    const bounds = periodBounds(period);
    // Тяжёлые запросы по сообщениям — по очереди: пул соединений общий с приёмом сообщений и вебхуков.
    const responses = await this.responseStats(bounds);
    const sent = await this.sentBySender(bounds);
    const responseOf = (senderId: string | null) =>
      toStats(
        responses.find((row) => !row.isTotal && row.senderId === senderId),
      );
    const sentBy = (senderId: string | null) =>
      sent.find((row) => row.senderId === senderId)?.count ?? 0;
    const total = responses.find((row) => row.isTotal);

    return {
      overall: toStats(total),
      unanswered: total?.unanswered ?? 0,
      members: await this.members(bounds, responseOf, sentBy),
      phone: { messagesSent: sentBy(null), response: responseOf(null) },
    };
  }

  private async members(
    { start, end }: PeriodBounds,
    responseOf: (senderId: string) => ResponseStats,
    sentBy: (senderId: string) => number,
  ): Promise<TeamMemberRow[]> {
    const [users, done, overdue] = await Promise.all([
      this.prisma.user.findMany({
        select: { id: true, name: true, isActive: true },
        orderBy: { name: 'asc' },
      }),
      this.prisma.task.groupBy({
        by: ['assigneeId'],
        where: { isDone: true, doneAt: { gte: start, lt: end } },
        _count: { _all: true },
      }),
      this.prisma.task.groupBy({
        by: ['assigneeId'],
        where: { isDone: false, dueAt: { lt: new Date() } },
        _count: { _all: true },
      }),
    ]);
    return (
      users
        .map((user) => ({
          user: { id: user.id, name: user.name },
          isActive: user.isActive,
          messagesSent: sentBy(user.id),
          response: responseOf(user.id),
          tasksDone: countFor(done, user.id),
          tasksOverdue: countFor(overdue, user.id),
        }))
        // Отключённые сотрудники видны, только если работали в этом периоде.
        .filter(
          (row) =>
            row.isActive ||
            row.messagesSent > 0 ||
            row.response.answered > 0 ||
            row.tasksDone > 0,
        )
        .sort(
          (a, b) =>
            b.messagesSent - a.messagesSent ||
            a.user.name.localeCompare(b.user.name, 'ru'),
        )
    );
  }

  /**
   * Время первого ответа. Ожидание начинается с сообщения гостя после нашего ответа (или с первого в диалоге)
   * и закрывается ближайшим нашим сообщением. Звонки и автосообщения не считаются ни вопросом, ни ответом.
   * Ближайший ответ находим без перебора: out_seq — сколько наших сообщений было в диалоге до этой строки.
   * Без ответа — ожидания старше 15 минут, на которые никто не ответил.
   */
  private responseStats({ start, end }: PeriodBounds): Promise<ResponseRow[]> {
    return this.prisma.$queryRaw<ResponseRow[]>`
      WITH stream AS (
        SELECT m."conversationId" AS conversation_id,
               m.direction,
               m."sentAt" AS sent_at,
               m."senderId" AS sender_id,
               lag(m.direction) OVER w AS prev_direction,
               count(*) FILTER (WHERE m.direction = 'OUT') OVER w AS out_seq
        FROM messages m
        LEFT JOIN automation_runs ar ON ar."messageId" = m.id
        WHERE ar.id IS NULL
          AND m.status IN ('RECEIVED', 'SENT')
          AND NOT ${SQL_IS_CALL}
          AND m."sentAt" >= ${sqlUtc(new Date(start.getTime() - LOOKBACK_MS))}
          AND m."sentAt" < ${sqlUtc(new Date(end.getTime() + LOOKAHEAD_MS))}
        WINDOW w AS (
          PARTITION BY m."conversationId"
          ORDER BY m."sentAt", m."createdAt", m.id
          ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        )
      ),
      waits AS (
        SELECT wait.sent_at AS asked_at, reply.sent_at AS replied_at, reply.sender_id
        FROM stream wait
        LEFT JOIN stream reply
          ON reply.conversation_id = wait.conversation_id
         AND reply.direction = 'OUT'
         AND reply.out_seq = wait.out_seq + 1
        WHERE wait.direction = 'IN'
          AND (wait.prev_direction IS NULL OR wait.prev_direction = 'OUT')
          AND wait.sent_at >= ${sqlUtc(start)}
          AND wait.sent_at < ${sqlUtc(end)}
      ),
      replies AS (
        SELECT extract(epoch FROM replied_at - asked_at)::float8 / 60 AS minutes, sender_id
        FROM waits
        WHERE replied_at IS NOT NULL
      )
      SELECT sender_id AS "senderId",
             GROUPING(sender_id) = 1 AS "isTotal",
             count(*)::int AS answered,
             percentile_cont(0.5) WITHIN GROUP (ORDER BY minutes) AS "medianMinutes",
             count(*) FILTER (WHERE minutes <= 15)::int AS "within15Minutes",
             count(*) FILTER (WHERE minutes <= 60)::int AS "withinHour",
             (
               SELECT count(*)::int FROM waits
               WHERE replied_at IS NULL AND asked_at < (now() AT TIME ZONE 'UTC') - interval '15 minutes'
             ) AS unanswered
      FROM replies
      GROUP BY GROUPING SETS ((sender_id), ())`;
  }

  /** Наши сообщения за период по отправителю; senderId null — отправлено с телефона мимо CRM. */
  private sentBySender({ start, end }: PeriodBounds): Promise<SentRow[]> {
    return this.prisma.$queryRaw<SentRow[]>`
      SELECT m."senderId" AS "senderId", count(*)::int AS count
      FROM messages m
      LEFT JOIN automation_runs ar ON ar."messageId" = m.id
      WHERE m.direction = 'OUT'
        AND m.status = 'SENT'
        AND ar.id IS NULL
        AND NOT ${SQL_IS_CALL}
        AND m."sentAt" >= ${sqlUtc(start)}
        AND m."sentAt" < ${sqlUtc(end)}
      GROUP BY 1`;
  }
}
