import type {
  FunnelReportDto,
  FunnelStageRow,
  FunnelTotals,
  StageKind,
} from '@crm/shared';
import {
  BOOKED_STAGE_KEY,
  CANCEL_REASON,
} from '../realtycalendar/deal-stage-keys.js';

export interface FunnelStage {
  id: string;
  name: string;
  color: string;
  kind: StageKind;
  position: number;
  systemKey: string | null;
}

/** Сколько сделок периода стоит на этапе у ответственного с этой причиной отказа. */
export interface FunnelGroup {
  stageId: string;
  ownerId: string | null;
  lostReason: string | null;
  count: number;
}

export interface FunnelOwnerTotals extends Omit<FunnelTotals, 'open'> {
  ownerId: string | null;
}

export interface FunnelSummary {
  totals: FunnelTotals;
  stages: FunnelStageRow[];
  owners: FunnelOwnerTotals[];
  lostReasons: FunnelReportDto['lostReasons'];
}

interface ClassifiedGroup extends FunnelGroup {
  booked: boolean;
  cancelled: boolean;
  lost: boolean;
}

const NO_REASON = 'Без причины';
const TOP_LOST_REASONS = 10;

const sum = (values: number[]) =>
  values.reduce((total, value) => total + value, 0);

/**
 * «Дошла до брони» — успешный этап, открытый этап не раньше «Бронь создана» (без такого этапа — только
 * успешные) или отказ из-за отмены брони в RealtyCalendar: бронь была, её потом отменили.
 */
function classify(
  stages: FunnelStage[],
  groups: FunnelGroup[],
): ClassifiedGroup[] {
  const bookedPosition = stages.find(
    (stage) => stage.systemKey === BOOKED_STAGE_KEY,
  )?.position;
  const stageById = new Map(stages.map((stage) => [stage.id, stage]));
  return groups.flatMap((group) => {
    const stage = stageById.get(group.stageId);
    if (!stage) return [];
    const cancelled =
      stage.kind === 'LOST' && group.lostReason === CANCEL_REASON;
    const reachedBooking =
      stage.kind === 'WON' ||
      (stage.kind === 'OPEN' &&
        bookedPosition !== undefined &&
        stage.position >= bookedPosition);
    return [
      {
        ...group,
        booked: reachedBooking || cancelled,
        cancelled,
        lost: stage.kind === 'LOST' && !cancelled,
      },
    ];
  });
}

function totalsOf(rows: ClassifiedGroup[]): Omit<FunnelTotals, 'open'> {
  const count = (predicate: (row: ClassifiedGroup) => boolean) =>
    sum(rows.filter(predicate).map((row) => row.count));
  return {
    deals: count(() => true),
    booked: count((row) => row.booked),
    cancelled: count((row) => row.cancelled),
    lost: count((row) => row.lost),
  };
}

/** Итоги воронки по этапам, ответственным и причинам отказа. */
export function summarizeFunnel(
  stages: FunnelStage[],
  groups: FunnelGroup[],
  reasonsLimit = TOP_LOST_REASONS,
): FunnelSummary {
  const rows = classify(stages, groups);
  const totals = totalsOf(rows);
  const ownerIds = [...new Set(rows.map((row) => row.ownerId))];
  return {
    totals: { ...totals, open: totals.deals - totals.booked - totals.lost },
    stages: [...stages]
      .sort((a, b) => a.position - b.position)
      .map((stage) => ({
        id: stage.id,
        name: stage.name,
        color: stage.color,
        kind: stage.kind,
        deals: sum(
          rows
            .filter((row) => row.stageId === stage.id)
            .map((row) => row.count),
        ),
      })),
    owners: ownerIds
      .map((ownerId) => ({
        ownerId,
        ...totalsOf(rows.filter((row) => row.ownerId === ownerId)),
      }))
      .sort((a, b) => b.deals - a.deals),
    lostReasons: topLostReasons(
      rows
        .filter((row) => row.lost)
        .map((row) => ({ reason: row.lostReason, count: row.count })),
      reasonsLimit,
    ),
  };
}

/** Причины отказа без учёта регистра и лишних пробелов; подпись — как в первом встреченном варианте. */
export function topLostReasons(
  reasons: Array<{ reason: string | null; count: number }>,
  limit: number,
): FunnelReportDto['lostReasons'] {
  const byKey = new Map<string, { reason: string; deals: number }>();
  for (const { reason, count } of reasons) {
    const trimmed = reason?.trim() ?? '';
    const key = trimmed.toLowerCase().replace(/\s+/g, ' ');
    const seen = byKey.get(key);
    byKey.set(key, {
      reason: seen?.reason ?? (trimmed || NO_REASON),
      deals: (seen?.deals ?? 0) + count,
    });
  }
  return [...byKey.values()].sort((a, b) => b.deals - a.deals).slice(0, limit);
}
