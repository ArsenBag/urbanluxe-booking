import { CANCEL_REASON } from '../realtycalendar/deal-stage-keys.js';
import { summarizeFunnel, topLostReasons, type FunnelStage } from './funnel.js';

const stage = (
  id: string,
  kind: FunnelStage['kind'],
  position: number,
  systemKey: string | null = null,
): FunnelStage => ({
  id,
  name: id,
  color: '#3b82f6',
  kind,
  position,
  systemKey,
});

const stages: FunnelStage[] = [
  stage('new', 'OPEN', 0),
  stage('booked', 'OPEN', 1, 'BOOKED'),
  stage('stayed', 'OPEN', 2, 'CHECKED_OUT'),
  stage('won', 'WON', 3),
  stage('lost', 'LOST', 4),
];

describe('summarizeFunnel', () => {
  const summary = summarizeFunnel(stages, [
    { stageId: 'new', ownerId: 'u1', lostReason: null, count: 4 },
    { stageId: 'booked', ownerId: 'u1', lostReason: null, count: 2 },
    { stageId: 'stayed', ownerId: 'u2', lostReason: null, count: 1 },
    { stageId: 'won', ownerId: null, lostReason: null, count: 1 },
    { stageId: 'lost', ownerId: 'u2', lostReason: 'Дорого', count: 2 },
    { stageId: 'lost', ownerId: 'u2', lostReason: null, count: 1 },
    { stageId: 'lost', ownerId: 'u1', lostReason: CANCEL_REASON, count: 2 },
  ]);

  it('counts deals that reached a booking, including bookings cancelled later', () => {
    expect(summary.totals).toEqual({
      deals: 13,
      booked: 6,
      cancelled: 2,
      lost: 3,
      open: 4,
    });
  });

  it('keeps stage counts as they are on the board', () => {
    expect(summary.stages.map((row) => [row.id, row.deals])).toEqual([
      ['new', 4],
      ['booked', 2],
      ['stayed', 1],
      ['won', 1],
      ['lost', 5],
    ]);
  });

  it('splits the same figures by owner, busiest first', () => {
    expect(summary.owners).toEqual([
      { ownerId: 'u1', deals: 8, booked: 4, cancelled: 2, lost: 0 },
      { ownerId: 'u2', deals: 4, booked: 1, cancelled: 0, lost: 3 },
      { ownerId: null, deals: 1, booked: 1, cancelled: 0, lost: 0 },
    ]);
  });

  it('lists refusal reasons without RealtyCalendar cancellations', () => {
    expect(summary.lostReasons).toEqual([
      { reason: 'Дорого', deals: 2 },
      { reason: 'Без причины', deals: 1 },
    ]);
  });

  it('counts only successful stages without a booking stage', () => {
    const plain = stages.map((row) => ({ ...row, systemKey: null }));
    const result = summarizeFunnel(plain, [
      { stageId: 'stayed', ownerId: null, lostReason: null, count: 2 },
      { stageId: 'won', ownerId: null, lostReason: null, count: 1 },
    ]);
    expect(result.totals).toEqual({
      deals: 3,
      booked: 1,
      cancelled: 0,
      lost: 0,
      open: 2,
    });
  });

  it('ignores groups of stages from another pipeline', () => {
    const result = summarizeFunnel(stages, [
      { stageId: 'elsewhere', ownerId: null, lostReason: null, count: 5 },
    ]);
    expect(result.totals.deals).toBe(0);
  });
});

describe('topLostReasons', () => {
  it('groups reasons regardless of case and spacing, most frequent first', () => {
    expect(
      topLostReasons(
        [
          { reason: 'Дорого', count: 1 },
          { reason: ' дорого ', count: 2 },
          { reason: 'Нет  мест', count: 1 },
          { reason: null, count: 1 },
          { reason: 'нет мест', count: 1 },
          { reason: '', count: 1 },
        ],
        10,
      ),
    ).toEqual([
      { reason: 'Дорого', deals: 3 },
      { reason: 'Нет  мест', deals: 2 },
      { reason: 'Без причины', deals: 2 },
    ]);
  });

  it('keeps only the top reasons', () => {
    const reasons = ['a', 'b', 'c'].map((reason, index) => ({
      reason,
      count: index + 1,
    }));
    expect(topLostReasons(reasons, 2)).toEqual([
      { reason: 'c', deals: 3 },
      { reason: 'b', deals: 2 },
    ]);
  });
});
