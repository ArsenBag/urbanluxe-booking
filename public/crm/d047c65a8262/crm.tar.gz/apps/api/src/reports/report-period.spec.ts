import { periodBounds } from './report-period.js';

describe('periodBounds', () => {
  it('runs from Tashkent midnight of the first day to midnight after the last', () => {
    const { start, end } = periodBounds({
      from: '2026-10-01',
      to: '2026-10-31',
    });
    expect(start.toISOString()).toBe('2026-09-30T19:00:00.000Z');
    expect(end.toISOString()).toBe('2026-10-31T19:00:00.000Z');
  });

  it('covers one whole day for a one-day period', () => {
    const { start, end } = periodBounds({
      from: '2026-10-06',
      to: '2026-10-06',
    });
    expect(end.getTime() - start.getTime()).toBe(86_400_000);
  });
});
