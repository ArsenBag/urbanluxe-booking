import { Injectable } from '@nestjs/common';
import {
  CHANNEL_TYPES,
  listPeriodDates,
  type ChannelCounts,
  type ChannelType,
  type InquiriesReportDto,
  type ReportPeriod,
} from '@crm/shared';
import { Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import {
  periodBounds,
  sqlTashkentDay,
  sqlUtc,
  SQL_IS_CALL,
  type PeriodBounds,
} from './report-period.js';

interface ConversationStartRow {
  channel: ChannelType;
  direction: 'IN' | 'OUT';
  day: string;
  count: number;
}

type MessageCountsRow = InquiriesReportDto['messages'] & {
  missedCalls: number;
};

const NO_MESSAGES: MessageCountsRow = {
  incoming: 0,
  fromCrm: 0,
  fromPhone: 0,
  automated: 0,
  missedCalls: 0,
};

function countByChannel(rows: ConversationStartRow[]): ChannelCounts {
  return Object.fromEntries(
    CHANNEL_TYPES.map((channel) => [
      channel,
      rows
        .filter((row) => row.channel === channel)
        .reduce((total, row) => total + row.count, 0),
    ]),
  ) as ChannelCounts;
}

/** Обращения: диалоги, начатые в периоде, и объём переписки. */
@Injectable()
export class InquiriesReportService {
  constructor(private readonly prisma: PrismaService) {}

  async report(period: ReportPeriod): Promise<InquiriesReportDto> {
    const bounds = periodBounds(period);
    const [starts, counts] = await Promise.all([
      this.conversationStarts(bounds),
      this.messageCounts(bounds),
    ]);
    const fromGuests = starts.filter((row) => row.direction === 'IN');
    const { missedCalls, ...messages } = counts ?? NO_MESSAGES;
    return {
      newConversations: {
        fromGuests: countByChannel(fromGuests),
        fromUs: countByChannel(starts.filter((row) => row.direction === 'OUT')),
      },
      byDay: listPeriodDates(period.from, period.to).map((date) => ({
        date,
        counts: countByChannel(fromGuests.filter((row) => row.day === date)),
      })),
      messages,
      missedCalls,
    };
  }

  /** Первое сообщение каждого диалога, если оно пришло в периоде: канал, кто написал, день по Ташкенту. */
  private conversationStarts({
    start,
    end,
  }: PeriodBounds): Promise<ConversationStartRow[]> {
    return this.prisma.$queryRaw<ConversationStartRow[]>`
      SELECT ch.type::text AS channel,
             first.direction::text AS direction,
             ${sqlTashkentDay(Prisma.sql`first."sentAt"`)} AS day,
             count(*)::int AS count
      FROM conversations c
      JOIN channels ch ON ch.id = c."channelId"
      JOIN LATERAL (
        SELECT m.direction, m."sentAt"
        FROM messages m
        WHERE m."conversationId" = c.id
          -- Неотправленное первое сообщение («Написать» с ошибкой) диалог не начинает.
          AND m.status IN ('RECEIVED', 'SENT')
        ORDER BY m."sentAt", m."createdAt", m.id
        LIMIT 1
      ) first ON true
      WHERE first."sentAt" >= ${sqlUtc(start)} AND first."sentAt" < ${sqlUtc(end)}
      GROUP BY 1, 2, 3`;
  }

  /** Сообщения периода; звонки — не сообщения, кроме пропущенных входящих в отдельном счётчике. */
  private async messageCounts({
    start,
    end,
  }: PeriodBounds): Promise<MessageCountsRow | undefined> {
    const rows = await this.prisma.$queryRaw<MessageCountsRow[]>`
      SELECT
        count(*) FILTER (WHERE m.direction = 'IN' AND NOT ${SQL_IS_CALL})::int AS incoming,
        count(*) FILTER (WHERE m.direction = 'OUT' AND m."senderId" IS NOT NULL AND ar.id IS NULL AND NOT ${SQL_IS_CALL})::int AS "fromCrm",
        count(*) FILTER (WHERE m.direction = 'OUT' AND m."senderId" IS NULL AND ar.id IS NULL AND NOT ${SQL_IS_CALL})::int AS "fromPhone",
        count(*) FILTER (WHERE ar.id IS NOT NULL)::int AS automated,
        count(*) FILTER (
          WHERE m.direction = 'IN' AND ${SQL_IS_CALL} AND (m.attachment->'call'->>'outcome') IS DISTINCT FROM 'answered'
        )::int AS "missedCalls"
      FROM messages m
      LEFT JOIN automation_runs ar ON ar."messageId" = m.id
      WHERE m."sentAt" >= ${sqlUtc(start)} AND m."sentAt" < ${sqlUtc(end)}
        AND m.status IN ('RECEIVED', 'SENT')`;
    return rows[0];
  }
}
