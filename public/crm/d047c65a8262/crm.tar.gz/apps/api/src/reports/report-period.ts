import type { ReportPeriod } from '@crm/shared';
import { tashkentDayEnd, tashkentDayStart } from '../common/dates.js';
import { Prisma } from '../generated/prisma/client.js';

export interface PeriodBounds {
  start: Date;
  /** Не включительно: полночь после последнего дня. */
  end: Date;
}

/** Период отчёта во времени: с полуночи первого дня до полуночи после последнего, по Ташкенту. */
export function periodBounds({ from, to }: ReportPeriod): PeriodBounds {
  return { start: tashkentDayStart(from), end: tashkentDayEnd(to) };
}

/**
 * Момент времени для сырого SQL. Колонки времени — timestamp без пояса в UTC, поэтому передаём строку ISO
 * и приводим явно: результат не зависит от часового пояса сессии базы.
 */
export const sqlUtc = (value: Date) =>
  Prisma.sql`(${value.toISOString()}::timestamptz AT TIME ZONE 'UTC')`;

/** День по Ташкенту (YYYY-MM-DD) для колонки времени в UTC. */
export const sqlTashkentDay = (column: Prisma.Sql) =>
  Prisma.sql`to_char(${column} + interval '5 hours', 'YYYY-MM-DD')`;

/** Звонок в переписке — сообщение с вложением kind = 'call'; m — псевдоним таблицы messages. */
export const SQL_IS_CALL = Prisma.sql`coalesce(m.attachment->>'kind' = 'call', false)`;
