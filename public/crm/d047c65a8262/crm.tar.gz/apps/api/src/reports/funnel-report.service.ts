import { Injectable, NotFoundException } from '@nestjs/common';
import type { FunnelReportDto, FunnelReportQuery } from '@crm/shared';
import { PrismaService } from '../prisma/prisma.service.js';
import { summarizeFunnel } from './funnel.js';
import { periodBounds } from './report-period.js';

const EMPTY_TOTALS = { deals: 0, booked: 0, cancelled: 0, lost: 0, open: 0 };

/** Воронка: сделки, созданные в периоде, по текущему этапу и ответственному. */
@Injectable()
export class FunnelReportService {
  constructor(private readonly prisma: PrismaService) {}

  async report(query: FunnelReportQuery): Promise<FunnelReportDto> {
    const pipelines = await this.prisma.pipeline.findMany({
      orderBy: [{ position: 'asc' }, { createdAt: 'asc' }],
      select: { id: true, name: true },
    });
    const pipeline = query.pipelineId
      ? pipelines.find((row) => row.id === query.pipelineId)
      : pipelines[0];
    if (query.pipelineId && !pipeline)
      throw new NotFoundException('Воронка не найдена');
    if (!pipeline)
      return {
        pipeline: null,
        pipelines,
        totals: EMPTY_TOTALS,
        stages: [],
        lostReasons: [],
        owners: [],
      };

    const summary = await this.summarize(pipeline.id, query);
    const ownerIds = summary.owners.flatMap((row) =>
      row.ownerId ? [row.ownerId] : [],
    );
    const owners = await this.prisma.user.findMany({
      where: { id: { in: ownerIds } },
      select: { id: true, name: true },
    });
    const ownerById = new Map(owners.map((owner) => [owner.id, owner]));

    return {
      pipeline,
      pipelines,
      totals: summary.totals,
      stages: summary.stages,
      lostReasons: summary.lostReasons,
      owners: summary.owners.map(({ ownerId, ...counts }) => ({
        owner: ownerId ? (ownerById.get(ownerId) ?? null) : null,
        ...counts,
      })),
    };
  }

  /** Сделки периода сгруппированы по этапу, ответственному и причине отказа — одним запросом. */
  private async summarize(pipelineId: string, query: FunnelReportQuery) {
    const { start, end } = periodBounds(query);
    const [stages, groups] = await Promise.all([
      this.prisma.stage.findMany({
        where: { pipelineId },
        orderBy: { position: 'asc' },
        select: {
          id: true,
          name: true,
          color: true,
          kind: true,
          position: true,
          systemKey: true,
        },
      }),
      this.prisma.deal.groupBy({
        by: ['stageId', 'ownerId', 'lostReason'],
        where: { pipelineId, createdAt: { gte: start, lt: end } },
        _count: { _all: true },
      }),
    ]);
    return summarizeFunnel(
      stages,
      groups.map((group) => ({
        stageId: group.stageId,
        ownerId: group.ownerId,
        lostReason: group.lostReason,
        count: group._count._all,
      })),
    );
  }
}
