import {
  listPeriodDates,
  reportPeriodDays,
  type BookingsReportDto,
} from '@crm/shared';

/** Бронь для отчёта: даты YYYY-MM-DD, сумма за всё проживание. */
export interface Stay {
  propertyId: string | null;
  checkIn: string;
  checkOut: string;
  amount: number | null;
  origin: string | null;
}

export interface ReportProperty {
  id: string;
  title: string;
  complex: string | null;
  /** Квартира RealtyCalendar; false — строка ЖК из выгрузки Excel, в загрузку не входит. */
  isApartment: boolean;
}

export interface BookingsReportInput {
  from: string;
  to: string;
  currency: string;
  properties: ReportProperty[];
  /** Подтверждённые брони, пересекающие период. */
  stays: Stay[];
  arrivals: number;
  cancellations: number;
}

interface StayShare {
  stay: Stay;
  nights: number;
  revenue: number;
}

const NO_PROPERTY = 'Квартира не указана';
const NO_COMPLEX = 'ЖК не определён';
const MS_PER_DAY = 86_400_000;

const dayNumber = (date: string) => Date.parse(date) / MS_PER_DAY;
const sum = (values: number[]) =>
  values.reduce((total, value) => total + value, 0);
const roundMoney = (value: number) => Math.round(value * 100) / 100;
const byTitle = (a: string, b: string) =>
  a.localeCompare(b, 'ru', { numeric: true });

/** Ночи брони внутри периода: ночь d занята, если checkIn ≤ d < checkOut. */
export function nightsInPeriod(stay: Stay, from: string, to: string): number {
  const start = Math.max(dayNumber(stay.checkIn), dayNumber(from));
  const end = Math.min(dayNumber(stay.checkOut), dayNumber(to) + 1);
  return Math.max(0, end - start);
}

/**
 * Часть суммы брони за ночи внутри периода — сумма делится поровну на все ночи по датам.
 * Поле «ночей» из RealtyCalendar не берём: если оно расходится с датами, период получил бы больше суммы брони.
 */
export function revenueInPeriod(stay: Stay, from: string, to: string): number {
  const totalNights = dayNumber(stay.checkOut) - dayNumber(stay.checkIn);
  if (stay.amount === null || totalNights <= 0) return 0;
  return (stay.amount * nightsInPeriod(stay, from, to)) / totalNights;
}

function totalsOf(shares: StayShare[]) {
  return {
    nights: sum(shares.map((share) => share.nights)),
    revenue: sum(shares.map((share) => share.revenue)),
  };
}

export function buildBookingsReport(
  input: BookingsReportInput,
): BookingsReportDto {
  const { from, to } = input;
  const days = reportPeriodDays(from, to);
  const shares = input.stays
    .map((stay) => ({
      stay,
      nights: nightsInPeriod(stay, from, to),
      revenue: revenueInPeriod(stay, from, to),
    }))
    .filter((share) => share.nights > 0);
  const apartments = input.properties.filter(
    (property) => property.isApartment,
  );
  const occupancy = (nights: number, units: number) =>
    units > 0 ? nights / (units * days) : null;

  const total = totalsOf(shares);
  const priced = totalsOf(shares.filter((share) => share.stay.amount !== null));

  return {
    currency: input.currency,
    apartments: apartments.length,
    days,
    totals: {
      nights: total.nights,
      occupancy: occupancy(total.nights, apartments.length),
      revenue: roundMoney(total.revenue),
      arrivals: input.arrivals,
      averageNightPrice:
        priced.nights > 0 ? roundMoney(priced.revenue / priced.nights) : null,
      cancellations: input.cancellations,
    },
    byDay: listPeriodDates(from, to).map((date) => ({
      date,
      occupied: shares.filter(
        (share) => share.stay.checkIn <= date && date < share.stay.checkOut,
      ).length,
    })),
    byComplex: complexRows(input.properties, shares, occupancy),
    byApartment: apartments
      .map((apartment) => {
        const own = totalsOf(
          shares.filter((share) => share.stay.propertyId === apartment.id),
        );
        return {
          id: apartment.id,
          title: apartment.title,
          complex: apartment.complex,
          nights: own.nights,
          occupancy: occupancy(own.nights, 1),
          revenue: roundMoney(own.revenue),
        };
      })
      .sort((a, b) => b.nights - a.nights || byTitle(a.title, b.title)),
    byOrigin: originRows(shares),
  };
}

function complexRows(
  properties: ReportProperty[],
  shares: StayShare[],
  occupancy: (nights: number, units: number) => number | null,
): BookingsReportDto['byComplex'] {
  const propertyById = new Map(
    properties.map((property) => [property.id, property]),
  );
  const complexOf = (propertyId: string | null) => {
    const property = propertyId ? propertyById.get(propertyId) : undefined;
    if (!property) return NO_PROPERTY;
    return property.complex ?? NO_COMPLEX;
  };
  const apartmentComplexes = properties
    .filter((property) => property.isApartment)
    .map((property) => property.complex ?? NO_COMPLEX);
  const titles = [
    ...new Set([
      ...apartmentComplexes,
      ...shares.map((share) => complexOf(share.stay.propertyId)),
    ]),
  ];

  return titles
    .map((title) => {
      const units = apartmentComplexes.filter(
        (complex) => complex === title,
      ).length;
      const own = totalsOf(
        shares.filter((share) => complexOf(share.stay.propertyId) === title),
      );
      return {
        title,
        apartments: units,
        nights: own.nights,
        occupancy: occupancy(own.nights, units),
        revenue: roundMoney(own.revenue),
      };
    })
    .sort(
      (a, b) =>
        b.nights - a.nights ||
        b.apartments - a.apartments ||
        byTitle(a.title, b.title),
    );
}

/** Площадки без учёта регистра: RealtyCalendar пишет и «Booking.com», и «booking.com». Подпись — первый вариант. */
function originRows(shares: StayShare[]): BookingsReportDto['byOrigin'] {
  const labelOf = (share: StayShare) => share.stay.origin?.trim() || null;
  const keyOf = (share: StayShare) => labelOf(share)?.toLowerCase() ?? null;
  const keys = [...new Set(shares.map(keyOf))];
  return keys
    .map((key) => {
      const own = shares.filter((share) => keyOf(share) === key);
      const totals = totalsOf(own);
      return {
        origin: labelOf(own[0]!),
        bookings: own.length,
        nights: totals.nights,
        revenue: roundMoney(totals.revenue),
      };
    })
    .sort((a, b) => b.nights - a.nights || b.bookings - a.bookings);
}
