import { Inject, Injectable } from '@nestjs/common';
import type { BookingsReportDto, ReportPeriod } from '@crm/shared';
import { dateOnlyFromDb, dateOnlyToDb } from '../common/dates.js';
import { ENV, type Env } from '../config/env.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { complexOfProperty } from '../realtycalendar/complexes.js';
import { buildBookingsReport, type ReportProperty } from './occupancy.js';

/** Потолок броней в отчёте: 56 квартир за год — несколько тысяч, запас многократный. */
const MAX_STAYS = 50_000;

/** ЖК квартиры по адресу; у строк из выгрузки Excel адреса может не быть — там название и есть ЖК. */
function toReportProperty(property: {
  id: string;
  title: string;
  address: string | null;
  rcId: number | null;
}): ReportProperty {
  return {
    id: property.id,
    title: property.title,
    complex: complexOfProperty(property),
    isApartment: property.rcId !== null,
  };
}

/** Брони и загрузка за период: только подтверждённые брони, по датам проживания. */
@Injectable()
export class BookingsReportService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  async report(period: ReportPeriod): Promise<BookingsReportDto> {
    const from = dateOnlyToDb(period.from);
    const to = dateOnlyToDb(period.to);
    const checkInInPeriod = { gte: from, lte: to };
    const [properties, stays, arrivals, cancellations] = await Promise.all([
      this.prisma.property.findMany({
        select: { id: true, title: true, address: true, rcId: true },
      }),
      this.prisma.booking.findMany({
        where: {
          status: 'BOOKED',
          checkIn: { lte: to },
          checkOut: { gt: from },
        },
        select: {
          propertyId: true,
          checkIn: true,
          checkOut: true,
          amount: true,
          origin: true,
        },
        orderBy: { checkIn: 'asc' },
        take: MAX_STAYS,
      }),
      this.prisma.booking.count({
        where: { status: 'BOOKED', checkIn: checkInInPeriod },
      }),
      // Отмены — только по вебхукам: брони из выгрузки Excel, которых нет в календаре, тоже помечены отменёнными.
      this.prisma.booking.count({
        where: {
          status: 'CANCELED',
          rcId: { not: null },
          checkIn: checkInInPeriod,
        },
      }),
    ]);

    return buildBookingsReport({
      from: period.from,
      to: period.to,
      currency: this.env.RC_CURRENCY,
      properties: properties.map(toReportProperty),
      stays: stays.map((stay) => ({
        propertyId: stay.propertyId,
        checkIn: dateOnlyFromDb(stay.checkIn),
        checkOut: dateOnlyFromDb(stay.checkOut),
        amount: stay.amount === null ? null : stay.amount.toNumber(),
        origin: stay.origin,
      })),
      arrivals,
      cancellations,
    });
  }
}
