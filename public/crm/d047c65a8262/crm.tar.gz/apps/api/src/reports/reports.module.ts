import { Module } from '@nestjs/common';
import { BookingsReportService } from './bookings-report.service.js';
import { FunnelReportService } from './funnel-report.service.js';
import { InquiriesReportService } from './inquiries-report.service.js';
import { ReportsController } from './reports.controller.js';
import { TeamReportService } from './team-report.service.js';

@Module({
  controllers: [ReportsController],
  providers: [
    InquiriesReportService,
    FunnelReportService,
    BookingsReportService,
    TeamReportService,
  ],
})
export class ReportsModule {}
