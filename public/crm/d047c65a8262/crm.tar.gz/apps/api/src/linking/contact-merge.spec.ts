import { mergedContactFields, type MergeableContact } from './contact-merge.js';

const OLDER = new Date('2026-09-01T10:00:00Z');
const NEWER = new Date('2026-10-05T10:00:00Z');

function contact(overrides: Partial<MergeableContact> = {}): MergeableContact {
  return {
    name: 'Гость',
    phones: [],
    email: null,
    source: 'OTHER',
    tags: [],
    notes: null,
    customFields: {},
    ownerId: null,
    avatarFileId: null,
    avatarHash: null,
    avatarSource: null,
    vip: false,
    blacklistedAt: null,
    blacklistReason: null,
    blacklistedById: null,
    createdAt: NEWER,
    ...overrides,
  };
}

describe('mergedContactFields', () => {
  it('keeps the conversation name unless the other one is asked for', () => {
    const chat = contact({ name: 'Ваня 🌴' });
    const booking = contact({ name: 'Ivan Petrov' });

    expect(mergedContactFields(chat, booking, false).data.name).toBe('Ваня 🌴');
    expect(mergedContactFields(chat, booking, true).data.name).toBe(
      'Ivan Petrov',
    );
  });

  it('collects phones and tags from both cards without duplicates, target first', () => {
    const chat = contact({ phones: ['+998901111111'], tags: ['vip'] });
    const booking = contact({
      phones: ['+998902222222', '+998901111111'],
      tags: ['booking', 'vip'],
    });

    const { data } = mergedContactFields(chat, booking, false);

    expect(data.phones).toEqual(['+998901111111', '+998902222222']);
    expect(data.tags).toEqual(['vip', 'booking']);
  });

  it('fills empty email and owner from the merged card', () => {
    const chat = contact({ email: null, ownerId: null });
    const booking = contact({ email: 'guest@example.com', ownerId: 'owner-1' });

    const { data } = mergedContactFields(chat, booking, false);

    expect(data.email).toBe('guest@example.com');
    expect(data.ownerId).toBe('owner-1');
  });

  it('keeps the other email in the notes instead of dropping it', () => {
    const chat = contact({
      email: 'chat@example.com',
      notes: 'Просит ранний заезд',
    });
    const booking = contact({ email: 'booking@example.com' });

    const { data } = mergedContactFields(chat, booking, false);

    expect(data.email).toBe('chat@example.com');
    expect(data.notes).toBe(
      'Просит ранний заезд\n\nДругой email: booking@example.com',
    );
  });

  it('keeps notes from both cards', () => {
    const { data } = mergedContactFields(
      contact({ notes: 'Просит ранний заезд' }),
      contact({ notes: 'Оплата наличными' }),
      false,
    );

    expect(data.notes).toBe('Просит ранний заезд\n\nОплата наличными');
    expect(
      mergedContactFields(contact(), contact(), false).data.notes,
    ).toBeNull();
  });

  it('prefers the target value of a custom field and adds the missing ones', () => {
    const chat = contact({ customFields: { passport: 'AA1234567' } });
    const booking = contact({
      customFields: { passport: 'old', citizenship: 'UZ' },
    });

    expect(mergedContactFields(chat, booking, false).data.customFields).toEqual(
      { passport: 'AA1234567', citizenship: 'UZ' },
    );
  });

  it('keeps the first contact date and the source of the older card', () => {
    const chat = contact({ source: 'WHATSAPP', createdAt: NEWER });
    const booking = contact({ source: 'BOOKING', createdAt: OLDER });

    const { data } = mergedContactFields(chat, booking, false);

    expect(data.createdAt).toEqual(OLDER);
    expect(data.source).toBe('BOOKING');
  });

  it('never deletes a photo both cards point to', () => {
    const photo = {
      avatarFileId: 'file-a',
      avatarHash: 'hash-a',
      avatarSource: 'WHATSAPP' as const,
    };

    expect(
      mergedContactFields(contact(photo), contact(photo), false)
        .orphanAvatarFileId,
    ).toBeNull();
  });

  it('takes the photo from the merged card only when the target has none', () => {
    const photo = {
      avatarFileId: 'file-b',
      avatarHash: 'hash-b',
      avatarSource: 'TELEGRAM' as const,
    };

    const adopted = mergedContactFields(contact(), contact(photo), false);
    expect(adopted.data.avatarFileId).toBe('file-b');
    expect(adopted.orphanAvatarFileId).toBeNull();

    const kept = mergedContactFields(
      contact({
        avatarFileId: 'file-a',
        avatarHash: 'hash-a',
        avatarSource: 'WHATSAPP',
      }),
      contact(photo),
      false,
    );
    expect(kept.data).toMatchObject({
      avatarFileId: 'file-a',
      avatarHash: 'hash-a',
      avatarSource: 'WHATSAPP',
    });
    expect(kept.orphanAvatarFileId).toBe('file-b');
  });

  it('keeps the VIP mark if either card had it', () => {
    const vip = contact({ vip: true });

    expect(mergedContactFields(contact(), vip, false).data.vip).toBe(true);
    expect(mergedContactFields(vip, contact(), false).data.vip).toBe(true);
    expect(mergedContactFields(contact(), contact(), false).data.vip).toBe(
      false,
    );
  });

  it('never loses a blacklist mark: the merged card stays blacklisted', () => {
    const listed = contact({
      blacklistedAt: OLDER,
      blacklistReason: 'Испортил мебель',
      blacklistedById: 'user-1',
    });

    const { data } = mergedContactFields(contact(), listed, false);

    expect(data).toMatchObject({
      blacklistedAt: OLDER,
      blacklistReason: 'Испортил мебель',
      blacklistedById: 'user-1',
    });
  });

  it('keeps the target blacklist reason when both cards are listed', () => {
    const target = contact({
      blacklistedAt: NEWER,
      blacklistReason: 'Шумел ночью',
      blacklistedById: 'user-2',
    });
    const source = contact({
      blacklistedAt: OLDER,
      blacklistReason: 'Испортил мебель',
      blacklistedById: 'user-1',
    });

    const { data } = mergedContactFields(target, source, false);

    expect(data.blacklistReason).toBe('Шумел ночью');
    expect(data.blacklistedById).toBe('user-2');
  });
});
