import {
  ConflictException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import type {
  LinkConversationInput,
  LinkDealRef,
  LinkMergeContactDto,
  LinkPreviewDto,
  LinkResultDto,
  LinkTarget,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { dateOnlyFromDb } from '../common/dates.js';
import { FileStorageService } from '../files/file-storage.service.js';
import type { Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { lockBooking } from '../realtycalendar/booking-lock.js';
import { MergeService } from './merge.service.js';

type Tx = Prisma.TransactionClient;

const DEAL_REF_SELECT = {
  id: true,
  title: true,
  stageId: true,
  contactId: true,
  closedAt: true,
} as const;

type TargetDeal = LinkDealRef & { contactId: string; closedAt: Date | null };

const STALE_PREVIEW =
  'Пока окно было открыто, бронь или сделка изменилась. Откройте окно связывания заново.';

/** Бронь или сделка, с которой связываем диалог. */
interface ResolvedTarget {
  /** Клиент брони или сделки; null — у брони нет клиента (нет ни имени, ни телефона гостя). */
  contactId: string | null;
  deal: TargetDeal | null;
  /** Для журнала: что именно связали. */
  summary: Record<string, string | null>;
}

const toDealRef = ({ id, title, stageId }: TargetDeal): LinkDealRef => ({
  id,
  title,
  stageId,
});

/**
 * Связь диалога с бронью или сделкой. Всё в CRM держится на карточке клиента: диалог, сделки и брони
 * принадлежат ей. Поэтому «связать» — значит влить карточку клиента брони в клиента диалога,
 * а при желании ещё и объединить сделку-обращение со сделкой брони.
 */
@Injectable()
export class LinkService {
  private readonly logger = new Logger(LinkService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly merge: MergeService,
    private readonly audit: ActivityLogService,
    private readonly files: FileStorageService,
  ) {}

  async preview(
    conversationId: string,
    target: LinkTarget,
  ): Promise<LinkPreviewDto> {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
      select: { contact: { select: { id: true, name: true } } },
    });
    if (!conversation) throw new NotFoundException('Диалог не найден');
    const { contact } = conversation;
    const resolved = await this.resolveTarget(this.prisma, target);
    const otherId =
      resolved.contactId && resolved.contactId !== contact.id
        ? resolved.contactId
        : null;
    return {
      contact,
      alreadyLinked: resolved.contactId === contact.id,
      mergeContact: otherId ? await this.mergeSummary(otherId) : null,
      targetDeal: resolved.deal ? toDealRef(resolved.deal) : null,
      dealMergeCandidate: await this.dealMergeCandidate(
        contact.id,
        otherId,
        resolved.deal,
      ),
    };
  }

  async link(
    conversationId: string,
    input: LinkConversationInput,
    actor: SessionUser,
  ): Promise<LinkResultDto> {
    const { result, orphanAvatarFileId } = await this.prisma.$transaction(
      async (tx) => {
        const conversation = await tx.conversation.findUnique({
          where: { id: conversationId },
          select: { contactId: true },
        });
        if (!conversation) throw new NotFoundException('Диалог не найден');
        const contactId = conversation.contactId;
        // Сначала блокировка, потом чтение: решение принимается по брони, какой её оставил последний вебхук.
        if (input.bookingId) await this.lockBookingById(tx, input.bookingId);
        const resolved = await this.resolveTarget(tx, input);
        const sourceId =
          resolved.contactId && resolved.contactId !== contactId
            ? resolved.contactId
            : null;
        // Вливаем только ту карточку, которую человек видел в окне подтверждения.
        if (sourceId !== input.mergeContactId) {
          throw new ConflictException(STALE_PREVIEW);
        }

        let orphan: string | null = null;
        if (sourceId) {
          ({ orphanAvatarFileId: orphan } = await this.merge.mergeContacts(
            tx,
            contactId,
            sourceId,
            input.useOtherName,
            actor,
          ));
        } else if (input.bookingId && resolved.contactId === null) {
          // Бронь без гостя (нет ни имени, ни телефона): записываем на клиента диалога вместе с автозадачами.
          await tx.booking.update({
            where: { id: input.bookingId },
            data: { contactId },
          });
          await tx.task.updateMany({
            where: { bookingId: input.bookingId, contactId: null },
            data: { contactId },
          });
        }

        const dealId = input.mergeDealId
          ? await this.mergeChatDeal(
              tx,
              contactId,
              resolved,
              input.mergeDealId,
              actor,
            )
          : (resolved.deal?.id ?? null);
        await this.audit.record(
          actor,
          {
            action: 'conversation.linked',
            ...(dealId
              ? { entityType: 'deal' as const, entityId: dealId }
              : { entityType: 'contact' as const, entityId: contactId }),
            payload: { conversationId, ...resolved.summary },
          },
          tx,
        );
        return { result: { contactId, dealId }, orphanAvatarFileId: orphan };
      },
    );
    // Фото влитой карточки — персональные данные: удаляем файл после коммита, как при удалении клиента.
    // Объединение уже сохранено, поэтому сбой удаления файла не превращаем в ошибку для сотрудника.
    if (orphanAvatarFileId) {
      await this.files
        .remove([orphanAvatarFileId])
        .catch((error: unknown) =>
          this.logger.warn(
            `Не удалось удалить фото влитой карточки ${orphanAvatarFileId}: ${String(error)}`,
          ),
        );
    }
    return result;
  }

  /** Вебхук RealtyCalendar по этой брони подождёт, пока связывание не закончится. */
  private async lockBookingById(tx: Tx, bookingId: string): Promise<void> {
    const keys = await tx.booking.findUnique({
      where: { id: bookingId },
      select: { id: true, rcId: true, importKey: true },
    });
    if (!keys) throw new NotFoundException('Бронь не найдена');
    await lockBooking(tx, keys);
  }

  private async resolveTarget(
    db: Tx,
    target: LinkTarget,
  ): Promise<ResolvedTarget> {
    if (target.bookingId) {
      const booking = await db.booking.findUnique({
        where: { id: target.bookingId },
        include: {
          deal: { select: DEAL_REF_SELECT },
          property: { select: { title: true } },
        },
      });
      if (!booking) throw new NotFoundException('Бронь не найдена');
      return {
        contactId: booking.contactId,
        deal: booking.deal,
        summary: {
          property: booking.property?.title ?? null,
          checkIn: dateOnlyFromDb(booking.checkIn),
          checkOut: dateOnlyFromDb(booking.checkOut),
        },
      };
    }
    const deal = await db.deal.findUnique({
      where: { id: target.dealId },
      select: DEAL_REF_SELECT,
    });
    if (!deal) throw new NotFoundException('Сделка не найдена');
    return { contactId: deal.contactId, deal, summary: { title: deal.title } };
  }

  private async mergeSummary(contactId: string): Promise<LinkMergeContactDto> {
    const contact = await this.prisma.contact.findUniqueOrThrow({
      where: { id: contactId },
      select: {
        id: true,
        name: true,
        _count: {
          select: { bookings: true, deals: true, conversations: true },
        },
      },
    });
    return { id: contact.id, name: contact.name, ...contact._count };
  }

  /**
   * Открытая сделка клиента диалога без броней (обычно автосделка «Новое обращение»), которую
   * стоит объединить со сделкой брони. Закрытую сделку брони (отмена, прошлое проживание) не трогаем:
   * новое обращение — это уже другая поездка.
   */
  private async dealMergeCandidate(
    contactId: string,
    otherContactId: string | null,
    targetDeal: TargetDeal | null,
  ): Promise<LinkDealRef | null> {
    if (!targetDeal || targetDeal.closedAt) return null;
    if (
      targetDeal.contactId !== contactId &&
      targetDeal.contactId !== otherContactId
    ) {
      return null;
    }
    return this.prisma.deal.findFirst({
      where: {
        contactId,
        closedAt: null,
        bookings: { none: {} },
        id: { not: targetDeal.id },
      },
      orderBy: { updatedAt: 'desc' },
      select: { id: true, title: true, stageId: true },
    });
  }

  private async mergeChatDeal(
    tx: Tx,
    contactId: string,
    resolved: ResolvedTarget,
    mergeDealId: string,
    actor: SessionUser,
  ): Promise<string> {
    const targetDeal = resolved.deal;
    const ownersAfterMerge = [contactId, resolved.contactId];
    if (
      !targetDeal ||
      targetDeal.closedAt ||
      !ownersAfterMerge.includes(targetDeal.contactId)
    ) {
      throw new ConflictException(
        'Сделку брони объединить нельзя: она закрыта или принадлежит другому клиенту.',
      );
    }
    const chatDeal = await tx.deal.findFirst({
      where: {
        id: mergeDealId,
        contactId,
        closedAt: null,
        bookings: { none: {} },
      },
      select: { id: true },
    });
    if (!chatDeal) {
      throw new ConflictException(
        'Сделка диалога изменилась. Откройте окно связывания заново.',
      );
    }
    return this.merge.mergeDeals(tx, chatDeal.id, targetDeal.id, actor);
  }
}
