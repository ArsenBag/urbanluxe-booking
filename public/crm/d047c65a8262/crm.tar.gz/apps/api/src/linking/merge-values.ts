/** Значения без повторов, порядок первого появления. */
export function uniqueValues(values: readonly string[]): string[] {
  return [...new Set(values)];
}

/** Заметки обеих карточек через пустую строку; пустые пропускаем. */
export function joinNotes(
  ...notes: ReadonlyArray<string | null>
): string | null {
  const parts = notes
    .map((note) => note?.trim())
    .filter((note): note is string => Boolean(note));
  return parts.length > 0 ? parts.join('\n\n') : null;
}
