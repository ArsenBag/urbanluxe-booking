import type { CustomFieldValues } from '@crm/shared';
import { customFieldValuesOf } from '../custom-fields/custom-fields.service.js';
import type { Contact } from '../generated/prisma/client.js';
import { joinNotes, uniqueValues } from './merge-values.js';

export type MergeableContact = Pick<
  Contact,
  | 'name'
  | 'phones'
  | 'email'
  | 'source'
  | 'tags'
  | 'notes'
  | 'customFields'
  | 'ownerId'
  | 'avatarFileId'
  | 'avatarHash'
  | 'avatarSource'
  | 'vip'
  | 'blacklistedAt'
  | 'blacklistReason'
  | 'blacklistedById'
  | 'createdAt'
>;

export interface ContactMergeResult {
  data: Omit<MergeableContact, 'customFields'> & {
    customFields: CustomFieldValues;
  };
  /** Фото влитой карточки, которое больше никому не принадлежит: удалить после коммита. */
  orphanAvatarFileId: string | null;
}

/**
 * Поля карточки после объединения: target (клиент диалога) остаётся, source вливается в неё.
 * Телефоны, метки и заметки складываем, пустые поля target берём из source; второй email — в заметки.
 * Если поле карточки заполнено в обеих — остаётся значение target.
 * «Клиент с» и источник — от более ранней карточки: так клиент впервые и пришёл.
 * VIP и чёрный список не теряются: достаточно отметки на одной из карточек (причина — от target, если есть у обеих).
 */
export function mergedContactFields(
  target: MergeableContact,
  source: MergeableContact,
  useSourceName: boolean,
): ContactMergeResult {
  const keepTargetAvatar =
    target.avatarFileId !== null || source.avatarFileId === null;
  const avatar = keepTargetAvatar ? target : source;
  const older = source.createdAt < target.createdAt ? source : target;
  const listed = target.blacklistedAt ? target : source;
  // Поле email одно: второй адрес не выбрасываем, а оставляем в заметках.
  const otherEmail =
    target.email && source.email && target.email !== source.email
      ? `Другой email: ${source.email}`
      : null;
  return {
    data: {
      name: useSourceName ? source.name : target.name,
      phones: uniqueValues([...target.phones, ...source.phones]),
      email: target.email ?? source.email,
      source: older.source,
      tags: uniqueValues([...target.tags, ...source.tags]),
      notes: joinNotes(target.notes, source.notes, otherEmail),
      customFields: {
        ...customFieldValuesOf(source.customFields),
        ...customFieldValuesOf(target.customFields),
      },
      ownerId: target.ownerId ?? source.ownerId,
      avatarFileId: avatar.avatarFileId,
      avatarHash: avatar.avatarHash,
      avatarSource: avatar.avatarSource,
      vip: target.vip || source.vip,
      blacklistedAt: listed.blacklistedAt,
      blacklistReason: listed.blacklistReason,
      blacklistedById: listed.blacklistedById,
      createdAt: older.createdAt,
    },
    orphanAvatarFileId:
      keepTargetAvatar && source.avatarFileId !== target.avatarFileId
        ? source.avatarFileId
        : null,
  };
}
