import { Module } from '@nestjs/common';
import { FilesModule } from '../files/files.module.js';
import { LinkService } from './link.service.js';
import { LinkingController } from './linking.controller.js';
import { MergeService } from './merge.service.js';

@Module({
  imports: [FilesModule],
  controllers: [LinkingController],
  providers: [LinkService, MergeService],
})
export class LinkingModule {}
