import {
  Body,
  Controller,
  Get,
  Param,
  ParseUUIDPipe,
  Post,
  Query,
} from '@nestjs/common';
import {
  linkConversationSchema,
  linkTargetSchema,
  type LinkConversationInput,
  type LinkPreviewDto,
  type LinkResultDto,
  type LinkTarget,
} from '@crm/shared';
import { CurrentUser } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { LinkService } from './link.service.js';

const uuid = () => new ParseUUIDPipe();

/** Связь диалога с бронью или сделкой — доступна всем сотрудникам: это их ежедневная работа во входящих. */
@Controller('conversations/:id')
export class LinkingController {
  constructor(private readonly links: LinkService) {}

  /** Что произойдёт при связывании: какая карточка вольётся, какие сделки можно объединить. */
  @Get('link-preview')
  preview(
    @Param('id', uuid()) id: string,
    @Query(new ZodValidationPipe(linkTargetSchema)) target: LinkTarget,
  ): Promise<LinkPreviewDto> {
    return this.links.preview(id, target);
  }

  @Post('link')
  link(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(linkConversationSchema))
    input: LinkConversationInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<LinkResultDto> {
    return this.links.link(id, input, actor);
  }
}
