import { planDealMerge, type MergeableDeal } from './deal-merge.js';

const OLDER = new Date('2026-09-01T10:00:00Z');
const NEWER = new Date('2026-10-05T10:00:00Z');
const CLOSED = new Date('2026-10-04T10:00:00Z');

function deal(
  overrides: Partial<MergeableDeal> & Pick<MergeableDeal, 'id'>,
): MergeableDeal {
  return {
    title: 'Сделка',
    pipelineId: 'pipeline-1',
    stageId: 'stage-new',
    stagePosition: 0,
    ownerId: null,
    amount: null,
    currency: 'USD',
    checkIn: null,
    checkOut: null,
    guests: null,
    notes: null,
    customFields: {},
    closedAt: null,
    lostReason: null,
    createdAt: NEWER,
    ...overrides,
  };
}

// Обращение из мессенджера (раньше) и сделка, созданная RealtyCalendar по брони (позже).
const inquiry = deal({
  id: 'inquiry',
  title: 'Ваня',
  createdAt: OLDER,
  ownerId: 'manager-1',
  notes: 'Хочет вид на город',
});
const booked = deal({
  id: 'booked',
  title: 'Ivan Petrov',
  stageId: 'stage-booked',
  stagePosition: 3,
  amount: '255.00',
  currency: 'UZS',
  checkIn: new Date('2026-11-10T00:00:00Z'),
  checkOut: new Date('2026-11-13T00:00:00Z'),
});

describe('planDealMerge', () => {
  it('keeps the older deal and moves it to the further stage', () => {
    const plan = planDealMerge(booked, inquiry);

    expect(plan.survivorId).toBe('inquiry');
    expect(plan.absorbedId).toBe('booked');
    expect(plan.stageChanged).toBe(true);
    expect(plan.data).toMatchObject({
      title: 'Ваня',
      pipelineId: 'pipeline-1',
      stageId: 'stage-booked',
      closedAt: null,
    });
  });

  it('takes the stay and the money from the deal whose stage wins', () => {
    const plan = planDealMerge(inquiry, booked);

    expect(plan.data).toMatchObject({
      amount: '255.00',
      currency: 'UZS',
      checkIn: booked.checkIn,
      checkOut: booked.checkOut,
      ownerId: 'manager-1',
      notes: 'Хочет вид на город',
    });
  });

  it('falls back to the other deal for empty details', () => {
    const tentative = deal({
      id: 'tentative',
      createdAt: OLDER,
      guests: 2,
      amount: '100.00',
      currency: 'USD',
    });
    const bare = deal({
      id: 'bare',
      stageId: 'stage-booked',
      stagePosition: 3,
    });

    expect(planDealMerge(tentative, bare).data).toMatchObject({
      guests: 2,
      amount: '100.00',
      currency: 'USD',
    });
  });

  it('prefers an open deal over a closed one, whatever the stage order', () => {
    const lostInquiry = deal({
      id: 'lost',
      createdAt: OLDER,
      stageId: 'stage-lost',
      stagePosition: 9,
      closedAt: CLOSED,
      lostReason: 'Не ответил',
    });

    const plan = planDealMerge(lostInquiry, booked);

    expect(plan.survivorId).toBe('lost');
    expect(plan.data).toMatchObject({
      stageId: 'stage-booked',
      closedAt: null,
      lostReason: null,
    });
  });

  it('keeps the survivor stage when it is already further along', () => {
    const living = deal({
      id: 'living',
      createdAt: OLDER,
      stageId: 'stage-living',
      stagePosition: 5,
    });

    const plan = planDealMerge(living, booked);

    expect(plan.stageChanged).toBe(false);
    expect(plan.data.stageId).toBe('stage-living');
  });

  it('keeps the survivor pipeline when the deals are in different pipelines', () => {
    const other = deal({
      id: 'other',
      createdAt: OLDER,
      pipelineId: 'pipeline-2',
      stageId: 'stage-x',
      stagePosition: 0,
    });

    const plan = planDealMerge(other, booked);

    expect(plan.data).toMatchObject({
      pipelineId: 'pipeline-2',
      stageId: 'stage-x',
    });
  });

  it('joins notes and custom fields of both deals', () => {
    const a = deal({
      id: 'a',
      createdAt: OLDER,
      notes: 'Первая',
      customFields: { floor: 'high', bed: 'double' },
    });
    const b = deal({
      id: 'b',
      notes: 'Вторая',
      customFields: { floor: 'low', parking: true },
      stageId: 'stage-booked',
      stagePosition: 3,
    });

    const plan = planDealMerge(a, b);

    expect(plan.data.notes).toBe('Первая\n\nВторая');
    expect(plan.data.customFields).toEqual({
      floor: 'low',
      bed: 'double',
      parking: true,
    });
  });
});
