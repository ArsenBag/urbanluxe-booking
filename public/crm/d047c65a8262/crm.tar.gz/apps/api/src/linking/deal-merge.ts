import type { CustomFieldValues } from '@crm/shared';
import { customFieldValuesOf } from '../custom-fields/custom-fields.service.js';
import type { Deal, Prisma } from '../generated/prisma/client.js';
import { joinNotes } from './merge-values.js';

export type MergeableDeal = Pick<
  Deal,
  | 'id'
  | 'title'
  | 'pipelineId'
  | 'stageId'
  | 'ownerId'
  | 'currency'
  | 'checkIn'
  | 'checkOut'
  | 'guests'
  | 'notes'
  | 'customFields'
  | 'closedAt'
  | 'lostReason'
  | 'createdAt'
> & {
  /** Decimal из базы или строка (в тестах). */
  amount: Prisma.Decimal | string | null;
  /** Позиция этапа в воронке: чем больше, тем дальше сделка продвинулась. */
  stagePosition: number;
};

export interface DealMergePlan {
  survivorId: string;
  absorbedId: string;
  /** Этап взят у поглощённой сделки — карточку ставим в конец этого этапа. */
  stageChanged: boolean;
  data: Pick<
    MergeableDeal,
    | 'title'
    | 'pipelineId'
    | 'stageId'
    | 'closedAt'
    | 'lostReason'
    | 'ownerId'
    | 'amount'
    | 'currency'
    | 'checkIn'
    | 'checkOut'
    | 'guests'
    | 'notes'
  > & { customFields: CustomFieldValues };
}

/**
 * Сделка, чей этап получит объединённая: открытая важнее закрытой, в одной воронке — та, что дальше.
 * В разных воронках этапы несравнимы — остаётся этап сохраняемой сделки.
 */
function stageWinner(
  survivor: MergeableDeal,
  absorbed: MergeableDeal,
): MergeableDeal {
  const survivorOpen = survivor.closedAt === null;
  if (survivorOpen !== (absorbed.closedAt === null)) {
    return survivorOpen ? survivor : absorbed;
  }
  if (survivor.pipelineId !== absorbed.pipelineId) return survivor;
  return absorbed.stagePosition > survivor.stagePosition ? absorbed : survivor;
}

/**
 * Объединение двух сделок одного гостя (обращение из мессенджера и сделка брони).
 * Сохраняется более ранняя — с неё начался путь гостя, по ней считается воронка; поглощённая удаляется.
 * Даты, сумма и гости — от сделки с победившим этапом (обычно это сделка брони), пустые — из другой.
 */
export function planDealMerge(
  a: MergeableDeal,
  b: MergeableDeal,
): DealMergePlan {
  const [survivor, absorbed] = b.createdAt < a.createdAt ? [b, a] : [a, b];
  const primary = stageWinner(survivor, absorbed);
  const secondary = primary === survivor ? absorbed : survivor;
  const money = primary.amount !== null ? primary : secondary;
  const stay =
    primary.checkIn !== null || primary.checkOut !== null ? primary : secondary;
  return {
    survivorId: survivor.id,
    absorbedId: absorbed.id,
    stageChanged: primary !== survivor,
    data: {
      title: survivor.title,
      pipelineId: primary.pipelineId,
      stageId: primary.stageId,
      closedAt: primary.closedAt,
      lostReason: primary.lostReason,
      ownerId: survivor.ownerId ?? absorbed.ownerId,
      amount: money.amount,
      currency: money.currency,
      checkIn: stay.checkIn,
      checkOut: stay.checkOut,
      guests: primary.guests ?? secondary.guests,
      notes: joinNotes(survivor.notes, absorbed.notes),
      customFields: {
        ...customFieldValuesOf(secondary.customFields),
        ...customFieldValuesOf(primary.customFields),
      },
    },
  };
}
