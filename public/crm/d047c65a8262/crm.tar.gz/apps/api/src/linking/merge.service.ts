import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { POSITION_STEP } from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import type { Prisma } from '../generated/prisma/client.js';
import { mergedContactFields } from './contact-merge.js';
import { planDealMerge } from './deal-merge.js';

type Tx = Prisma.TransactionClient;

export interface ContactMergeOutcome {
  /** Фото влитой карточки, которое больше не нужно: удалить после коммита. */
  orphanAvatarFileId: string | null;
}

/**
 * Объединение дублей: карточка клиента из брони RealtyCalendar и карточка из мессенджера,
 * сделка-обращение и сделка брони. Работает внутри транзакции вызывающего.
 */
@Injectable()
export class MergeService {
  constructor(private readonly audit: ActivityLogService) {}

  /** Вливает карточку source в target: всё, что было у source, переезжает, сама карточка удаляется. */
  async mergeContacts(
    tx: Tx,
    targetId: string,
    sourceId: string,
    useSourceName: boolean,
    actor: SessionUser,
  ): Promise<ContactMergeOutcome> {
    // Порядок блокировок по id: два встречных объединения не заблокируют друг друга навсегда.
    await tx.$queryRaw`SELECT id::text FROM contacts WHERE id = ANY(${[targetId, sourceId]}::uuid[]) ORDER BY id FOR UPDATE`;
    const target = await tx.contact.findUnique({ where: { id: targetId } });
    const source = await tx.contact.findUnique({ where: { id: sourceId } });
    if (!target || !source) {
      throw new NotFoundException(
        'Клиент не найден — возможно, карточку уже объединили',
      );
    }
    const move = {
      where: { contactId: sourceId },
      data: { contactId: targetId },
    };
    const moved = {
      bookings: (await tx.booking.updateMany(move)).count,
      deals: (await tx.deal.updateMany(move)).count,
      conversations: (await tx.conversation.updateMany(move)).count,
    };
    await tx.task.updateMany(move);
    await tx.contactChannel.updateMany(move);
    // История влитой карточки остаётся видна в объединённой.
    await tx.activityLog.updateMany({
      where: { entityType: 'contact', entityId: sourceId },
      data: { entityId: targetId },
    });

    const { data, orphanAvatarFileId } = mergedContactFields(
      target,
      source,
      useSourceName,
    );
    await tx.contact.update({ where: { id: targetId }, data });
    // Сделки, названные по прежнему имени (автосделки), переименовываем вместе с клиентом — как при входящих.
    if (data.name !== target.name) {
      await tx.deal.updateMany({
        where: { contactId: targetId, title: target.name },
        data: { title: data.name },
      });
    }
    await tx.contact.delete({ where: { id: sourceId } });
    await this.audit.record(
      actor,
      {
        action: 'contact.merged',
        entityType: 'contact',
        entityId: targetId,
        payload: { sourceContactId: sourceId, ...moved },
      },
      tx,
    );
    return { orphanAvatarFileId };
  }

  /** Объединяет две сделки одного клиента; возвращает id оставшейся. */
  async mergeDeals(
    tx: Tx,
    firstId: string,
    secondId: string,
    actor: SessionUser,
  ): Promise<string> {
    // Как на канбане: сначала этапы, потом строки сделок. Обратный порядок с переносом карточки
    // в тот же момент дал бы взаимную блокировку.
    const stages = await tx.deal.findMany({
      where: { id: { in: [firstId, secondId] } },
      select: { stageId: true },
    });
    for (const stageId of [
      ...new Set(stages.map((deal) => deal.stageId)),
    ].sort()) {
      await this.lockStage(tx, stageId);
    }
    await tx.$queryRaw`SELECT id::text FROM deals WHERE id = ANY(${[firstId, secondId]}::uuid[]) ORDER BY id FOR UPDATE`;
    const deals = await tx.deal.findMany({
      where: { id: { in: [firstId, secondId] } },
      include: { stage: { select: { position: true } } },
    });
    const [first, second] = [firstId, secondId].map((id) =>
      deals.find((deal) => deal.id === id),
    );
    if (!first || !second) {
      throw new ConflictException(
        'Сделка уже удалена или объединена. Обновите страницу.',
      );
    }
    const plan = planDealMerge(
      { ...first, stagePosition: first.stage.position },
      { ...second, stagePosition: second.stage.position },
    );
    const absorbed = plan.absorbedId === first.id ? first : second;

    const move = {
      where: { dealId: plan.absorbedId },
      data: { dealId: plan.survivorId },
    };
    await tx.booking.updateMany(move);
    await tx.task.updateMany(move);
    await tx.activityLog.updateMany({
      where: { entityType: 'deal', entityId: plan.absorbedId },
      data: { entityId: plan.survivorId },
    });
    await tx.deal.delete({ where: { id: plan.absorbedId } });
    await tx.deal.update({
      where: { id: plan.survivorId },
      data: {
        ...plan.data,
        ...(plan.stageChanged && {
          position: await this.endOfStage(tx, plan.data.stageId),
        }),
      },
    });
    await this.audit.record(
      actor,
      {
        action: 'deal.merged',
        entityType: 'deal',
        entityId: plan.survivorId,
        payload: { title: absorbed.title, absorbedDealId: plan.absorbedId },
      },
      tx,
    );
    return plan.survivorId;
  }

  /** Блокировка этапа — та же, что при переносе карточек на канбане (повторно брать можно). */
  private async lockStage(tx: Tx, stageId: string): Promise<void> {
    await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${stageId}))::text AS locked`;
  }

  /** Конец колонки этапа. */
  private async endOfStage(tx: Tx, stageId: string): Promise<number> {
    await this.lockStage(tx, stageId);
    const last = await tx.deal.findFirst({
      where: { stageId },
      orderBy: { position: 'desc' },
      select: { position: true },
    });
    return (last?.position ?? 0) + POSITION_STEP;
  }
}
