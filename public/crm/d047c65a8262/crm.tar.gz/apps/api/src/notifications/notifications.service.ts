import { Injectable } from '@nestjs/common';
import {
  isAnsweredCall,
  messagePreview,
  type BookingNotification,
  type MessageAttachment,
  type MessageNotification,
  type NotificationFeedDto,
} from '@crm/shared';
import type { SessionUser } from '../auth/session-user.js';
import { tashkentToday } from '../automations/automation-schedule.js';
import { dateOnlyFromDb, dateOnlyToDb } from '../common/dates.js';
import { PrismaService } from '../prisma/prisma.service.js';

/**
 * Запас назад от курсора: приём сообщения мог закоммититься позже, чем выдан курсор,
 * а время записи в БД — начало транзакции. Повторы браузер отбрасывает по id.
 */
const CURSOR_OVERLAP_MS = 60_000;
/** Компьютер проснулся через час — уведомляем только о свежем, старое видно в разделах. */
const MAX_LOOKBACK_MS = 10 * 60_000;
/**
 * Импорт истории сохраняет сообщения с давним временем отправки — о них не уведомляем.
 * Флага «из истории» у сообщения нет: импортированное за последний час всё же уведомит,
 * а сообщение, доставленное с опозданием больше часа, — нет.
 */
const MAX_MESSAGE_AGE_MS = 60 * 60_000;
const MAX_EVENTS = 20;

/** Новые события для уведомлений сотрудника: входящие в его и неназначенных чатах, новые брони. */
@Injectable()
export class NotificationsService {
  constructor(private readonly prisma: PrismaService) {}

  async feed(
    actor: SessionUser,
    after: string | undefined,
  ): Promise<NotificationFeedDto> {
    const now = new Date();
    const cursor = now.toISOString();
    if (!after) return { cursor, events: [] };
    const since = new Date(
      Math.max(
        new Date(after).getTime() - CURSOR_OVERLAP_MS,
        now.getTime() - MAX_LOOKBACK_MS,
      ),
    );
    const messages = await this.messageEvents(actor, since, now);
    const bookings = await this.bookingEvents(since, now);
    const events = [...messages, ...bookings].sort((a, b) =>
      a.at.localeCompare(b.at),
    );
    return { cursor, events };
  }

  private async messageEvents(
    actor: SessionUser,
    since: Date,
    now: Date,
  ): Promise<MessageNotification[]> {
    const messages = await this.prisma.message.findMany({
      where: {
        direction: 'IN',
        createdAt: { gt: since },
        sentAt: { gt: new Date(now.getTime() - MAX_MESSAGE_AGE_MS) },
        conversation: { OR: [{ assigneeId: actor.id }, { assigneeId: null }] },
      },
      include: {
        conversation: {
          select: {
            id: true,
            channel: { select: { type: true } },
            contact: { select: { name: true, blacklistedAt: true } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: MAX_EVENTS,
    });
    return messages.flatMap((message) => {
      const attachment =
        (message.attachment as MessageAttachment | null) ?? null;
      if (isAnsweredCall(attachment)) return [];
      return [
        {
          kind: 'message' as const,
          id: message.id,
          at: message.createdAt.toISOString(),
          conversationId: message.conversation.id,
          contactName: message.conversation.contact.name,
          channelType: message.conversation.channel.type,
          preview: messagePreview(message.text, attachment, {
            direction: 'IN',
          }),
          blacklisted: message.conversation.contact.blacklistedAt !== null,
        },
      ];
    });
  }

  /**
   * Брони, впервые пришедшие вебхуком RealtyCalendar (строки из выгрузки Excel — нет).
   * Старая бронь, которую вебхук не сопоставил с выгрузкой, тоже окажется «новой» —
   * поэтому брони с уже прошедшим выездом не показываем.
   */
  private async bookingEvents(
    since: Date,
    now: Date,
  ): Promise<BookingNotification[]> {
    const bookings = await this.prisma.booking.findMany({
      where: {
        createdAt: { gt: since },
        rcId: { not: null },
        status: { in: ['BOOKED', 'REQUEST'] },
        checkOut: { gte: dateOnlyToDb(tashkentToday(now)) },
      },
      include: {
        property: { select: { title: true } },
        contact: { select: { blacklistedAt: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: MAX_EVENTS,
    });
    return bookings.map((booking) => ({
      kind: 'booking' as const,
      id: booking.id,
      at: booking.createdAt.toISOString(),
      status: booking.status === 'REQUEST' ? 'REQUEST' : 'BOOKED',
      propertyTitle: booking.property?.title ?? null,
      guestName: booking.guestName,
      checkIn: dateOnlyFromDb(booking.checkIn),
      checkOut: dateOnlyFromDb(booking.checkOut),
      origin: booking.origin,
      blacklisted: Boolean(booking.contact?.blacklistedAt),
    }));
  }
}
