import { Controller, Get, Query } from '@nestjs/common';
import {
  notificationFeedQuerySchema,
  type NotificationFeedDto,
  type NotificationFeedQuery,
} from '@crm/shared';
import { CurrentUser } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { NotificationsService } from './notifications.service.js';

@Controller('notifications')
export class NotificationsController {
  constructor(private readonly notifications: NotificationsService) {}

  /** Браузер опрашивает каждые несколько секунд, передавая курсор из прошлого ответа. */
  @Get()
  feed(
    @Query(new ZodValidationPipe(notificationFeedQuerySchema)) query: NotificationFeedQuery,
    @CurrentUser() actor: SessionUser,
  ): Promise<NotificationFeedDto> {
    return this.notifications.feed(actor, query.after);
  }
}
