import { existsSync } from 'node:fs';
import { resolve } from 'node:path';

/** Путь к .env в корне монорепо. Скрипты пакета запускаются из apps/api. */
const ROOT_ENV_PATH = resolve(process.cwd(), '../../.env');

/**
 * Загружает общий .env из корня монорепо.
 * Если файла нет (в проде переменные задаёт окружение), ничего не делает.
 */
export function loadRootEnv(): void {
  if (existsSync(ROOT_ENV_PATH)) {
    process.loadEnvFile(ROOT_ENV_PATH);
  }
}
