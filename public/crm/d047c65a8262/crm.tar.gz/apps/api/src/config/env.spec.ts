import { loadEnv } from './env.js';

const base = { DATABASE_URL: 'postgresql://u:p@localhost:5432/db', JWT_SECRET: 'x'.repeat(32) };

describe('loadEnv', () => {
  it('applies defaults', () => {
    const env = loadEnv(base);

    expect(env.API_PORT).toBe(4000);
    expect(env.SESSION_TTL_HOURS).toBe(168);
  });

  it('fails fast on a short JWT secret', () => {
    expect(() => loadEnv({ ...base, JWT_SECRET: 'short' })).toThrow(/JWT_SECRET/);
  });

  it('fails fast when DATABASE_URL is missing', () => {
    expect(() => loadEnv({ JWT_SECRET: base.JWT_SECRET })).toThrow(/DATABASE_URL/);
  });
});

describe('loadEnv with empty values', () => {
  it('treats KEY= as not set', () => {
    const env = loadEnv({ ...base, TELEGRAM_API_ID: '', TELEGRAM_API_HASH: '', RC_WEBHOOK_SECRET: '' });

    expect(env.TELEGRAM_API_ID).toBeUndefined();
    expect(env.RC_WEBHOOK_SECRET).toBeUndefined();
  });
});

describe('loadEnv in production', () => {
  const production = { ...base, NODE_ENV: 'production', WEB_ORIGIN: 'https://crm.example.uz' };

  it('accepts https addresses', () => {
    expect(loadEnv({ ...production, PUBLIC_API_URL: 'https://crm.example.uz' }).WEB_ORIGIN).toBe('https://crm.example.uz');
  });

  it('refuses to start over plain http', () => {
    expect(() => loadEnv({ ...production, WEB_ORIGIN: 'http://crm.example.uz' })).toThrow(/WEB_ORIGIN/);
    expect(() => loadEnv({ ...production, PUBLIC_API_URL: 'http://crm.example.uz' })).toThrow(/PUBLIC_API_URL/);
  });

  it('keeps http allowed in development', () => {
    expect(loadEnv({ ...base, WEB_ORIGIN: 'http://localhost:3000' }).WEB_ORIGIN).toBe('http://localhost:3000');
  });
});
