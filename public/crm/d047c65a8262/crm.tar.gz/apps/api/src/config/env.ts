import { z } from 'zod';

const JWT_SECRET_MIN_LENGTH = 32;

const envSchema = z
  .object({
    NODE_ENV: z
      .enum(['development', 'test', 'production'])
      .default('development'),
    API_PORT: z.coerce.number().int().positive().default(4000),
    DATABASE_URL: z
      .string()
      .url('DATABASE_URL должен быть URL подключения к PostgreSQL'),
    /**
     * Размер пула соединений с БД. Для локальной БД без Docker (prisma dev / PGlite) ставьте 1:
     * она не выдерживает параллельных соединений. В проде не задаётся (по умолчанию 10).
     */
    DATABASE_POOL_MAX: z.coerce.number().int().positive().optional(),
    WEB_ORIGIN: z.string().url().default('http://localhost:3000'),
    /** Папка для файлов из переписки (фото, голосовые, документы). В проде — том Docker. */
    FILES_DIR: z.string().min(1).default('data/files'),
    JWT_SECRET: z
      .string()
      .min(
        JWT_SECRET_MIN_LENGTH,
        `JWT_SECRET должен быть не короче ${JWT_SECRET_MIN_LENGTH} символов`,
      ),
    SESSION_TTL_HOURS: z.coerce.number().int().positive().default(168),
    /**
     * Каким прокси доверять при определении IP клиента (настройка Express "trust proxy"):
     * "loopback" — прокси на этой же машине, "1" — один прокси перед API, либо подсеть "10.0.0.0/8".
     */
    TRUST_PROXY: z.string().min(1).default('loopback'),
    /** Ключи приложения Telegram с my.telegram.org. Без них подключение Telegram недоступно. */
    TELEGRAM_API_ID: z.coerce.number().int().positive().optional(),
    TELEGRAM_API_HASH: z
      .string()
      .regex(/^[0-9a-f]{32}$/, 'TELEGRAM_API_HASH — 32 символа 0-9a-f')
      .optional(),
    /** Ключ шифрования сессий мессенджеров в БД: openssl rand -base64 32. */
    CHANNEL_SECRET_KEY: z.string().optional(),
    /**
     * Секрет в адресе вебхука RealtyCalendar. RealtyCalendar не подписывает запросы,
     * поэтому защита — длинный случайный адрес: openssl rand -hex 24.
     */
    RC_WEBHOOK_SECRET: z
      .string()
      .min(24, 'RC_WEBHOOK_SECRET — минимум 24 символа')
      .optional(),
    /** Публичный адрес API (https://crm.example.uz) — для показа адреса вебхука в настройках. */
    PUBLIC_API_URL: z.string().url().optional(),
    /**
     * Мост с PMS Urban Luxe (менеджер каналов, 2026-10-16). Все четыре пусты — модуль молчит, CRM работает как прежде.
     * PMS_API_KEY — секретный ключ организации High Life из PMS («Интеграции → API-ключи», права read/book/cancel/manage).
     */
    PMS_API_URL: z.string().url().default('https://urbanluxe.cc/api/v1'),
    PMS_API_KEY: z.string().min(16).optional(),
    /** Секрет вебхука PMS (whsec_…): им подписан каждый запрос на /api/webhooks/urbanluxe. */
    PMS_WEBHOOK_SECRET: z.string().min(16).optional(),
    /** Адрес шахматки PMS для ссылок «Открыть в PMS». */
    PMS_WEB_URL: z.string().url().default('https://urbanluxe.cc/pms'),
    /**
     * true — брони PMS с источником RealtyCalendar пропускать (CRM получает их своим вебхуком RC; переходный период
     * у High Life). false (по умолчанию) — принимать все брони PMS (CRM Urban Luxe, где вебхука RC нет).
     */
    PMS_SKIP_RC: z
      .enum(['true', 'false'])
      .default('false')
      .transform((value) => value === 'true'),
    /** Валюта сумм в RealtyCalendar (настройка агентства). */
    RC_CURRENCY: z.enum(['USD', 'UZS']).default('USD'),
    /** Автоматизации по броням (перенос сделок, автосообщения). Выключаются в тестах. */
    AUTOMATIONS_ENABLED: z
      .enum(['true', 'false'])
      .default('true')
      .transform((value) => value === 'true'),
    /** Пауза между запросами фото профиля: личный аккаунт Telegram не должен выглядеть как бот. */
    AVATAR_REQUEST_GAP_MS: z.coerce.number().int().min(0).default(2000),
    /**
     * Когда повторять скачивание файла, если оно не удалось при приёме сообщения (мс через запятую):
     * сразу, через минуту и через 10 минут — мессенджер мог ещё не выложить файл.
     */
    ATTACHMENT_RETRY_DELAYS_MS: z
      .string()
      .regex(/^\d+(,\d+)*$/, 'ATTACHMENT_RETRY_DELAYS_MS — числа через запятую')
      .default('0,60000,600000')
      .transform((value) => value.split(',').map(Number)),
    /** WhatsApp через Green-API (https://console.green-api.com): адрес API, id и токен инстанса. */
    GREEN_API_URL: z.string().url().default('https://api.green-api.com'),
    /** Адрес для загрузки файлов (mediaUrl в личном кабинете Green-API). Не задан — GREEN_API_URL. */
    GREEN_API_MEDIA_URL: z.string().url().optional(),
    GREEN_API_ID_INSTANCE: z
      .string()
      .regex(/^\d+$/, 'GREEN_API_ID_INSTANCE — число')
      .optional(),
    GREEN_API_TOKEN: z.string().min(10).optional(),
    /** Токен, который Green-API присылает в заголовке Authorization вебхука: openssl rand -hex 24. */
    GREEN_API_WEBHOOK_TOKEN: z
      .string()
      .min(24, 'GREEN_API_WEBHOOK_TOKEN — минимум 24 символа')
      .optional(),
  })
  .superRefine((env, context) => {
    if (Boolean(env.TELEGRAM_API_ID) !== Boolean(env.TELEGRAM_API_HASH)) {
      context.addIssue({
        code: 'custom',
        path: ['TELEGRAM_API_HASH'],
        message: 'Укажите и TELEGRAM_API_ID, и TELEGRAM_API_HASH',
      });
    }
    if (Boolean(env.GREEN_API_ID_INSTANCE) !== Boolean(env.GREEN_API_TOKEN)) {
      context.addIssue({
        code: 'custom',
        path: ['GREEN_API_TOKEN'],
        message: 'Укажите и GREEN_API_ID_INSTANCE, и GREEN_API_TOKEN',
      });
    }
    if (env.GREEN_API_ID_INSTANCE && !env.GREEN_API_WEBHOOK_TOKEN) {
      context.addIssue({
        code: 'custom',
        path: ['GREEN_API_WEBHOOK_TOKEN'],
        message: 'Нужен для защиты вебхука WhatsApp',
      });
    }
    if (env.TELEGRAM_API_ID && !env.CHANNEL_SECRET_KEY) {
      context.addIssue({
        code: 'custom',
        path: ['CHANNEL_SECRET_KEY'],
        message: 'Нужен для хранения сессии Telegram',
      });
    }
    // В проде cookie сессии отдаётся только по HTTPS (Secure, __Host-): по http вход просто не заработает.
    if (env.NODE_ENV === 'production') {
      for (const key of ['WEB_ORIGIN', 'PUBLIC_API_URL'] as const) {
        const value = env[key];
        if (value && !value.startsWith('https://')) {
          context.addIssue({
            code: 'custom',
            path: [key],
            message: `${key} в проде должен начинаться с https://`,
          });
        }
      }
    }
  });

export type Env = z.infer<typeof envSchema>;

/** Проверяет переменные окружения при старте и падает с понятной ошибкой. */
export function loadEnv(source: NodeJS.ProcessEnv = process.env): Env {
  // «KEY=» в .env означает «не задано», а не пустую строку (иначе необязательные числа не пройдут).
  const defined = Object.fromEntries(
    Object.entries(source).filter(([, value]) => value !== ''),
  );
  const result = envSchema.safeParse(defined);
  if (!result.success) {
    const details = result.error.issues
      .map((issue) => `  - ${issue.path.join('.')}: ${issue.message}`)
      .join('\n');
    throw new Error(`Некорректные переменные окружения:\n${details}`);
  }
  return result.data;
}

export const ENV = Symbol('ENV');
