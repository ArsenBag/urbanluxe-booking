import { contactIdsByPhoneDigits } from '../contacts/contact-phone-search.js';
import type { Prisma } from '../generated/prisma/client.js';
import type { PrismaService } from '../prisma/prisma.service.js';

/** Сделки по тексту: название сделки, имя клиента (без учёта регистра) или цифры его телефона. */
export async function dealTextCondition(
  prisma: PrismaService,
  text: string,
): Promise<Prisma.DealWhereInput> {
  const phoneMatches = await contactIdsByPhoneDigits(prisma, text);
  return {
    OR: [
      { title: { contains: text, mode: 'insensitive' } },
      { contact: { name: { contains: text, mode: 'insensitive' } } },
      ...(phoneMatches.length > 0 ? [{ contactId: { in: phoneMatches } }] : []),
    ],
  };
}
