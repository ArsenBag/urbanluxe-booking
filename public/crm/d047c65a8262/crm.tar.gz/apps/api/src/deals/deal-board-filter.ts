import { NO_OWNER_FILTER, type DealBoardQuery } from '@crm/shared';
import {
  dateOnlyToDb,
  tashkentDayEnd,
  tashkentDayStart,
} from '../common/dates.js';
import type { Prisma } from '../generated/prisma/client.js';

/** Закрытые сделки показываем на доске ещё столько дней, потом они уходят в архив. */
const CLOSED_VISIBLE_DAYS = 30;
const MS_PER_DAY = 86_400_000;

/** Диапазон дней по Ташкенту для колонки времени; без обеих границ — без условия. */
function dayRange(
  from: string | undefined,
  to: string | undefined,
): Prisma.DateTimeFilter | undefined {
  if (!from && !to) return undefined;
  return {
    ...(from && { gte: tashkentDayStart(from) }),
    ...(to && { lt: tashkentDayEnd(to) }),
  };
}

/** Диапазон для колонки-даты без времени (дата заезда): обе границы включительно. */
function dateOnlyRange(
  from: string | undefined,
  to: string | undefined,
): Prisma.DateTimeNullableFilter | undefined {
  if (!from && !to) return undefined;
  return {
    ...(from && { gte: dateOnlyToDb(from) }),
    ...(to && { lte: dateOnlyToDb(to) }),
  };
}

function ownerCondition(ownerIds: string[]): Prisma.DealWhereInput {
  const ids = ownerIds.filter((id) => id !== NO_OWNER_FILTER);
  return {
    OR: [
      ...(ids.length > 0 ? [{ ownerId: { in: ids } }] : []),
      ...(ownerIds.includes(NO_OWNER_FILTER) ? [{ ownerId: null }] : []),
    ],
  };
}

/**
 * Условие выборки канбана. Без фильтра по закрытию — открытые и недавно закрытые сделки;
 * с ним — только закрытые в этот период, сколько бы времени ни прошло. Фильтр по заезду пропускает
 * только сделки с датой заезда.
 */
export function dealBoardWhere(
  query: DealBoardQuery,
  now: Date,
  /** Условие поиска по тексту (dealTextCondition): ему нужен запрос в базу, поэтому считается заранее. */
  text: Prisma.DealWhereInput | undefined,
): Prisma.DealWhereInput {
  const closed = dayRange(query.closedFrom, query.closedTo);
  const created = dayRange(query.createdFrom, query.createdTo);
  const checkIn = dateOnlyRange(query.checkInFrom, query.checkInTo);
  const closedSince = new Date(
    now.getTime() - CLOSED_VISIBLE_DAYS * MS_PER_DAY,
  );
  const conditions: Prisma.DealWhereInput[] = [
    { pipelineId: query.pipelineId },
    closed
      ? { closedAt: { not: null, ...closed } }
      : { OR: [{ closedAt: null }, { closedAt: { gte: closedSince } }] },
    ...(created ? [{ createdAt: created }] : []),
    ...(checkIn ? [{ checkIn }] : []),
    ...(text ? [text] : []),
    ...(query.ownerIds?.length ? [ownerCondition(query.ownerIds)] : []),
    ...(query.sources?.length
      ? [{ contact: { source: { in: query.sources } } }]
      : []),
  ];
  return { AND: conditions };
}
