import { closingStateFor } from './deal-closing.js';

const NOW = new Date('2026-10-04T12:00:00Z');
const EARLIER = new Date('2026-10-01T09:00:00Z');
const open = { closedAt: null, lostReason: null };

describe('closingStateFor', () => {
  it('stamps closedAt when a deal moves to a won stage', () => {
    expect(closingStateFor('WON', open, undefined, NOW)).toEqual({ closedAt: NOW, lostReason: null });
  });

  it('keeps the original close time when moving between closed stages', () => {
    const closed = { closedAt: EARLIER, lostReason: null };

    expect(closingStateFor('LOST', closed, 'Дорого', NOW)).toEqual({ closedAt: EARLIER, lostReason: 'Дорого' });
  });

  it('reopens a deal moved back to an open stage and clears the lost reason', () => {
    const lost = { closedAt: EARLIER, lostReason: 'Дорого' };

    expect(closingStateFor('OPEN', lost, undefined, NOW)).toEqual({ closedAt: null, lostReason: null });
  });

  it('keeps an existing lost reason when none is provided', () => {
    const lost = { closedAt: EARLIER, lostReason: 'Нет дат' };

    expect(closingStateFor('LOST', lost, undefined, NOW).lostReason).toBe('Нет дат');
  });

  it('drops the lost reason on a won stage', () => {
    const lost = { closedAt: EARLIER, lostReason: 'Нет дат' };

    expect(closingStateFor('WON', lost, undefined, NOW).lostReason).toBeNull();
  });
});
