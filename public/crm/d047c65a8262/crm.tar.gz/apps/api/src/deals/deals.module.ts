import { Module } from '@nestjs/common';
import { StageAutomationModule } from '../stage-automation/stage-automation.module.js';
import { DealsController } from './deals.controller.js';
import { DealsService } from './deals.service.js';

@Module({
  imports: [StageAutomationModule],
  controllers: [DealsController],
  providers: [DealsService],
})
export class DealsModule {}
