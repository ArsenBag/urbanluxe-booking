import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import {
  createDealSchema,
  dealBoardQuerySchema,
  linkSearchQuerySchema,
  moveDealSchema,
  updateDealSchema,
  type ActivityDto,
  type CreateDealInput,
  type DealBoardQuery,
  type DealDto,
  type LinkSearchQuery,
  type MoveDealInput,
  type UpdateDealInput,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import { CurrentUser, Roles } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { DealsService } from './deals.service.js';

const uuid = () => new ParseUUIDPipe();

@Controller()
export class DealsController {
  constructor(
    private readonly deals: DealsService,
    private readonly audit: ActivityLogService,
  ) {}

  @Get('deals')
  board(
    @Query(new ZodValidationPipe(dealBoardQuerySchema)) query: DealBoardQuery,
  ): Promise<DealDto[]> {
    return this.deals.board(query);
  }

  @Get('contacts/:id/deals')
  listByContact(@Param('id', uuid()) contactId: string): Promise<DealDto[]> {
    return this.deals.listByContact(contactId);
  }

  /** Поиск сделки из диалога: название, имя или телефон клиента. Объявлен до deals/:id. */
  @Get('deals/search')
  search(
    @Query(new ZodValidationPipe(linkSearchQuerySchema)) query: LinkSearchQuery,
  ): Promise<DealDto[]> {
    return this.deals.search(query.q);
  }

  @Get('deals/:id')
  get(@Param('id', uuid()) id: string): Promise<DealDto> {
    return this.deals.get(id);
  }

  @Get('deals/:id/activity')
  activity(@Param('id', uuid()) id: string): Promise<ActivityDto[]> {
    return this.audit.historyForDeal(id);
  }

  @Post('deals')
  create(
    @Body(new ZodValidationPipe(createDealSchema)) input: CreateDealInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<DealDto> {
    return this.deals.create(input, actor);
  }

  @Patch('deals/:id')
  update(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(updateDealSchema)) input: UpdateDealInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<DealDto> {
    return this.deals.update(id, input, actor);
  }

  @Post('deals/:id/move')
  move(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(moveDealSchema)) input: MoveDealInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<DealDto> {
    return this.deals.move(id, input, actor);
  }

  @Delete('deals/:id')
  @Roles('ADMIN')
  remove(
    @Param('id', uuid()) id: string,
    @CurrentUser() actor: SessionUser,
  ): Promise<null> {
    return this.deals.remove(id, actor);
  }
}
