import type { StageKind } from '@crm/shared';

export interface ClosingState {
  closedAt: Date | null;
  lostReason: string | null;
}

/**
 * Как меняется статус закрытия сделки при переходе между этапами.
 * В открытый этап — сделка снова в работе. В закрытый — фиксируем время закрытия,
 * причина отказа сохраняется только для этапа «Отказ».
 */
export function closingStateFor(
  targetKind: StageKind,
  current: ClosingState,
  lostReason: string | null | undefined,
  now: Date,
): ClosingState {
  if (targetKind === 'OPEN') {
    return { closedAt: null, lostReason: null };
  }
  return {
    closedAt: current.closedAt ?? now,
    lostReason: targetKind === 'LOST' ? (lostReason ?? current.lostReason) : null,
  };
}
