import type { Currency, DealDto } from '@crm/shared';
import { dateOnlyFromDb } from '../common/dates.js';
import { toEntityRef, USER_REF_SELECT } from '../common/entity-refs.js';
import { customFieldValuesOf } from '../custom-fields/custom-fields.service.js';
import type { Deal, StageKind } from '../generated/prisma/client.js';

export const DEAL_INCLUDE = {
  contact: { select: { id: true, name: true, phones: true } },
  owner: USER_REF_SELECT,
  stage: { select: { kind: true } },
  _count: { select: { tasks: { where: { isDone: false } } } },
} as const;

export type DealWithRelations = Deal & {
  contact: { id: string; name: string; phones: string[] };
  owner: { id: string; name: string } | null;
  stage: { kind: StageKind };
  _count: { tasks: number };
};

export function toDealDto(deal: DealWithRelations): DealDto {
  return {
    id: deal.id,
    title: deal.title,
    pipelineId: deal.pipelineId,
    stageId: deal.stageId,
    stageKind: deal.stage.kind,
    contact: deal.contact,
    owner: toEntityRef(deal.owner),
    amount: deal.amount?.toString() ?? null,
    currency: deal.currency as Currency,
    checkIn: deal.checkIn ? dateOnlyFromDb(deal.checkIn) : null,
    checkOut: deal.checkOut ? dateOnlyFromDb(deal.checkOut) : null,
    guests: deal.guests,
    notes: deal.notes,
    position: deal.position,
    closedAt: deal.closedAt?.toISOString() ?? null,
    lostReason: deal.lostReason,
    openTasksCount: deal._count.tasks,
    customFields: customFieldValuesOf(deal.customFields),
    createdAt: deal.createdAt.toISOString(),
    updatedAt: deal.updatedAt.toISOString(),
  };
}
