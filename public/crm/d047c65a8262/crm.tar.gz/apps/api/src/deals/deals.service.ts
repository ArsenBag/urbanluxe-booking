import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  POSITION_STEP,
  positionBetween,
  MAX_BOARD_DEALS,
  MAX_LINK_SEARCH_RESULTS,
  type CreateDealInput,
  type DealBoardQuery,
  type DealDto,
  type MoveDealInput,
  type UpdateDealInput,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { nullableDateOnlyToDb } from '../common/dates.js';
import { isPrismaError, PrismaErrorCode } from '../common/prisma-errors.js';
import type { Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { StageAutomationService } from '../stage-automation/stage-automation.service.js';
import { dealBoardWhere } from './deal-board-filter.js';
import { dealTextCondition } from './deal-search.js';
import { closingStateFor } from './deal-closing.js';
import { DEAL_INCLUDE, toDealDto } from './deal.mapper.js';

type Tx = Prisma.TransactionClient;

const BOARD_OUTDATED =
  'Доска устарела: карточки уже передвинул кто-то другой. Обновите страницу.';
/** Потолок сделок в списке сделок клиента: защита от случайно огромных выборок. */
const MAX_CONTACT_DEALS = 200;
const OWNER_NOT_FOUND = {
  message: 'Ответственный не найден',
  fields: { ownerId: 'Пользователь не найден' },
};

@Injectable()
export class DealsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
    private readonly stageAutomation: StageAutomationService,
  ) {}

  /** Сделки для канбана: открытые и недавно закрытые, с фильтрами по датам, ответственным, источнику и тексту. */
  async board(query: DealBoardQuery, now = new Date()): Promise<DealDto[]> {
    const text = query.search
      ? await dealTextCondition(this.prisma, query.search)
      : undefined;
    const deals = await this.prisma.deal.findMany({
      where: dealBoardWhere(query, now, text),
      include: DEAL_INCLUDE,
      // id — для стабильного порядка карточек с одинаковой позицией.
      orderBy: [{ position: 'asc' }, { id: 'asc' }],
      take: MAX_BOARD_DEALS,
    });
    return deals.map(toDealDto);
  }

  /** Поиск сделки для связи с диалогом. Открытые выше закрытых; пустой запрос — недавние открытые. */
  async search(query: string): Promise<DealDto[]> {
    const where: Prisma.DealWhereInput = query
      ? await dealTextCondition(this.prisma, query)
      : { closedAt: null };
    const deals = await this.prisma.deal.findMany({
      where,
      include: DEAL_INCLUDE,
      orderBy: [
        { closedAt: { sort: 'desc', nulls: 'first' } },
        { updatedAt: 'desc' },
      ],
      take: MAX_LINK_SEARCH_RESULTS,
    });
    return deals.map(toDealDto);
  }

  async listByContact(contactId: string): Promise<DealDto[]> {
    const deals = await this.prisma.deal.findMany({
      where: { contactId },
      include: DEAL_INCLUDE,
      orderBy: { createdAt: 'desc' },
      take: MAX_CONTACT_DEALS,
    });
    return deals.map(toDealDto);
  }

  async get(id: string): Promise<DealDto> {
    const deal = await this.prisma.deal.findUnique({
      where: { id },
      include: DEAL_INCLUDE,
    });
    if (!deal) {
      throw new NotFoundException('Сделка не найдена');
    }
    return toDealDto(deal);
  }

  async create(input: CreateDealInput, actor: SessionUser): Promise<DealDto> {
    const {
      pipelineId,
      stageId,
      contactId,
      ownerId,
      title,
      checkIn,
      checkOut,
      ...fields
    } = input;
    const deal = await this.prisma
      .$transaction(async (tx) => {
        const stage = await this.resolveStage(tx, pipelineId, stageId);
        await this.lockStage(tx, stage.id);
        const contact = await tx.contact.findUnique({
          where: { id: contactId },
          select: { name: true },
        });
        if (!contact) {
          throw new BadRequestException({
            message: 'Клиент не найден',
            fields: { contactId: 'Клиент не найден' },
          });
        }
        const created = await tx.deal.create({
          data: {
            ...fields,
            title: title ?? contact.name,
            pipelineId,
            stageId: stage.id,
            contactId,
            ownerId: ownerId === undefined ? actor.id : ownerId,
            checkIn: nullableDateOnlyToDb(checkIn),
            checkOut: nullableDateOnlyToDb(checkOut),
            position: await this.nextPositionAtEnd(tx, stage.id),
            closedAt: stage.kind === 'OPEN' ? null : new Date(),
          },
          include: DEAL_INCLUDE,
        });
        await this.audit.record(
          actor,
          {
            action: 'deal.created',
            entityType: 'deal',
            entityId: created.id,
            payload: { title: created.title, contactId },
          },
          tx,
        );
        return created;
      })
      .catch((error: unknown) => {
        throw isPrismaError(error, PrismaErrorCode.ForeignKeyViolation)
          ? new BadRequestException(OWNER_NOT_FOUND)
          : error;
      });
    return toDealDto(deal);
  }

  async update(
    id: string,
    input: UpdateDealInput,
    actor: SessionUser,
  ): Promise<DealDto> {
    const { checkIn, checkOut, ...fields } = input;
    try {
      const deal = await this.prisma.$transaction(async (tx) => {
        await this.assertStayDatesValid(tx, id, input);
        const updated = await tx.deal.update({
          where: { id },
          data: {
            ...fields,
            checkIn: nullableDateOnlyToDb(checkIn),
            checkOut: nullableDateOnlyToDb(checkOut),
          },
          include: DEAL_INCLUDE,
        });
        await this.audit.record(
          actor,
          {
            action: 'deal.updated',
            entityType: 'deal',
            entityId: id,
            payload: { fields: Object.keys(input) },
          },
          tx,
        );
        return updated;
      });
      return toDealDto(deal);
    } catch (error) {
      if (isPrismaError(error, PrismaErrorCode.RecordNotFound)) {
        throw new NotFoundException('Сделка не найдена');
      }
      if (isPrismaError(error, PrismaErrorCode.ForeignKeyViolation)) {
        throw new BadRequestException(OWNER_NOT_FOUND);
      }
      throw error;
    }
  }

  /** Перемещает карточку на этап между соседями prev и next. */
  async move(
    id: string,
    input: MoveDealInput,
    actor: SessionUser,
  ): Promise<DealDto> {
    const { deal, stageChanged } = await this.prisma.$transaction(async (tx) => {
      const current = await tx.deal.findUnique({ where: { id } });
      if (!current) {
        throw new NotFoundException('Сделка не найдена');
      }
      const stage = await tx.stage.findUnique({ where: { id: input.stageId } });
      if (!stage || stage.pipelineId !== current.pipelineId) {
        throw new BadRequestException('Этап не принадлежит воронке сделки');
      }

      await this.lockStage(tx, stage.id);
      const position = await this.positionForMove(tx, id, input);
      const closing = closingStateFor(
        stage.kind,
        current,
        input.lostReason,
        new Date(),
      );
      const moved = await tx.deal.update({
        where: { id },
        data: { stageId: stage.id, position, ...closing },
        include: DEAL_INCLUDE,
      });
      if (current.stageId !== stage.id) {
        await this.audit.record(
          actor,
          {
            action: 'deal.moved',
            entityType: 'deal',
            entityId: id,
            payload: {
              fromStageId: current.stageId,
              toStageId: stage.id,
              toStageName: stage.name,
            },
          },
          tx,
        );
      }
      return { deal: moved, stageChanged: current.stageId !== stage.id };
    });
    // Автоперенос по датам брони не ждёт планировщика: карточка, отмеченная «Заселён» после 19:00
    // накануне выезда, сразу уходит в «Выезд завтра».
    if (stageChanged && (await this.stageAutomation.onDealChanged(id))) {
      return this.get(id);
    }
    return toDealDto(deal);
  }

  async remove(id: string, actor: SessionUser): Promise<null> {
    try {
      await this.prisma.$transaction(async (tx) => {
        const deleted = await tx.deal.delete({ where: { id } });
        await this.audit.record(
          actor,
          {
            action: 'deal.deleted',
            entityType: 'deal',
            entityId: id,
            payload: { title: deleted.title },
          },
          tx,
        );
      });
      return null;
    } catch (error) {
      if (isPrismaError(error, PrismaErrorCode.RecordNotFound)) {
        throw new NotFoundException('Сделка не найдена');
      }
      throw error;
    }
  }

  private async resolveStage(
    tx: Tx,
    pipelineId: string,
    stageId: string | undefined,
  ) {
    const stage = stageId
      ? await tx.stage.findFirst({ where: { id: stageId, pipelineId } })
      : await tx.stage.findFirst({
          where: { pipelineId },
          orderBy: { position: 'asc' },
        });
    if (!stage) {
      throw new BadRequestException(
        stageId
          ? 'Этап не принадлежит воронке'
          : 'Воронка не найдена или в ней нет этапов',
      );
    }
    return stage;
  }

  private async nextPositionAtEnd(
    tx: Tx,
    stageId: string,
    excludeDealId?: string,
  ): Promise<number> {
    const last = await tx.deal.findFirst({
      where: { stageId, ...(excludeDealId && { id: { not: excludeDealId } }) },
      orderBy: { position: 'desc' },
      select: { position: true },
    });
    return positionBetween(last?.position ?? null, null) as number;
  }

  /** Даты в PATCH проверяются вместе с уже сохранёнными: можно прислать только одну из них. */
  private async assertStayDatesValid(
    tx: Tx,
    id: string,
    input: UpdateDealInput,
  ): Promise<void> {
    if (input.checkIn === undefined && input.checkOut === undefined) {
      return;
    }
    const existing = await tx.deal.findUnique({
      where: { id },
      select: { checkIn: true, checkOut: true },
    });
    if (!existing) {
      throw new NotFoundException('Сделка не найдена');
    }
    const checkIn =
      input.checkIn === undefined
        ? existing.checkIn
        : nullableDateOnlyToDb(input.checkIn);
    const checkOut =
      input.checkOut === undefined
        ? existing.checkOut
        : nullableDateOnlyToDb(input.checkOut);
    if (checkIn && checkOut && checkOut <= checkIn) {
      throw new BadRequestException({
        message: 'Дата выезда должна быть позже даты заезда',
        fields: { checkOut: 'Дата выезда должна быть позже даты заезда' },
      });
    }
  }

  /**
   * Транзакционная блокировка колонки: одновременные переносы в один этап выполняются по очереди
   * и не получают одинаковые позиции. Снимается автоматически в конце транзакции.
   */
  private async lockStage(tx: Tx, stageId: string): Promise<void> {
    await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${stageId}))::text AS locked`;
  }

  private async positionForMove(
    tx: Tx,
    dealId: string,
    input: MoveDealInput,
    isRetry = false,
  ): Promise<number> {
    // Без соседей (смена этапа из карточки сделки) — в конец колонки.
    if (!input.prevDealId && !input.nextDealId) {
      return this.nextPositionAtEnd(tx, input.stageId, dealId);
    }
    const neighbour = async (neighbourId: string | null) => {
      if (!neighbourId) return null;
      const found = await tx.deal.findUnique({
        where: { id: neighbourId },
        select: { stageId: true, position: true },
      });
      if (!found || found.stageId !== input.stageId || neighbourId === dealId) {
        throw new ConflictException(BOARD_OUTDATED);
      }
      return found.position;
    };

    const prev = await neighbour(input.prevDealId);
    const next = await neighbour(input.nextDealId);
    if (prev !== null && next !== null && prev >= next) {
      throw new ConflictException(BOARD_OUTDATED);
    }
    const position = positionBetween(prev, next);
    if (position !== null) {
      return position;
    }
    if (isRetry) {
      // После перенумерации место обязано появиться; иначе данные противоречивы — не зацикливаемся.
      throw new ConflictException(BOARD_OUTDATED);
    }
    // Между соседями не осталось места: перенумеровываем колонку и считаем заново.
    await this.rebalanceStage(tx, input.stageId, dealId);
    return this.positionForMove(tx, dealId, input, true);
  }

  private async rebalanceStage(
    tx: Tx,
    stageId: string,
    excludeDealId: string,
  ): Promise<void> {
    const deals = await tx.deal.findMany({
      where: { stageId, id: { not: excludeDealId } },
      orderBy: { position: 'asc' },
      select: { id: true },
    });
    await Promise.all(
      deals.map((deal, index) =>
        tx.deal.update({
          where: { id: deal.id },
          data: { position: (index + 1) * POSITION_STEP },
        }),
      ),
    );
  }
}
