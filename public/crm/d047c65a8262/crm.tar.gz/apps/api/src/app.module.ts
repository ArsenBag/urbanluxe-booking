import {
  type MiddlewareConsumer,
  Module,
  type NestModule,
} from '@nestjs/common';
import { APP_FILTER, APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { AuditModule } from './audit/audit.module.js';
import { AuthGuard } from './auth/auth.guard.js';
import { AuthModule } from './auth/auth.module.js';
import { ApiResponseInterceptor } from './common/api-response.interceptor.js';
import { csrfMiddleware } from './common/csrf.middleware.js';
import { HttpExceptionFilter } from './common/http-exception.filter.js';
import { ConfigModule } from './config/config.module.js';
import { ContactsModule } from './contacts/contacts.module.js';
import { CustomFieldsModule } from './custom-fields/custom-fields.module.js';
import { DealsModule } from './deals/deals.module.js';
import { FilesModule } from './files/files.module.js';
import { HealthController } from './health/health.controller.js';
import { InboxModule } from './inbox/inbox.module.js';
import { LinkingModule } from './linking/linking.module.js';
import { NotificationsModule } from './notifications/notifications.module.js';
import { PipelinesModule } from './pipelines/pipelines.module.js';
import { PrismaModule } from './prisma/prisma.module.js';
import { ReportsModule } from './reports/reports.module.js';
import { TasksModule } from './tasks/tasks.module.js';
import { TelegramModule } from './telegram/telegram.module.js';
import { RatesModule } from './rates/rates.module.js';
import { ChannelManagerModule } from './channel-manager/channel-manager.module.js';
import { PmsModule } from './pms/pms.module.js';
import { RealtyCalendarModule } from './realtycalendar/realtycalendar.module.js';
import { TemplatesModule } from './templates/templates.module.js';
import { WhatsAppModule } from './whatsapp/whatsapp.module.js';
import { AutomationsModule } from './automations/automations.module.js';
import { UsersModule } from './users/users.module.js';

/** Общий лимит на IP. Сотрудники офиса выходят в интернет с одного IP, поэтому с запасом. */
const REQUESTS_PER_MINUTE = 1000;
const ONE_MINUTE_MS = 60_000;

@Module({
  imports: [
    ConfigModule,
    PrismaModule,
    AuditModule,
    ThrottlerModule.forRoot([
      { limit: REQUESTS_PER_MINUTE, ttl: ONE_MINUTE_MS },
    ]),
    AuthModule,
    UsersModule,
    ContactsModule,
    CustomFieldsModule,
    PipelinesModule,
    DealsModule,
    TasksModule,
    FilesModule,
    InboxModule,
    TelegramModule,
    TemplatesModule,
    RealtyCalendarModule,
    PmsModule,
    RatesModule,
    ChannelManagerModule,
    LinkingModule,
    WhatsAppModule,
    AutomationsModule,
    NotificationsModule,
    ReportsModule,
  ],
  controllers: [HealthController],
  providers: [
    // Порядок важен: сначала лимит запросов, потом проверка сессии.
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_GUARD, useClass: AuthGuard },
    { provide: APP_INTERCEPTOR, useClass: ApiResponseInterceptor },
    { provide: APP_FILTER, useClass: HttpExceptionFilter },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    // '{*path}' — все маршруты в синтаксисе path-to-regexp v8 (голая '*' устарела и даёт предупреждение).
    consumer.apply(csrfMiddleware).forRoutes('{*path}');
  }
}
