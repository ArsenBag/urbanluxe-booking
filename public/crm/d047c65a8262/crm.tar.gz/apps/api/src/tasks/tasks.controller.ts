import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import {
  createTaskSchema,
  taskListQuerySchema,
  updateTaskSchema,
  type CreateTaskInput,
  type TaskDto,
  type TaskListQuery,
  type UpdateTaskInput,
} from '@crm/shared';
import { CurrentUser } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { TasksService } from './tasks.service.js';

@Controller('tasks')
export class TasksController {
  constructor(private readonly tasks: TasksService) {}

  @Get()
  list(
    @Query(new ZodValidationPipe(taskListQuerySchema)) query: TaskListQuery,
    @CurrentUser() actor: SessionUser,
  ): Promise<TaskDto[]> {
    return this.tasks.list(query, actor);
  }

  @Post()
  create(
    @Body(new ZodValidationPipe(createTaskSchema)) input: CreateTaskInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<TaskDto> {
    return this.tasks.create(input, actor);
  }

  @Patch(':id')
  update(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body(new ZodValidationPipe(updateTaskSchema)) input: UpdateTaskInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<TaskDto> {
    return this.tasks.update(id, input, actor);
  }

  @Delete(':id')
  remove(@Param('id', new ParseUUIDPipe()) id: string, @CurrentUser() actor: SessionUser): Promise<null> {
    return this.tasks.remove(id, actor);
  }
}
