import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import type { CreateTaskInput, TaskDto, TaskListQuery, UpdateTaskInput } from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { toEntityRef, USER_REF_SELECT } from '../common/entity-refs.js';
import { isPrismaError, PrismaErrorCode } from '../common/prisma-errors.js';
import type { Prisma, Task } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';

const TASK_INCLUDE = {
  assignee: USER_REF_SELECT,
  deal: { select: { id: true, title: true } },
  contact: { select: { id: true, name: true } },
} as const;

type TaskWithRelations = Task & {
  assignee: { id: string; name: string } | null;
  deal: { id: string; title: string } | null;
  contact: { id: string; name: string } | null;
};

/** Сколько задач максимум отдаём одним списком: на маленькую команду этого с запасом. */
const MAX_TASKS = 500;

function toTaskDto(task: TaskWithRelations): TaskDto {
  return {
    id: task.id,
    title: task.title,
    dueAt: task.dueAt?.toISOString() ?? null,
    isDone: task.isDone,
    doneAt: task.doneAt?.toISOString() ?? null,
    assignee: toEntityRef(task.assignee),
    deal: task.deal,
    contact: toEntityRef(task.contact),
    createdAt: task.createdAt.toISOString(),
  };
}

@Injectable()
export class TasksService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
  ) {}

  async list(query: TaskListQuery, actor: SessionUser): Promise<TaskDto[]> {
    const where: Prisma.TaskWhereInput = {
      ...(query.scope === 'mine' && { assigneeId: actor.id }),
      ...(query.status !== 'all' && { isDone: query.status === 'done' }),
      ...(query.dealId && { dealId: query.dealId }),
      ...(query.contactId && { contactId: query.contactId }),
    };
    const tasks = await this.prisma.task.findMany({
      where,
      include: TASK_INCLUDE,
      orderBy: [{ isDone: 'asc' }, { dueAt: { sort: 'asc', nulls: 'last' } }, { createdAt: 'asc' }],
      take: MAX_TASKS,
    });
    return tasks.map(toTaskDto);
  }

  async create(input: CreateTaskInput, actor: SessionUser): Promise<TaskDto> {
    // Клиент задачи по сделке всегда берётся из сделки, чтобы связи не расходились.
    const contactId = input.dealId ? await this.contactOfDeal(input.dealId) : input.contactId;
    try {
      const task = await this.prisma.$transaction(async (tx) => {
        const created = await tx.task.create({
          data: {
            title: input.title,
            dueAt: input.dueAt ? new Date(input.dueAt) : null,
            assigneeId: input.assigneeId === undefined ? actor.id : input.assigneeId,
            createdById: actor.id,
            dealId: input.dealId,
            contactId,
          },
          include: TASK_INCLUDE,
        });
        await this.audit.record(actor, this.taskEntry('task.created', created), tx);
        return created;
      });
      return toTaskDto(task);
    } catch (error) {
      if (isPrismaError(error, PrismaErrorCode.ForeignKeyViolation)) {
        throw new BadRequestException('Сделка, клиент или исполнитель не найдены');
      }
      throw error;
    }
  }

  async update(id: string, input: UpdateTaskInput, actor: SessionUser): Promise<TaskDto> {
    const { dueAt, isDone, ...fields } = input;
    try {
      const task = await this.prisma.$transaction(async (tx) => {
        const current = await tx.task.findUnique({ where: { id }, select: { isDone: true } });
        if (!current) {
          throw new NotFoundException('Задача не найдена');
        }
        // Повторная отметка «выполнено» не перезаписывает время выполнения и не дублирует запись в журнале.
        const doneChanged = isDone !== undefined && isDone !== current.isDone;
        const data: Prisma.TaskUncheckedUpdateInput = {
          ...fields,
          ...(dueAt !== undefined && { dueAt: dueAt ? new Date(dueAt) : null }),
          ...(doneChanged && { isDone, doneAt: isDone ? new Date() : null }),
        };
        const updated = await tx.task.update({ where: { id }, data, include: TASK_INCLUDE });
        if (!doneChanged && Object.keys(fields).length === 0 && dueAt === undefined) {
          return updated;
        }
        const action = doneChanged ? (isDone ? 'task.completed' : 'task.reopened') : 'task.updated';
        await this.audit.record(actor, this.taskEntry(action, updated), tx);
        return updated;
      });
      return toTaskDto(task);
    } catch (error) {
      if (isPrismaError(error, PrismaErrorCode.RecordNotFound)) {
        throw new NotFoundException('Задача не найдена');
      }
      if (isPrismaError(error, PrismaErrorCode.ForeignKeyViolation)) {
        throw new BadRequestException('Исполнитель не найден');
      }
      throw error;
    }
  }

  /** Удалить задачу может её автор или администратор. */
  async remove(id: string, actor: SessionUser): Promise<null> {
    const task = await this.prisma.task.findUnique({ where: { id } });
    if (!task) {
      throw new NotFoundException('Задача не найдена');
    }
    if (actor.role !== 'ADMIN' && task.createdById !== actor.id) {
      throw new ForbiddenException('Удалить задачу может только её автор или администратор');
    }
    await this.prisma.$transaction(async (tx) => {
      await tx.task.delete({ where: { id } });
      await this.audit.record(actor, this.taskEntry('task.deleted', task), tx);
    });
    return null;
  }

  private async contactOfDeal(dealId: string | null): Promise<string | null> {
    if (!dealId) return null;
    const deal = await this.prisma.deal.findUnique({ where: { id: dealId }, select: { contactId: true } });
    if (!deal) {
      throw new BadRequestException('Сделка не найдена');
    }
    return deal.contactId;
  }

  /** Задача пишется в журнал сделки (или клиента), чтобы попасть в их историю. */
  private taskEntry(action: string, task: Task) {
    return task.dealId
      ? { action, entityType: 'deal' as const, entityId: task.dealId, payload: { taskId: task.id, title: task.title } }
      : task.contactId
        ? { action, entityType: 'contact' as const, entityId: task.contactId, payload: { taskId: task.id, title: task.title } }
        : { action, entityType: 'task' as const, entityId: task.id, payload: { title: task.title } };
  }
}
