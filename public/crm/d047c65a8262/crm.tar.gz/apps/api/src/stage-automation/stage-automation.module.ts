import { Module } from '@nestjs/common';
import { StageAutomationSettingsService } from './stage-automation-settings.service.js';
import { StageAutomationController } from './stage-automation.controller.js';
import { StageAutomationService } from './stage-automation.service.js';

/** Автоперенос сделок по датам брони: настройки и правила. Подключают сделки, брони и планировщик автоматизаций. */
@Module({
  controllers: [StageAutomationController],
  providers: [StageAutomationService, StageAutomationSettingsService],
  exports: [StageAutomationService],
})
export class StageAutomationModule {}
