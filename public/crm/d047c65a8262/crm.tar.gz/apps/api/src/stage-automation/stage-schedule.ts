import type { StageRule } from '@crm/shared';
import { shiftDate, tashkentAt } from '../common/dates.js';

/** Этап воронки: id и место на доске (больше — дальше по воронке). */
export interface StageRef {
  id: string;
  position: number;
}

/** Настройки автопереноса; пустой этап выключает правило. Время — ЧЧ:ММ по Ташкенту. */
export interface StageRules<S extends StageRef = StageRef> {
  checkIn: S | null;
  checkInTime: string;
  checkedIn: S | null;
  checkOutSoon: S | null;
  checkOutSoonTime: string;
  checkedOut: S | null;
  checkedOutTime: string;
}

/** Даты брони, YYYY-MM-DD. */
export interface Stay {
  checkIn: string;
  checkOut: string;
}

/** Сработавшее правило: по брони и этой дате (заезда или выезда) оно больше не сработает. */
export interface RuleRun {
  rule: StageRule;
  date: string;
}

export interface StagePlan<S extends StageRef = StageRef> {
  /** Куда перенести сделку (один из этапов настроек); null — оставить на месте. */
  target: S | null;
  fired: RuleRun[];
}

/** Дата события правила: сменились даты брони — правило сработает снова. */
export const ruleDate = (rule: StageRule, stay: Stay): string => (rule === 'CHECK_IN' ? stay.checkIn : stay.checkOut);

/**
 * Что сделать со сделкой брони сейчас. Каждое правило срабатывает по брони один раз и двигает сделку
 * только вперёд: перенесённую менеджером карточку (вперёд или назад) автоматика больше не трогает.
 * Считается от дат брони, а не от сегодняшнего числа: бронь, сделанная в 02:00 на ночь с прошлой даты,
 * сразу попадает в «Заезд сегодня», а бронь на наступивший день ждёт утра.
 */
export function planStageMove<S extends StageRef>(input: {
  stay: Stay;
  stage: StageRef;
  rules: StageRules<S>;
  done: readonly RuleRun[];
  now: Date;
}): StagePlan<S> {
  const { stay, rules, now } = input;
  const pending = (rule: StageRule) => !input.done.some((run) => run.rule === rule && run.date === ruleDate(rule, stay));
  const run = (rule: StageRule): RuleRun => ({ rule, date: ruleDate(rule, stay) });
  const forward = (from: StageRef, to: S): S | null => (from.position < to.position ? to : null);

  // После выезда прежние правила уже не к месту: гость уехал.
  if (now >= tashkentAt(stay.checkOut, rules.checkedOutTime)) {
    if (!rules.checkedOut || !pending('CHECKED_OUT')) return { target: null, fired: [] };
    return { target: forward(input.stage, rules.checkedOut), fired: [run('CHECKED_OUT')] };
  }

  const fired: RuleRun[] = [];
  let stage: StageRef = input.stage;
  let target: S | null = null;
  if (rules.checkIn && pending('CHECK_IN') && now >= tashkentAt(stay.checkIn, rules.checkInTime)) {
    fired.push(run('CHECK_IN'));
    target = forward(stage, rules.checkIn);
    stage = target ?? stage;
  }
  // «Выезд завтра» — только из «Заселён»: пока менеджер не отметил заселение, правило ждёт.
  const { checkedIn, checkOutSoon } = rules;
  if (
    checkedIn &&
    checkOutSoon &&
    pending('CHECK_OUT_SOON') &&
    now >= tashkentAt(shiftDate(stay.checkOut, -1), rules.checkOutSoonTime)
  ) {
    if (stage.id === checkedIn.id) {
      fired.push(run('CHECK_OUT_SOON'));
      target = forward(stage, checkOutSoon) ?? target;
    } else if (stage.position > checkedIn.position) {
      // Менеджер сам перенёс дальше «Заселён» — правило своё отработало.
      fired.push(run('CHECK_OUT_SOON'));
    }
  }
  return { target, fired };
}
