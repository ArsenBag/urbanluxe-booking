import { Inject, Injectable, Logger } from '@nestjs/common';
import { POSITION_STEP, type StageRule } from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import { tashkentToday } from '../automations/automation-schedule.js';
import { dateOnlyFromDb, dateOnlyToDb, shiftDate } from '../common/dates.js';
import { isPrismaError, PrismaErrorCode } from '../common/prisma-errors.js';
import { ENV, type Env } from '../config/env.js';
import type { Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { StageAutomationSettingsService, type ActiveRules, type RuleStage } from './stage-automation-settings.service.js';
import { planStageMove } from './stage-schedule.js';

type Tx = Prisma.TransactionClient;

/** Брони, выехавшие раньше, уже не двигаем: сделки по ним давно обработаны. */
const LOOKBACK_DAYS = 7;
/** Брони читаем страницами: выборку и так ограничивает окно дат, а сегодняшние заезды не должны теряться в хвосте. */
const PAGE_SIZE = 200;

const BOOKING_SELECT = {
  id: true,
  checkIn: true,
  checkOut: true,
  deal: { select: { id: true, stage: { select: { id: true, position: true } } } },
  stageMoveRuns: { select: { rule: true, date: true } },
} satisfies Prisma.BookingSelect;

type CandidateBooking = Prisma.BookingGetPayload<{ select: typeof BOOKING_SELECT }>;

/** Сделку только что перенёс кто-то другой: перенос отменяется, следующий проход решит заново. */
class StageChangedMeanwhile extends Error {}

/**
 * Автоперенос сделок по датам брони: «Заезд сегодня», «Выезд завтра» (только из «Заселён»), «Выехал».
 * Правила — в stage-schedule.ts, настройки — в StageAutomationSettingsService.
 */
@Injectable()
export class StageAutomationService {
  private readonly logger = new Logger(StageAutomationService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
    private readonly settings: StageAutomationSettingsService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  /** Проход планировщика по броням вокруг сегодняшней даты. Возвращает число перенесённых сделок. */
  runOnce(now = new Date()): Promise<number> {
    return this.process(null, now);
  }

  /** Правила для броней одной сделки. Возвращает число переносов. */
  applyToDeal(dealId: string, now = new Date()): Promise<number> {
    return this.process(dealId, now);
  }

  /**
   * Сразу после переноса сделки менеджером или изменения её брони — не ждать планировщика: карточка,
   * отмеченная «Заселён» после 19:00 накануне выезда, тут же уходит в «Выезд завтра», а бронь, пришедшая
   * в день заезда, — в «Заезд сегодня». true — сделку перенесли. Сбой автопереноса не должен ломать
   * действие сотрудника или вебхук: только в журнал, следующий проход планировщика попробует снова.
   */
  async onDealChanged(dealId: string): Promise<boolean> {
    if (!this.env.AUTOMATIONS_ENABLED) return false;
    try {
      return (await this.applyToDeal(dealId)) > 0;
    } catch (error) {
      this.logger.error(`Автоперенос сделки ${dealId} не выполнен`, error instanceof Error ? error.stack : error);
      return false;
    }
  }

  private async process(dealId: string | null, now: Date): Promise<number> {
    const rules = await this.settings.activeRules();
    if (!rules) return 0;
    const today = tashkentToday(now);
    const where = {
      status: 'BOOKED',
      dealId: dealId ?? { not: null },
      deal: { closedAt: null, pipelineId: rules.pipelineId },
      // Заезд не позже сегодняшнего: правила срабатывают не раньше дня заезда.
      checkIn: { lte: dateOnlyToDb(today) },
      checkOut: { gte: dateOnlyToDb(shiftDate(today, -LOOKBACK_DAYS)) },
    } satisfies Prisma.BookingWhereInput;
    let moved = 0;
    // Проход не меняет состав выборки (ни статус брони, ни воронку сделки), поэтому страницы не съезжают.
    for (let page = 0; ; page += 1) {
      const bookings = await this.prisma.booking.findMany({
        where,
        select: BOOKING_SELECT,
        orderBy: [{ checkIn: 'asc' }, { id: 'asc' }],
        skip: page * PAGE_SIZE,
        take: PAGE_SIZE,
      });
      for (const booking of bookings) {
        try {
          if (await this.applyToBooking(booking, rules, now)) moved += 1;
        } catch (error) {
          // Сбой по одной брони не должен прерывать остальные.
          this.logger.error(`Автоперенос по брони ${booking.id} не выполнен`, error instanceof Error ? error.stack : error);
        }
      }
      if (bookings.length < PAGE_SIZE) return moved;
    }
  }

  /** true — сделку перенесли. */
  private async applyToBooking(booking: CandidateBooking, rules: ActiveRules, now: Date): Promise<boolean> {
    const deal = booking.deal;
    if (!deal) return false;
    const plan = planStageMove({
      stay: { checkIn: dateOnlyFromDb(booking.checkIn), checkOut: dateOnlyFromDb(booking.checkOut) },
      stage: deal.stage,
      rules,
      done: booking.stageMoveRuns.map((run) => ({ rule: run.rule as StageRule, date: dateOnlyFromDb(run.date) })),
      now,
    });
    if (plan.fired.length === 0) return false;
    const target = plan.target;
    try {
      await this.prisma.$transaction(async (tx) => {
        // Уникальный ключ (бронь, правило, дата) не даст правилу сработать дважды даже при параллельных проходах.
        await tx.stageMoveRun.createMany({
          data: plan.fired.map((run) => ({ bookingId: booking.id, rule: run.rule, date: dateOnlyToDb(run.date) })),
        });
        if (target) await this.moveDeal(tx, { id: deal.id, stageId: deal.stage.id }, target);
      });
    } catch (error) {
      if (error instanceof StageChangedMeanwhile || isPrismaError(error, PrismaErrorCode.UniqueViolation)) return false;
      throw error;
    }
    return target !== null;
  }

  private async moveDeal(tx: Tx, deal: { id: string; stageId: string }, target: RuleStage): Promise<void> {
    // Как при ручном переносе: одновременные переносы в одну колонку не получают одинаковых позиций.
    await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${target.id}))::text AS locked`;
    const last = await tx.deal.findFirst({ where: { stageId: target.id }, orderBy: { position: 'desc' }, select: { position: true } });
    // Только если сделка всё там же: менеджер мог перенести её в эту же секунду.
    const { count } = await tx.deal.updateMany({
      where: { id: deal.id, stageId: deal.stageId, closedAt: null },
      data: { stageId: target.id, position: (last?.position ?? 0) + POSITION_STEP },
    });
    if (count === 0) throw new StageChangedMeanwhile();
    await this.audit.record(
      null,
      {
        action: 'deal.moved',
        entityType: 'deal',
        entityId: deal.id,
        payload: { fromStageId: deal.stageId, toStageId: target.id, toStageName: target.name, via: 'AUTOMATION' },
      },
      tx,
    );
  }
}
