import { Body, Controller, Get, Put } from '@nestjs/common';
import { stageAutomationSchema, type StageAutomationDto, type StageAutomationInput } from '@crm/shared';
import { CurrentUser, Roles } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { StageAutomationSettingsService } from './stage-automation-settings.service.js';

/** Блок настроек «Автоперенос сделок». */
@Controller('stage-automation')
@Roles('ADMIN')
export class StageAutomationController {
  constructor(private readonly settings: StageAutomationSettingsService) {}

  @Get()
  get(): Promise<StageAutomationDto> {
    return this.settings.get();
  }

  @Put()
  update(
    @Body(new ZodValidationPipe(stageAutomationSchema)) input: StageAutomationInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<StageAutomationDto> {
    return this.settings.update(input, actor);
  }
}
