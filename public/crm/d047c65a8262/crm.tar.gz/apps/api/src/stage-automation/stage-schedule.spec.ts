import {
  planStageMove,
  type RuleRun,
  type StageRef,
  type StageRules,
  type Stay,
} from './stage-schedule.js';

// Воронка как на проде: «Бронь создана» → «Заезд сегодня» → «Заселён» → «Выезд завтра» → «Выехал».
const BOOKED: StageRef = { id: 'booked', position: 2 };
const CHECK_IN: StageRef = { id: 'check-in', position: 3 };
const CHECKED_IN: StageRef = { id: 'checked-in', position: 4 };
const CHECK_OUT_SOON: StageRef = { id: 'check-out-soon', position: 5 };
const CHECKED_OUT: StageRef = { id: 'checked-out', position: 6 };

const RULES: StageRules = {
  checkIn: CHECK_IN,
  checkInTime: '08:00',
  checkedIn: CHECKED_IN,
  checkOutSoon: CHECK_OUT_SOON,
  checkOutSoonTime: '19:00',
  checkedOut: CHECKED_OUT,
  checkedOutTime: '12:00',
};

const STAY: Stay = { checkIn: '2026-11-20', checkOut: '2026-11-23' };
const CHECK_IN_DONE: RuleRun = { rule: 'CHECK_IN', date: '2026-11-20' };

/** Время по Ташкенту (UTC+5) → момент. */
const tashkent = (dateTime: string) => new Date(`${dateTime}:00+05:00`);

const plan = (
  stage: StageRef,
  now: string,
  options: { stay?: Stay; done?: RuleRun[]; rules?: StageRules } = {},
) =>
  planStageMove({
    stay: options.stay ?? STAY,
    stage,
    rules: options.rules ?? RULES,
    done: options.done ?? [],
    now: tashkent(now),
  });

describe('planStageMove: «Заезд сегодня»', () => {
  it('waits until 08:00 on the check-in day', () => {
    expect(plan(BOOKED, '2026-11-20T07:59')).toEqual({
      target: null,
      fired: [],
    });
  });

  it('moves the deal from 08:00 on the check-in day', () => {
    expect(plan(BOOKED, '2026-11-20T08:00')).toEqual({
      target: CHECK_IN,
      fired: [CHECK_IN_DONE],
    });
  });

  it('takes a booking that arrives in the evening of the check-in day straight there', () => {
    expect(plan(BOOKED, '2026-11-20T21:00').target).toBe(CHECK_IN);
  });

  it('fires once: a deal the manager moved back stays where it is', () => {
    expect(plan(BOOKED, '2026-11-20T10:00', { done: [CHECK_IN_DONE] })).toEqual(
      { target: null, fired: [] },
    );
  });

  it('fires again when the check-in date changes', () => {
    const moved = { rule: 'CHECK_IN', date: '2026-11-18' } as const;

    expect(plan(BOOKED, '2026-11-20T10:00', { done: [moved] }).target).toBe(
      CHECK_IN,
    );
  });

  it('never moves backwards: a deal already «Заселён» stays, and the rule is spent', () => {
    expect(plan(CHECKED_IN, '2026-11-20T08:00')).toEqual({
      target: null,
      fired: [CHECK_IN_DONE],
    });
  });

  it('follows the configured time', () => {
    const rules = { ...RULES, checkInTime: '09:30' };

    expect(plan(BOOKED, '2026-11-20T09:29', { rules }).target).toBeNull();
    expect(plan(BOOKED, '2026-11-20T09:30', { rules }).target).toBe(CHECK_IN);
  });

  it('is off without a stage', () => {
    expect(
      plan(BOOKED, '2026-11-20T10:00', { rules: { ...RULES, checkIn: null } }),
    ).toEqual({ target: null, fired: [] });
  });
});

describe('planStageMove: bookings made after midnight', () => {
  const NIGHT: Stay = { checkIn: '2026-11-20', checkOut: '2026-11-21' };

  it('takes a booking for the previous date straight to «Заезд сегодня»: the guest arrives now', () => {
    expect(plan(BOOKED, '2026-11-21T02:00', { stay: NIGHT }).target).toBe(
      CHECK_IN,
    );
  });

  it('keeps a booking for the coming day out of «Заезд сегодня» until 08:00', () => {
    const tomorrow = { checkIn: '2026-11-21', checkOut: '2026-11-22' };

    expect(
      plan(BOOKED, '2026-11-21T02:00', { stay: tomorrow }).target,
    ).toBeNull();
    expect(plan(BOOKED, '2026-11-21T08:00', { stay: tomorrow }).target).toBe(
      CHECK_IN,
    );
  });

  it('moves the night guest on to «Выезд завтра» once the manager marks «Заселён»', () => {
    const done = [{ rule: 'CHECK_IN', date: '2026-11-20' } as const];

    expect(
      plan(CHECKED_IN, '2026-11-21T02:30', { stay: NIGHT, done }).target,
    ).toBe(CHECK_OUT_SOON);
  });
});

describe('planStageMove: «Выезд завтра»', () => {
  const CHECK_OUT_SOON_DONE: RuleRun = {
    rule: 'CHECK_OUT_SOON',
    date: '2026-11-23',
  };

  it('waits until 19:00 the day before check-out', () => {
    expect(
      plan(CHECKED_IN, '2026-11-22T18:59', { done: [CHECK_IN_DONE] }),
    ).toEqual({ target: null, fired: [] });
  });

  it('moves a «Заселён» deal from 19:00 the day before check-out', () => {
    expect(
      plan(CHECKED_IN, '2026-11-22T19:00', { done: [CHECK_IN_DONE] }),
    ).toEqual({
      target: CHECK_OUT_SOON,
      fired: [CHECK_OUT_SOON_DONE],
    });
  });

  it('keeps waiting while the manager has not marked the guest «Заселён»', () => {
    expect(
      plan(CHECK_IN, '2026-11-22T19:00', { done: [CHECK_IN_DONE] }),
    ).toEqual({ target: null, fired: [] });
  });

  it('moves right after the manager marks «Заселён», even late at night', () => {
    expect(
      plan(CHECKED_IN, '2026-11-22T23:30', { done: [CHECK_IN_DONE] }).target,
    ).toBe(CHECK_OUT_SOON);
  });

  it('is spent when the manager moved the deal past «Заселён» by hand', () => {
    expect(
      plan(CHECK_OUT_SOON, '2026-11-22T19:00', { done: [CHECK_IN_DONE] }),
    ).toEqual({
      target: null,
      fired: [CHECK_OUT_SOON_DONE],
    });
  });

  it('fires once', () => {
    expect(
      plan(CHECKED_IN, '2026-11-22T20:00', {
        done: [CHECK_IN_DONE, CHECK_OUT_SOON_DONE],
      }).target,
    ).toBeNull();
  });

  it('sends a one-night booking that came at 21:00 to «Заезд сегодня» first, then on after check-in', () => {
    const oneNight = { checkIn: '2026-11-20', checkOut: '2026-11-21' };

    expect(plan(BOOKED, '2026-11-20T21:00', { stay: oneNight })).toEqual({
      target: CHECK_IN,
      fired: [CHECK_IN_DONE],
    });
    expect(
      plan(CHECKED_IN, '2026-11-20T21:30', {
        stay: oneNight,
        done: [CHECK_IN_DONE],
      }).target,
    ).toBe(CHECK_OUT_SOON);
  });

  it('is off without its stage or without «Заселён»', () => {
    expect(
      plan(CHECKED_IN, '2026-11-22T19:00', {
        done: [CHECK_IN_DONE],
        rules: { ...RULES, checkOutSoon: null },
      }).target,
    ).toBeNull();
    expect(
      plan(CHECKED_IN, '2026-11-22T19:00', {
        done: [CHECK_IN_DONE],
        rules: { ...RULES, checkedIn: null },
      }).target,
    ).toBeNull();
  });
});

describe('planStageMove: «Выехал»', () => {
  const CHECKED_OUT_DONE: RuleRun = { rule: 'CHECKED_OUT', date: '2026-11-23' };

  it('waits until 12:00 on the check-out day', () => {
    expect(plan(CHECK_OUT_SOON, '2026-11-23T11:59').target).toBeNull();
  });

  it('moves the deal at 12:00 on the check-out day from any earlier stage', () => {
    expect(plan(CHECK_OUT_SOON, '2026-11-23T12:00')).toEqual({
      target: CHECKED_OUT,
      fired: [CHECKED_OUT_DONE],
    });
    expect(plan(CHECK_IN, '2026-11-23T12:00').target).toBe(CHECKED_OUT);
    expect(plan(BOOKED, '2026-11-23T12:00').target).toBe(CHECKED_OUT);
  });

  it('stops the earlier rules after check-out time', () => {
    expect(
      plan(BOOKED, '2026-11-23T12:00', {
        rules: { ...RULES, checkedOut: null },
      }),
    ).toEqual({ target: null, fired: [] });
  });

  it('fires once', () => {
    expect(
      plan(CHECK_OUT_SOON, '2026-11-23T13:00', { done: [CHECKED_OUT_DONE] })
        .target,
    ).toBeNull();
  });
});
