import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import {
  STAGE_AUTOMATION_STAGE_FIELDS,
  type StageAutomationDto,
  type StageAutomationInput,
  type StageAutomationStageField,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import type { Prisma, Stage, StageAutomation } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import type { StageRef, StageRules } from './stage-schedule.js';

/** Настройки — одна строка таблицы. */
const SETTINGS_ID = 1;

const WITH_STAGES = { checkInStage: true, checkedInStage: true, checkOutSoonStage: true, checkedOutStage: true } as const;

/** Этап правила: название нужно для истории сделки. */
export type RuleStage = StageRef & { name: string };

/** Настройки для прохода автопереноса: только включённые правила и воронка их этапов. */
export interface ActiveRules extends StageRules<RuleStage> {
  pipelineId: string;
}

function toDto(row: StageAutomation): StageAutomationDto {
  return {
    enabled: row.enabled,
    checkInStageId: row.checkInStageId,
    checkInTime: row.checkInTime,
    checkedInStageId: row.checkedInStageId,
    checkOutSoonStageId: row.checkOutSoonStageId,
    checkOutSoonTime: row.checkOutSoonTime,
    checkedOutStageId: row.checkedOutStageId,
    checkedOutTime: row.checkedOutTime,
  };
}

/** Этапы правил стоят в воронке по порядку: «Заезд сегодня» → «Заселён» → «Выезд завтра» → «Выехал». */
function isOrdered(stages: ReadonlyArray<Stage | null>): boolean {
  const positions = stages.flatMap((stage) => (stage ? [stage.position] : []));
  return positions.every((position, index) => index === 0 || position > positions[index - 1]);
}

function invalid(field: StageAutomationStageField, message: string): BadRequestException {
  return new BadRequestException({ message: 'Проверьте введённые данные', fields: { [field]: message } });
}

/** Настройки автопереноса сделок по датам брони (блок «Автоперенос сделок», только администратор). */
@Injectable()
export class StageAutomationSettingsService {
  private readonly logger = new Logger(StageAutomationSettingsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: ActivityLogService,
  ) {}

  async get(): Promise<StageAutomationDto> {
    // Строку создаёт миграция; если её нет — заводим с выключенным автопереносом (значения по умолчанию из схемы).
    const row = await this.prisma.stageAutomation.upsert({ where: { id: SETTINGS_ID }, create: { id: SETTINGS_ID }, update: {} });
    return toDto(row);
  }

  async update(input: StageAutomationInput, actor: SessionUser): Promise<StageAutomationDto> {
    const row = await this.prisma.$transaction(async (tx) => {
      // Проверка в той же транзакции: этап не исчезнет между проверкой и сохранением.
      const pipelineId = await this.assertStages(tx, input);
      const before = await tx.stageAutomation.findUnique({ where: { id: SETTINGS_ID } });
      const saved = await tx.stageAutomation.upsert({
        where: { id: SETTINGS_ID },
        create: { ...input, id: SETTINGS_ID },
        update: input,
      });
      // Настройки относятся к воронке их этапов: запись в журнале действий — у неё.
      const historyPipeline = pipelineId ?? (await tx.pipeline.findFirst({ orderBy: { position: 'asc' }, select: { id: true } }))?.id;
      if (historyPipeline) {
        await this.audit.record(
          actor,
          {
            action: 'stage-automation.updated',
            entityType: 'pipeline',
            entityId: historyPipeline,
            payload: { ...input, before: before ? { ...toDto(before) } : null },
          },
          tx,
        );
      }
      return saved;
    });
    return toDto(row);
  }

  /** Включённые правила для прохода; null — автоперенос выключен или ни один этап не выбран. */
  async activeRules(): Promise<ActiveRules | null> {
    const row = await this.prisma.stageAutomation.findUnique({ where: { id: SETTINGS_ID }, include: WITH_STAGES });
    if (!row?.enabled) return null;
    const stages = [row.checkInStage, row.checkedInStage, row.checkOutSoonStage, row.checkedOutStage];
    const pipelineId = stages.find(Boolean)?.pipelineId;
    if (!pipelineId) return null;
    // Этапы переставили в воронке после сохранения настроек — «только вперёд» потеряло смысл: правила стоят,
    // пока администратор не поправит порядок (блок настроек это показывает).
    if (!isOrdered(stages)) {
      this.logger.warn('Автоперенос сделок остановлен: этапы правил стоят в воронке не по порядку');
      return null;
    }
    // Этап, который после сохранения настроек стал закрывающим или переехал в другую воронку, правило выключает.
    const usable = (stage: Stage | null): RuleStage | null => {
      if (!stage) return null;
      if (stage.kind === 'OPEN' && stage.pipelineId === pipelineId) return { id: stage.id, position: stage.position, name: stage.name };
      this.logger.warn(`Автоперенос сделок: этап «${stage.name}» закрывает сделку или из другой воронки — правило не работает`);
      return null;
    };
    return {
      pipelineId,
      checkIn: usable(row.checkInStage),
      checkInTime: row.checkInTime,
      checkedIn: usable(row.checkedInStage),
      checkOutSoon: usable(row.checkOutSoonStage),
      checkOutSoonTime: row.checkOutSoonTime,
      checkedOut: usable(row.checkedOutStage),
      checkedOutTime: row.checkedOutTime,
    };
  }

  /**
   * Этапы — из одной воронки, «в работе» и по порядку: «Заезд сегодня» → «Заселён» → «Выезд завтра» → «Выехал».
   * Иначе перенос «только вперёд» сломался бы. Возвращает воронку выбранных этапов (null — ни один не выбран).
   */
  private async assertStages(tx: Prisma.TransactionClient, input: StageAutomationInput): Promise<string | null> {
    const chosen = STAGE_AUTOMATION_STAGE_FIELDS.flatMap((field) => (input[field] ? [{ field, id: input[field] }] : []));
    const stages = new Map(
      (await tx.stage.findMany({ where: { id: { in: chosen.map((item) => item.id) } } })).map((stage) => [stage.id, stage]),
    );
    let previous: Stage | null = null;
    for (const { field, id } of chosen) {
      const stage = stages.get(id);
      if (!stage) throw invalid(field, 'Этап не найден — обновите страницу');
      if (stage.kind !== 'OPEN') throw invalid(field, 'Нужен этап «В работе»: закрывающий этап закрыл бы сделку');
      if (previous && stage.pipelineId !== previous.pipelineId) throw invalid(field, 'Все этапы должны быть из одной воронки');
      if (previous && stage.position <= previous.position) {
        throw invalid(field, `В воронке этот этап должен стоять после «${previous.name}»`);
      }
      previous = stage;
    }
    return previous?.pipelineId ?? null;
  }
}
