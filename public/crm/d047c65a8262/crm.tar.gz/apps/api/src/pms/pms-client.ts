import { Inject, Injectable, Logger } from '@nestjs/common';
import { ENV, type Env } from '../config/env.js';

/** Ответ Public API PMS: { ok, data } | { ok:false, error:{code,message} }. */
interface PmsEnvelope<T> {
  ok: boolean;
  data?: T;
  error?: { code: string; message: string };
}

export interface PmsBooking {
  id: string;
  ref: string | null;
  apartment_id: string;
  status: 'request' | 'confirmed' | 'checked_in' | 'checked_out' | 'cancelled' | 'blocked';
  check_in: string;
  check_out: string;
  nights: number;
  arrival_time: string | null;
  departure_time: string | null;
  guest: { name: string | null; phone: string | null; email: string | null; telegram: string | null; whatsapp?: string | null };
  guests_count: number | null;
  total_price: number | null;
  prepaid?: number | null;
  deposit?: number | null;
  currency: string;
  source: string | null;
  channel: string | null;
  external_ref: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  cancelled_at: string | null;
}

export interface PmsBookingInput {
  apartment_id: string;
  check_in: string;
  check_out: string;
  guest: { name: string | null; phone: string | null; email: string | null };
  guests_count?: number | null;
  status?: 'request' | 'confirmed';
  total_price?: number | null;
  prepaid?: number | null;
  notes?: string | null;
  arrival_time?: string | null;
  departure_time?: string | null;
  external_ref: string;
}

export interface PmsApartment {
  id: string;
  external_ref: string | null;
  /** realty_id объекта в RealtyCalendar, если квартира когда-то была там; null — нет. */
  rc_id: number | null;
  name: string;
  complex: string | null;
  floor: number | null;
  rooms: string | null;
  max_guests: number | null;
}

export interface PmsApartmentUpsert {
  external_ref: string;
  name: string;
  complex: string;
  address?: string | null;
  rc_id?: number | null;
  is_active?: boolean;
}

/** Ошибка PMS: по коду решаем, показывать её пользователю (409 — даты заняты) или повторить позже (сеть, 5xx). */
export class PmsError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
  ) {
    super(message);
  }

  /** Повторная отправка не поможет: PMS отказала по смыслу (даты заняты, нет прав, не найдено). */
  get isFinal(): boolean {
    return this.status >= 400 && this.status < 500 && this.status !== 429;
  }
}

const TIMEOUT_MS = 15_000;

/** HTTP-клиент Public API PMS Urban Luxe (https://urbanluxe.cc/api/docs). Без ключа — выключен. */
@Injectable()
export class PmsClient {
  private readonly logger = new Logger(PmsClient.name);

  constructor(@Inject(ENV) private readonly env: Env) {}

  get enabled(): boolean {
    return Boolean(this.env.PMS_API_KEY);
  }

  bookingUrl(pmsId: string): string {
    return `${this.env.PMS_WEB_URL}#booking=${pmsId}`;
  }

  createBooking(input: PmsBookingInput): Promise<PmsBooking> {
    return this.request<PmsBooking>('POST', '/bookings', input);
  }

  updateBooking(pmsId: string, input: Partial<PmsBookingInput>): Promise<PmsBooking> {
    return this.request<PmsBooking>('PATCH', `/bookings/${pmsId}`, input);
  }

  cancelBooking(pmsId: string, reason: string): Promise<PmsBooking> {
    return this.request<PmsBooking>('POST', `/bookings/${pmsId}/cancel`, { reason });
  }

  upsertApartment(input: PmsApartmentUpsert): Promise<{ id: string; created: boolean; linked_existing: boolean; complex: string }> {
    return this.request('POST', '/apartments', input);
  }

  /** Квартиры организации в PMS (GET /apartments). */
  apartments(): Promise<PmsApartment[]> {
    return this.request('GET', '/apartments');
  }

  me(): Promise<{ organization: { id: number; name: string }; key: { name: string; scopes: string[] }; apartments: number }> {
    return this.request('GET', '/me');
  }

  private async request<T>(method: string, path: string, body?: unknown): Promise<T> {
    if (!this.env.PMS_API_KEY) throw new PmsError(0, 'disabled', 'PMS не настроена (PMS_API_KEY)');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    let response: Response;
    try {
      response = await fetch(`${this.env.PMS_API_URL}${path}`, {
        method,
        headers: {
          Authorization: `Bearer ${this.env.PMS_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: controller.signal,
      });
    } catch (error) {
      throw new PmsError(0, 'network', `PMS недоступна: ${(error as Error).message}`);
    } finally {
      clearTimeout(timer);
    }
    let json: PmsEnvelope<T> | null = null;
    try {
      json = (await response.json()) as PmsEnvelope<T>;
    } catch {
      json = null;
    }
    if (!response.ok || !json?.ok) {
      const code = json?.error?.code ?? `http_${response.status}`;
      const message = json?.error?.message ?? `PMS ответила ${response.status}`;
      // В журнал — код и путь, без тела запроса (в нём имя и телефон гостя).
      this.logger.warn(`PMS ${method} ${path} → ${response.status} ${code}`);
      throw new PmsError(response.status, code, message);
    }
    return json.data as T;
  }
}
