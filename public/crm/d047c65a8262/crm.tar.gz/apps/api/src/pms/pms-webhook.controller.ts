import {
  Body,
  Controller,
  Headers,
  HttpCode,
  HttpStatus,
  Inject,
  Logger,
  Post,
  Req,
  UnauthorizedException,
} from '@nestjs/common';
import { createHmac, timingSafeEqual } from 'node:crypto';
import type { Request } from 'express';
import { z } from 'zod';
import { Public } from '../auth/decorators.js';
import { ENV, type Env } from '../config/env.js';
import type { PmsBooking } from './pms-client.js';
import { PmsSyncService } from './pms-sync.service.js';
import { PmsStateService } from './pms-state.service.js';

/** Тело вебхука PMS: { id, event, created_at, data: бронь }. Поля брони проверяем мягко — лишние отбрасываем. */
const webhookSchema = z.object({
  id: z.union([z.number(), z.string()]),
  event: z.enum(['booking.created', 'booking.updated', 'booking.cancelled', 'ping']),
  created_at: z.string().optional(),
  data: z.unknown(),
});

const bookingSchema = z.object({
  id: z.string().uuid(),
  ref: z.string().nullish(),
  apartment_id: z.string().min(1),
  status: z.enum(['request', 'confirmed', 'checked_in', 'checked_out', 'cancelled', 'blocked']),
  check_in: z.string().min(10),
  check_out: z.string().min(10),
  nights: z.number().int().nonnegative().catch(0),
  arrival_time: z.string().nullish().catch(null),
  departure_time: z.string().nullish().catch(null),
  guest: z
    .object({
      name: z.string().nullish(),
      phone: z.string().nullish(),
      email: z.string().nullish(),
      telegram: z.string().nullish(),
      whatsapp: z.string().nullish(),
    })
    .catch({ name: null, phone: null, email: null, telegram: null }),
  guests_count: z.number().nullish().catch(null),
  total_price: z.number().nullish().catch(null),
  prepaid: z.number().nullish().catch(null),
  deposit: z.number().nullish().catch(null),
  currency: z.string().catch('USD'),
  source: z.string().nullish().catch(null),
  channel: z.string().nullish().catch(null),
  external_ref: z.string().nullish().catch(null),
  notes: z.string().nullish().catch(null),
  created_at: z.string(),
  updated_at: z.string().catch(''),
  cancelled_at: z.string().nullish().catch(null),
});

function signatureMatches(secret: string, rawBody: Buffer, header: string | undefined): boolean {
  if (!header) return false;
  const expected = 'sha256=' + createHmac('sha256', secret).update(rawBody).digest('hex');
  const a = Buffer.from(expected);
  const b = Buffer.from(header.trim());
  return a.length === b.length && timingSafeEqual(a, b);
}

/**
 * Вебхуки PMS Urban Luxe: любая бронь по квартирам High Life (площадки через Channex, сайт, шахматка PMS,
 * RealtyCalendar High Life) → бронь CRM. Подпись — HMAC-SHA256 по сырому телу (заголовок X-UL-Signature).
 */
@Controller('webhooks/urbanluxe')
export class PmsWebhookController {
  private readonly logger = new Logger(PmsWebhookController.name);

  constructor(
    private readonly sync: PmsSyncService,
    private readonly state: PmsStateService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  @Public()
  @Post()
  @HttpCode(HttpStatus.OK)
  async receive(
    @Req() req: Request & { rawBody?: Buffer },
    @Body() body: unknown,
    @Headers('x-ul-signature') signature: string | undefined,
    @Headers('x-ul-event') eventHeader: string | undefined,
  ): Promise<{ result: string }> {
    const secret = this.env.PMS_WEBHOOK_SECRET;
    if (!secret || !req.rawBody || !signatureMatches(secret, req.rawBody, signature)) {
      throw new UnauthorizedException('Подпись вебхука PMS не сошлась');
    }
    const parsed = webhookSchema.safeParse(body);
    if (!parsed.success) {
      this.logger.warn(`Вебхук PMS не распознан (${eventHeader ?? '?'})`);
      return { result: 'ignored' };
    }
    this.state.touch(parsed.data.event);
    if (parsed.data.event === 'ping') return { result: 'pong' };
    const booking = bookingSchema.safeParse(parsed.data.data);
    if (!booking.success) {
      this.logger.warn(`Бронь в вебхуке PMS не распознана: ${booking.error.issues.map((i) => i.path.join('.')).join(', ')}`);
      return { result: 'ignored' };
    }
    const data = booking.data as PmsBooking;
    // Переходный период: брони RealtyCalendar High Life CRM уже получает вебхуком RC — из PMS их не дублируем.
    // Когда RC у High Life выключен, это условие убрать.
    if (data.source === 'rc') return { result: 'skipped_rc' };
    // Ошибка обработки — 500: PMS повторит отправку (1 / 5 / 30 / 120 минут).
    const outcome = await this.sync.apply(data);
    return { result: outcome };
  }
}
