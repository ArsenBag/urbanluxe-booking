import { Controller, Get, Inject, Post } from '@nestjs/common';
import type { PmsPropertiesSyncResultDto, PmsStatusDto } from '@crm/shared';
import { Roles } from '../auth/decorators.js';
import { ENV, type Env } from '../config/env.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { PmsClient } from './pms-client.js';
import { PmsOutboundService } from './pms-outbound.service.js';
import { PmsPropertiesService } from './pms-properties.service.js';
import { PmsStateService } from './pms-state.service.js';

/** Состояние моста с PMS Urban Luxe и ручные действия — только администратору. */
@Controller('integrations/pms')
export class PmsController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly client: PmsClient,
    private readonly outbound: PmsOutboundService,
    private readonly properties: PmsPropertiesService,
    private readonly state: PmsStateService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  @Get()
  @Roles('ADMIN')
  async status(): Promise<PmsStatusDto> {
    let organization: string | null = null;
    let keyName: string | null = null;
    let connectionError: string | null = null;
    if (this.client.enabled) {
      try {
        const me = await this.client.me();
        organization = me.organization.name;
        keyName = me.key.name;
      } catch (error) {
        connectionError = (error as Error).message;
      }
    }
    const [propertiesLinked, propertiesTotal, bookingsPending, bookingsFromPms] = await Promise.all([
      this.prisma.property.count({ where: { pmsId: { not: null } } }),
      this.prisma.property.count({ where: { rcId: { not: null } } }),
      this.prisma.booking.count({ where: { source: 'CRM', rcId: null, OR: [{ pmsSyncedAt: null }, { pmsError: { not: null } }] } }),
      this.prisma.booking.count({ where: { source: 'PMS' } }),
    ]);
    return {
      enabled: this.client.enabled,
      apiUrl: this.env.PMS_API_URL,
      webUrl: this.env.PMS_WEB_URL,
      webhookUrl: this.env.PUBLIC_API_URL ? `${this.env.PUBLIC_API_URL}/api/webhooks/urbanluxe` : null,
      webhookSecretSet: Boolean(this.env.PMS_WEBHOOK_SECRET),
      organization,
      keyName,
      connectionError,
      lastWebhookAt: this.state.lastWebhookAt?.toISOString() ?? null,
      lastWebhookEvent: this.state.lastWebhookEvent,
      lastPropertiesSyncAt: this.state.lastPropertiesSyncAt?.toISOString() ?? null,
      propertiesLinked,
      propertiesTotal,
      bookingsPending,
      bookingsFromPms,
    };
  }

  @Post('sync-properties')
  @Roles('ADMIN')
  syncProperties(): Promise<PmsPropertiesSyncResultDto> {
    return this.properties.syncAll();
  }

  /** Квартиры из PMS в CRM — для экземпляра, где объекты не приходили из RealtyCalendar (Urban Luxe). */
  @Post('import-properties')
  @Roles('ADMIN')
  importProperties(): Promise<PmsPropertiesSyncResultDto> {
    return this.properties.importFromPms();
  }

  @Post('retry')
  @Roles('ADMIN')
  async retry(): Promise<{ sent: number }> {
    return { sent: await this.outbound.retryPending() };
  }
}
