import { Injectable, Logger } from '@nestjs/common';
import { tashkentToday } from '../automations/automation-schedule.js';
import type { Booking, BookingStatus, Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { BookingEffectsService, PMS_ACTOR } from '../realtycalendar/booking-effects.service.js';
import { lockBooking } from '../realtycalendar/booking-lock.js';
import { guestChanged, keepCrmValues, toBookingRow, type BookingSnapshot } from '../realtycalendar/rc-mapper.js';
import { StageAutomationService } from '../stage-automation/stage-automation.service.js';
import type { PmsBooking } from './pms-client.js';

type Tx = Prisma.TransactionClient;

export type PmsSyncOutcome = 'created' | 'updated' | 'stale' | 'skipped';

/** Площадка для карточки брони — как у броней RealtyCalendar («Airbnb», «Booking.com»). */
const ORIGIN_LABELS: Record<string, string> = {
  airbnb: 'Airbnb',
  booking: 'Booking.com',
  ostrovok: 'Ostrovok',
  yandex: 'Яндекс Путешествия',
  sutochno: 'Sutochno',
  website: 'Сайт',
  'partner-site': 'Сайт партнёра',
  manual: 'PMS',
  telegram: 'Telegram',
  channex: 'Площадка',
  api: 'PMS',
};

function statusOf(pms: PmsBooking['status']): BookingStatus | null {
  switch (pms) {
    case 'request':
      return 'REQUEST';
    case 'confirmed':
    case 'checked_in':
    case 'checked_out':
      return 'BOOKED';
    case 'cancelled':
      return 'CANCELED';
    default:
      // blocked — блок владельца, не бронь: в CRM не нужен
      return null;
  }
}

function originOf(pms: PmsBooking): string | null {
  const key = (pms.channel ?? pms.source ?? '').toLowerCase();
  if (!key) return null;
  return ORIGIN_LABELS[key] ?? pms.channel ?? pms.source;
}

/** Бронь PMS → снимок в формате CRM (тот же, что у вебхука RealtyCalendar). */
export function toPmsSnapshot(
  pms: PmsBooking,
  property: { rcId: number | null; title: string; address: string | null },
): BookingSnapshot | null {
  const status = statusOf(pms.status);
  if (!status) return null;
  return {
    rcId: null,
    importKey: null,
    status,
    checkIn: pms.check_in.slice(0, 10),
    checkOut: pms.check_out.slice(0, 10),
    nights: pms.nights,
    arrivalTime: pms.arrival_time,
    departureTime: pms.departure_time,
    amount: pms.total_price ?? null,
    prepayment: pms.prepaid ?? null,
    deposit: pms.deposit ?? null,
    origin: originOf(pms),
    guestName: pms.guest?.name ?? null,
    guestPhone: pms.guest?.phone ?? null,
    guestEmail: pms.guest?.email ?? null,
    notes: pms.notes,
    rcUrl: null,
    // Версия брони — время изменения в PMS: устаревшие повторы вебхука отбрасываются.
    rcUpdatedAt: new Date(pms.updated_at ?? pms.created_at),
    property: { rcId: property.rcId, title: property.title, address: property.address },
  };
}

/**
 * Брони из PMS Urban Luxe (вебхуки booking.created / updated / cancelled): та же цепочка, что у броней
 * RealtyCalendar — клиент, сделка, задачи заезда/выезда, журнал. Бронь ищется по pmsId, а бронь, внесённая
 * в CRM и отправленная в PMS, — по external_ref (это её id в CRM): вебхук по ней не создаёт дубля.
 */
@Injectable()
export class PmsSyncService {
  private readonly logger = new Logger(PmsSyncService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly effects: BookingEffectsService,
    private readonly stageAutomation: StageAutomationService,
  ) {}

  async apply(pms: PmsBooking): Promise<PmsSyncOutcome> {
    const { outcome, dealId } = await this.applyInTransaction(pms);
    if (dealId) await this.stageAutomation.onDealChanged(dealId);
    return outcome;
  }

  private applyInTransaction(pms: PmsBooking): Promise<{ outcome: PmsSyncOutcome; dealId: string | null }> {
    return this.prisma.$transaction(async (tx) => {
      const property = await tx.property.findUnique({ where: { pmsId: pms.apartment_id } });
      if (!property) {
        this.logger.warn(`Квартира PMS ${pms.apartment_id} не привязана к объекту CRM — выполните синхронизацию объектов`);
        return { outcome: 'skipped', dealId: null };
      }
      const snapshot = toPmsSnapshot(pms, property);
      if (!snapshot) return { outcome: 'skipped', dealId: null };

      // Повторы и параллельные события по одной брони — строго по очереди.
      await lockBooking(tx, { rcId: null, importKey: `pms:${pms.id}` });
      const own = await tx.booking.findUnique({ where: { pmsId: pms.id } });
      // Эхо брони, внесённой в CRM: external_ref = её id в CRM.
      const echoed =
        !own && pms.external_ref
          ? await tx.booking.findFirst({ where: { id: pms.external_ref, pmsId: null } })
          : null;
      const existing = own ?? echoed;
      if (existing && existing.rcId !== null) {
        // Бронь уже ведёт RealtyCalendar (переходный период): PMS её не перезаписывает.
        return { outcome: 'skipped', dealId: null };
      }
      if (existing && existing.rcUpdatedAt > snapshot.rcUpdatedAt) {
        // Эхо своей же брони (CRM записала её позже, чем PMS создала) или устаревший повтор — только привязываем id.
        if (!existing.pmsId) await tx.booking.update({ where: { id: existing.id }, data: { pmsId: pms.id, pmsSyncedAt: new Date(), pmsError: null } });
        return { outcome: 'stale', dealId: null };
      }

      // Пустые поля из PMS не стирают то, что сотрудник внёс в CRM.
      const current = keepCrmValues(snapshot, existing);
      const contactId =
        existing && !guestChanged(existing, current)
          ? existing.contactId
          : await this.effects.resolveContact(tx, current, PMS_ACTOR);
      const previous = existing && contactId !== existing.contactId ? { ...existing, dealId: null } : existing;
      const finished = current.checkOut < tashkentToday(new Date());
      const dealId =
        finished && !previous?.dealId
          ? null
          : await this.effects.syncDeal(tx, current, contactId, previous, PMS_ACTOR);
      const data = toBookingRow(current, { propertyId: property.id, contactId, dealId });
      const booking: Booking = existing
        ? await tx.booking.update({
            where: { id: existing.id },
            data: { ...data, pmsId: pms.id, pmsSyncedAt: new Date(), pmsError: null },
          })
        : await tx.booking.create({
            data: { source: 'PMS', pmsId: pms.id, pmsSyncedAt: new Date(), ...data },
          });
      await this.effects.syncTasks(tx, booking, current, existing);
      await this.effects.recordHistory(tx, booking, current, existing, PMS_ACTOR);
      return { outcome: existing ? 'updated' : 'created', dealId: booking.dealId };
    });
  }
}
