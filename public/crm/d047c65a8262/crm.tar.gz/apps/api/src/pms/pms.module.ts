import { Module } from '@nestjs/common';
import { RealtyCalendarModule } from '../realtycalendar/realtycalendar.module.js';
import { StageAutomationModule } from '../stage-automation/stage-automation.module.js';
import { PmsCoreModule } from './pms-core.module.js';
import { PmsSyncService } from './pms-sync.service.js';
import { PmsWebhookController } from './pms-webhook.controller.js';
import { PmsController } from './pms.controller.js';

/** Приём броней из PMS Urban Luxe (вебхук) и настройки моста. См. docs/PMS-BRIDGE.md. */
@Module({
  imports: [PmsCoreModule, RealtyCalendarModule, StageAutomationModule],
  controllers: [PmsWebhookController, PmsController],
  providers: [PmsSyncService],
})
export class PmsModule {}
