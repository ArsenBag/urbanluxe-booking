import { Module } from '@nestjs/common';
import { PmsClient } from './pms-client.js';
import { PmsOutboundService } from './pms-outbound.service.js';
import { PmsPropertiesService } from './pms-properties.service.js';
import { PmsStateService } from './pms-state.service.js';

/**
 * Ядро моста с PMS Urban Luxe: HTTP-клиент, отправка броней CRM в PMS, синхронизация объектов.
 * Отдельно от PmsModule, чтобы RealtyCalendarModule (брони CRM) мог его импортировать без цикла.
 */
@Module({
  providers: [PmsClient, PmsOutboundService, PmsPropertiesService, PmsStateService],
  exports: [PmsClient, PmsOutboundService, PmsPropertiesService, PmsStateService],
})
export class PmsCoreModule {}
