import { Injectable } from '@nestjs/common';

/** Что видно в «Настройки → Интеграции → PMS»: когда приходил последний вебхук и какой. Живёт в памяти процесса. */
@Injectable()
export class PmsStateService {
  lastWebhookAt: Date | null = null;
  lastWebhookEvent: string | null = null;
  lastPropertiesSyncAt: Date | null = null;

  touch(event: string): void {
    this.lastWebhookAt = new Date();
    this.lastWebhookEvent = event;
  }
}
