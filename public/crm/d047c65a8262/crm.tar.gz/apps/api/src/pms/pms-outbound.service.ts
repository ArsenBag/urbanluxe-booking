import {
  ConflictException,
  Injectable,
  Logger,
  type OnApplicationBootstrap,
  type OnModuleDestroy,
} from '@nestjs/common';
import { dateOnlyFromDb } from '../common/dates.js';
import type { Booking, Property } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { PmsClient, PmsError, type PmsBookingInput } from './pms-client.js';

/** Повтор невыгруженных броней CRM: сеть или 5xx у PMS не должны терять бронь. */
const RETRY_INTERVAL_MS = 60_000;
const FIRST_RUN_DELAY_MS = 20_000;
const RETRY_BATCH = 20;
const ERROR_TEXT_LIMIT = 300;

const decimal = (value: { toNumber(): number } | null) => value?.toNumber() ?? null;

/** Бронь CRM → тело запроса PMS. external_ref = id брони в CRM: по нему вебхук PMS узнаёт своё эхо. */
export function toPmsInput(booking: Booking, property: Property): PmsBookingInput {
  return {
    apartment_id: property.pmsId ?? '',
    check_in: dateOnlyFromDb(booking.checkIn),
    check_out: dateOnlyFromDb(booking.checkOut),
    guest: { name: booking.guestName, phone: booking.guestPhone, email: booking.guestEmail },
    status: booking.status === 'REQUEST' ? 'request' : 'confirmed',
    total_price: decimal(booking.amount),
    prepaid: decimal(booking.prepayment),
    notes: booking.notes,
    arrival_time: booking.arrivalTime,
    departure_time: booking.departureTime,
    external_ref: booking.id,
  };
}

/**
 * Брони, внесённые в CRM, → PMS Urban Luxe (там они закрывают даты на площадках). Смысловой отказ PMS
 * (даты заняты) — ошибка пользователю сразу; сетевой — бронь сохраняется с пометкой и уходит повтором.
 */
@Injectable()
export class PmsOutboundService implements OnApplicationBootstrap, OnModuleDestroy {
  private readonly logger = new Logger(PmsOutboundService.name);
  private timer: NodeJS.Timeout | null = null;
  private firstRun: NodeJS.Timeout | null = null;
  private running = false;

  constructor(
    private readonly prisma: PrismaService,
    private readonly client: PmsClient,
  ) {}

  get enabled(): boolean {
    return this.client.enabled;
  }

  onApplicationBootstrap(): void {
    if (!this.enabled) return;
    this.firstRun = setTimeout(() => void this.retryPending(), FIRST_RUN_DELAY_MS);
    this.firstRun.unref();
    this.timer = setInterval(() => void this.retryPending(), RETRY_INTERVAL_MS);
    this.timer.unref();
  }

  onModuleDestroy(): void {
    if (this.firstRun) clearTimeout(this.firstRun);
    if (this.timer) clearInterval(this.timer);
  }

  /**
   * Проверка занятости в PMS до записи в CRM: PMS главный по занятости (знает все площадки).
   * Возвращает pmsId созданной брони; null — PMS недоступна (бронь запишется в CRM и уйдёт повтором).
   * Квартира без pmsId — ошибка: сначала «Синхронизировать объекты» в настройках.
   */
  async reserve(bookingId: string, draft: Omit<PmsBookingInput, 'external_ref'>, property: Property): Promise<string | null> {
    if (!this.enabled) return null;
    if (!property.pmsId) {
      throw new ConflictException('Квартира не привязана к PMS — выполните «Синхронизировать объекты» в Настройки → Интеграции');
    }
    try {
      const created = await this.client.createBooking({ ...draft, external_ref: bookingId });
      return created.id;
    } catch (error) {
      this.rethrowIfFinal(error);
      return null;
    }
  }

  /** Отмена брони в PMS, если запись в CRM не удалась после успешного reserve. */
  async release(pmsId: string): Promise<void> {
    try {
      await this.client.cancelBooking(pmsId, 'CRM: запись не удалась');
    } catch (error) {
      this.logger.warn(`Не удалось отменить бронь PMS ${pmsId} после сбоя CRM: ${(error as Error).message}`);
    }
  }

  /**
   * Изменение брони CRM → PATCH в PMS (до записи в CRM: пересечение дат вернёт 409 и запись не состоится).
   * 'sent' — PMS приняла; 'failed' — сеть/5xx (CRM запишет изменение, повтор отправит его); 'skipped' — брони в PMS нет.
   */
  async update(booking: Pick<Booking, 'pmsId'>, input: PmsBookingInput): Promise<'sent' | 'failed' | 'skipped'> {
    if (!this.enabled || !booking.pmsId) return 'skipped';
    try {
      await this.client.updateBooking(booking.pmsId, input);
      return 'sent';
    } catch (error) {
      this.rethrowIfFinal(error);
      return 'failed';
    }
  }

  async cancel(bookingId: string): Promise<void> {
    if (!this.enabled) return;
    const booking = await this.prisma.booking.findUnique({ where: { id: bookingId } });
    if (!booking?.pmsId) return;
    try {
      await this.client.cancelBooking(booking.pmsId, 'Отменена в CRM');
      await this.markSynced(bookingId);
    } catch (error) {
      if (error instanceof PmsError && (error.code === 'bad_status' || error.status === 404)) {
        await this.markSynced(bookingId);
        return;
      }
      await this.markError(bookingId, error);
    }
  }

  async markSynced(bookingId: string, pmsId?: string): Promise<void> {
    await this.prisma.booking.update({
      where: { id: bookingId },
      data: { pmsSyncedAt: new Date(), pmsError: null, ...(pmsId ? { pmsId } : {}) },
    });
  }

  async markError(bookingId: string, error: unknown): Promise<void> {
    const text = (error as Error).message ?? String(error);
    await this.prisma.booking.update({
      where: { id: bookingId },
      data: { pmsError: text.slice(0, ERROR_TEXT_LIMIT) },
    });
  }

  /** Невыгруженные и изменённые после последней отправки брони CRM — отправить заново. */
  async retryPending(): Promise<number> {
    if (this.running || !this.enabled) return 0;
    this.running = true;
    let sent = 0;
    try {
      const pending = await this.prisma.booking.findMany({
        where: {
          source: 'CRM',
          rcId: null,
          property: { pmsId: { not: null } },
          OR: [{ pmsSyncedAt: null }, { pmsError: { not: null } }],
        },
        include: { property: true },
        orderBy: { updatedAt: 'asc' },
        take: RETRY_BATCH,
      });
      for (const booking of pending) {
        if (!booking.property?.pmsId) continue;
        try {
          if (booking.status === 'CANCELED' || booking.status === 'DELETED') {
            if (booking.pmsId) await this.client.cancelBooking(booking.pmsId, 'Отменена в CRM');
            await this.markSynced(booking.id);
          } else if (booking.pmsId) {
            await this.client.updateBooking(booking.pmsId, toPmsInput(booking, booking.property));
            await this.markSynced(booking.id);
          } else {
            const created = await this.client.createBooking(toPmsInput(booking, booking.property));
            await this.markSynced(booking.id, created.id);
          }
          sent++;
        } catch (error) {
          // Смысловой отказ (даты заняты в PMS) повтором не лечится: остаётся пометкой в карточке брони.
          await this.markError(booking.id, error);
          if (!(error instanceof PmsError) || !error.isFinal) break; // PMS недоступна — остальные подождут минуту
        }
      }
    } catch (error) {
      this.logger.error(`Повтор отправки в PMS: ${(error as Error).message}`);
    } finally {
      this.running = false;
    }
    if (sent) this.logger.log(`В PMS отправлено броней: ${sent}`);
    return sent;
  }

  private rethrowIfFinal(error: unknown): void {
    if (error instanceof PmsError && error.isFinal) {
      if (error.code === 'dates_taken') {
        throw new ConflictException('Даты заняты в PMS (другая бронь или площадка) — выберите другие даты');
      }
      throw new ConflictException(`PMS отклонила бронь: ${error.message}`);
    }
    this.logger.warn(`PMS недоступна, бронь уйдёт повтором: ${(error as Error).message}`);
  }
}
