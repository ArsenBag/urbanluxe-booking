import { Injectable, Logger } from '@nestjs/common';
import type { PmsPropertiesSyncResultDto } from '@crm/shared';
import { PrismaService } from '../prisma/prisma.service.js';
import { complexOfProperty } from '../realtycalendar/complexes.js';
import { PmsClient } from './pms-client.js';
import { PmsStateService } from './pms-state.service.js';

export type PmsPropertiesSyncResult = PmsPropertiesSyncResultDto;

/**
 * Квартиры CRM → PMS Urban Luxe (организация High Life). Объект без ЖК (строка ЖК из старой выгрузки,
 * «Объект 313432») пропускается. По rcId PMS привязывает общие квартиры к уже существующим.
 */
@Injectable()
export class PmsPropertiesService {
  private readonly logger = new Logger(PmsPropertiesService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly client: PmsClient,
    private readonly state: PmsStateService,
  ) {}

  async syncAll(): Promise<PmsPropertiesSyncResult> {
    const result: PmsPropertiesSyncResult = { total: 0, created: 0, linked: 0, updated: 0, skipped: [] };
    if (!this.client.enabled) {
      result.skipped.push({ id: '-', title: '-', reason: 'PMS не настроена (PMS_API_KEY)' });
      return result;
    }
    const properties = await this.prisma.property.findMany({ orderBy: { title: 'asc' } });
    result.total = properties.length;
    for (const property of properties) {
      // Строки ЖК из выгрузки Excel (без rcId) — не квартиры.
      if (property.rcId === null) {
        result.skipped.push({ id: property.id, title: property.title, reason: 'не квартира (строка ЖК из выгрузки)' });
        continue;
      }
      const complex = complexOfProperty(property);
      if (!complex) {
        result.skipped.push({ id: property.id, title: property.title, reason: 'ЖК не узнан по адресу и коду' });
        continue;
      }
      try {
        const r = await this.client.upsertApartment({
          external_ref: property.id,
          name: property.title,
          complex,
          address: property.address,
          rc_id: property.rcId,
          is_active: true,
        });
        await this.prisma.property.update({ where: { id: property.id }, data: { pmsId: r.id, pmsSyncedAt: new Date() } });
        if (r.created) result.created++;
        else if (r.linked_existing) result.linked++;
        else result.updated++;
      } catch (error) {
        result.skipped.push({ id: property.id, title: property.title, reason: (error as Error).message });
      }
    }
    this.state.lastPropertiesSyncAt = new Date();
    this.logger.log(`Объекты → PMS: создано ${result.created}, привязано ${result.linked}, обновлено ${result.updated}, пропущено ${result.skipped.length}`);
    return result;
  }
}
