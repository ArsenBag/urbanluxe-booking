import { Injectable, Logger } from '@nestjs/common';
import type { PmsPropertiesSyncResultDto } from '@crm/shared';
import { PrismaService } from '../prisma/prisma.service.js';
import { complexOfProperty } from '../realtycalendar/complexes.js';
import { PmsClient } from './pms-client.js';
import { PmsStateService } from './pms-state.service.js';

export type PmsPropertiesSyncResult = PmsPropertiesSyncResultDto;

/**
 * Квартиры CRM → PMS Urban Luxe (организация High Life). Объект без ЖК (строка ЖК из старой выгрузки,
 * «Объект 313432») пропускается. По rcId PMS привязывает общие квартиры к уже существующим.
 */
@Injectable()
export class PmsPropertiesService {
  private readonly logger = new Logger(PmsPropertiesService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly client: PmsClient,
    private readonly state: PmsStateService,
  ) {}

  /**
   * Квартиры PMS → объекты CRM (для экземпляра CRM Urban Luxe, где объектов из RealtyCalendar нет).
   * Привязка: по pmsId, иначе по rcId (объект RealtyCalendar из вебхуков), иначе создаётся новый. Квартира без
   * RealtyCalendar получает служебный rcId (9 000 000 + порядковый): код CRM считает квартирой только объект с rcId.
   */
  async importFromPms(): Promise<PmsPropertiesSyncResult> {
    const result: PmsPropertiesSyncResult = { total: 0, created: 0, linked: 0, updated: 0, skipped: [] };
    if (!this.client.enabled) {
      result.skipped.push({ id: '-', title: '-', reason: 'PMS не настроена (PMS_API_KEY)' });
      return result;
    }
    const apartments = await this.client.apartments();
    result.total = apartments.length;
    const SYNTHETIC_RC_FROM = 9_000_000;
    let next = ((await this.prisma.property.aggregate({ _max: { rcId: true }, where: { rcId: { gte: SYNTHETIC_RC_FROM } } }))._max.rcId ?? SYNTHETIC_RC_FROM - 1) + 1;
    for (const apt of apartments) {
      const title = apt.complex ? `${apt.complex} ${apt.name.replace(/^Апартамент\s*/i, '')}`.trim() : apt.name;
      try {
        const byPms = await this.prisma.property.findUnique({ where: { pmsId: apt.id } });
        if (byPms) {
          await this.prisma.property.update({ where: { id: byPms.id }, data: { title, address: apt.complex ?? byPms.address, pmsSyncedAt: new Date() } });
          result.updated++;
          continue;
        }
        const byRc = apt.rc_id ? await this.prisma.property.findUnique({ where: { rcId: apt.rc_id } }) : null;
        if (byRc) {
          await this.prisma.property.update({ where: { id: byRc.id }, data: { pmsId: apt.id, pmsSyncedAt: new Date() } });
          result.linked++;
          continue;
        }
        await this.prisma.property.create({
          data: { title, address: apt.complex, rcId: apt.rc_id ?? next++, pmsId: apt.id, pmsSyncedAt: new Date() },
        });
        result.created++;
      } catch (error) {
        result.skipped.push({ id: apt.id, title, reason: (error as Error).message });
      }
    }
    this.state.lastPropertiesSyncAt = new Date();
    this.logger.log(`Квартиры из PMS: создано ${result.created}, привязано ${result.linked}, обновлено ${result.updated}, ошибок ${result.skipped.length}`);
    return result;
  }

  async syncAll(): Promise<PmsPropertiesSyncResult> {
    const result: PmsPropertiesSyncResult = { total: 0, created: 0, linked: 0, updated: 0, skipped: [] };
    if (!this.client.enabled) {
      result.skipped.push({ id: '-', title: '-', reason: 'PMS не настроена (PMS_API_KEY)' });
      return result;
    }
    const properties = await this.prisma.property.findMany({ orderBy: { title: 'asc' } });
    result.total = properties.length;
    for (const property of properties) {
      // Строки ЖК из выгрузки Excel (без rcId) — не квартиры.
      if (property.rcId === null) {
        result.skipped.push({ id: property.id, title: property.title, reason: 'не квартира (строка ЖК из выгрузки)' });
        continue;
      }
      const complex = complexOfProperty(property);
      if (!complex) {
        result.skipped.push({ id: property.id, title: property.title, reason: 'ЖК не узнан по адресу и коду' });
        continue;
      }
      try {
        const r = await this.client.upsertApartment({
          external_ref: property.id,
          name: property.title,
          complex,
          address: property.address,
          rc_id: property.rcId,
          is_active: true,
        });
        await this.prisma.property.update({ where: { id: property.id }, data: { pmsId: r.id, pmsSyncedAt: new Date() } });
        if (r.created) result.created++;
        else if (r.linked_existing) result.linked++;
        else result.updated++;
      } catch (error) {
        result.skipped.push({ id: property.id, title: property.title, reason: (error as Error).message });
      }
    }
    this.state.lastPropertiesSyncAt = new Date();
    this.logger.log(`Объекты → PMS: создано ${result.created}, привязано ${result.linked}, обновлено ${result.updated}, пропущено ${result.skipped.length}`);
    return result;
  }
}
