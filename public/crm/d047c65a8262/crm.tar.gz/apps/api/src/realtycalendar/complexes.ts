/**
 * Жилые комплексы High Life по адресу. В выгрузке RealtyCalendar вместо квартиры указан адрес дома,
 * причём в разных написаниях («Массив Бешагач 1/1», «Шайхантахурский район, массив Бешагач, 1/1»…).
 * Сопоставление подтверждено владельцем 2026-10-04. У части квартир RealtyCalendar адрес не заполнен —
 * для них ЖК узнаём по началу кода квартиры (U-13, Modera-294, NO_10_179…; NO_ — Nest One, со слов
 * владельца 2026-10-08).
 */
const COMPLEXES: Array<{ title: string; patterns: RegExp[]; codes: RegExp[] }> = [
  { title: 'U-Tower', patterns: [/бешагач\D*1\s*\/\s*1/], codes: [/^u-\d/] },
  { title: 'Modera Towers', patterns: [/руставели\D*19/], codes: [/^modera\b/] },
  { title: 'NRG Oybek', patterns: [/нукус\D*31\s*\/\s*1/], codes: [/^oybek\b/] },
  { title: 'Seoul Moon', patterns: [/баходира\D*2\s*\/\s*2/], codes: [/^sm\s*-\s*\d/] },
  { title: 'Gardens Residence', patterns: [/алишера навои\D*3\b/], codes: [/^gardens\b/] },
  { title: 'Nest One', patterns: [/батыра закирова\D*1\s*а/], codes: [/^no_\d/] },
  { title: 'Parkwood', patterns: [/мироншаха\D*[68]\b/], codes: [/^p-/] },
];

const normalize = (text: string | null | undefined) =>
  text?.toLowerCase().replace(/ё/g, 'е').replace(/\s+/g, ' ').trim() ?? '';

/** Название ЖК по адресу или null, если адрес не узнан. */
export function complexForAddress(address: string | null | undefined): string | null {
  const normalized = normalize(address);
  if (!normalized) return null;
  return COMPLEXES.find((complex) => complex.patterns.some((pattern) => pattern.test(normalized)))?.title ?? null;
}

/** Название ЖК по коду квартиры RealtyCalendar («U-13», «NO_10_179») или null. */
function complexForCode(title: string): string | null {
  const normalized = normalize(title);
  if (!normalized) return null;
  return COMPLEXES.find((complex) => complex.codes.some((code) => code.test(normalized)))?.title ?? null;
}

/**
 * ЖК квартиры CRM: по адресу, по названию, по коду квартиры, а у строк из выгрузки Excel (без rcId)
 * название и есть ЖК. null — квартира RealtyCalendar без узнаваемого адреса и кода («Объект 313432»).
 */
export function complexOfProperty(property: { title: string; address: string | null; rcId: number | null }): string | null {
  return (
    complexForAddress(property.address) ??
    complexForAddress(property.title) ??
    complexForCode(property.title) ??
    (property.rcId === null ? property.title : null)
  );
}
