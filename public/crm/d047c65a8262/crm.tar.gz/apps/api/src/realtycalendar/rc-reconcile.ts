import type { BookingStatus } from '../generated/prisma/client.js';
import { isCanceled, type BookingSnapshot } from './rc-mapper.js';

/** Бронь CRM для сверки: даты YYYY-MM-DD, ЖК — по адресу квартиры или строке выгрузки. */
export interface CrmBookingRef {
  id: string;
  rcId: number | null;
  importKey: string | null;
  checkIn: string;
  checkOut: string;
  guestPhone: string | null;
  complex: string | null;
  origin: string | null;
  status: BookingStatus;
}

/**
 * known — строка уже загружена прежней выгрузкой и вебхука по ней не было (её можно обновить);
 * matched — та же бронь уже пришла вебхуком (её не трогаем: в вебхуке точнее квартира и данные);
 * canceled — бронь отменена в CRM (вебхуком или при прошлой сверке): в выгрузке нет статуса,
 *   отменённые брони в ней выглядят действующими, поэтому такую строку не загружаем;
 * new — в CRM такой брони нет.
 */
export type ReconcileKind = 'known' | 'matched' | 'canceled' | 'new';

/** По какому признаку найдена пара: ключ строки, телефон гостя или только ЖК и даты (слабый признак). */
export type MatchBasis = 'key' | 'phone' | 'complex';

export interface ReconciledRow {
  snapshot: BookingSnapshot;
  kind: ReconcileKind;
  bookingId: string | null;
  /** Пара — бронь из вебхука (а не строка прежней выгрузки). */
  viaWebhook: boolean;
  basis: MatchBasis | null;
}

export interface ReconcileResult {
  rows: ReconciledRow[];
  /** Подтверждённые брони CRM, которых нет в выгрузке: возможно, отменены в RealtyCalendar, а вебхук не дошёл. */
  missingInExcel: CrmBookingRef[];
}

type Fits = (snapshot: BookingSnapshot, booking: CrmBookingRef) => boolean;

const sameStay: Fits = (snapshot, booking) =>
  booking.checkIn === snapshot.checkIn && booking.checkOut === snapshot.checkOut;

/** Ключ строки: та же строка, загруженная прежней выгрузкой (возможно, потом привязанная вебхуком). */
const byImportKey: Fits = (snapshot, booking) => snapshot.importKey !== null && booking.importKey === snapshot.importKey;

const byPhone: Fits = (snapshot, booking) =>
  sameStay(snapshot, booking) && snapshot.guestPhone !== null && booking.guestPhone === snapshot.guestPhone;

/** Тот же ЖК и даты — только если телефон неизвестен хотя бы с одной стороны: разные известные гости — не пара. */
const byComplex: Fits = (snapshot, booking) =>
  sameStay(snapshot, booking) &&
  booking.complex !== null &&
  booking.complex === snapshot.property?.title &&
  (snapshot.guestPhone === null || booking.guestPhone === null);

const live = (booking: CrmBookingRef) => !isCanceled(booking.status);
const canceled = (booking: CrmBookingRef) => isCanceled(booking.status);
const any = () => true;

/**
 * Проходы от надёжного признака к слабому: ключ строки (при любом статусе), телефон, затем только ЖК и даты.
 * Внутри признака сначала действующие брони, потом отменённые: при равной уверенности строка достаётся
 * действующей, но совпадение по телефону с отменённой важнее, чем совпадение одного ЖК с действующей.
 */
const PASSES: ReadonlyArray<[MatchBasis, Fits, (booking: CrmBookingRef) => boolean]> = [
  ['key', byImportKey, any],
  ['phone', byPhone, live],
  ['phone', byPhone, canceled],
  ['complex', byComplex, live],
  ['complex', byComplex, canceled],
];

function kindOf(snapshot: BookingSnapshot, booking: CrmBookingRef): ReconcileKind {
  if (isCanceled(booking.status)) return 'canceled';
  const isOwnRow = booking.importKey === snapshot.importKey && booking.rcId === null;
  return isOwnRow ? 'known' : 'matched';
}

/**
 * Сверка выгрузки Excel с бронями CRM. В выгрузке нет номера брони, квартиры и статуса — только адрес дома,
 * поэтому пары ищем проходами по всем строкам (PASSES). Каждый проход идёт по всем строкам, чтобы порядок
 * строк не влиял на результат; каждая бронь CRM достаётся не больше чем одной строке.
 */
export function reconcileExcel(snapshots: BookingSnapshot[], bookings: CrmBookingRef[]): ReconcileResult {
  const assigned = new Map<number, { booking: CrmBookingRef; basis: MatchBasis }>();
  const taken = new Set<string>();
  for (const [basis, fits, eligible] of PASSES) {
    snapshots.forEach((snapshot, index) => {
      if (assigned.has(index)) return;
      const booking = bookings.find(
        (candidate) => !taken.has(candidate.id) && eligible(candidate) && fits(snapshot, candidate),
      );
      if (!booking) return;
      assigned.set(index, { booking, basis });
      taken.add(booking.id);
    });
  }

  const rows = snapshots.map((snapshot, index): ReconciledRow => {
    const pair = assigned.get(index);
    if (!pair) return { snapshot, kind: 'new', bookingId: null, viaWebhook: false, basis: null };
    const { booking, basis } = pair;
    return {
      snapshot,
      kind: kindOf(snapshot, booking),
      bookingId: booking.id,
      viaWebhook: booking.rcId !== null,
      basis,
    };
  });
  return {
    rows,
    missingInExcel: bookings.filter((booking) => booking.status === 'BOOKED' && !taken.has(booking.id)),
  };
}
