import { createHash } from 'node:crypto';
import { nightsBetween, normalizePhone } from '@crm/shared';
import { XMLParser } from 'fast-xml-parser';
import { complexForAddress } from './complexes.js';
import type { BookingSnapshot } from './rc-mapper.js';

/** Колонки выгрузки броней RealtyCalendar (Excel 2003 XML). */
const COLUMNS = ['Объект', 'Заезд', 'Выезд', 'Контакты', 'Примечания', 'Гостей', 'Сумма', 'Источник', 'Менеджер'] as const;
type Column = (typeof COLUMNS)[number];
export type ExcelRow = Record<Column, string>;

const PHONE_PATTERN = /\+?\d[\d\s()-]{7,}\d/;
/** «manual» в выгрузке означает «внесена вручную» — это не площадка. */
const MANUAL_SOURCES = new Set(['', 'manual']);

interface XmlCell {
  'Data'?: { '#text'?: string | number } | string | number;
  '@_Index'?: string;
}

const asArray = <T>(value: T | T[] | undefined): T[] => (value === undefined ? [] : Array.isArray(value) ? value : [value]);

function cellText(cell: XmlCell): string {
  const data = cell['Data'];
  if (data === undefined) return '';
  const value = typeof data === 'object' ? data['#text'] : data;
  return value === undefined ? '' : String(value).trim();
}

/** Строки первого листа как записи «колонка → значение». Колонки ищутся по заголовку. */
export function parseSpreadsheetMl(xml: string): ExcelRow[] {
  const parser = new XMLParser({ removeNSPrefix: true, ignoreAttributes: false, attributeNamePrefix: '@_', parseTagValue: false, trimValues: true });
  const workbook = parser.parse(xml)?.Workbook;
  const worksheet = asArray(workbook?.Worksheet)[0];
  const rows = asArray<{ 'Cell'?: XmlCell | XmlCell[] }>(worksheet?.Table?.Row);
  if (rows.length === 0) {
    throw new Error('В файле не найдено ни одной строки: это не выгрузка броней RealtyCalendar?');
  }
  const toValues = (row: { 'Cell'?: XmlCell | XmlCell[] }): string[] => {
    const values: string[] = [];
    for (const cell of asArray(row['Cell'])) {
      const index = cell['@_Index'];
      if (index) while (values.length < Number(index) - 1) values.push('');
      values.push(cellText(cell));
    }
    return values;
  };
  const header = toValues(rows[0]);
  const missing = COLUMNS.filter((column) => !header.includes(column) && column !== 'Гостей');
  if (missing.length > 0) {
    throw new Error(`В выгрузке нет колонок: ${missing.join(', ')}`);
  }
  return rows.slice(1).map((row) => {
    const values = toValues(row);
    return Object.fromEntries(COLUMNS.map((column) => [column, values[header.indexOf(column)] ?? ''])) as ExcelRow;
  });
}

/** 25.10.2026 → 2026-10-25. */
function toIsoDate(value: string): string {
  const match = /^(\d{2})\.(\d{2})\.(\d{4})$/.exec(value);
  // Значение ячейки в сообщение не пишем: при сдвиге колонок там оказались бы имя или телефон гостя.
  if (!match) throw new Error("Неожиданный формат даты в выгрузке (ожидается ДД.ММ.ГГГГ)");
  return `${match[3]}-${match[2]}-${match[1]}`;
}

/** Имя и телефон из колонки «Контакты» («Имя Фамилия +998 90 123 45 67»), телефон — также из примечаний. */
export function parseGuest(contacts: string, notes: string): { name: string | null; phone: string | null } {
  const phoneText = PHONE_PATTERN.exec(contacts)?.[0] ?? PHONE_PATTERN.exec(notes)?.[0] ?? null;
  const phone = phoneText ? normalizePhone(phoneText) : null;
  const name = contacts
    .replace(PHONE_PATTERN, ' ')
    .replace(/[,;]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return { name: name || null, phone };
}

/**
 * Строки выгрузки → брони для импорта: только с выездом не раньше fromDate (YYYY-MM-DD; обычно сегодня —
 * будущие и те, кто живёт сейчас). Ключ строки — хэш её содержимого: повторный импорт того же файла
 * обновляет брони, а не дублирует.
 */
export function toImportSnapshots(rows: ExcelRow[], fromDate: string, importedAt: Date): BookingSnapshot[] {
  const seen = new Map<string, number>();
  const result: BookingSnapshot[] = [];
  for (const row of rows) {
    if (!row['Заезд'] || !row['Выезд']) continue;
    const checkIn = toIsoDate(row['Заезд']);
    const checkOut = toIsoDate(row['Выезд']);
    // Одинаковые строки (две брони в разных квартирах одного дома) различаем порядковым номером.
    const content = COLUMNS.map((column) => row[column]).join('␟');
    const occurrence = (seen.get(content) ?? 0) + 1;
    seen.set(content, occurrence);
    if (checkOut < fromDate) continue;

    const { name, phone } = parseGuest(row['Контакты'], row['Примечания']);
    const amount = row['Сумма'] ? Number(row['Сумма'].replace(',', '.')) : null;
    const source = row['Источник'].trim();
    const address = row['Объект'].trim();
    result.push({
      rcId: null,
      importKey: createHash('sha256').update(`${content}␟${occurrence}`).digest('hex'),
      status: 'BOOKED',
      checkIn,
      checkOut,
      nights: nightsBetween(checkIn, checkOut),
      arrivalTime: null,
      departureTime: null,
      amount: amount !== null && Number.isFinite(amount) ? amount : null,
      prepayment: null,
      deposit: null,
      origin: MANUAL_SOURCES.has(source.toLowerCase()) ? null : source,
      guestName: name,
      guestPhone: phone,
      guestEmail: null,
      notes: row['Примечания'] || null,
      rcUrl: null,
      rcUpdatedAt: importedAt,
      property: address ? { rcId: null, title: complexForAddress(address) ?? address, address } : null,
    });
  }
  return result;
}
