import {
  Body,
  Controller,
  Get,
  HttpCode,
  Param,
  ParseUUIDPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import {
  bookingRangeQuerySchema,
  isoDateSchema,
  linkSearchQuerySchema,
  manualBookingSchema,
  type BookingDayDto,
  type BookingDto,
  type BookingRangeQuery,
  type LinkSearchQuery,
  type ManualBookingInput,
  type PropertyDto,
  type RealtyCalendarStatusDto,
} from '@crm/shared';
import { z } from 'zod';
import { CurrentUser, Roles } from '../auth/decorators.js';
import type { SessionUser } from '../auth/session-user.js';
import { ZodValidationPipe } from '../common/zod-validation.pipe.js';
import { BookingsService } from './bookings.service.js';
import { ManualBookingsService } from './manual-bookings.service.js';

const uuid = () => new ParseUUIDPipe();
/** Сотрудник вносит брони руками; больше — это скрипт или зацикленная форма. */
const BOOKING_CHANGES_PER_MINUTE = 60;
const ONE_MINUTE_MS = 60_000;
const BOOKING_CHANGES_LIMIT = {
  default: { limit: BOOKING_CHANGES_PER_MINUTE, ttl: ONE_MINUTE_MS },
};
const dayQuerySchema = z.object({ date: isoDateSchema });

@Controller()
export class BookingsController {
  constructor(
    private readonly bookings: BookingsService,
    private readonly manual: ManualBookingsService,
  ) {}

  @Get('bookings')
  range(
    @Query(new ZodValidationPipe(bookingRangeQuerySchema))
    query: BookingRangeQuery,
  ): Promise<BookingDto[]> {
    return this.bookings.range(query);
  }

  /** Бронь, внесённая сотрудником на шахматке (в RealtyCalendar её нужно внести отдельно). */
  @Post('bookings')
  @Throttle(BOOKING_CHANGES_LIMIT)
  create(
    @Body(new ZodValidationPipe(manualBookingSchema)) input: ManualBookingInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<BookingDto> {
    return this.manual.create(input, actor);
  }

  /** Правка брони из CRM целиком, как в окне брони. Брони из RealtyCalendar меняются только там. */
  @Put('bookings/:id')
  @Throttle(BOOKING_CHANGES_LIMIT)
  update(
    @Param('id', uuid()) id: string,
    @Body(new ZodValidationPipe(manualBookingSchema)) input: ManualBookingInput,
    @CurrentUser() actor: SessionUser,
  ): Promise<BookingDto> {
    return this.manual.update(id, input, actor);
  }

  @Post('bookings/:id/cancel')
  @Throttle(BOOKING_CHANGES_LIMIT)
  @HttpCode(200)
  cancel(
    @Param('id', uuid()) id: string,
    @CurrentUser() actor: SessionUser,
  ): Promise<BookingDto> {
    return this.manual.cancel(id, actor);
  }

  /** Поиск брони из диалога: код квартиры, имя гостя или телефон. */
  @Get('bookings/search')
  search(
    @Query(new ZodValidationPipe(linkSearchQuerySchema)) query: LinkSearchQuery,
  ): Promise<BookingDto[]> {
    return this.bookings.search(query.q);
  }

  @Get('bookings/day')
  day(
    @Query(new ZodValidationPipe(dayQuerySchema)) query: { date: string },
  ): Promise<BookingDayDto> {
    return this.bookings.day(query.date);
  }

  @Get('properties')
  properties(): Promise<PropertyDto[]> {
    return this.bookings.properties();
  }

  @Get('contacts/:id/bookings')
  byContact(@Param('id', uuid()) id: string): Promise<BookingDto[]> {
    return this.bookings.byContact(id);
  }

  @Get('deals/:id/bookings')
  byDeal(@Param('id', uuid()) id: string): Promise<BookingDto[]> {
    return this.bookings.byDeal(id);
  }

  /** Адрес вебхука содержит секрет — только администратору. */
  @Get('integrations/realtycalendar')
  @Roles('ADMIN')
  status(): Promise<RealtyCalendarStatusDto> {
    return this.bookings.status();
  }
}
