import {
  Body,
  Controller,
  HttpCode,
  HttpStatus,
  Inject,
  Logger,
  NotFoundException,
  Param,
  Post,
} from '@nestjs/common';
import { timingSafeEqual } from 'node:crypto';
import type { z } from 'zod';
import { Public } from '../auth/decorators.js';
import { ENV, type Env } from '../config/env.js';
import { toBookingSnapshot, unreadableFields } from './rc-mapper.js';
import { describeShape } from './rc-webhook-shape.js';
import { rcWebhookSchema, rcWebhookStrictSchema } from './rc-webhook.schema.js';
import { RealtyCalendarSyncService } from './realtycalendar-sync.service.js';

function secretsMatch(expected: string, received: string): boolean {
  const a = Buffer.from(expected);
  const b = Buffer.from(received);
  return a.length === b.length && timingSafeEqual(a, b);
}

const issuePaths = (error: z.ZodError) =>
  error.issues.map((issue) => issue.path.join('.')).join(', ');

/** Номер брони из нераспознанного тела, если он похож на номер; иначе «?». */
function rawBookingId(body: unknown): string {
  const id = (body as { data?: { booking?: { id?: unknown } } } | null)?.data
    ?.booking?.id;
  return typeof id === 'number' ||
    (typeof id === 'string' && /^\d{1,12}$/.test(id))
    ? String(id)
    : '?';
}

/**
 * Приём вебхуков RealtyCalendar. Подписи у RealtyCalendar нет — запрос принимается,
 * только если в адресе верный секрет. Неверный адрес выглядит как несуществующий (404).
 */
@Controller('webhooks/realtycalendar')
export class RcWebhookController {
  private readonly logger = new Logger(RcWebhookController.name);

  constructor(
    private readonly sync: RealtyCalendarSyncService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  @Public()
  @Post(':secret')
  @HttpCode(HttpStatus.OK)
  async receive(
    @Param('secret') secret: string,
    @Body() body: unknown,
  ): Promise<{ result: string }> {
    if (
      !this.env.RC_WEBHOOK_SECRET ||
      !secretsMatch(this.env.RC_WEBHOOK_SECRET, secret)
    ) {
      throw new NotFoundException();
    }
    const parsed = rcWebhookSchema.safeParse(body);
    if (!parsed.success) {
      // Повтор того же тела не поможет — отвечаем 200, чтобы RealtyCalendar не слал его двое суток.
      // В журнал — номер брони и названия полей, без данных гостя: по номеру бронь находится в RealtyCalendar.
      this.logger.warn(
        `Вебхук RealtyCalendar не распознан (бронь ${rawBookingId(body)}): ${issuePaths(parsed.error)}; ${describeShape(body)}`,
      );
      return { result: 'ignored' };
    }
    const strict = rcWebhookStrictSchema.safeParse(body);
    // Ошибка обработки пробрасывается (500): RealtyCalendar повторит отправку по своему расписанию.
    const unreadable = strict.success
      ? []
      : unreadableFields(strict.error.issues.map((issue) => issue.path));
    const result = await this.sync.apply(
      toBookingSnapshot(parsed.data, unreadable),
    );
    const summary = `Вебхук RealtyCalendar ${parsed.data.action} (бронь ${parsed.data.data.booking.id}): ${result}`;
    if (strict.success) this.logger.log(summary);
    else
      this.logger.warn(
        `${summary}; пропущены поля в незнакомом формате: ${issuePaths(strict.error)}`,
      );
    return { result };
  }
}
