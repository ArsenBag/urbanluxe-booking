import { z } from 'zod';

/**
 * Вебхук RealtyCalendar (https://realtycalendar.helpdeskeddy.com/ru/knowledge_base/art/208).
 * Описываем только поля, которые используем; остальные отбрасываются.
 *
 * Брони с площадок (Booking.com и др.) приходят в других форматах, чем в документации: время
 * «14:00:00» или «11:00-12:00», суммы и id строкой, даты с временем. Известные варианты приводим
 * к одному виду. Неизвестный формат необязательного поля не должен терять всю бронь: мягкая схема
 * делает такое поле пустым, строгая — показывает, какие поля пришлось отбросить (для журнала).
 */

const ISO_DAY = /^(\d{4}-\d{2}-\d{2})/;
const RU_DAY = /^(\d{2})\.(\d{2})\.(\d{4})(?:[ T].*)?$/;
const CLOCK = /^\s*(\d{1,2})[:.](\d{2})/;
const NUMBER = /^-?\d+(\.\d+)?$/;
const THOUSANDS = /^-?\d{1,3}(,\d{3})+$/;
/** 12-часовой формат: по цифрам «2:00 PM» не угадать — такое время лучше отбросить. */
const TWELVE_HOUR = /[ap]\.?\s?m\.?/i;
/** Unix-время в миллисекундах — больше этого числа; меньше — в секундах. */
const MILLISECONDS_FROM = 1e12;

/** «2026-11-10T00:00:00», «10.11.2026» и «10.11.2026 00:00» → «2026-11-10». */
function normalizeDate(value: unknown): unknown {
  if (typeof value !== 'string') return value;
  const text = value.trim();
  const ru = RU_DAY.exec(text);
  if (ru) return `${ru[3]}-${ru[2]}-${ru[1]}`;
  return ISO_DAY.exec(text)?.[1] ?? text;
}

/** «14:00:00», «11:00-12:00», «9.30» → «14:00», «11:00», «09:30»; пустая строка — нет времени. */
function normalizeTime(value: unknown): unknown {
  if (typeof value !== 'string' || TWELVE_HOUR.test(value)) return value;
  const clock = CLOCK.exec(value);
  if (clock) return `${clock[1]!.padStart(2, '0')}:${clock[2]}`;
  return value.trim() === '' ? null : value;
}

/**
 * «1 250,50» → 1250.5, «1,234.50» и «1,234» → 1234 (запятая — разделитель тысяч), пустая строка — нет
 * значения. Запятая перед двумя цифрами — десятичная: «120,50» → 120.5.
 */
function normalizeNumber(value: unknown): unknown {
  if (typeof value !== 'string') return value;
  const compact = value.replace(/[\s\u00a0]/g, '');
  if (compact === '') return null;
  const decimal =
    compact.includes('.') || THOUSANDS.test(compact)
      ? compact.replace(/,/g, '')
      : compact.replace(',', '.');
  return NUMBER.test(decimal) ? Number(decimal) : value;
}

/** Unix-время числом (секунды или миллисекунды) → ISO-строка; строки не трогаем. */
function normalizeTimestamp(value: unknown): unknown {
  if (typeof value !== 'number' || !Number.isFinite(value)) return value;
  return new Date(
    value > MILLISECONDS_FROM ? value : value * 1000,
  ).toISOString();
}

const normalizeText = (value: unknown): unknown =>
  typeof value === 'number' ? String(value) : value;

const MIN_YEAR = 2000;
const MAX_YEAR = 2100;
/** int4 в базе: номера броней и объектов RealtyCalendar. */
const MAX_INT4 = 2_147_483_647;
/** Decimal(12,2) в базе: суммы броней. */
const MAX_MONEY = 9_999_999_999.99;
/** Десять лет проживания — уже ошибка, а не бронь. */
const MAX_NIGHTS = 3650;
/** Время изменения из будущего «заморозило» бы бронь: настоящие изменения считались бы устаревшими. */
const FUTURE_TOLERANCE_MS = 86_400_000;
const SHORT_TEXT = 200;
const LONG_TEXT = 5000;
const ACTION = /^[\w.:-]{1,40}$/;
const TIMESTAMP = /^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}/;

/**
 * Настоящая календарная дата в разумных годах: 2026-13-45 и 0000-01-01 не пройдут (иначе ошибка
 * базы, ответ 500 и повторы вебхука двое суток).
 */
const isoDate = z.preprocess(
  normalizeDate,
  z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .refine((value) => {
      const parsed = new Date(`${value}T00:00:00Z`);
      const year = parsed.getUTCFullYear();
      return (
        !Number.isNaN(parsed.getTime()) &&
        parsed.toISOString().startsWith(value) &&
        year >= MIN_YEAR &&
        year <= MAX_YEAR
      );
    }, 'Несуществующая дата'),
);
const timestamp = z.preprocess(
  normalizeTimestamp,
  z
    .string()
    .regex(TIMESTAMP, 'Некорректное время')
    .refine((value) => {
      const time = Date.parse(value);
      return (
        !Number.isNaN(time) &&
        new Date(time).getUTCFullYear() >= MIN_YEAR &&
        time <= Date.now() + FUTURE_TOLERANCE_MS
      );
    }, 'Некорректное время'),
);

const integer = z.preprocess(
  normalizeNumber,
  z.number().int().min(1).max(MAX_INT4),
);
const optionalInteger = z.preprocess(
  normalizeNumber,
  z.number().int().min(1).max(MAX_INT4).nullish(),
);
const nights = z.preprocess(
  normalizeNumber,
  z.number().int().min(0).max(MAX_NIGHTS).nullish(),
);
const time = z.preprocess(
  normalizeTime,
  z
    .string()
    .regex(/^([01]\d|2[0-3]):[0-5]\d$/)
    .nullish(),
);
const money = z.preprocess(
  normalizeNumber,
  z.number().min(-MAX_MONEY).max(MAX_MONEY).nullish(),
);
/** Строка, обрезанная до max: слишком длинное имя или примечание не должно ломать запись в базу. */
const text = (max: number) =>
  z.preprocess(
    normalizeText,
    z
      .string()
      .nullish()
      .transform((value) =>
        typeof value === 'string' ? value.slice(0, max) : value,
      ),
  );
const status = z.preprocess(
  (value) => {
    if (typeof value !== 'string') return value;
    const normalized = value.trim().toLowerCase();
    return normalized === 'cancelled' ? 'canceled' : normalized;
  },
  z.enum(['booked', 'request', 'canceled', 'deleted']),
);

/**
 * lenient: нечитаемое описательное поле (время, суммы, примечания, площадка) становится null, бронь всё
 * равно обрабатывается. Гость и квартира остаются строгими: нечитаемый блок в обновлении иначе стёр бы
 * имя, телефон и квартиру уже известной брони — такую бронь лучше пропустить и увидеть в журнале.
 */
function buildSchema(lenient: boolean) {
  const soft = <T extends z.ZodType>(schema: T) =>
    lenient ? schema.catch(null as z.output<T>) : schema;
  const action = z.string().regex(ACTION);
  return z.object({
    // В обработке action не участвует — только в журнале, поэтому странное значение не теряет бронь.
    action: lenient ? action.catch('unknown') : action,
    status,
    data: z.object({
      booking: z
        .object({
          id: integer,
          begin_date: isoDate,
          end_date: isoDate,
          realty_id: optionalInteger,
          updated_at: timestamp,
          number_of_nights: soft(nights),
          arrival_time: soft(time),
          departure_time: soft(time),
          amount: soft(money),
          prepayment: soft(money),
          deposit: soft(money),
          notes: soft(text(LONG_TEXT)),
          source: soft(text(SHORT_TEXT)),
          url: soft(text(SHORT_TEXT)),
          address: text(LONG_TEXT),
          client: z
            .object({
              fio: text(SHORT_TEXT),
              phone: text(SHORT_TEXT),
              additional_phone: text(SHORT_TEXT),
              email: text(SHORT_TEXT),
            })
            .nullish(),
          apartment: z
            .object({
              id: integer,
              title: text(SHORT_TEXT),
              address: text(LONG_TEXT),
            })
            .nullish(),
          booking_origin: soft(z.object({ title: text(SHORT_TEXT) }).nullish()),
        })
        .refine((booking) => booking.end_date >= booking.begin_date, {
          message: 'Выезд раньше заезда',
          path: ['end_date'],
        }),
    }),
  });
}

/** Схема для обработки: обязательные поля строгие, остальные — мягкие. */
export const rcWebhookSchema = buildSchema(true);
/** Та же схема без смягчения: её ошибки показывают, какие поля мягкая схема отбросила. */
export const rcWebhookStrictSchema = buildSchema(false);

export type RcWebhook = z.infer<typeof rcWebhookSchema>;
