import { autoTasksFor } from './booking-tasks.js';
import type { BookingSnapshot } from './rc-mapper.js';

const booking = {
  checkIn: '2026-10-20',
  checkOut: '2026-10-23',
  arrivalTime: null,
  departureTime: '10:30',
  guestName: 'Дилноза',
  property: { rcId: 1, title: 'U-Tower 1204', address: null },
} as BookingSnapshot;

describe('autoTasksFor', () => {
  it('uses house rules by default and the guest time when given, in Tashkent time', () => {
    const [checkIn, checkOut] = autoTasksFor(booking);

    expect(checkIn).toMatchObject({ kind: 'CHECK_IN', title: 'Заезд: Дилноза — U-Tower 1204' });
    expect(checkIn.dueAt.toISOString()).toBe('2026-10-20T10:00:00.000Z');
    expect(checkOut.kind).toBe('CHECK_OUT');
    expect(checkOut.dueAt.toISOString()).toBe('2026-10-23T05:30:00.000Z');
  });

  it('pads single-digit hours', () => {
    const [checkIn] = autoTasksFor({ ...booking, arrivalTime: '9:15' });

    expect(checkIn.dueAt.toISOString()).toBe('2026-10-20T04:15:00.000Z');
  });
});
