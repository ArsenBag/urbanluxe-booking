import { reconcileExcel, type CrmBookingRef } from './rc-reconcile.js';
import type { BookingSnapshot } from './rc-mapper.js';

const row = (overrides: Partial<BookingSnapshot>): BookingSnapshot => ({
  rcId: null,
  importKey: 'key',
  status: 'BOOKED',
  checkIn: '2026-10-10',
  checkOut: '2026-10-12',
  nights: 2,
  arrivalTime: null,
  departureTime: null,
  amount: null,
  prepayment: null,
  deposit: null,
  origin: 'Booking.com',
  guestName: null,
  guestPhone: null,
  guestEmail: null,
  notes: null,
  rcUrl: null,
  rcUpdatedAt: new Date('2026-10-08T00:00:00Z'),
  property: { rcId: null, title: 'U-Tower', address: 'Бешагач 1/1' },
  ...overrides,
});

const crm = (overrides: Partial<CrmBookingRef>): CrmBookingRef => ({
  id: 'b1',
  rcId: 101,
  importKey: null,
  checkIn: '2026-10-10',
  checkOut: '2026-10-12',
  guestPhone: null,
  complex: 'U-Tower',
  origin: 'Booking.com',
  status: 'BOOKED',
  ...overrides,
});

describe('reconcileExcel', () => {
  it('recognises rows loaded before by their key: own rows and rows a webhook adopted', () => {
    const result = reconcileExcel(
      [row({ importKey: 'own' }), row({ importKey: 'adopted' })],
      [
        crm({ id: 'x', rcId: null, importKey: 'own' }),
        crm({ id: 'y', rcId: 7, importKey: 'adopted' }),
      ],
    );
    expect(result.rows.map((item) => [item.kind, item.bookingId])).toEqual([
      ['known', 'x'],
      ['matched', 'y'],
    ]);
    expect(result.missingInExcel).toEqual([]);
  });

  it('matches a webhook booking by dates and guest phone, then by dates and complex', () => {
    const result = reconcileExcel(
      [
        row({ importKey: 'a', guestPhone: '+998901112233' }),
        row({ importKey: 'b' }),
      ],
      [
        crm({ id: 'by-complex' }),
        crm({
          id: 'by-phone',
          guestPhone: '+998901112233',
          complex: 'Modera Towers',
        }),
      ],
    );
    expect(result.rows.map((item) => item.bookingId)).toEqual([
      'by-phone',
      'by-complex',
    ]);
  });

  it('pairs same-day bookings in one complex one to one and reports the extra row as missing', () => {
    const result = reconcileExcel(
      [
        row({ importKey: 'a' }),
        row({ importKey: 'b' }),
        row({ importKey: 'c' }),
      ],
      [crm({ id: 'one' }), crm({ id: 'two' })],
    );
    expect(result.rows.map((item) => item.kind)).toEqual([
      'matched',
      'matched',
      'new',
    ]);
    expect(new Set(result.rows.map((item) => item.bookingId))).toEqual(
      new Set(['one', 'two', null]),
    );
  });

  it('lists CRM bookings that the export does not have', () => {
    const result = reconcileExcel(
      [row({ importKey: 'a' })],
      [
        crm({ id: 'here' }),
        crm({ id: 'gone', checkIn: '2026-10-20', checkOut: '2026-10-22' }),
      ],
    );
    expect(result.missingInExcel.map((booking) => booking.id)).toEqual([
      'gone',
    ]);
  });

  it('does not let an earlier row take a booking that a later row owns by key', () => {
    const result = reconcileExcel(
      [row({ importKey: 'A' }), row({ importKey: 'B' })],
      [crm({ id: 'x', rcId: null, importKey: 'B' })],
    );
    expect(result.rows.map((item) => [item.kind, item.bookingId])).toEqual([
      ['new', null],
      ['known', 'x'],
    ]);
  });

  it('gives a phone match priority over a complex match whatever the row order', () => {
    const result = reconcileExcel(
      [row({ importKey: 'bob' }), row({ importKey: 'anna', guestPhone: '+998901112233' })],
      [crm({ id: 'anna-booking', guestPhone: '+998901112233' })],
    );
    expect(result.rows.map((item) => [item.kind, item.bookingId])).toEqual([
      ['new', null],
      ['matched', 'anna-booking'],
    ]);
  });

  it('never pairs two different known guests just because the complex and dates agree', () => {
    const result = reconcileExcel(
      [row({ importKey: 'a', guestPhone: '+998902222222' })],
      [crm({ id: 'other-guest', guestPhone: '+998901111111' })],
    );
    expect(result.rows[0]?.kind).toBe('new');
    expect(result.missingInExcel.map((booking) => booking.id)).toEqual(['other-guest']);
  });

  it('tells webhook bookings from rows of an earlier export', () => {
    const result = reconcileExcel(
      [row({ importKey: 'changed' }), row({ importKey: 'b', checkIn: '2026-11-01', checkOut: '2026-11-03' })],
      [crm({ id: 'old-row', rcId: null, importKey: 'before-change' }), crm({ id: 'hook', checkIn: '2026-11-01', checkOut: '2026-11-03' })],
    );
    expect(result.rows.map((item) => [item.kind, item.viaWebhook])).toEqual([
      ['matched', false],
      ['matched', true],
    ]);
  });

  it('marks a row of a booking canceled in CRM as canceled, not as missing', () => {
    const result = reconcileExcel(
      [
        row({ importKey: 'own-canceled' }),
        row({ importKey: 'hook-canceled', guestPhone: '+998903333333', checkIn: '2026-11-01', checkOut: '2026-11-03' }),
      ],
      [
        crm({ id: 'x', rcId: null, importKey: 'own-canceled', status: 'CANCELED' }),
        crm({ id: 'y', guestPhone: '+998903333333', checkIn: '2026-11-01', checkOut: '2026-11-03', status: 'DELETED' }),
      ],
    );
    expect(result.rows.map((item) => [item.kind, item.bookingId])).toEqual([
      ['canceled', 'x'],
      ['canceled', 'y'],
    ]);
    expect(result.missingInExcel).toEqual([]);
  });

  it('pairs a row with a live booking before a canceled one of the same stay', () => {
    const result = reconcileExcel(
      [row({ importKey: 'a' }), row({ importKey: 'b' }), row({ importKey: 'c' })],
      [crm({ id: 'gone', status: 'CANCELED' }), crm({ id: 'live' })],
    );
    expect(result.rows.map((item) => [item.kind, item.bookingId])).toEqual([
      ['matched', 'live'],
      ['canceled', 'gone'],
      ['new', null],
    ]);
  });

  it('prefers a phone match with a canceled booking to a bare complex match with a live one', () => {
    const result = reconcileExcel(
      [
        row({ importKey: 'canceled-guest', guestPhone: '+998904444444' }),
        row({ importKey: 'live-guest', guestPhone: '+998905555555' }),
      ],
      [crm({ id: 'live' }), crm({ id: 'gone', guestPhone: '+998904444444', status: 'CANCELED' })],
    );
    expect(result.rows.map((item) => [item.kind, item.bookingId, item.basis])).toEqual([
      ['canceled', 'gone', 'phone'],
      ['matched', 'live', 'complex'],
    ]);
  });

  it('never matches a different stay or another complex', () => {
    const result = reconcileExcel(
      [
        row({ importKey: 'a', checkOut: '2026-10-13' }),
        row({
          importKey: 'b',
          property: { rcId: null, title: 'Nest One', address: null },
        }),
      ],
      [crm({ id: 'u-tower' })],
    );
    expect(result.rows.map((item) => item.kind)).toEqual(['new', 'new']);
    expect(result.missingInExcel.map((booking) => booking.id)).toEqual([
      'u-tower',
    ]);
  });
});
