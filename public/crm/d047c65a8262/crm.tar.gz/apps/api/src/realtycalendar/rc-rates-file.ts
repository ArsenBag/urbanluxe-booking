import {
  channelListingInputSchema,
  isoDateSchema,
  MAX_MIN_STAY,
  MAX_RATE_RANGE_DAYS,
  ratePlanInputSchema,
  SALES_CHANNELS,
} from '@crm/shared';
import { z } from 'zod';
import type { RateNight } from '../rates/rates.service.js';

/**
 * Выгрузка цен и площадок из RealtyCalendar для переезда в CRM. Её собирает агент в браузере владельца
 * (только чтение RC): цены по ночам уже посчитаны так же, как их показывает шахматка RC (базовая цена,
 * дни недели, сезоны, ручные цены — сверено ячейка в ячейку), ограничения — из ручных цен RC, площадки —
 * из «Менеджера каналов» RC. Данных гостей в файле нет.
 */

const MS_PER_DAY = 86_400_000;
const addDays = (date: string, days: number) =>
  new Date(Date.parse(`${date}T00:00:00Z`) + days * MS_PER_DAY)
    .toISOString()
    .slice(0, 10);

const restrictionSchema = z
  .object({
    from: isoDateSchema,
    to: isoDateSchema,
    minStay: z.number().int().min(2).max(MAX_MIN_STAY).nullable(),
    closed: z.boolean(),
    closedToArrival: z.boolean(),
    closedToDeparture: z.boolean(),
  })
  .refine((restriction) => restriction.from <= restriction.to, {
    message: 'Конец периода ограничений раньше начала',
  });

/** Площадку проверяем по тем же правилам, что и при сохранении, — ошибку покажет уже пробный запуск. */
const PLACEHOLDER_PROPERTY_ID = '00000000-0000-4000-8000-000000000000';

const channelSchema = z.object({
  channel: z.enum(SALES_CHANNELS),
  enabled: z.boolean(),
  externalHotelId: z.string().max(100).nullable(),
  externalRoomId: z.string().max(100).nullable(),
  commissionPercent: z.number().min(0).max(100).nullable(),
  ratePlans: z.array(ratePlanInputSchema),
});

const priceListSchema = z
  .string()
  .transform((text) => text.split(',').map(Number))
  .refine((prices) => prices.every((price) => Number.isFinite(price) && price > 0), {
    message: 'Цена ночи — положительное число',
  });

const fileSchema = z
  .object({
    version: z.literal(1),
    source: z.literal('realtycalendar'),
    exportedAt: z.string(),
    currency: z.string().length(3),
    from: isoDateSchema,
    days: z.number().int().min(1).max(MAX_RATE_RANGE_DAYS),
    apartments: z.array(
      z.object({
        rcId: z.number().int().positive(),
        title: z.string().max(200),
        prices: priceListSchema,
        restrictions: z.array(restrictionSchema),
        channels: z.array(channelSchema),
      }),
    ),
  })
  .superRefine((file, context) => {
    file.apartments.forEach((apartment, index) => {
      if (apartment.prices.length !== file.days) {
        context.addIssue({
          code: 'custom',
          message: `У ${apartment.title}: цен ${apartment.prices.length}, а ночей ${file.days}`,
          path: ['apartments', index, 'prices'],
        });
      }
      // Ночь берёт ограничения одного периода: при пересечении флаг второго потерялся бы.
      const sorted = [...apartment.restrictions].sort((a, b) => a.from.localeCompare(b.from));
      if (sorted.some((restriction, i) => i > 0 && restriction.from <= sorted[i - 1].to)) {
        context.addIssue({
          code: 'custom',
          message: `У ${apartment.title}: периоды ограничений пересекаются`,
          path: ['apartments', index, 'restrictions'],
        });
      }
      apartment.channels.forEach((channel, channelIndex) => {
        const result = channelListingInputSchema.safeParse({ ...channel, propertyId: PLACEHOLDER_PROPERTY_ID });
        if (!result.success) {
          context.addIssue({
            code: 'custom',
            message: `У ${apartment.title}, ${channel.channel}: ${result.error.issues[0].message}`,
            path: ['apartments', index, 'channels', channelIndex],
          });
        }
      });
    });
  });

export type RcRatesFile = z.infer<typeof fileSchema>;
export type RcRatesChannel = z.infer<typeof channelSchema>;

export interface PlannedApartment {
  rcId: number;
  title: string;
  nights: RateNight[];
  channels: RcRatesChannel[];
}

/** Файл выгрузки или понятная ошибка, что в нём не так. */
export function parseRcRatesFile(data: unknown): RcRatesFile {
  const result = fileSchema.safeParse(data);
  if (!result.success) {
    const issue = result.error.issues[0];
    throw new Error(
      `Файл выгрузки не подходит: ${issue.message} (${issue.path.join('.') || 'весь файл'})`,
    );
  }
  return result.data;
}

/** Ночи каждой квартиры с today: цена из выгрузки и ограничения, которые на неё приходятся. */
export function planRcRatesImport(
  file: RcRatesFile,
  today: string,
): PlannedApartment[] {
  return file.apartments.map((apartment) => ({
    rcId: apartment.rcId,
    title: apartment.title,
    channels: apartment.channels,
    nights: apartment.prices.flatMap((price, index) => {
      const date = addDays(file.from, index);
      if (date < today) return [];
      const restriction = apartment.restrictions.find(
        (item) => item.from <= date && date <= item.to,
      );
      return [
        {
          date,
          price,
          minStay: restriction?.minStay ?? null,
          closed: restriction?.closed ?? false,
          closedToArrival: restriction?.closedToArrival ?? false,
          closedToDeparture: restriction?.closedToDeparture ?? false,
        },
      ];
    }),
  }));
}
