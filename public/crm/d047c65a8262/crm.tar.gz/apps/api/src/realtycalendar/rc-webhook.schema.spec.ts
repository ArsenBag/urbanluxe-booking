import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { rcWebhookSchema, rcWebhookStrictSchema } from './rc-webhook.schema.js';

const sample = JSON.parse(
  readFileSync(
    resolve(import.meta.dirname, '../../test/fixtures/rc-create-booking.json'),
    'utf8',
  ),
);

/** Вебхук на основе образца из документации с заменой полей брони. */
function withBooking(
  changes: Record<string, unknown>,
  top: Record<string, unknown> = {},
) {
  const body = structuredClone(sample);
  Object.assign(body.data.booking, changes);
  return Object.assign(body, top);
}

const issuePaths = (body: unknown) => {
  const result = rcWebhookStrictSchema.safeParse(body);
  return result.success
    ? []
    : result.error.issues.map((issue) => issue.path.join('.'));
};

describe('rcWebhookSchema', () => {
  it('accepts the documented sample as is', () => {
    expect(rcWebhookStrictSchema.safeParse(sample).success).toBe(true);
    expect(rcWebhookSchema.safeParse(sample).success).toBe(true);
  });

  it('understands the formats channel bookings (Booking.com and others) arrive in', () => {
    const body = withBooking(
      {
        id: '123456',
        realty_id: '77',
        begin_date: '2026-11-10T00:00:00',
        end_date: '13.11.2026',
        number_of_nights: '3',
        arrival_time: '14:00:00',
        departure_time: '11:00-12:00',
        amount: '1 250,50',
        prepayment: '',
        client: {
          fio: 'Guest',
          phone: 998901234567,
          email: 'x@guest.booking.com',
          additional_phone: null,
        },
      },
      { status: 'Booked' },
    );
    expect(issuePaths(body)).toEqual([]);
    const booking = rcWebhookSchema.parse(body).data.booking;
    expect(booking).toMatchObject({
      id: 123456,
      realty_id: 77,
      begin_date: '2026-11-10',
      end_date: '2026-11-13',
      number_of_nights: 3,
      arrival_time: '14:00',
      departure_time: '11:00',
      amount: 1250.5,
      prepayment: null,
    });
    expect(booking.client?.phone).toBe('998901234567');
    expect(rcWebhookSchema.parse(body).status).toBe('booked');
  });

  it('reads more date, number, status and time variants without guessing', () => {
    const body = withBooking(
      {
        begin_date: '10.11.2026 00:00',
        end_date: '13.11.2026',
        updated_at: Date.parse('2026-10-01T09:00:00Z') / 1000,
        amount: '1,234',
        prepayment: '1,234.50',
        deposit: '120,50',
        arrival_time: '2:00 PM',
      },
      { status: 'Cancelled' },
    );
    expect(issuePaths(body)).toEqual(['data.booking.arrival_time']);
    const parsed = rcWebhookSchema.parse(body);
    expect(parsed.status).toBe('canceled');
    expect(parsed.data.booking).toMatchObject({
      begin_date: '2026-11-10',
      updated_at: '2026-10-01T09:00:00.000Z',
      amount: 1234,
      prepayment: 1234.5,
      deposit: 120.5,
      arrival_time: null,
    });
  });

  it('drops an unreadable descriptive field instead of losing the whole booking', () => {
    const body = withBooking({
      arrival_time: 'после обеда',
      amount: { value: 100, currency: 'USD' },
      deposit: '1000000000000',
    });
    expect(issuePaths(body)).toEqual([
      'data.booking.arrival_time',
      'data.booking.amount',
      'data.booking.deposit',
    ]);
    const booking = rcWebhookSchema.parse(body).data.booking;
    expect(booking).toMatchObject({
      arrival_time: null,
      amount: null,
      deposit: null,
    });
    expect(booking.id).toBe(sample.data.booking.id);
  });

  it('skips a booking with an unreadable guest or apartment rather than wiping them', () => {
    expect(
      rcWebhookSchema.safeParse(
        withBooking({ apartment: { id: 'не число', title: 'U-51' } }),
      ).success,
    ).toBe(false);
    expect(
      rcWebhookSchema.safeParse(withBooking({ client: 'кто-то' })).success,
    ).toBe(false);
  });

  it('rejects values the database cannot store instead of failing with 500 and retries', () => {
    expect(
      rcWebhookSchema.safeParse(withBooking({ id: '99999999999' })).success,
    ).toBe(false);
    expect(
      rcWebhookSchema.safeParse(withBooking({ begin_date: '0000-01-01' }))
        .success,
    ).toBe(false);
    expect(
      rcWebhookSchema.safeParse(
        withBooking({ begin_date: '2026-11-13', end_date: '2026-11-10' }),
      ).success,
    ).toBe(false);
    expect(
      rcWebhookSchema.safeParse(
        withBooking({ updated_at: '2099-01-01T00:00:00Z' }),
      ).success,
    ).toBe(false);
    expect(
      rcWebhookSchema.safeParse(withBooking({ updated_at: '1' })).success,
    ).toBe(false);
  });

  it('trims overlong text and neutralises a strange action', () => {
    const body = withBooking(
      { client: { fio: 'Я'.repeat(500), phone: null, email: null } },
      { action: 'x\nERROR forged' },
    );
    const parsed = rcWebhookSchema.parse(body);
    expect(parsed.data.booking.client?.fio).toHaveLength(200);
    expect(parsed.action).toBe('unknown');
  });

  it('still rejects a booking without readable dates, id or status', () => {
    expect(
      rcWebhookSchema.safeParse(withBooking({ begin_date: 'скоро' })).success,
    ).toBe(false);
    expect(
      rcWebhookSchema.safeParse(withBooking({ id: undefined })).success,
    ).toBe(false);
    expect(
      rcWebhookSchema.safeParse(withBooking({}, { status: 'pending' })).success,
    ).toBe(false);
  });
});
