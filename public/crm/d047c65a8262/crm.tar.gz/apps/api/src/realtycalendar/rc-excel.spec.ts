import { parseGuest, parseSpreadsheetMl, toImportSnapshots } from './rc-excel.js';

const row = (cells: string[]) =>
  `<ss:Row>${cells.map((value) => `<ss:Cell><ss:Data ss:Type="String">${value}</ss:Data></ss:Cell>`).join('')}</ss:Row>`;

const HEADER = ['Объект', 'Заезд', 'Выезд', 'Контакты', 'Примечания', 'Гостей', 'Сумма', 'Источник', 'Менеджер'];

function workbook(rows: string[][]): string {
  return `<?xml version="1.0"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<ss:Worksheet ss:Name="Sheet1"><ss:Table>${[HEADER, ...rows].map(row).join('')}</ss:Table></ss:Worksheet></Workbook>`;
}

const TODAY = '2026-10-04';
const NOW = new Date('2026-10-04T10:00:00Z');

describe('parseSpreadsheetMl', () => {
  it('maps cells to columns by header', () => {
    const rows = parseSpreadsheetMl(workbook([['Бешагач 1/1', '05.10.2026', '08.10.2026', 'Тест Гость +998 90 000 00 01', '', '', '255.5', 'booking.com', 'Менеджер']]));

    expect(rows[0]).toMatchObject({ Объект: 'Бешагач 1/1', Заезд: '05.10.2026', Сумма: '255.5', Источник: 'booking.com' });
  });

  it('respects ss:Index gaps for empty cells', () => {
    const xml = workbook([]).replace(
      '</ss:Table>',
      `<ss:Row><ss:Cell><ss:Data ss:Type="String">Нукус 31/1</ss:Data></ss:Cell><ss:Cell ss:Index="3"><ss:Data ss:Type="String">09.10.2026</ss:Data></ss:Cell></ss:Row></ss:Table>`,
    );

    expect(parseSpreadsheetMl(xml)[0]).toMatchObject({ Объект: 'Нукус 31/1', Заезд: '', Выезд: '09.10.2026' });
  });

  it('rejects a file without the expected columns', () => {
    expect(() => parseSpreadsheetMl(workbook([]).replace('<ss:Data ss:Type="String">Заезд</ss:Data>', '<ss:Data ss:Type="String">Дата</ss:Data>'))).toThrow(/Заезд/);
  });
});

describe('parseGuest', () => {
  it.each([
    ['Тест Гость +998 90 000 00 01', '', 'Тест Гость', '+998900000001'],
    ['+7 900 000-00-02', '', null, '+79000000002'],
    ['Тест', 'звонить +998 91 000 00 03', 'Тест', '+998910000003'],
    ['Тест Гость', '', 'Тест Гость', null],
  ])('%s', (contacts, notes, name, phone) => {
    expect(parseGuest(contacts, notes)).toEqual({ name, phone });
  });
});

describe('toImportSnapshots', () => {
  const rows = parseSpreadsheetMl(
    workbook([
      ['Шайхантахурский район, массив Бешагач, 1/1', '05.10.2026', '08.10.2026', 'Тест Гость +998 90 000 00 01', '2 гостя', '', '255.5', 'booking.com', 'М'],
      ['Массив Бешагач 1/1', '05.10.2026', '08.10.2026', 'Тест Гость +998 90 000 00 01', '2 гостя', '', '255.5', 'booking.com', 'М'],
      ['Шота Руставели 19', '01.10.2026', '04.10.2026', '', '', '', '100', 'manual', 'М'],
      ['Шота Руставели 19', '01.09.2026', '03.09.2026', '', '', '', '100', '', 'М'],
    ]),
  );
  const snapshots = toImportSnapshots(rows, TODAY, NOW);

  it('keeps only bookings with check-out today or later', () => {
    expect(snapshots.map((s) => s.checkIn)).toEqual(['2026-10-05', '2026-10-05', '2026-10-01']);
  });

  it('maps addresses to complexes, sources and guests', () => {
    expect(snapshots[0]).toMatchObject({
      rcId: null,
      status: 'BOOKED',
      nights: 3,
      amount: 255.5,
      origin: 'booking.com',
      guestName: 'Тест Гость',
      guestPhone: '+998900000001',
      property: { rcId: null, title: 'U-Tower', address: 'Шайхантахурский район, массив Бешагач, 1/1' },
    });
    expect(snapshots[2]).toMatchObject({ origin: null, guestName: null, property: { title: 'Modera Towers' } });
  });

  it('gives stable unique keys, also for identical rows', () => {
    const again = toImportSnapshots(rows, TODAY, NOW);
    const keys = snapshots.map((s) => s.importKey);

    expect(new Set(keys).size).toBe(keys.length);
    expect(again.map((s) => s.importKey)).toEqual(keys);
  });
});
