import { matchesPropertyCode } from './booking-search.js';

describe('matchesPropertyCode', () => {
  it('ignores case, dashes and spaces in apartment codes', () => {
    expect(matchesPropertyCode('U-51', 'u51')).toBe(true);
    expect(matchesPropertyCode('U-51', 'U 51')).toBe(true);
    expect(matchesPropertyCode('NO_10_179', 'no10179')).toBe(true);
  });

  it('matches a part of the code', () => {
    expect(matchesPropertyCode('U-51', '51')).toBe(true);
    expect(matchesPropertyCode('U-51', '52')).toBe(false);
  });

  it('never matches an empty or punctuation-only query', () => {
    expect(matchesPropertyCode('U-51', '')).toBe(false);
    expect(matchesPropertyCode('U-51', ' - ')).toBe(false);
  });
});
