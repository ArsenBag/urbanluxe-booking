import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { Prisma, type Booking } from '../generated/prisma/client.js';
import {
  contactSourceForOrigin,
  guestChanged,
  isSameCrmBooking,
  keepCrmValues,
  keepUnreadableFields,
  toBookingSnapshot,
  unreadableFields,
} from './rc-mapper.js';
import { rcWebhookSchema } from './rc-webhook.schema.js';

const example = JSON.parse(readFileSync(resolve(import.meta.dirname, '../../test/fixtures/rc-create-booking.json'), 'utf8'));

describe('toBookingSnapshot', () => {
  it('maps the documented example', () => {
    const snapshot = toBookingSnapshot(rcWebhookSchema.parse(example));

    expect(snapshot).toMatchObject({
      rcId: 113386019,
      status: 'BOOKED',
      checkIn: '2025-06-25',
      checkOut: '2025-06-26',
      nights: 1,
      amount: 500,
      prepayment: 500,
      deposit: 0,
      origin: null,
      guestName: 'Кирилл',
      guestPhone: '+79998888888',
      guestEmail: null,
      notes: '2 гостей',
      rcUrl: 'https://realtycalendar.ru/event_calendars/113386019',
      property: { rcId: 208656, title: 'Тверская 18', address: 'Тверская 18' },
    });
    expect(snapshot.rcUpdatedAt.toISOString()).toBe('2025-06-16T08:30:44.353Z');
  });

  it('maps statuses and computes nights when missing', () => {
    const canceled = structuredClone(example);
    canceled.status = 'canceled';
    delete canceled.data.booking.number_of_nights;
    canceled.data.booking.end_date = '2025-06-28';

    expect(toBookingSnapshot(rcWebhookSchema.parse(canceled))).toMatchObject({ status: 'CANCELED', nights: 3 });
  });

  it('drops a phone that cannot be normalized', () => {
    const odd = structuredClone(example);
    odd.data.booking.client.phone = 'звонить через ресепшн';

    expect(toBookingSnapshot(rcWebhookSchema.parse(odd)).guestPhone).toBeNull();
  });
});

describe('unreadable webhook fields', () => {
  it('names the booking fields behind zod issue paths, ignoring the rest', () => {
    expect(
      unreadableFields([
        ['data', 'booking', 'arrival_time'],
        ['data', 'booking', 'amount'],
        ['data', 'booking', 'booking_origin', 'title'],
        ['data', 'booking', 'client', 'fio'],
        ['action'],
      ]),
    ).toEqual(['arrivalTime', 'amount', 'origin']);
  });

  it('keeps the stored values of unreadable fields when a known booking is updated', () => {
    const snapshot = {
      ...toBookingSnapshot(rcWebhookSchema.parse(example)),
      arrivalTime: null,
      amount: null,
      unreadable: ['arrivalTime', 'amount'] as const,
    };
    const existing = { arrivalTime: '16:00', amount: new Prisma.Decimal('320.50') } as Booking;

    expect(keepUnreadableFields(snapshot, existing)).toMatchObject({ arrivalTime: '16:00', amount: 320.5, notes: '2 гостей' });
    expect(keepUnreadableFields(snapshot, null)).toBe(snapshot);
  });
});

describe('bookings entered in the CRM', () => {
  const fromRc = (client: { fio: string | null; phone: string | null }, origin: string | null = null) => {
    const body = structuredClone(example);
    body.data.booking.client = { ...body.data.booking.client, ...client };
    body.data.booking.booking_origin = { id: null, title: origin };
    body.data.booking.amount = null;
    body.data.booking.notes = null;
    return toBookingSnapshot(rcWebhookSchema.parse(body));
  };
  const crmBooking = {
    source: 'CRM',
    rcId: null,
    guestName: 'Азиз',
    guestPhone: '+998932062891',
    guestEmail: null,
    amount: new Prisma.Decimal('120'),
    notes: 'Поздний заезд',
  } as Booking;

  it('keeps the guest, money and notes typed in the CRM when RealtyCalendar sends none', () => {
    const merged = keepCrmValues(fromRc({ fio: null, phone: null }), crmBooking);

    expect(merged).toMatchObject({ guestName: 'Азиз', guestPhone: '+998932062891', amount: 120, notes: 'Поздний заезд' });
    expect(guestChanged(crmBooking, merged)).toBe(false);
  });

  it('lets RealtyCalendar clear money and notes once it leads the booking, but keeps the guest', () => {
    const adopted = { ...crmBooking, rcId: 113386019 } as Booking;
    const merged = keepCrmValues(fromRc({ fio: null, phone: null }), adopted);

    expect(merged).toMatchObject({ guestName: 'Азиз', guestPhone: '+998932062891', amount: null, notes: null });
    expect(guestChanged(adopted, merged)).toBe(false);
  });

  it('takes the RealtyCalendar values for its own bookings', () => {
    const rcBooking = { ...crmBooking, source: 'REALTYCALENDAR' } as Booking;
    const snapshot = fromRc({ fio: null, phone: null });

    expect(keepCrmValues(snapshot, rcBooking)).toBe(snapshot);
    expect(guestChanged(rcBooking, snapshot)).toBe(true);
  });

  it('changes the guest of a CRM booking only for a different known phone', () => {
    const withoutPhone = { ...crmBooking, guestPhone: null } as Booking;

    expect(guestChanged(withoutPhone, fromRc({ fio: 'Азиз', phone: '+998901112233' }))).toBe(false);
    expect(guestChanged(crmBooking, fromRc({ fio: 'Азиз', phone: '+998901112233' }))).toBe(true);
  });

  it('treats a RealtyCalendar booking as the same one only for the same guest or a manual entry', () => {
    // Тот же телефон — та же бронь, даже если пришла с площадки.
    expect(isSameCrmBooking(crmBooking, fromRc({ fio: 'Aziz', phone: '+998932062891' }, 'Booking.com'))).toBe(true);
    // Внесена в RealtyCalendar вручную без телефона — сравнить не по чему, считаем той же.
    expect(isSameCrmBooking(crmBooking, fromRc({ fio: null, phone: null }))).toBe(true);
    // Другой гость или бронь с площадки без телефона — овербукинг, а не та же бронь.
    expect(isSameCrmBooking(crmBooking, fromRc({ fio: 'Ольга', phone: '+998901112233' }))).toBe(false);
    expect(isSameCrmBooking(crmBooking, fromRc({ fio: null, phone: null }, 'Airbnb'))).toBe(false);
  });
});

describe('contactSourceForOrigin', () => {
  it.each([
    ['Booking.com', 'BOOKING'],
    ['Airbnb', 'AIRBNB'],
    [null, 'OTHER'],
    ['Сайт', 'WEBSITE'],
    ['Островок', 'OTHER'],
  ])('%s → %s', (origin, expected) => {
    expect(contactSourceForOrigin(origin)).toBe(expected);
  });
});
