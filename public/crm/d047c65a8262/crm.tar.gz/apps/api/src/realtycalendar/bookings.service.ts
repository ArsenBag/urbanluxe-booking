import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import {
  MAX_LINK_SEARCH_RESULTS,
  type BookingDayDto,
  type BookingDto,
  type BookingRangeQuery,
  type PropertyDto,
  type RealtyCalendarStatusDto,
} from '@crm/shared';
import { tashkentToday } from '../automations/automation-schedule.js';
import { dateOnlyFromDb, dateOnlyToDb } from '../common/dates.js';
import { toEntityRef } from '../common/entity-refs.js';
import { ENV, type Env } from '../config/env.js';
import {
  contactIdsByPhoneDigits,
  MIN_PHONE_SEARCH_DIGITS,
} from '../contacts/contact-phone-search.js';
import type { Booking, Prisma, Property } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { matchesPropertyCode } from './booking-search.js';
import { complexOfProperty } from './complexes.js';

const BOOKING_INCLUDE = {
  property: true,
  contact: { select: { id: true, name: true, blacklistedAt: true } },
  deal: { select: { id: true, title: true } },
} as const;

type BookingWithRelations = Booking & {
  property: Property | null;
  contact: { id: string; name: string; blacklistedAt: Date | null } | null;
  deal: { id: string; title: string } | null;
};

/** Потолок броней в одном ответе — на 56 объектов и 120 дней с большим запасом. */
const MAX_BOOKINGS = 3000;
const ACTIVE: Prisma.BookingWhereInput = {
  status: { in: ['BOOKED', 'REQUEST'] },
};
/** Прошедшие брони в поиске — не старше этого: гость пишет о недавнем проживании (депозит, забытые вещи). */
const SEARCH_PAST_DAYS = 180;
const MS_PER_DAY = 86_400_000;

function toPropertyDto(property: Property): PropertyDto {
  return {
    id: property.id,
    title: property.title,
    address: property.address,
    rcId: property.rcId,
    complex: complexOfProperty(property),
  };
}

@Injectable()
export class BookingsService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  async get(id: string): Promise<BookingDto> {
    const booking = await this.prisma.booking.findUnique({
      where: { id },
      include: BOOKING_INCLUDE,
    });
    if (!booking) throw new NotFoundException('Бронь не найдена');
    return this.toDto(booking);
  }

  /** Брони, пересекающие период (для шахматки). */
  async range(query: BookingRangeQuery): Promise<BookingDto[]> {
    const bookings = await this.prisma.booking.findMany({
      where: {
        ...ACTIVE,
        checkIn: { lte: dateOnlyToDb(query.to) },
        checkOut: { gt: dateOnlyToDb(query.from) },
        ...(query.propertyId && { propertyId: query.propertyId }),
      },
      include: BOOKING_INCLUDE,
      orderBy: { checkIn: 'asc' },
      take: MAX_BOOKINGS,
    });
    return bookings.map((booking) => this.toDto(booking));
  }

  /** Сводка дня: заезды, выезды и кто проживает. */
  async day(date: string): Promise<BookingDayDto> {
    const day = dateOnlyToDb(date);
    const bookings = await this.prisma.booking.findMany({
      where: {
        status: 'BOOKED',
        checkIn: { lte: day },
        checkOut: { gte: day },
      },
      include: BOOKING_INCLUDE,
      orderBy: [{ checkIn: 'asc' }],
      take: MAX_BOOKINGS,
    });
    const dtos = bookings.map((booking) => this.toDto(booking));
    return {
      date,
      arrivals: dtos.filter((booking) => booking.checkIn === date),
      departures: dtos.filter((booking) => booking.checkOut === date),
      staying: dtos.filter(
        (booking) => booking.checkIn < date && booking.checkOut > date,
      ),
    };
  }

  /**
   * Поиск брони для связи с диалогом: по коду квартиры, имени гостя или клиента, телефону.
   * Сначала текущие и будущие по дате заезда, затем прошедшие от недавних. Пустой запрос — ближайшие заезды.
   */
  async search(query: string, now = new Date()): Promise<BookingDto[]> {
    const today = dateOnlyToDb(tashkentToday(now));
    const matching = query ? await this.searchWhere(query) : ACTIVE;
    const upcoming = await this.prisma.booking.findMany({
      where: { AND: [matching, { checkOut: { gte: today } }] },
      include: BOOKING_INCLUDE,
      orderBy: { checkIn: 'asc' },
      take: MAX_LINK_SEARCH_RESULTS,
    });
    const room = MAX_LINK_SEARCH_RESULTS - upcoming.length;
    const past =
      query && room > 0
        ? await this.prisma.booking.findMany({
            where: {
              AND: [
                matching,
                {
                  checkOut: {
                    lt: today,
                    gte: new Date(
                      today.getTime() - SEARCH_PAST_DAYS * MS_PER_DAY,
                    ),
                  },
                },
              ],
            },
            include: BOOKING_INCLUDE,
            orderBy: { checkIn: 'desc' },
            take: room,
          })
        : [];
    return [...upcoming, ...past].map((booking) => this.toDto(booking));
  }

  async byContact(contactId: string): Promise<BookingDto[]> {
    return this.list({ contactId });
  }

  async byDeal(dealId: string): Promise<BookingDto[]> {
    return this.list({ dealId });
  }

  async properties(): Promise<PropertyDto[]> {
    const properties = await this.prisma.property.findMany({
      orderBy: { title: 'asc' },
    });
    return properties.map(toPropertyDto);
  }

  async status(): Promise<RealtyCalendarStatusDto> {
    const [last, bookingsCount, propertiesCount] = await Promise.all([
      this.prisma.booking.findFirst({
        orderBy: { updatedAt: 'desc' },
        select: { updatedAt: true },
      }),
      this.prisma.booking.count(),
      this.prisma.property.count(),
    ]);
    const { PUBLIC_API_URL: base, RC_WEBHOOK_SECRET: secret } = this.env;
    return {
      webhookUrl:
        base && secret
          ? `${base.replace(/\/$/, '')}/api/webhooks/realtycalendar/${secret}`
          : null,
      lastEventAt: last?.updatedAt.toISOString() ?? null,
      bookingsCount,
      propertiesCount,
    };
  }

  /** Отменённые тоже ищем: гость может писать и о них. Удалённые в RealtyCalendar — нет. */
  private async searchWhere(query: string): Promise<Prisma.BookingWhereInput> {
    // Объектов несколько десятков — код квартиры удобнее сравнить здесь, без знаков и регистра.
    const properties = await this.prisma.property.findMany({
      select: { id: true, title: true },
    });
    const propertyIds = properties
      .filter((property) => matchesPropertyCode(property.title, query))
      .map((property) => property.id);
    const contactIds = await contactIdsByPhoneDigits(this.prisma, query);
    const digits = query.replace(/\D/g, '');
    const conditions: Prisma.BookingWhereInput[] = [
      { guestName: { contains: query, mode: 'insensitive' } },
      { contact: { name: { contains: query, mode: 'insensitive' } } },
      ...(propertyIds.length > 0 ? [{ propertyId: { in: propertyIds } }] : []),
      ...(contactIds.length > 0 ? [{ contactId: { in: contactIds } }] : []),
      ...(digits.length >= MIN_PHONE_SEARCH_DIGITS
        ? [{ guestPhone: { contains: digits } }]
        : []),
    ];
    return { status: { not: 'DELETED' }, OR: conditions };
  }

  private async list(where: Prisma.BookingWhereInput): Promise<BookingDto[]> {
    const bookings = await this.prisma.booking.findMany({
      where,
      include: BOOKING_INCLUDE,
      orderBy: { checkIn: 'desc' },
      take: MAX_BOOKINGS,
    });
    return bookings.map((booking) => this.toDto(booking));
  }

  private toDto(booking: BookingWithRelations): BookingDto {
    return {
      id: booking.id,
      rcId: booking.rcId,
      source: booking.source,
      status: booking.status,
      property: booking.property ? toPropertyDto(booking.property) : null,
      contact: toEntityRef(booking.contact),
      guestBlacklisted: Boolean(booking.contact?.blacklistedAt),
      deal: booking.deal,
      checkIn: dateOnlyFromDb(booking.checkIn),
      checkOut: dateOnlyFromDb(booking.checkOut),
      nights: booking.nights,
      arrivalTime: booking.arrivalTime,
      departureTime: booking.departureTime,
      amount: booking.amount?.toString() ?? null,
      prepayment: booking.prepayment?.toString() ?? null,
      deposit: booking.deposit?.toString() ?? null,
      currency: this.env.RC_CURRENCY,
      origin: booking.origin,
      guestName: booking.guestName,
      guestPhone: booking.guestPhone,
      notes: booking.notes,
      rcUrl: booking.rcUrl,
      pmsId: booking.pmsId,
      pmsUrl: booking.pmsId ? `${this.env.PMS_WEB_URL}#booking=${booking.pmsId}` : null,
      pmsError: booking.pmsError,
    };
  }
}
