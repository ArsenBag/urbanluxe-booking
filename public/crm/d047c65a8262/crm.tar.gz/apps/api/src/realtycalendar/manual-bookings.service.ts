import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  isCrmOnlyBooking,
  nightsBetween,
  type BookingDto,
  type ManualBookingInput,
} from '@crm/shared';
import type { SessionUser } from '../auth/session-user.js';
import { tashkentToday } from '../automations/automation-schedule.js';
import { dateOnlyFromDb, dateOnlyToDb } from '../common/dates.js';
import type { Booking, Prisma, Property } from '../generated/prisma/client.js';
import { randomUUID } from 'node:crypto';
import { PmsOutboundService } from '../pms/pms-outbound.service.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { StageAutomationService } from '../stage-automation/stage-automation.service.js';
import {
  BookingEffectsService,
  crmActor,
  type BookingActor,
} from './booking-effects.service.js';
import { lockBooking } from './booking-lock.js';
import { BookingsService } from './bookings.service.js';
import { toBookingRow, type BookingSnapshot } from './rc-mapper.js';

type Tx = Prisma.TransactionClient;

const ACTIVE_STATUSES: Booking['status'][] = ['BOOKED', 'REQUEST'];
const MANAGED_BY_RC =
  'Эта бронь есть в RealtyCalendar — меняйте её там, CRM обновится сама';
const MANAGED_BY_PMS = 'Эта бронь ведётся в PMS (площадка, сайт или шахматка PMS) — меняйте её там, CRM обновится сама';

interface Guest {
  contactId: string | null;
  guestName: string | null;
  guestPhone: string | null;
}

/** 2026-10-12 → 12.10.2026 */
const shortDate = (date: string) =>
  `${date.slice(8, 10)}.${date.slice(5, 7)}.${date.slice(0, 4)}`;

function toSnapshot(
  input: ManualBookingInput,
  guest: Guest,
  property: Property,
  guestEmail: string | null,
): BookingSnapshot {
  return {
    rcId: null,
    importKey: null,
    status: input.status,
    checkIn: input.checkIn,
    checkOut: input.checkOut,
    nights: nightsBetween(input.checkIn, input.checkOut),
    arrivalTime: input.arrivalTime,
    departureTime: input.departureTime,
    amount: input.amount,
    prepayment: input.prepayment,
    deposit: input.deposit,
    origin: null,
    guestName: guest.guestName,
    guestPhone: guest.guestPhone,
    guestEmail,
    notes: input.notes,
    rcUrl: null,
    // Версия брони для вебхуков RealtyCalendar; у брони из CRM — время последней правки.
    rcUpdatedAt: new Date(),
    property: {
      rcId: property.rcId,
      title: property.title,
      address: property.address,
    },
  };
}

/** Снимок сохранённой брони с другим статусом — для отмены. */
function snapshotOfBooking(
  booking: Booking,
  property: Property | null,
  status: Booking['status'],
): BookingSnapshot {
  const decimal = (value: { toNumber(): number } | null) =>
    value?.toNumber() ?? null;
  return {
    rcId: booking.rcId,
    importKey: booking.importKey,
    status,
    checkIn: dateOnlyFromDb(booking.checkIn),
    checkOut: dateOnlyFromDb(booking.checkOut),
    nights: booking.nights,
    arrivalTime: booking.arrivalTime,
    departureTime: booking.departureTime,
    amount: decimal(booking.amount),
    prepayment: decimal(booking.prepayment),
    deposit: decimal(booking.deposit),
    origin: booking.origin,
    guestName: booking.guestName,
    guestPhone: booking.guestPhone,
    guestEmail: booking.guestEmail,
    notes: booking.notes,
    rcUrl: booking.rcUrl,
    rcUpdatedAt: new Date(),
    property: property
      ? { rcId: property.rcId, title: property.title, address: property.address }
      : null,
  };
}

/**
 * Брони, которые сотрудник вносит на шахматке. В RealtyCalendar их нет (у него нет API), пока сотрудник
 * не внесёт ту же бронь и туда: тогда вебхук привяжет её к этой и дальше бронь ведёт RealtyCalendar.
 * Клиент, сделка и задачи заезда/выезда — как у броней из RealtyCalendar.
 */
@Injectable()
export class ManualBookingsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly effects: BookingEffectsService,
    private readonly bookings: BookingsService,
    private readonly stageAutomation: StageAutomationService,
    private readonly pms: PmsOutboundService,
  ) {}

  async create(input: ManualBookingInput, user: SessionUser): Promise<BookingDto> {
    const actor = crmActor(user);
    // Мост с PMS (2026-10-16): сначала бронь создаётся в PMS — она знает занятость всех площадок и вернёт
    // «даты заняты» раньше, чем бронь появится в CRM. id брони CRM задаём заранее: PMS хранит его как external_ref.
    const id = randomUUID();
    const propertyForPms = await this.prisma.property.findUnique({ where: { id: input.propertyId } });
    const guestForPms = await this.guestOf(this.prisma, input);
    const pmsId =
      propertyForPms && propertyForPms.rcId !== null
        ? await this.pms.reserve(
            id,
            {
              apartment_id: propertyForPms.pmsId ?? '',
              check_in: input.checkIn,
              check_out: input.checkOut,
              guest: { name: guestForPms.guestName, phone: guestForPms.guestPhone, email: null },
              status: input.status === 'REQUEST' ? 'request' : 'confirmed',
              total_price: input.amount,
              prepaid: input.prepayment,
              notes: input.notes,
              arrival_time: input.arrivalTime,
              departure_time: input.departureTime,
            },
            propertyForPms,
          )
        : null;
    let created: Booking;
    try {
      created = await this.prisma.$transaction(async (tx) => {
        const property = await this.apartment(tx, input.propertyId);
        await this.assertFree(tx, property, input, null);
        const guest = await this.guestOf(tx, input);
        const snapshot = toSnapshot(input, guest, property, null);
        const contactId =
          guest.contactId ??
          (await this.effects.resolveContact(tx, snapshot, actor));
        const dealId = await this.dealFor(tx, snapshot, contactId, null, actor);
        const booking = await tx.booking.create({
          data: {
            id,
            source: 'CRM',
            pmsId,
            pmsSyncedAt: pmsId ? new Date() : null,
            pmsError: pmsId || !this.pms.enabled ? null : 'PMS недоступна при создании — отправится повтором',
            ...toBookingRow(snapshot, { propertyId: property.id, contactId, dealId }),
          },
        });
        await this.effects.syncTasks(tx, booking, snapshot, null);
        await this.effects.recordHistory(tx, booking, snapshot, null, actor);
        return booking;
      });
    } catch (error) {
      // Бронь в PMS уже есть, а в CRM не записалась — освобождаем даты в PMS.
      if (pmsId) await this.pms.release(pmsId);
      throw error;
    }
    await this.moveDealByDates(created.dealId);
    return this.bookings.get(created.id);
  }

  async update(
    id: string,
    input: ManualBookingInput,
    user: SessionUser,
  ): Promise<BookingDto> {
    const actor = crmActor(user);
    const updated = await this.prisma.$transaction(async (tx) => {
      const existing = await this.lockedCrmBooking(tx, id);
      const property = await this.apartment(tx, input.propertyId);
      await this.assertFree(tx, property, input, id);
      const guest = await this.guestOf(tx, input);
      const snapshot = toSnapshot(input, guest, property, existing.guestEmail);
      // Изменение сначала в PMS: пересечение с бронью площадки вернёт «даты заняты» до записи в CRM.
      const pmsSent = await this.pms.update(existing, {
        apartment_id: property.pmsId ?? '',
        check_in: input.checkIn,
        check_out: input.checkOut,
        guest: { name: guest.guestName, phone: guest.guestPhone, email: existing.guestEmail },
        status: input.status === 'REQUEST' ? 'request' : 'confirmed',
        total_price: input.amount,
        prepaid: input.prepayment,
        notes: input.notes,
        arrival_time: input.arrivalTime,
        departure_time: input.departureTime,
        external_ref: existing.id,
      });
      const contactId =
        guest.contactId ??
        (await this.effects.resolveContact(tx, snapshot, actor));
      // Другой гость — сделку прежнего клиента не трогаем, у нового берём или заводим свою.
      const previous =
        contactId !== existing.contactId
          ? { ...existing, dealId: null }
          : existing;
      const dealId = await this.dealFor(tx, snapshot, contactId, previous, actor);
      const booking = await tx.booking.update({
        where: { id },
        data: {
          ...toBookingRow(snapshot, { propertyId: property.id, contactId, dealId }),
          // PMS приняла изменение — отметка синхронизации; недоступна — пометка, повтор отправит PATCH через минуту.
          ...(pmsSent === 'sent' && { pmsSyncedAt: new Date(), pmsError: null }),
          ...(pmsSent === 'failed' && { pmsError: 'PMS недоступна — изменение отправится повтором' }),
        },
      });
      await this.effects.syncTasks(tx, booking, snapshot, existing);
      await this.effects.recordHistory(tx, booking, snapshot, existing, actor);
      return booking;
    });
    await this.moveDealByDates(updated.dealId);
    return this.bookings.get(id);
  }

  /** Отмена: бронь уходит с шахматки, открытая сделка — в «Отказ», незакрытые задачи заезда/выезда снимаются. */
  async cancel(id: string, user: SessionUser): Promise<BookingDto> {
    const actor = crmActor(user);
    await this.prisma.$transaction(async (tx) => {
      const existing = await this.lockedCrmBooking(tx, id);
      const property = existing.propertyId
        ? await tx.property.findUnique({ where: { id: existing.propertyId } })
        : null;
      const snapshot = snapshotOfBooking(existing, property, 'CANCELED');
      await this.effects.syncDeal(tx, snapshot, existing.contactId, existing, actor);
      const booking = await tx.booking.update({
        where: { id },
        data: { status: 'CANCELED', rcUpdatedAt: snapshot.rcUpdatedAt },
      });
      await this.effects.syncTasks(tx, booking, snapshot, existing);
      await this.effects.recordHistory(tx, booking, snapshot, existing, actor);
    });
    await this.pms.cancel(id);
    return this.bookings.get(id);
  }

  /** Бронь на сегодня, внесённая после 08:00, сразу переносит сделку в «Заезд сегодня». */
  private async moveDealByDates(dealId: string | null): Promise<void> {
    if (dealId) await this.stageAutomation.onDealChanged(dealId);
  }

  /** Как у броней из RealtyCalendar: прошедшее проживание без сделки новую сделку не заводит. */
  private async dealFor(
    tx: Tx,
    snapshot: BookingSnapshot,
    contactId: string | null,
    previous: Booking | null,
    actor: BookingActor,
  ): Promise<string | null> {
    const finished = snapshot.checkOut < tashkentToday(new Date());
    if (finished && !previous?.dealId) return null;
    return this.effects.syncDeal(tx, snapshot, contactId, previous, actor);
  }

  /**
   * Бронь, которую можно менять в CRM. Блокировка — та же, что у вебхука, привязывающего бронь CRM:
   * если он успел раньше, бронь уже ведёт RealtyCalendar.
   */
  private async lockedCrmBooking(tx: Tx, id: string): Promise<Booking> {
    await lockBooking(tx, { id, rcId: null, importKey: null });
    const booking = await tx.booking.findUnique({ where: { id } });
    if (!booking) throw new NotFoundException('Бронь не найдена');
    if (booking.source === 'PMS') throw new ConflictException(MANAGED_BY_PMS);
    if (!isCrmOnlyBooking(booking)) throw new ConflictException(MANAGED_BY_RC);
    if (!ACTIVE_STATUSES.includes(booking.status)) {
      throw new ConflictException('Бронь уже отменена');
    }
    return booking;
  }

  /** Бронь вносится на квартиру из RealtyCalendar, а не на строку ЖК из старой выгрузки. */
  private async apartment(tx: Tx, propertyId: string): Promise<Property> {
    const property = await tx.property.findUnique({ where: { id: propertyId } });
    if (!property || property.rcId === null) {
      throw new BadRequestException({
        message: 'Выберите квартиру',
        fields: { propertyId: 'Выберите квартиру из списка' },
      });
    }
    return property;
  }

  /** Даты не должны пересекаться с действующей бронью этой квартиры (выезд и заезд в один день — можно). */
  private async assertFree(
    tx: Tx,
    property: Property,
    input: Pick<ManualBookingInput, 'checkIn' | 'checkOut'>,
    excludeId: string | null,
  ): Promise<void> {
    // Две брони на одну квартиру, внесённые одновременно, проверяются по очереди.
    await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${`property:${property.id}`}))::text AS locked`;
    const conflict = await tx.booking.findFirst({
      where: {
        propertyId: property.id,
        status: { in: ACTIVE_STATUSES },
        checkIn: { lt: dateOnlyToDb(input.checkOut) },
        checkOut: { gt: dateOnlyToDb(input.checkIn) },
        ...(excludeId && { id: { not: excludeId } }),
      },
      orderBy: { checkIn: 'asc' },
      select: { checkIn: true, checkOut: true },
    });
    if (conflict) {
      const from = shortDate(dateOnlyFromDb(conflict.checkIn));
      const to = shortDate(dateOnlyFromDb(conflict.checkOut));
      throw new ConflictException(
        `${property.title} занята: бронь с ${from} по ${to}`,
      );
    }
  }

  /** Клиент CRM, выбранный в форме: имя и телефон гостя по умолчанию берём из его карточки. */
  private async guestOf(tx: Tx, input: ManualBookingInput): Promise<Guest> {
    if (!input.contactId) {
      return {
        contactId: null,
        guestName: input.guestName,
        guestPhone: input.guestPhone,
      };
    }
    const contact = await tx.contact.findUnique({
      where: { id: input.contactId },
      select: { name: true, phones: true },
    });
    if (!contact) {
      throw new BadRequestException({
        message: 'Клиент не найден',
        fields: { contactId: 'Клиент не найден' },
      });
    }
    return {
      contactId: input.contactId,
      guestName: input.guestName ?? contact.name,
      guestPhone: input.guestPhone ?? contact.phones[0] ?? null,
    };
  }
}
