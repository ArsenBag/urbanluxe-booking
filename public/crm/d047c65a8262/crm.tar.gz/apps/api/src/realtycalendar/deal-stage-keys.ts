/** Служебный ключ этапа «Бронь создана»: синхронизация переносит туда сделку по новой брони. */
export const BOOKED_STAGE_KEY = 'BOOKED';

/** Причина отказа, которую ставит синхронизация, когда бронь отменили в RealtyCalendar. */
export const CANCEL_REASON = 'Бронь отменена в RealtyCalendar';

/** Причина отказа, когда сотрудник отменил бронь, внесённую в CRM. */
export const CRM_CANCEL_REASON = 'Бронь отменена в CRM';
