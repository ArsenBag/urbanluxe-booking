import { describeShape } from './rc-webhook-shape.js';

describe('describeShape', () => {
  it('shows the event name and the nested field names, never the values', () => {
    const shape = describeShape({
      action: 'create_booking_request',
      data: {
        request: {
          id: 1,
          client: { fio: 'Гость Секретов', phone: '+998901234567' },
          dates: ['2026-11-10'],
        },
      },
    });
    expect(shape).toBe(
      'action=create_booking_request; поля: action, data{request{id, client{fio, phone}, dates[]}}',
    );
    expect(shape).not.toContain('Гость');
    expect(shape).not.toContain('+998');
  });

  it('cuts deep nesting and long key lists', () => {
    const wide = Object.fromEntries(
      Array.from({ length: 80 }, (_, index) => [`k${index}`, index]),
    );
    const shape = describeShape({
      action: 'x',
      data: { a: { b: { c: { d: 1 } } }, wide },
    });
    expect(shape).toContain('a{b{c{…}}}');
    expect(shape).toContain('…');
    expect(shape.length).toBeLessThan(1000);
  });

  it('neutralises strange event names and keys', () => {
    expect(describeShape({ action: 'x\nERROR forged', 'evil\nkey': 1 })).toBe(
      'action=?; поля: action, ?',
    );
    expect(describeShape(null)).toBe('action=?; поля: —');
    expect(describeShape('text')).toBe('action=?; поля: —');
  });
});
