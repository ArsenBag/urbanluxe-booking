import {
  parseRcRatesFile,
  planRcRatesImport,
  type RcRatesFile,
} from './rc-rates-file.js';

const channel = {
  channel: 'BOOKING',
  enabled: true,
  externalHotelId: '17060443',
  externalRoomId: '1706044301',
  commissionPercent: 15,
  ratePlans: [
    {
      name: 'Standard Rate',
      parentIndex: null,
      markupKind: 'PERCENT',
      markupValue: 20,
      minNights: 1,
      maxNights: 364,
      closed: false,
    },
  ],
};

const file = (patch: Record<string, unknown> = {}) => ({
  version: 1,
  source: 'realtycalendar',
  exportedAt: '2026-10-14T20:34:29.369Z',
  currency: 'USD',
  from: '2026-10-15',
  days: 4,
  apartments: [
    {
      rcId: 369869,
      title: 'Gardens-A2-65',
      prices: '100,120,120,100',
      restrictions: [
        {
          from: '2026-10-16',
          to: '2026-10-17',
          minStay: 3,
          closed: false,
          closedToArrival: true,
          closedToDeparture: false,
        },
      ],
      channels: [channel],
    },
  ],
  ...patch,
});

describe('parseRcRatesFile', () => {
  it('reads a RealtyCalendar export with prices for every night', () => {
    const parsed = parseRcRatesFile(file());

    expect(parsed.apartments[0].prices).toEqual([100, 120, 120, 100]);
    expect(parsed.apartments[0].channels[0].ratePlans[0]).toMatchObject({
      name: 'Standard Rate',
      markupValue: 20,
    });
  });

  it('rejects a price list that does not cover every night', () => {
    expect(() =>
      parseRcRatesFile(
        file({
          apartments: [{ ...file().apartments[0], prices: '100,120' }],
        }),
      ),
    ).toThrow(/цен/);
  });

  it('rejects a non-numeric or non-positive price', () => {
    expect(() =>
      parseRcRatesFile(
        file({
          apartments: [{ ...file().apartments[0], prices: '100,abc,120,0' }],
        }),
      ),
    ).toThrow();
  });

  it('rejects overlapping or inverted restriction periods (a flag would be lost)', () => {
    const restriction = file().apartments[0].restrictions[0];
    const withRestrictions = (restrictions: unknown[]) =>
      file({ apartments: [{ ...file().apartments[0], restrictions }] });

    expect(() =>
      parseRcRatesFile(
        withRestrictions([
          restriction,
          {
            ...restriction,
            from: '2026-10-17',
            to: '2026-10-18',
            closed: true,
          },
        ]),
      ),
    ).toThrow(/пересекаются/);
    expect(() =>
      parseRcRatesFile(
        withRestrictions([
          { ...restriction, from: '2026-10-18', to: '2026-10-16' },
        ]),
      ),
    ).toThrow();
  });

  it('checks channel rules already when reading, so a dry run catches them', () => {
    const badChannel = {
      ...channel,
      ratePlans: [{ ...channel.ratePlans[0], parentIndex: 0 }],
    };

    expect(() =>
      parseRcRatesFile(
        file({
          apartments: [{ ...file().apartments[0], channels: [badChannel] }],
        }),
      ),
    ).toThrow(/тариф/);
  });

  it('rejects another file format or version', () => {
    expect(() => parseRcRatesFile(file({ version: 2 }))).toThrow();
    expect(() => parseRcRatesFile({ hello: 'world' })).toThrow();
  });
});

describe('planRcRatesImport', () => {
  const parsed = (): RcRatesFile => parseRcRatesFile(file());

  it('turns every night into a price with the restrictions of that night', () => {
    const [apartment] = planRcRatesImport(parsed(), '2026-10-15');

    expect(apartment.nights).toEqual([
      {
        date: '2026-10-15',
        price: 100,
        minStay: null,
        closed: false,
        closedToArrival: false,
        closedToDeparture: false,
      },
      {
        date: '2026-10-16',
        price: 120,
        minStay: 3,
        closed: false,
        closedToArrival: true,
        closedToDeparture: false,
      },
      {
        date: '2026-10-17',
        price: 120,
        minStay: 3,
        closed: false,
        closedToArrival: true,
        closedToDeparture: false,
      },
      {
        date: '2026-10-18',
        price: 100,
        minStay: null,
        closed: false,
        closedToArrival: false,
        closedToDeparture: false,
      },
    ]);
  });

  it('skips nights that are already in the past', () => {
    const [apartment] = planRcRatesImport(parsed(), '2026-10-17');

    expect(apartment.nights.map((night) => night.date)).toEqual([
      '2026-10-17',
      '2026-10-18',
    ]);
  });

  it('passes the channels through unchanged', () => {
    const [apartment] = planRcRatesImport(parsed(), '2026-10-15');

    expect(apartment).toMatchObject({ rcId: 369869, title: 'Gardens-A2-65' });
    expect(apartment.channels).toHaveLength(1);
    expect(apartment.channels[0]).toMatchObject({
      channel: 'BOOKING',
      externalHotelId: '17060443',
    });
  });
});
