import { Injectable } from '@nestjs/common';
import { tashkentToday } from '../automations/automation-schedule.js';
import { dateOnlyToDb } from '../common/dates.js';
import type { Booking, Prisma } from '../generated/prisma/client.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { StageAutomationService } from '../stage-automation/stage-automation.service.js';
import {
  BookingEffectsService,
  REALTYCALENDAR_ACTOR,
} from './booking-effects.service.js';
import { lockBooking } from './booking-lock.js';
import { complexOfProperty } from './complexes.js';
import {
  CANCELED_STATUSES,
  guestChanged,
  isCanceled,
  isSameCrmBooking,
  keepCrmValues,
  keepUnreadableFields,
  toBookingRow,
  type BookingSnapshot,
} from './rc-mapper.js';

type Tx = Prisma.TransactionClient;

/** matched — строка выгрузки Excel, которую уже ведёт вебхук: её не перезаписываем. */
export type SyncOutcome = 'created' | 'updated' | 'stale' | 'matched';

const ACTIVE_STATUSES: Booking['status'][] = ['BOOKED', 'REQUEST'];

/**
 * Применение броней из RealtyCalendar: объект, клиент, бронь, сделка и задачи заезда/выезда.
 * RealtyCalendar — источник правды по броням; CRM только отражает их у себя.
 */
@Injectable()
export class RealtyCalendarSyncService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly effects: BookingEffectsService,
    private readonly stageAutomation: StageAutomationService,
  ) {}

  async apply(snapshot: BookingSnapshot): Promise<SyncOutcome> {
    const { outcome, dealId } = await this.applyInTransaction(snapshot);
    // Бронь на сегодня, пришедшая после 08:00, сразу попадает в «Заезд сегодня», не дожидаясь планировщика.
    if (dealId) await this.stageAutomation.onDealChanged(dealId);
    return outcome;
  }

  private applyInTransaction(
    snapshot: BookingSnapshot,
  ): Promise<{ outcome: SyncOutcome; dealId: string | null }> {
    return this.prisma.$transaction(async (tx) => {
      // Повторы и параллельные события по одной брони обрабатываем строго по очереди.
      await lockBooking(tx, snapshot);
      const own =
        snapshot.rcId !== null
          ? await tx.booking.findUnique({ where: { rcId: snapshot.rcId } })
          : await tx.booking.findUnique({
              where: { importKey: snapshot.importKey ?? '' },
            });
      // Первый вебхук по брони из выгрузки Excel или внесённой в CRM: находим её и привязываем, а не создаём дубль.
      const adopted =
        !own && snapshot.rcId !== null
          ? ((await this.findImportedMatch(tx, snapshot)) ??
            (await this.findCrmMatch(tx, snapshot)))
          : null;
      const existing = own ?? adopted;
      // Строка выгрузки не перезаписывает бронь, которую ведёт вебхук (в нём точнее квартира и данные),
      // и не возвращает отменённую: статуса в выгрузке нет, отменённые брони в ней выглядят действующими.
      if (
        snapshot.rcId === null &&
        own &&
        (own.rcId !== null || isCanceled(own.status))
      ) {
        return { outcome: 'matched', dealId: null };
      }
      if (own && own.rcUpdatedAt > snapshot.rcUpdatedAt) {
        return { outcome: 'stale', dealId: null };
      }

      // Нечитаемые поля вебхука не затирают сохранённые значения известной брони,
      // а пустые — то, что сотрудник внёс в CRM.
      const current = keepCrmValues(
        keepUnreadableFields(snapshot, existing),
        existing,
      );
      const propertyId = await this.upsertProperty(tx, current);
      // Гостя в брони могли сменить в RealtyCalendar — тогда ищем клиента заново и отвязываем
      // сделку прежнего клиента (её судьбу решает менеджер).
      const contactId =
        existing && !guestChanged(existing, current)
          ? existing.contactId
          : await this.effects.resolveContact(tx, current, REALTYCALENDAR_ACTOR);
      const previous =
        existing && contactId !== existing.contactId
          ? { ...existing, dealId: null }
          : existing;
      // Прошедшее проживание (сверка по выгрузке) не заводит новых сделок: гость уехал, доску не засоряем.
      const finished = current.checkOut < tashkentToday(new Date());
      const dealId =
        finished && !previous?.dealId
          ? null
          : await this.effects.syncDeal(
              tx,
              current,
              contactId,
              previous,
              REALTYCALENDAR_ACTOR,
            );
      const data = toBookingRow(current, { propertyId, contactId, dealId });
      const booking = existing
        ? await tx.booking.update({
            // Строка выгрузки пишется, только пока бронь не перешла к вебхуку и не отменена: вебхук мог
            // привязать или отменить её параллельно (у них разные блокировки) — тогда строка падает с ошибкой.
            where: {
              id: existing.id,
              ...(current.rcId === null && {
                AND: [{ rcId: null }, { status: { notIn: CANCELED_STATUSES } }],
              }),
            },
            data: {
              ...data,
              ...(current.rcId !== null && { rcId: current.rcId }),
            },
          })
        : await tx.booking.create({
            data: {
              rcId: current.rcId,
              importKey: current.importKey,
              ...data,
            },
          });

      await this.effects.syncTasks(tx, booking, current, existing);
      await this.effects.recordHistory(
        tx,
        booking,
        current,
        existing,
        REALTYCALENDAR_ACTOR,
      );
      return {
        outcome: existing ? 'updated' : 'created',
        dealId: booking.dealId,
      };
    });
  }

  private async upsertProperty(
    tx: Tx,
    snapshot: BookingSnapshot,
  ): Promise<string | null> {
    if (!snapshot.property) return null;
    const { rcId, title, address, named = true } = snapshot.property;
    if (rcId === null) {
      // Объекты из выгрузки (ЖК без id в RealtyCalendar) различаем по названию.
      const known = await tx.property.findFirst({
        where: { rcId: null, title },
        select: { id: true },
      });
      return (
        known?.id ??
        (
          await tx.property.create({
            data: { title, address },
            select: { id: true },
          })
        ).id
      );
    }
    const property = await tx.property.upsert({
      where: { rcId },
      create: { rcId, title, address },
      // Бронь без названия или адреса квартиры (бывает у броней с площадок) не затирает уже известные.
      update: {
        ...(named && { title }),
        ...(address !== null && { address }),
      },
    });
    return property.id;
  }

  /**
   * Бронь из выгрузки Excel, которой соответствует вебхук: те же даты и тот же телефон гостя,
   * либо единственная бронь на эти даты в том же ЖК. При сомнении — не привязываем (лучше дубль, чем чужая бронь).
   */
  private async findImportedMatch(
    tx: Tx,
    snapshot: BookingSnapshot,
  ): Promise<Booking | null> {
    const candidates = await tx.booking.findMany({
      where: {
        rcId: null,
        importKey: { not: null },
        // Отменённая строка выгрузки — не пара: иначе новая бронь «воскресит» чужую отменённую.
        status: { notIn: CANCELED_STATUSES },
        checkIn: dateOnlyToDb(snapshot.checkIn),
        checkOut: dateOnlyToDb(snapshot.checkOut),
      },
      include: { property: { select: { title: true } } },
    });
    const byPhone = snapshot.guestPhone
      ? candidates.filter((c) => c.guestPhone === snapshot.guestPhone)
      : [];
    if (byPhone.length === 1) return byPhone[0];
    const complex = snapshot.property
      ? complexOfProperty(snapshot.property)
      : null;
    // Тот же ЖК и даты — только если телефон неизвестен хотя бы с одной стороны: разные гости — не пара.
    const byComplex = complex
      ? candidates.filter(
          (c) =>
            c.property?.title === complex &&
            (!snapshot.guestPhone || !c.guestPhone),
        )
      : [];
    return byComplex.length === 1 ? byComplex[0] : null;
  }

  /**
   * Бронь, которую сотрудник внёс в CRM, а потом и в RealtyCalendar: та же квартира, те же даты и тот же гость
   * (isSameCrmBooking). Отмена в RealtyCalendar брони на эти даты не должна снять действующую бронь CRM —
   * отменённые не привязываем. С этого момента бронь ведёт RealtyCalendar.
   */
  private async findCrmMatch(
    tx: Tx,
    snapshot: BookingSnapshot,
  ): Promise<Booking | null> {
    const propertyRcId = snapshot.property?.rcId ?? null;
    if (propertyRcId === null || isCanceled(snapshot.status)) return null;
    const where: Prisma.BookingWhereInput = {
      source: 'CRM',
      rcId: null,
      status: { in: ACTIVE_STATUSES },
      property: { rcId: propertyRcId },
      checkIn: dateOnlyToDb(snapshot.checkIn),
      checkOut: dateOnlyToDb(snapshot.checkOut),
    };
    const candidates = (await tx.booking.findMany({ where })).filter(
      (candidate) => isSameCrmBooking(candidate, snapshot),
    );
    if (candidates.length !== 1) return null;
    const { id } = candidates[0];
    await lockBooking(tx, { id, rcId: null, importKey: null });
    // Пока ждали блокировку, сотрудник мог изменить или отменить бронь — проверяем заново.
    const fresh = await tx.booking.findFirst({ where: { ...where, id } });
    return fresh && isSameCrmBooking(fresh, snapshot) ? fresh : null;
  }
}
