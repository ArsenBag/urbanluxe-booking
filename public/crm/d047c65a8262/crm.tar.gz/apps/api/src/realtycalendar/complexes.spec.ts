import { complexForAddress, complexOfProperty } from './complexes.js';

describe('complexForAddress', () => {
  it.each([
    ['Шайхантахурский район, массив Бешагач, 1/1', 'U-Tower'],
    ['Массив Бешагач 1/1', 'U-Tower'],
    ['массив бешагач 1/1', 'U-Tower'],
    ['Бешагач 1/1', 'U-Tower'],
    ['улица Шота Руставели, 19', 'Modera Towers'],
    ['Шота Руставели 19', 'Modera Towers'],
    ['Мирабадский район, 7-й проезд Мироншаха, 8', 'Parkwood'],
    ['Мирабадский район, 7-й проезд Мироншаха, 6', 'Parkwood'],
    ['Баходира 2/2', 'Seoul Moon'],
    ['Нукус 31/1', 'NRG Oybek'],
    ['улица Алишера Навои, 3', 'Gardens Residence'],
    ['улица Батыра Закирова, 1А', 'Nest One'],
  ])('%s → %s', (address, complex) => {
    expect(complexForAddress(address)).toBe(complex);
  });

  it('returns null for an unknown or empty address', () => {
    expect(complexForAddress('Тверская 18')).toBeNull();
    expect(complexForAddress('Алишера Навои 33')).toBeNull();
    expect(complexForAddress(null)).toBeNull();
  });
});

describe('complexOfProperty', () => {
  const apartment = (title: string, address: string | null = null) => ({ title, address, rcId: 1 });

  it.each([
    ['U-13', 'U-Tower'],
    ['Modera-294', 'Modera Towers'],
    ['OYBEK-4-39', 'NRG Oybek'],
    ['NO_10_179', 'Nest One'],
    ['P-C20-30', 'Parkwood'],
    ['SM - 169', 'Seoul Moon'],
    ['Gardens-A2-65', 'Gardens Residence'],
  ])('knows the complex of apartment %s without an address', (title, complex) => {
    expect(complexOfProperty(apartment(title))).toBe(complex);
  });

  it('prefers the address and leaves unknown apartments without a complex', () => {
    expect(complexOfProperty(apartment('U-13', 'Нукус 31/1'))).toBe('NRG Oybek');
    expect(complexOfProperty(apartment('Объект 313432'))).toBeNull();
    expect(complexOfProperty(apartment('Тверская 18'))).toBeNull();
    expect(complexOfProperty(apartment('USA-1'))).toBeNull();
  });

  it('treats the title of a complex row from the export as the complex', () => {
    expect(complexOfProperty({ title: 'Новый ЖК', address: null, rcId: null })).toBe('Новый ЖК');
  });
});
