import type { Prisma } from '../generated/prisma/client.js';

/**
 * Блокировка брони до конца транзакции: вебхуки RealtyCalendar по одной брони, связывание её
 * с диалогом и правка в CRM идут строго по очереди — каждый видит бронь такой, какой её оставил предыдущий.
 * Брони из выгрузки до первого вебхука блокируются по ключу выгрузки, внесённые в CRM — по своему id,
 * а после вебхука — по id RealtyCalendar.
 */
export async function lockBooking(
  tx: Prisma.TransactionClient,
  booking: { rcId: number | null; importKey: string | null; id?: string },
): Promise<void> {
  const identity =
    booking.rcId !== null
      ? `rc:${booking.rcId}`
      : booking.importKey !== null || booking.id === undefined
        ? `import:${booking.importKey}`
        : `crm:${booking.id}`;
  await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${`rc-booking:${identity}`}))::text AS locked`;
}
