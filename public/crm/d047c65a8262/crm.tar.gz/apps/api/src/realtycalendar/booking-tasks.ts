import type { BookingSnapshot } from './rc-mapper.js';

/** Ташкент живёт в UTC+5 без перехода на летнее время. */
const TASHKENT_OFFSET = '+05:00';
/** Правила проживания High Life: заезд с 15:00, выезд до 12:00. */
export const DEFAULT_ARRIVAL_TIME = '15:00';
export const DEFAULT_DEPARTURE_TIME = '12:00';

export type AutoTaskKind = 'CHECK_IN' | 'CHECK_OUT';

export interface AutoTaskSpec {
  kind: AutoTaskKind;
  title: string;
  dueAt: Date;
}

function at(date: string, time: string | null, fallback: string): Date {
  const [hours, minutes] = (time ?? fallback).split(':');
  return new Date(`${date}T${hours.padStart(2, '0')}:${minutes}:00${TASHKENT_OFFSET}`);
}

/** Задачи «заезд» и «выезд» по подтверждённой брони. */
export function autoTasksFor(booking: BookingSnapshot): AutoTaskSpec[] {
  const guest = booking.guestName ?? 'гость';
  const place = booking.property?.title ? ` — ${booking.property.title}` : '';
  return [
    {
      kind: 'CHECK_IN',
      title: `Заезд: ${guest}${place}`,
      dueAt: at(booking.checkIn, booking.arrivalTime, DEFAULT_ARRIVAL_TIME),
    },
    {
      kind: 'CHECK_OUT',
      title: `Выезд: принять квартиру, вернуть депозит — ${guest}${place}`,
      dueAt: at(booking.checkOut, booking.departureTime, DEFAULT_DEPARTURE_TIME),
    },
  ];
}
