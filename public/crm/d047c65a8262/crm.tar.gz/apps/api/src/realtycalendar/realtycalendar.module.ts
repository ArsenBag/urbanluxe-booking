import { Module } from '@nestjs/common';
import { PmsCoreModule } from '../pms/pms-core.module.js';
import { StageAutomationModule } from '../stage-automation/stage-automation.module.js';
import { BookingEffectsService } from './booking-effects.service.js';
import { BookingsController } from './bookings.controller.js';
import { BookingsService } from './bookings.service.js';
import { ManualBookingsService } from './manual-bookings.service.js';
import { RcWebhookController } from './rc-webhook.controller.js';
import { RealtyCalendarSyncService } from './realtycalendar-sync.service.js';

@Module({
  imports: [StageAutomationModule, PmsCoreModule],
  controllers: [RcWebhookController, BookingsController],
  providers: [
    RealtyCalendarSyncService,
    BookingEffectsService,
    BookingsService,
    ManualBookingsService,
  ],
  exports: [RealtyCalendarSyncService, BookingEffectsService],
})
export class RealtyCalendarModule {}
