import { Inject, Injectable, Logger } from '@nestjs/common';
import { POSITION_STEP } from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import type { SessionUser } from '../auth/session-user.js';
import { tashkentToday } from '../automations/automation-schedule.js';
import { dateOnlyFromDb, dateOnlyToDb } from '../common/dates.js';
import { ENV, type Env } from '../config/env.js';
import { PREFER_BLACKLISTED_ORDER } from '../contacts/guest-blacklist.js';
import type { Booking, Prisma } from '../generated/prisma/client.js';
import { autoTasksFor } from './booking-tasks.js';
import {
  BOOKED_STAGE_KEY,
  CANCEL_REASON,
  CRM_CANCEL_REASON,
} from './deal-stage-keys.js';
import {
  contactSourceForOrigin,
  isCanceled,
  type BookingSnapshot,
} from './rc-mapper.js';

type Tx = Prisma.TransactionClient;

/** Кто меняет бронь: вебхук или выгрузка RealtyCalendar (без сотрудника) либо сотрудник в CRM. */
export interface BookingActor {
  user: SessionUser | null;
  via: 'REALTYCALENDAR' | 'CRM' | 'PMS';
}

export const REALTYCALENDAR_ACTOR: BookingActor = {
  user: null,
  via: 'REALTYCALENDAR',
};

/** Бронь пришла из PMS Urban Luxe (мост 2026-10-16). */
export const PMS_ACTOR: BookingActor = {
  user: null,
  via: 'PMS',
};

export const crmActor = (user: SessionUser): BookingActor => ({
  user,
  via: 'CRM',
});

/**
 * Что бронь меняет в остальной CRM: клиент, сделка, задачи заезда и выезда, история.
 * Общее для броней из RealtyCalendar и внесённых сотрудником в CRM.
 */
@Injectable()
export class BookingEffectsService {
  private readonly logger = new Logger(BookingEffectsService.name);

  constructor(
    private readonly audit: ActivityLogService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  /** Клиент по телефону или email; если не нашли — новый (источник — площадка брони). */
  async resolveContact(
    tx: Tx,
    snapshot: BookingSnapshot,
    actor: BookingActor,
  ): Promise<string | null> {
    // Две брони одного нового гостя, пришедшие одновременно, не должны создать двух клиентов.
    const identity = snapshot.guestPhone ?? snapshot.guestEmail;
    if (identity) {
      await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${`rc-guest:${identity}`}))::text AS locked`;
    }
    if (snapshot.guestPhone) {
      const byPhone = await tx.contact.findFirst({
        where: { phones: { has: snapshot.guestPhone } },
        orderBy: PREFER_BLACKLISTED_ORDER,
        select: { id: true },
      });
      if (byPhone) return byPhone.id;
    }
    if (snapshot.guestEmail) {
      const byEmail = await tx.contact.findFirst({
        where: { email: snapshot.guestEmail },
        orderBy: PREFER_BLACKLISTED_ORDER,
        select: { id: true },
      });
      if (byEmail) return byEmail.id;
    }
    if (!snapshot.guestName && !snapshot.guestPhone) {
      return null;
    }
    const contact = await tx.contact.create({
      data: {
        name: snapshot.guestName ?? snapshot.guestPhone ?? 'Гость',
        phones: snapshot.guestPhone ? [snapshot.guestPhone] : [],
        email: snapshot.guestEmail,
        source: contactSourceForOrigin(snapshot.origin),
      },
    });
    await this.audit.record(
      actor.user,
      {
        action: 'contact.created',
        entityType: 'contact',
        entityId: contact.id,
        payload: { via: actor.via },
      },
      tx,
    );
    return contact.id;
  }

  /**
   * Сделка брони. Подтверждённая бронь: берём связанную или открытую сделку клиента
   * (или создаём) и переводим в этап «Бронь создана», если она ещё не дальше по воронке.
   * Отмена/удаление: открытая связанная сделка уходит в «Отказ».
   */
  async syncDeal(
    tx: Tx,
    snapshot: BookingSnapshot,
    contactId: string | null,
    existing: Booking | null,
    actor: BookingActor,
  ): Promise<string | null> {
    if (isCanceled(snapshot.status)) {
      if (existing?.dealId) await this.loseDeal(tx, existing.dealId, actor);
      // Восстановленная бронь заново пройдёт автоперенос: сделка вернётся в «Бронь создана».
      if (existing) await this.forgetStageMoves(tx, existing.id);
      return existing?.dealId ?? null;
    }
    if (!contactId) return existing?.dealId ?? null;

    const linked = existing?.dealId
      ? await tx.deal.findUnique({
          where: { id: existing.dealId },
          include: { stage: true },
        })
      : null;
    // Сделку, закрытую нашей же отменой, при восстановлении брони открываем снова
    // и считаем «до этапа брони», чтобы ниже она переехала в «Бронь создана».
    const reopen =
      snapshot.status === 'BOOKED' &&
      linked?.closedAt &&
      linked.lostReason === CANCEL_REASON;
    if (reopen) {
      await tx.deal.update({
        where: { id: linked.id },
        data: { closedAt: null, lostReason: null },
      });
    }
    const current = reopen
      ? {
          ...linked,
          closedAt: null,
          stage: { ...linked.stage, kind: 'OPEN' as const, position: -1 },
        }
      : linked;
    // Чужую сделку не трогаем: подходит только открытая сделка клиента без броней.
    const deal =
      (current && !current.closedAt ? current : null) ??
      (await tx.deal.findFirst({
        where: { contactId, closedAt: null, bookings: { none: {} } },
        include: { stage: true },
        orderBy: { updatedAt: 'desc' },
      }));

    const details = {
      checkIn: dateOnlyToDb(snapshot.checkIn),
      checkOut: dateOnlyToDb(snapshot.checkOut),
      ...(snapshot.amount !== null && {
        amount: snapshot.amount,
        currency: this.env.RC_CURRENCY,
      }),
    };

    if (!deal) {
      const stage = await this.targetStageForNewDeal(
        tx,
        snapshot.status === 'BOOKED',
      );
      if (!stage) return null;
      const contact = await tx.contact.findUniqueOrThrow({
        where: { id: contactId },
        select: { name: true },
      });
      const created = await tx.deal.create({
        data: {
          ...details,
          title: contact.name,
          pipelineId: stage.pipelineId,
          stageId: stage.id,
          contactId,
          // Сделку по брони, внесённой сотрудником, ведёт он сам.
          ownerId: actor.user?.id ?? null,
          position: await this.endOfStage(tx, stage.id),
        },
      });
      await this.audit.record(
        actor.user,
        {
          action: 'deal.created',
          entityType: 'deal',
          entityId: created.id,
          payload: { title: created.title, contactId, via: actor.via },
        },
        tx,
      );
      // Бронь перешла к новой сделке (сменился гость) — автоперенос начинается для неё заново.
      if (existing) await this.forgetStageMoves(tx, existing.id);
      return created.id;
    }

    const bookedStage =
      snapshot.status === 'BOOKED'
        ? await tx.stage.findFirst({
            where: { pipelineId: deal.pipelineId, systemKey: BOOKED_STAGE_KEY },
          })
        : null;
    const moveForward =
      bookedStage &&
      deal.stage.kind === 'OPEN' &&
      deal.stage.position < bookedStage.position;
    await tx.deal.update({
      where: { id: deal.id },
      data: {
        ...details,
        ...(moveForward && {
          stageId: bookedStage.id,
          position: await this.endOfStage(tx, bookedStage.id),
        }),
      },
    });
    if (moveForward) {
      await this.audit.record(
        actor.user,
        {
          action: 'deal.moved',
          entityType: 'deal',
          entityId: deal.id,
          payload: {
            fromStageId: deal.stageId,
            toStageId: bookedStage.id,
            toStageName: bookedStage.name,
            via: actor.via,
          },
        },
        tx,
      );
    }
    if (existing && deal.id !== existing.dealId) await this.forgetStageMoves(tx, existing.id);
    return deal.id;
  }

  /**
   * Задачи заезда/выезда: создаются по брони, снимаются при отмене. Срок меняем, только если
   * сдвинулись даты или время брони — ручной перенос менеджера не затираем.
   * Выполненная задача при сдвиге даты открывается снова: заезд теперь в другой день.
   */
  async syncTasks(
    tx: Tx,
    booking: Booking,
    snapshot: BookingSnapshot,
    existing: Booking | null,
  ): Promise<void> {
    if (snapshot.status !== 'BOOKED') {
      await tx.task.deleteMany({
        where: {
          bookingId: booking.id,
          isDone: false,
          autoKind: { not: null },
        },
      });
      return;
    }
    // Проживание уже закончилось (сверка прошлых броней из выгрузки): задачи заезда и выезда не нужны.
    if (snapshot.checkOut < tashkentToday(new Date())) return;
    const owner = booking.dealId
      ? ((
          await tx.deal.findUnique({
            where: { id: booking.dealId },
            select: { ownerId: true },
          })
        )?.ownerId ?? null)
      : null;
    const previousDue = existing
      ? new Map(
          autoTasksFor({
            ...snapshot,
            checkIn: dateOnlyFromDb(existing.checkIn),
            checkOut: dateOnlyFromDb(existing.checkOut),
            arrivalTime: existing.arrivalTime,
            departureTime: existing.departureTime,
          }).map((spec) => [spec.kind, spec.dueAt.getTime()]),
        )
      : new Map<string, number>();
    for (const spec of autoTasksFor(snapshot)) {
      const task = await tx.task.findUnique({
        where: {
          bookingId_autoKind: { bookingId: booking.id, autoKind: spec.kind },
        },
      });
      const timeMoved = previousDue.get(spec.kind) !== spec.dueAt.getTime();
      if (task) {
        await tx.task.update({
          where: { id: task.id },
          data: {
            dealId: booking.dealId,
            contactId: booking.contactId,
            ...(timeMoved && {
              title: spec.title,
              dueAt: spec.dueAt,
              isDone: false,
              doneAt: null,
            }),
          },
        });
      } else if (spec.dueAt.getTime() >= Date.now()) {
        // Задачу на уже прошедшее время не создаём (например, заезд гостя, который уже живёт).
        await tx.task.create({
          data: {
            title: spec.title,
            dueAt: spec.dueAt,
            assigneeId: owner,
            bookingId: booking.id,
            autoKind: spec.kind,
            dealId: booking.dealId,
            contactId: booking.contactId,
          },
        });
      }
    }
  }

  async recordHistory(
    tx: Tx,
    booking: Booking,
    snapshot: BookingSnapshot,
    existing: Booking | null,
    actor: BookingActor,
  ): Promise<void> {
    const action = !existing
      ? 'booking.created'
      : snapshot.status !== existing.status && isCanceled(snapshot.status)
        ? 'booking.canceled'
        : 'booking.updated';
    const entity = booking.dealId
      ? ({ entityType: 'deal', entityId: booking.dealId } as const)
      : booking.contactId
        ? ({ entityType: 'contact', entityId: booking.contactId } as const)
        : null;
    if (!entity) return;
    await this.audit.record(
      actor.user,
      {
        action,
        ...entity,
        // Суммы и статус — чтобы по истории было видно, кто и на что менял предоплату или депозит.
        payload: {
          bookingId: booking.id,
          rcId: snapshot.rcId,
          property: snapshot.property?.title ?? null,
          checkIn: snapshot.checkIn,
          checkOut: snapshot.checkOut,
          status: snapshot.status,
          amount: snapshot.amount,
          prepayment: snapshot.prepayment,
          deposit: snapshot.deposit,
          via: actor.via,
        },
      },
      tx,
    );
  }

  private async targetStageForNewDeal(tx: Tx, isBooked: boolean) {
    const pipeline = await tx.pipeline.findFirst({
      orderBy: { position: 'asc' },
      include: { stages: { orderBy: { position: 'asc' } } },
    });
    if (!pipeline) {
      this.logger.warn('Нет воронок — сделка по брони не создана');
      return null;
    }
    const booked = isBooked
      ? pipeline.stages.find((stage) => stage.systemKey === BOOKED_STAGE_KEY)
      : undefined;
    return (
      booked ?? pipeline.stages.find((stage) => stage.kind === 'OPEN') ?? null
    );
  }

  private async loseDeal(
    tx: Tx,
    dealId: string,
    actor: BookingActor,
  ): Promise<void> {
    const deal = await tx.deal.findUnique({
      where: { id: dealId },
      include: { stage: true },
    });
    if (!deal || deal.closedAt) return;
    const lostStage = await tx.stage.findFirst({
      where: { pipelineId: deal.pipelineId, kind: 'LOST' },
      orderBy: { position: 'asc' },
    });
    if (!lostStage) return;
    await tx.deal.update({
      where: { id: dealId },
      data: {
        stageId: lostStage.id,
        position: await this.endOfStage(tx, lostStage.id),
        closedAt: new Date(),
        lostReason: actor.via === 'CRM' ? CRM_CANCEL_REASON : CANCEL_REASON,
      },
    });
    await this.audit.record(
      actor.user,
      {
        action: 'deal.moved',
        entityType: 'deal',
        entityId: dealId,
        payload: {
          fromStageId: deal.stageId,
          toStageId: lostStage.id,
          toStageName: lostStage.name,
          via: actor.via,
        },
      },
      tx,
    );
  }

  /** Журнал автопереноса по брони (stage_move_runs): после сброса правила сработают снова. */
  private async forgetStageMoves(tx: Tx, bookingId: string): Promise<void> {
    await tx.stageMoveRun.deleteMany({ where: { bookingId } });
  }

  private async endOfStage(tx: Tx, stageId: string): Promise<number> {
    const last = await tx.deal.findFirst({
      where: { stageId },
      orderBy: { position: 'desc' },
      select: { position: true },
    });
    return (last?.position ?? 0) + POSITION_STEP;
  }
}
