import { nightsBetween, normalizePhone, type ContactSource } from '@crm/shared';
import { dateOnlyToDb } from '../common/dates.js';
import type { Booking, BookingStatus, Prisma } from '../generated/prisma/client.js';
import type { RcWebhook } from './rc-webhook.schema.js';

const STATUS_MAP: Record<RcWebhook['status'], BookingStatus> = {
  booked: 'BOOKED',
  request: 'REQUEST',
  canceled: 'CANCELED',
  deleted: 'DELETED',
};

/** Брони, отменённые или удалённые в RealtyCalendar. */
export const CANCELED_STATUSES: BookingStatus[] = ['CANCELED', 'DELETED'];

export const isCanceled = (status: BookingStatus): boolean =>
  CANCELED_STATUSES.includes(status);

/** Бронь из вебхука или выгрузки Excel в виде, удобном для сохранения. */
export interface BookingSnapshot {
  /** id в RealtyCalendar; null — строка выгрузки Excel (тогда задан importKey). */
  rcId: number | null;
  importKey: string | null;
  status: BookingStatus;
  checkIn: string;
  checkOut: string;
  nights: number;
  arrivalTime: string | null;
  departureTime: string | null;
  amount: number | null;
  prepayment: number | null;
  deposit: number | null;
  origin: string | null;
  guestName: string | null;
  guestPhone: string | null;
  guestEmail: string | null;
  notes: string | null;
  rcUrl: string | null;
  rcUpdatedAt: Date;
  property: {
    rcId: number | null;
    title: string;
    address: string | null;
    /** false — вебхук не прислал названия квартиры (подставлены адрес или номер): известное не затираем. */
    named?: boolean;
  } | null;
  /** Поля, которые вебхук прислал в нечитаемом виде: у известной брони остаются прежние значения. */
  unreadable?: readonly UnreadableField[];
}

/** Описательные поля брони, которые мягкая схема вебхука может отбросить. */
export type UnreadableField = 'nights' | 'arrivalTime' | 'departureTime' | 'amount' | 'prepayment' | 'deposit' | 'notes' | 'origin' | 'rcUrl';

const FIELD_BY_WEBHOOK_KEY: Record<string, UnreadableField> = {
  number_of_nights: 'nights',
  arrival_time: 'arrivalTime',
  departure_time: 'departureTime',
  amount: 'amount',
  prepayment: 'prepayment',
  deposit: 'deposit',
  notes: 'notes',
  booking_origin: 'origin',
  url: 'rcUrl',
};

/** Поля брони по путям ошибок строгой схемы (data.booking.<поле>…); прочие пути не относятся к отбрасываемым. */
export function unreadableFields(paths: ReadonlyArray<ReadonlyArray<PropertyKey>>): UnreadableField[] {
  const fields = paths.flatMap((path) => {
    const field = path[0] === 'data' && path[1] === 'booking' ? FIELD_BY_WEBHOOK_KEY[String(path[2])] : undefined;
    return field ? [field] : [];
  });
  return [...new Set(fields)];
}

const decimalOrNull = (value: { toNumber(): number } | null) => value?.toNumber() ?? null;

/**
 * Нечитаемое поле в обновлении известной брони не затирает сохранённое значение: берём его из базы.
 * Время заезда и выезда тоже — иначе сроки задач сбросились бы на время по умолчанию.
 */
export function keepUnreadableFields(snapshot: BookingSnapshot, existing: Booking | null): BookingSnapshot {
  const unreadable = snapshot.unreadable ?? [];
  if (!existing || unreadable.length === 0) return snapshot;
  const stored: Pick<BookingSnapshot, UnreadableField> = {
    nights: existing.nights,
    arrivalTime: existing.arrivalTime,
    departureTime: existing.departureTime,
    amount: decimalOrNull(existing.amount),
    prepayment: decimalOrNull(existing.prepayment),
    deposit: decimalOrNull(existing.deposit),
    notes: existing.notes,
    origin: existing.origin,
    rcUrl: existing.rcUrl,
  };
  return { ...snapshot, ...Object.fromEntries(unreadable.map((field) => [field, stored[field]])) };
}

/** Поля строки брони в базе по снимку и найденным квартире, клиенту и сделке. */
export function toBookingRow(
  snapshot: BookingSnapshot,
  links: { propertyId: string | null; contactId: string | null; dealId: string | null },
) {
  return {
    ...links,
    status: snapshot.status,
    checkIn: dateOnlyToDb(snapshot.checkIn),
    checkOut: dateOnlyToDb(snapshot.checkOut),
    nights: snapshot.nights,
    arrivalTime: snapshot.arrivalTime,
    departureTime: snapshot.departureTime,
    amount: snapshot.amount,
    prepayment: snapshot.prepayment,
    deposit: snapshot.deposit,
    origin: snapshot.origin,
    guestName: snapshot.guestName,
    guestPhone: snapshot.guestPhone,
    guestEmail: snapshot.guestEmail,
    notes: snapshot.notes,
    rcUrl: snapshot.rcUrl,
    rcUpdatedAt: snapshot.rcUpdatedAt,
  } satisfies Prisma.BookingUncheckedUpdateInput;
}

const CRM_GUEST_FIELDS = ['guestName', 'guestPhone', 'guestEmail'] as const;
const CRM_DETAIL_FIELDS = ['arrivalTime', 'departureTime', 'amount', 'prepayment', 'deposit', 'notes'] as const;

/**
 * Бронь внесена сотрудником в CRM: пустые поля вебхука RealtyCalendar не стирают то, что сотрудник ввёл.
 * Время, суммы и заметки — только при привязке: дальше бронь ведёт RealtyCalendar и может их очистить.
 * Гостя — и потом: без его телефона каждый следующий вебхук отвязывал бы бронь от клиента и сделки.
 */
export function keepCrmValues(snapshot: BookingSnapshot, existing: Booking | null): BookingSnapshot {
  if (existing?.source !== 'CRM') return snapshot;
  const fields = existing.rcId === null ? [...CRM_GUEST_FIELDS, ...CRM_DETAIL_FIELDS] : CRM_GUEST_FIELDS;
  const stored: Pick<BookingSnapshot, (typeof CRM_GUEST_FIELDS | typeof CRM_DETAIL_FIELDS)[number]> = {
    guestName: existing.guestName,
    guestPhone: existing.guestPhone,
    guestEmail: existing.guestEmail,
    arrivalTime: existing.arrivalTime,
    departureTime: existing.departureTime,
    amount: decimalOrNull(existing.amount),
    prepayment: decimalOrNull(existing.prepayment),
    deposit: decimalOrNull(existing.deposit),
    notes: existing.notes,
  };
  return {
    ...snapshot,
    ...Object.fromEntries(fields.map((field) => [field, snapshot[field] ?? stored[field]])),
  };
}

/**
 * Бронь RealtyCalendar на ту же квартиру и те же даты — та же, что внесена в CRM, если совпал гость
 * (телефон или email), а когда сравнить не по чему — если её внесли в RealtyCalendar вручную, без площадки.
 * Другой известный гость или бронь с площадки — это другая бронь на те же даты (овербукинг): её не
 * привязываем, чтобы на шахматке были видны обе.
 */
export function isSameCrmBooking(crm: Booking, snapshot: BookingSnapshot): boolean {
  const pairs: Array<[string | null, string | null]> = [
    [crm.guestPhone, snapshot.guestPhone],
    [crm.guestEmail, snapshot.guestEmail],
  ];
  const known = pairs.filter((pair): pair is [string, string] => pair[0] !== null && pair[1] !== null);
  if (known.some(([stored, incoming]) => stored !== incoming)) return false;
  return known.length > 0 || snapshot.origin === null;
}

/**
 * Сменился ли гость брони: тогда клиента ищут заново. У брони из CRM клиента выбрал сотрудник — он меняется,
 * только если RealtyCalendar прислал другой телефон или email, а не просто добавил недостающий.
 */
export function guestChanged(existing: Booking, current: BookingSnapshot): boolean {
  if (existing.source === 'CRM') {
    const differs = (stored: string | null, incoming: string | null) =>
      stored !== null && incoming !== null && stored !== incoming;
    return differs(existing.guestPhone, current.guestPhone) || differs(existing.guestEmail, current.guestEmail);
  }
  return existing.guestPhone !== current.guestPhone || existing.guestEmail !== current.guestEmail;
}

const clean = (value: string | null | undefined): string | null => {
  const trimmed = value?.trim();
  return trimmed ? trimmed : null;
};

export function toBookingSnapshot(webhook: RcWebhook, unreadable: readonly UnreadableField[] = []): BookingSnapshot {
  const booking = webhook.data.booking;
  const client = booking.client;
  const phone =
    normalizePhone(client?.phone ?? '') ??
    normalizePhone(client?.additional_phone ?? '');
  const propertyRcId = booking.apartment?.id ?? booking.realty_id ?? null;

  return {
    rcId: booking.id,
    importKey: null,
    status: STATUS_MAP[webhook.status],
    checkIn: booking.begin_date,
    checkOut: booking.end_date,
    nights:
      booking.number_of_nights ??
      nightsBetween(booking.begin_date, booking.end_date),
    arrivalTime: clean(booking.arrival_time),
    departureTime: clean(booking.departure_time),
    amount: booking.amount ?? null,
    prepayment: booking.prepayment ?? null,
    deposit: booking.deposit ?? null,
    origin: clean(booking.booking_origin?.title),
    guestName: clean(client?.fio),
    guestPhone: phone,
    guestEmail: clean(client?.email)?.toLowerCase() ?? null,
    notes: clean(booking.notes),
    rcUrl: clean(booking.url),
    rcUpdatedAt: new Date(booking.updated_at),
    property:
      propertyRcId === null
        ? null
        : {
            rcId: propertyRcId,
            title:
              clean(booking.apartment?.title) ??
              clean(booking.address) ??
              `Объект ${propertyRcId}`,
            address:
              clean(booking.apartment?.address) ?? clean(booking.address),
            named: clean(booking.apartment?.title) !== null,
          },
    unreadable,
  };
}

/** Источник нового клиента по площадке, с которой пришла бронь. */
export function contactSourceForOrigin(origin: string | null): ContactSource {
  const value = origin?.toLowerCase() ?? '';
  if (value.includes('booking')) return 'BOOKING';
  if (value.includes('airbnb')) return 'AIRBNB';
  if (
    value.includes('сайт') ||
    value.includes('site') ||
    value.includes('виджет')
  )
    return 'WEBSITE';
  return 'OTHER';
}
