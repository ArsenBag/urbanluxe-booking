/**
 * «Скелет» нераспознанного вебхука для журнала: название события и названия полей с вложенностью,
 * без значений — по нему видно, как устроено незнакомое событие, а данные гостей в журнал не попадают.
 */
const SAFE_KEY = /^[\w.-]{1,40}$/;
const ACTION = /^[\w.:-]{1,40}$/;
const MAX_DEPTH = 3;
const MAX_KEYS = 40;

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

function describeValue(value: unknown, depth: number): string {
  if (Array.isArray(value)) return '[]';
  if (!isRecord(value)) return '';
  if (depth >= MAX_DEPTH) return '{…}';
  return `{${describeKeys(value, depth + 1)}}`;
}

function describeKeys(record: Record<string, unknown>, depth: number): string {
  const keys = Object.keys(record);
  const shown = keys
    .slice(0, MAX_KEYS)
    .map((key) =>
      SAFE_KEY.test(key) ? `${key}${describeValue(record[key], depth)}` : '?',
    );
  return [...shown, ...(keys.length > MAX_KEYS ? ['…'] : [])].join(', ');
}

export function describeShape(body: unknown): string {
  if (!isRecord(body)) return 'action=?; поля: —';
  const action =
    typeof body.action === 'string' && ACTION.test(body.action)
      ? body.action
      : '?';
  return `action=${action}; поля: ${describeKeys(body, 0)}`;
}
