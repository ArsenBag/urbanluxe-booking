/** Код квартиры без регистра, пробелов и знаков: «U-51», «u 51» и «U51» совпадают. */
function normalizeCode(value: string): string {
  return value.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
}

/** Название объекта содержит введённый код (или его часть). */
export function matchesPropertyCode(title: string, query: string): boolean {
  const code = normalizeCode(query);
  return code.length > 0 && normalizeCode(title).includes(code);
}
