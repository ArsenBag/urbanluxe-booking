import { Module } from '@nestjs/common';
import { InboxModule } from '../inbox/inbox.module.js';
import { StageAutomationModule } from '../stage-automation/stage-automation.module.js';
import { AutomationScheduler } from './automation.scheduler.js';
import { AutomationService } from './automation.service.js';

@Module({
  imports: [InboxModule, StageAutomationModule],
  providers: [AutomationService, AutomationScheduler],
  exports: [AutomationService],
})
export class AutomationsModule {}
