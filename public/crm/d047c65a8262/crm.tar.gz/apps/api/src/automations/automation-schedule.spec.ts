import { isDue, sendWindow, tashkentToday } from './automation-schedule.js';

describe('sendWindow', () => {
  it('sends the check-in instruction from 18:00 the day before until 15:00 on arrival day (Tashkent)', () => {
    const window = sendWindow('BEFORE_CHECK_IN', '2026-10-20', '2026-10-23');

    expect(window.from.toISOString()).toBe('2026-10-19T13:00:00.000Z');
    expect(window.until.toISOString()).toBe('2026-10-20T10:00:00.000Z');
  });

  it('asks for a review from 14:00 on check-out day for two days', () => {
    const window = sendWindow('AFTER_CHECK_OUT', '2026-10-20', '2026-10-23');

    expect(window.from.toISOString()).toBe('2026-10-23T09:00:00.000Z');
    expect(window.until.toISOString()).toBe('2026-10-25T09:00:00.000Z');
  });

  it('crosses month boundaries', () => {
    expect(sendWindow('BEFORE_CHECK_IN', '2026-11-01', '2026-11-03').from.toISOString()).toBe('2026-10-31T13:00:00.000Z');
  });
});

describe('isDue', () => {
  it('is due inside the window only', () => {
    expect(isDue('BEFORE_CHECK_IN', '2026-10-20', '2026-10-23', new Date('2026-10-19T12:59:00Z'))).toBe(false);
    expect(isDue('BEFORE_CHECK_IN', '2026-10-20', '2026-10-23', new Date('2026-10-19T13:00:00Z'))).toBe(true);
    expect(isDue('BEFORE_CHECK_IN', '2026-10-20', '2026-10-23', new Date('2026-10-20T10:00:00Z'))).toBe(false);
  });
});

describe('tashkentToday', () => {
  it('uses the Tashkent date, not UTC', () => {
    expect(tashkentToday(new Date('2026-10-04T20:30:00Z'))).toBe('2026-10-05');
  });
});
