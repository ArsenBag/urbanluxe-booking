import { Inject, Injectable, Logger, type OnApplicationBootstrap, type OnModuleDestroy } from '@nestjs/common';
import { ENV, type Env } from '../config/env.js';
import { StageAutomationService } from '../stage-automation/stage-automation.service.js';
import { AutomationService } from './automation.service.js';

/** Как часто проверяем брони: сделки переезжают по времени настроек (08:00, 19:00, 12:00) с точностью до минуты. */
const RUN_INTERVAL_MS = 60_000;
/** Первый проход — вскоре после запуска, когда всё поднялось. */
const FIRST_RUN_DELAY_MS = 30_000;

/** Периодический запуск автоматизаций. Без внешних очередей: один процесс API, проходы не пересекаются. */
@Injectable()
export class AutomationScheduler implements OnApplicationBootstrap, OnModuleDestroy {
  private readonly logger = new Logger(AutomationScheduler.name);
  private timer: NodeJS.Timeout | null = null;
  private firstRun: NodeJS.Timeout | null = null;
  private running = false;

  constructor(
    private readonly automations: AutomationService,
    private readonly stageAutomation: StageAutomationService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  onApplicationBootstrap(): void {
    if (!this.env.AUTOMATIONS_ENABLED) {
      this.logger.log('Автоматизации выключены (AUTOMATIONS_ENABLED=false)');
      return;
    }
    this.firstRun = setTimeout(() => void this.tick(), FIRST_RUN_DELAY_MS);
    this.firstRun.unref();
    this.timer = setInterval(() => void this.tick(), RUN_INTERVAL_MS);
    this.timer.unref();
  }

  onModuleDestroy(): void {
    if (this.firstRun) clearTimeout(this.firstRun);
    if (this.timer) clearInterval(this.timer);
  }

  /** Ошибки прохода логируются и не роняют процесс; следующий проход попробует снова. */
  private async tick(): Promise<void> {
    if (this.running) return;
    this.running = true;
    try {
      // Перенос сделок и автосообщения независимы: сбой одного не останавливает другое.
      const dealsMoved = await this.safely('Автоперенос сделок', () => this.stageAutomation.runOnce());
      const messages = await this.safely('Автосообщения', () => this.automations.runOnce());
      const messagesSent = messages?.messagesSent ?? 0;
      if (dealsMoved || messagesSent) {
        this.logger.log(`Автоматизации: сделок перенесено ${dealsMoved ?? 0}, сообщений отправлено ${messagesSent}`);
      }
    } finally {
      this.running = false;
    }
  }

  private async safely<T>(name: string, run: () => Promise<T>): Promise<T | null> {
    try {
      return await run();
    } catch (error) {
      this.logger.error(`${name}: проход прерван`, error instanceof Error ? error.stack : error);
      return null;
    }
  }
}
