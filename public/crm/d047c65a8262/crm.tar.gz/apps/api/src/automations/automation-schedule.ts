import type { TemplateAutomation } from '@crm/shared';
import { shiftDate, tashkentAt } from '../common/dates.js';

/** Когда отправлять: накануне заезда в 18:00, после выезда в 14:00 (по Ташкенту). */
const SEND_TIME: Record<TemplateAutomation, string> = {
  BEFORE_CHECK_IN: '18:00',
  AFTER_CHECK_OUT: '14:00',
};
/**
 * Окно, в течение которого ещё имеет смысл отправить. Позже — не отправляем вовсе
 * (сервер был выключен, бронь загрузили задним числом): поздняя инструкция только запутает гостя.
 */
const WINDOW_HOURS: Record<TemplateAutomation, number> = {
  BEFORE_CHECK_IN: 21, // до 15:00 дня заезда
  AFTER_CHECK_OUT: 48,
};

export interface SendWindow {
  from: Date;
  until: Date;
}

/** Окно отправки автоматического сообщения по датам брони (YYYY-MM-DD). */
export function sendWindow(kind: TemplateAutomation, checkIn: string, checkOut: string): SendWindow {
  const day = kind === 'BEFORE_CHECK_IN' ? shiftDate(checkIn, -1) : checkOut;
  const from = tashkentAt(day, SEND_TIME[kind]);
  return { from, until: new Date(from.getTime() + WINDOW_HOURS[kind] * 3_600_000) };
}

export function isDue(kind: TemplateAutomation, checkIn: string, checkOut: string, now: Date): boolean {
  const { from, until } = sendWindow(kind, checkIn, checkOut);
  return now >= from && now < until;
}

/** Сегодняшняя дата по Ташкенту (YYYY-MM-DD). */
export function tashkentToday(now: Date): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Tashkent' }).format(now);
}
