import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import {
  firstName,
  MAX_CAPTION_LENGTH,
  renderTemplate,
  TEMPLATE_AUTOMATIONS,
  templateDate,
  type MessageDto,
  type TemplateAutomation,
} from '@crm/shared';
import { ActivityLogService } from '../audit/activity-log.service.js';
import { dateOnlyFromDb, dateOnlyToDb, shiftDate } from '../common/dates.js';
import { isPrismaError, PrismaErrorCode } from '../common/prisma-errors.js';
import { InboxService } from '../inbox/inbox.service.js';
import { PrismaService } from '../prisma/prisma.service.js';
import { isDue, tashkentToday } from './automation-schedule.js';

/** Сколько броней максимум обрабатываем за один проход — защита от огромных выборок. */
const BATCH_LIMIT = 500;

const formatDate = (date: Date) => templateDate(dateOnlyFromDb(date));
const shift = (date: string, days: number) => dateOnlyToDb(shiftDate(date, days));

export interface AutomationResult {
  messagesSent: number;
}

/**
 * Автосообщения гостю накануне заезда и после выезда. Безопасно запускать повторно: каждое сообщение
 * уходит по брони один раз. Перенос сделок по датам — StageAutomationService.
 */
@Injectable()
export class AutomationService {
  private readonly logger = new Logger(AutomationService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly inbox: InboxService,
    private readonly audit: ActivityLogService,
  ) {}

  async runOnce(now = new Date()): Promise<AutomationResult> {
    const today = tashkentToday(now);
    let messagesSent = 0;
    for (const kind of TEMPLATE_AUTOMATIONS) {
      messagesSent += await this.sendDueMessages(kind, today, now);
    }
    return { messagesSent };
  }

  private async sendDueMessages(kind: TemplateAutomation, today: string, now: Date): Promise<number> {
    const template = await this.prisma.replyTemplate.findUnique({ where: { automation: kind } });
    if (!template) return 0;

    // Кандидаты — брони вокруг сегодняшней даты; точное окно проверяет isDue.
    const dateFilter =
      kind === 'BEFORE_CHECK_IN'
        ? { checkIn: { gte: dateOnlyToDb(today), lte: shift(today, 1) } }
        : { checkOut: { gte: shift(today, -2), lte: dateOnlyToDb(today) } };
    const bookings = await this.prisma.booking.findMany({
      where: { status: 'BOOKED', contactId: { not: null }, ...dateFilter, automationRuns: { none: { kind } } },
      include: { contact: { select: { name: true } }, property: { select: { title: true } } },
      orderBy: [{ checkIn: 'asc' }, { id: 'asc' }],
      take: BATCH_LIMIT,
    });

    let sent = 0;
    for (const booking of bookings) {
      try {
        if (await this.sendForBooking(kind, template, booking, now)) sent += 1;
      } catch (error) {
        // Сбой по одной брони не должен прерывать остальные.
        this.logger.error(`Автосообщение по брони ${booking.id} не обработано`, error instanceof Error ? error.stack : error);
      }
    }
    return sent;
  }

  /** true — сообщение отправлено. */
  private async sendForBooking(
    kind: TemplateAutomation,
    template: { body: string; title: string; fileId: string | null },
    booking: {
      id: string;
      contactId: string | null;
      dealId: string | null;
      checkIn: Date;
      checkOut: Date;
      guestName: string | null;
      contact: { name: string } | null;
      property: { title: string } | null;
    },
    now: Date,
  ): Promise<boolean> {
    {
      const checkIn = dateOnlyFromDb(booking.checkIn);
      const checkOut = dateOnlyFromDb(booking.checkOut);
      if (!booking.contactId || !isDue(kind, checkIn, checkOut, now)) return false;
      const conversation = await this.prisma.conversation.findFirst({
        where: { contactId: booking.contactId, channel: { status: 'CONNECTED' } },
        orderBy: { lastMessageAt: { sort: 'desc', nulls: 'last' } },
      });
      // Писать некуда (клиент не писал в подключённый мессенджер) — попробуем на следующем проходе.
      if (!conversation) return false;

      // Сначала «занимаем» отправку: уникальный ключ не даст отправить дважды даже при параллельных запусках.
      let runId: string;
      try {
        runId = (await this.prisma.automationRun.create({ data: { kind, bookingId: booking.id } })).id;
      } catch (error) {
        if (isPrismaError(error, PrismaErrorCode.UniqueViolation)) return false;
        throw error;
      }
      const text = renderTemplate(template.body, {
        имя: firstName(booking.contact?.name ?? booking.guestName ?? ''),
        объект: booking.property?.title ?? '',
        заезд: formatDate(booking.checkIn),
        выезд: formatDate(booking.checkOut),
      });
      const message = await this.deliver(conversation.id, template, text);
      await this.prisma.automationRun.update({ where: { id: runId }, data: { messageId: message.id } });
      await this.audit.record(null, {
        action: 'automation.sent',
        entityType: booking.dealId ? 'deal' : 'contact',
        entityId: booking.dealId ?? booking.contactId,
        payload: { kind, title: template.title, status: message.status },
      });
      if (message.status === 'FAILED') {
        // Повторно сами не шлём (иначе при сломанном канале — новое «неотправленное» на каждом проходе):
        // сообщение видно в чате с кнопкой «Повторить» и в истории сделки.
        this.logger.warn(`Автосообщение «${template.title}» не отправлено (бронь ${booking.id}): ${message.error ?? ''}`);
        return false;
      }
      return true;
    }
  }

  /**
   * Шаблон с файлом уходит одним сообщением — файлом с текстом в подписи (одно сообщение — одна отметка
   * автоотправки, иначе второе считалось бы ответом сотрудника). Полный текст гостю важнее файла: если после
   * подстановки данных брони текст не влез в подпись или файл шаблона только что заменили — уходит текст.
   */
  private async deliver(
    conversationId: string,
    template: { title: string; fileId: string | null },
    text: string,
  ): Promise<MessageDto> {
    if (template.fileId && text.length <= MAX_CAPTION_LENGTH) {
      try {
        return await this.inbox.sendStoredFile(conversationId, template.fileId, text, null);
      } catch (error) {
        if (!(error instanceof NotFoundException)) throw error;
        this.logger.warn(`Автосообщение «${template.title}»: файл шаблона не найден — уходит только текст`);
      }
    } else if (template.fileId) {
      this.logger.warn(`Автосообщение «${template.title}»: текст длиннее подписи к файлу — уходит только текст`);
    }
    return this.inbox.send(conversationId, text, null);
  }
}
