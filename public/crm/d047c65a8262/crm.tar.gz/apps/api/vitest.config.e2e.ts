import { defineConfig } from 'vitest/config';

export default defineConfig({
  resolve: { tsconfigPaths: true },
  test: {
    globals: true,
    root: './',
    include: ['**/*.e2e-spec.ts'],
    // Хэширование argon2 медленное намеренно, даём тестам запас по времени.
    testTimeout: 20_000,
    hookTimeout: 30_000,
    // Файлы работают с одной БД: запускаем по очереди, чтобы не мешали друг другу.
    fileParallelism: false,
  },
});
