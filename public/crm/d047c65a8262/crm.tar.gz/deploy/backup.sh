#!/usr/bin/env bash
# Ежедневная резервная копия БД и файлов переписки. Запуск из cron (см. docs/DEPLOY.md).
# Хранит копии BACKUP_DAYS дней в BACKUP_DIR; более старые копии удаляет.
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/crm}"
BACKUP_DAYS="${BACKUP_DAYS:-14}"
MIN_DUMP_BYTES=100

mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"
file="$BACKUP_DIR/crm-$(date +%Y-%m-%d_%H%M).sql.gz"

cd "$PROJECT_DIR"
docker compose -f docker-compose.prod.yml exec -T postgres pg_dump -U crm --clean --if-exists crm | gzip > "$file"
chmod 600 "$file"

# Пустой дамп — ошибка, а не тихий успех.
if [ "$(gzip -dc "$file" | head -c "$MIN_DUMP_BYTES" | wc -c)" -lt "$MIN_DUMP_BYTES" ]; then
  echo "Резервная копия пустая: $file" >&2
  exit 1
fi

# Файлы переписки (фото, голосовые, документы) — архивом из тома API.
files="$BACKUP_DIR/files-$(date +%Y-%m-%d_%H%M).tar.gz"
docker compose -f docker-compose.prod.yml exec -T api tar -C /data/files -cf - . | gzip > "$files"
chmod 600 "$files"

find "$BACKUP_DIR" \( -name 'crm-*.sql.gz' -o -name 'files-*.tar.gz' \) -mtime +"$BACKUP_DAYS" -print0 | xargs -0 -r rm --
echo "Резервная копия сохранена: $file, $files"
