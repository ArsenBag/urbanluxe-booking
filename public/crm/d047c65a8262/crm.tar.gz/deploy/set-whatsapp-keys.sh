#!/usr/bin/env bash
# Подключает инстанс Green-API (WhatsApp) к CRM на сервере: записывает ключи в .env, перезапускает API
# и через API Green-API включает вебхук на CRM с секретным токеном из .env сервера.
# Запуск на Mac из папки проекта: ./deploy/set-whatsapp-keys.sh
# Данные берутся из карточки инстанса на https://console.green-api.com.
# Токен вводится с клавиатуры: не попадает в историю терминала, в чат и в аргументы команд.
set -euo pipefail

SERVER="${CRM_SERVER:-lvkim91@138.249.248.114}"
SSH_KEY="${CRM_SSH_KEY:-$HOME/.ssh/id_ed25519_highlife}"
SSH=(ssh -i "$SSH_KEY" -o IdentitiesOnly=yes "$SERVER")

read -rp "idInstance: " ID
read -rsp "apiTokenInstance (при вводе не отображается): " TOKEN
echo
read -rp "apiUrl (например https://7103.api.greenapi.com): " API_URL
read -rp "mediaUrl (например https://7103.media.greenapi.com): " MEDIA_URL

ID="${ID//[[:space:]]/}"
TOKEN="${TOKEN//[[:space:]]/}"
API_URL="${API_URL//[[:space:]]/}"
MEDIA_URL="${MEDIA_URL//[[:space:]]/}"
API_URL="${API_URL%/}"
MEDIA_URL="${MEDIA_URL%/}"
URL_PATTERN='^https://[A-Za-z0-9.-]+$'
if [[ ! "$ID" =~ ^[0-9]{5,15}$ ]]; then echo "idInstance — число. Ничего не изменено." >&2; exit 1; fi
if [[ ! "$TOKEN" =~ ^[A-Za-z0-9]{20,100}$ ]]; then echo "apiTokenInstance — длинная строка из букв и цифр. Ничего не изменено." >&2; exit 1; fi
if [[ ! "$API_URL" =~ $URL_PATTERN ]]; then echo "apiUrl — адрес вида https://7103.api.greenapi.com. Ничего не изменено." >&2; exit 1; fi
if [[ ! "$MEDIA_URL" =~ $URL_PATTERN ]]; then echo "mediaUrl — адрес вида https://7103.media.greenapi.com. Ничего не изменено." >&2; exit 1; fi

printf '%s\n%s\n%s\n%s\n' "$ID" "$TOKEN" "$API_URL" "$MEDIA_URL" \
  | "${SSH[@]}" "sudo sh -c 'umask 077; cat > /opt/crm/.whatsapp-keys.tmp'"

"${SSH[@]}" 'sudo bash -s' <<'REMOTE'
set -euo pipefail
cd /opt/crm
ID=$(sed -n 1p .whatsapp-keys.tmp)
TOKEN=$(sed -n 2p .whatsapp-keys.tmp)
API_URL=$(sed -n 3p .whatsapp-keys.tmp)
MEDIA_URL=$(sed -n 4p .whatsapp-keys.tmp)
rm -f .whatsapp-keys.tmp

set_env() {
  grep -q "^$1=" .env || echo "$1=" >> .env
  sed -i "s|^$1=.*|$1=$2|" .env
}
set_env GREEN_API_URL "$API_URL"
set_env GREEN_API_MEDIA_URL "$MEDIA_URL"
set_env GREEN_API_ID_INSTANCE "$ID"
set_env GREEN_API_TOKEN "$TOKEN"
WEBHOOK_TOKEN=$(grep '^GREEN_API_WEBHOOK_TOKEN=' .env | cut -d= -f2-)
if [ -z "$WEBHOOK_TOKEN" ]; then
  WEBHOOK_TOKEN=$(openssl rand -hex 24)
  set_env GREEN_API_WEBHOOK_TOKEN "$WEBHOOK_TOKEN"
fi
DOMAIN=$(grep '^DOMAIN=' .env | cut -d= -f2-)

# Настройки инстанса: вебхук на CRM с токеном, уведомления о входящих, исходящих, звонках и состоянии номера.
SETTINGS=$(printf '{"webhookUrl":"https://%s/api/webhooks/whatsapp","webhookUrlToken":"%s","incomingWebhook":"yes","outgoingMessageWebhook":"yes","outgoingAPIMessageWebhook":"yes","incomingCallWebhook":"yes","stateWebhook":"yes"}' "$DOMAIN" "$WEBHOOK_TOKEN")
RESULT=$(curl -sS --max-time 20 -X POST -H 'content-type: application/json' -d "$SETTINGS" \
  "${API_URL}/waInstance${ID}/setSettings/${TOKEN}" || true)
if ! echo "$RESULT" | grep -q '"saveSettings": *true'; then
  echo "Green-API не принял настройки (проверьте idInstance, токен и apiUrl). Ответ: $(echo "$RESULT" | head -c 200)" >&2
  exit 1
fi
STATE=$(curl -sS --max-time 20 "${API_URL}/waInstance${ID}/getStateInstance/${TOKEN}" | grep -o '"stateInstance": *"[A-Za-z]*"' | grep -o '[A-Za-z]*"$' | tr -d '"' || true)

docker compose -f docker-compose.prod.yml up -d api >/dev/null 2>&1
for _ in $(seq 1 30); do
  docker compose -f docker-compose.prod.yml logs --since 2m api 2>&1 | grep -q "successfully started" && break
  sleep 2
done
if ! docker compose -f docker-compose.prod.yml logs --since 2m api 2>&1 | grep -q "successfully started"; then
  echo "API не запустился. Последние строки журнала:" >&2
  docker compose -f docker-compose.prod.yml logs --tail 15 api >&2
  exit 1
fi
echo "Готово: ключи сохранены, вебхук Green-API настроен на https://${DOMAIN}/api/webhooks/whatsapp."
case "$STATE" in
  authorized) echo "Номер WhatsApp подключён (authorized)." ;;
  notAuthorized) echo "Номер ещё не подключён: отсканируйте QR-код в кабинете Green-API телефоном с WhatsApp компании." ;;
  *) echo "Состояние инстанса: ${STATE:-неизвестно}. Его видно и в CRM: «Настройки» → «Каналы»." ;;
esac
REMOTE
