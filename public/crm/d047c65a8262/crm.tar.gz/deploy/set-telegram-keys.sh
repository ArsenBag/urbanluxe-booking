#!/usr/bin/env bash
# Записывает ключи Telegram (https://my.telegram.org → API development tools) в .env на сервере
# и перезапускает API. Запуск на Mac из папки проекта: ./deploy/set-telegram-keys.sh
# Ключи вводятся с клавиатуры: не попадают в историю терминала, в чат и в аргументы команд.
set -euo pipefail

SERVER="${CRM_SERVER:-lvkim91@138.249.248.114}"
SSH_KEY="${CRM_SSH_KEY:-$HOME/.ssh/id_ed25519_highlife}"
SSH=(ssh -i "$SSH_KEY" -o IdentitiesOnly=yes "$SERVER")

read -rp "App api_id: " API_ID
read -rsp "App api_hash (при вводе не отображается): " API_HASH
echo

API_ID="${API_ID//[[:space:]]/}"
API_HASH="${API_HASH//[[:space:]]/}"
if [[ ! "$API_ID" =~ ^[0-9]{3,12}$ ]]; then
  echo "api_id — это число (например 1234567). Ничего не изменено." >&2
  exit 1
fi
if [[ ! "$API_HASH" =~ ^[0-9a-f]{32}$ ]]; then
  echo "api_hash — 32 символа из 0-9 и a-f. Ничего не изменено." >&2
  exit 1
fi

# Значения уходят на сервер через stdin во временный файл, доступный только root.
printf '%s\n%s\n' "$API_ID" "$API_HASH" | "${SSH[@]}" "sudo sh -c 'umask 077; cat > /opt/crm/.telegram-keys.tmp'"

"${SSH[@]}" 'sudo bash -s' <<'REMOTE'
set -euo pipefail
cd /opt/crm
ID=$(sed -n 1p .telegram-keys.tmp)
HASH=$(sed -n 2p .telegram-keys.tmp)
rm -f .telegram-keys.tmp
for key in TELEGRAM_API_ID TELEGRAM_API_HASH; do
  grep -q "^${key}=" .env || echo "${key}=" >> .env
done
sed -i "s/^TELEGRAM_API_ID=.*/TELEGRAM_API_ID=${ID}/; s/^TELEGRAM_API_HASH=.*/TELEGRAM_API_HASH=${HASH}/" .env
docker compose -f docker-compose.prod.yml up -d api >/dev/null 2>&1
# Ждём запуска API и проверяем, что Telegram больше не считается ненастроенным.
for _ in $(seq 1 30); do
  if docker compose -f docker-compose.prod.yml logs --since 2m api 2>&1 | grep -q "successfully started"; then
    break
  fi
  sleep 2
done
if docker compose -f docker-compose.prod.yml logs --since 2m api 2>&1 | grep -q "Telegram не настроен"; then
  echo "API запустился, но Telegram не принял ключи — проверьте их и запустите скрипт ещё раз." >&2
  exit 1
fi
if ! docker compose -f docker-compose.prod.yml logs --since 2m api 2>&1 | grep -q "successfully started"; then
  echo "API не запустился. Последние строки журнала:" >&2
  docker compose -f docker-compose.prod.yml logs --tail 15 api >&2
  exit 1
fi
echo "Готово: ключи Telegram сохранены, API перезапущен."
REMOTE
