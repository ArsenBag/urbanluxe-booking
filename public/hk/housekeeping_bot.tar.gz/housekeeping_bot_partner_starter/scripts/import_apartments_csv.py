import asyncio
import csv
import sys
from pathlib import Path

from app.config import load_settings
from app.db import connect, initialize_database
from app.repositories.apartments import upsert_apartment


REQUIRED_COLUMNS = {
    "code",
    "building",
    "address",
    "floor",
    "apartment_type",
    "area_m2",
    "bathrooms_count",
    "beds_count",
    "sofa_beds_count",
}


def as_int(value, default=0):
    value = (value or "").strip()
    return int(value) if value else default


async def main():
    if len(sys.argv) != 2:
        print("Usage: PYTHONPATH=. python scripts/import_apartments_csv.py apartments.csv")
        raise SystemExit(1)

    csv_path = Path(sys.argv[1])
    if not csv_path.exists():
        print(f"File not found: {csv_path}")
        raise SystemExit(1)

    settings = load_settings()
    await initialize_database(settings)
    db = await connect(settings)
    imported = 0
    try:
        with csv_path.open("r", encoding="utf-8-sig", newline="") as file:
            reader = csv.DictReader(file)
            missing = REQUIRED_COLUMNS.difference(reader.fieldnames or [])
            if missing:
                print("Missing columns: " + ", ".join(sorted(missing)))
                raise SystemExit(1)

            for row in reader:
                await upsert_apartment(
                    db,
                    code=row["code"].strip(),
                    building=row["building"].strip(),
                    address=row["address"].strip(),
                    floor=as_int(row["floor"]),
                    apartment_type=row["apartment_type"].strip(),
                    area_m2=as_int(row["area_m2"]),
                    bathrooms_count=as_int(row["bathrooms_count"], 1),
                    beds_count=as_int(row["beds_count"], 1),
                    sofa_beds_count=as_int(row["sofa_beds_count"]),
                )
                realty_id = as_int(row.get("realty_id"))
                if realty_id:
                    await db.execute(
                        "UPDATE apartments SET realty_id = ? WHERE code = ?",
                        (realty_id, row["code"].strip()),
                    )
                    await db.commit()
                imported += 1
    finally:
        await db.close()

    print(f"Imported apartments: {imported}")


if __name__ == "__main__":
    asyncio.run(main())
