#!/usr/bin/env sh
set -eu

cd "$(dirname "$0")/.."

DB_PATH="${HOUSEKEEPING_DB_PATH:-data/housekeeping.sqlite3}"
BACKUP_DIR="${HOUSEKEEPING_BACKUP_DIR:-data/backups}"

if [ ! -f "$DB_PATH" ]; then
  echo "Database not found: $DB_PATH"
  exit 1
fi

mkdir -p "$BACKUP_DIR"

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_PATH="$BACKUP_DIR/housekeeping-$STAMP.sqlite3"

python3 - "$DB_PATH" "$BACKUP_PATH" <<'PY'
from contextlib import closing
import sqlite3
import sys

with closing(sqlite3.connect(sys.argv[1])) as source:
    with closing(sqlite3.connect(sys.argv[2])) as backup:
        source.backup(backup)
        if backup.execute("PRAGMA quick_check").fetchone()[0] != "ok":
            raise RuntimeError("Backup integrity check failed")
PY
echo "Backup created: $BACKUP_PATH"
