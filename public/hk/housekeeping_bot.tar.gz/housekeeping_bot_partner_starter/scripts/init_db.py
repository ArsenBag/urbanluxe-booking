import asyncio

from app.config import load_settings
from app.db import initialize_database


async def main():
    settings = load_settings()
    await initialize_database(settings)
    print(f"Database initialized: {settings.database_path}")


if __name__ == "__main__":
    asyncio.run(main())

