from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional
from urllib.parse import unquote

import os

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover - local convenience before deps install
    def load_dotenv(*args, **kwargs):
        return False


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _parse_admin_ids(raw_value: str) -> List[int]:
    ids = []
    for item in raw_value.split(","):
        item = item.strip()
        if not item:
            continue
        try:
            ids.append(int(item))
        except ValueError:
            raise ValueError("ADMIN_TELEGRAM_IDS must contain only numeric Telegram IDs")
    return ids


@dataclass(frozen=True)
class Settings:
    bot_token: str
    telegram_request_timeout: float
    telegram_force_ipv4: bool
    database_url: str
    admin_telegram_ids: List[int]
    timezone: str
    google_sheet_id: Optional[str]
    google_credentials_file: Optional[str]
    realtycalendar_webhook_enabled: bool
    realtycalendar_webhook_host: str
    realtycalendar_webhook_port: int
    realtycalendar_webhook_token: Optional[str]
    analytics_webhook_url: Optional[str]
    analytics_webhook_token: Optional[str]
    cleaning_reconcile_interval_seconds: int
    dashboard_enabled: bool = True
    dashboard_token: Optional[str] = None

    @property
    def database_path(self) -> Path:
        prefixes = ("sqlite+aiosqlite:///", "sqlite:///")
        value = self.database_url
        for prefix in prefixes:
            if value.startswith(prefix):
                value = value[len(prefix):]
                break

        path = Path(unquote(value))
        if not path.is_absolute():
            path = PROJECT_ROOT / path
        return path


def load_settings() -> Settings:
    load_dotenv(PROJECT_ROOT / ".env")

    webhook_enabled = os.getenv(
        "REALTYCALENDAR_WEBHOOK_ENABLED", "false"
    ).strip().lower() in {"1", "true", "yes", "on"}
    webhook_token = os.getenv("REALTYCALENDAR_WEBHOOK_TOKEN", "").strip()
    dashboard_enabled = os.getenv(
        "DASHBOARD_ENABLED", "false"
    ).strip().lower() in {"1", "true", "yes", "on"}
    dashboard_token = os.getenv("DASHBOARD_TOKEN", "").strip()
    for enabled, secret, name in (
        (webhook_enabled, webhook_token, "REALTYCALENDAR_WEBHOOK_TOKEN"),
        (dashboard_enabled, dashboard_token, "DASHBOARD_TOKEN"),
    ):
        if enabled and (len(secret) < 24 or secret.startswith("replace-with-")):
            raise ValueError(f"{name} must be set to a unique secret of at least 24 characters")

    telegram_timeout = os.getenv("TELEGRAM_REQUEST_TIMEOUT", "120").strip()
    try:
        telegram_timeout_value = float(telegram_timeout)
    except ValueError:
        raise ValueError("TELEGRAM_REQUEST_TIMEOUT must be a number")

    webhook_port = os.getenv("REALTYCALENDAR_WEBHOOK_PORT", "8080").strip()
    try:
        webhook_port_value = int(webhook_port)
    except ValueError:
        raise ValueError("REALTYCALENDAR_WEBHOOK_PORT must be a number")

    reconcile_interval = os.getenv("CLEANING_RECONCILE_INTERVAL_SECONDS", "900").strip()
    try:
        reconcile_interval_value = int(reconcile_interval)
    except ValueError:
        raise ValueError("CLEANING_RECONCILE_INTERVAL_SECONDS must be a number")

    return Settings(
        bot_token=os.getenv("BOT_TOKEN", "").strip(),
        telegram_request_timeout=telegram_timeout_value,
        telegram_force_ipv4=os.getenv(
            "TELEGRAM_FORCE_IPV4",
            "false",
        ).strip().lower() in {"1", "true", "yes", "on"},
        database_url=os.getenv(
            "DATABASE_URL",
            "sqlite+aiosqlite:///data/housekeeping.sqlite3",
        ).strip(),
        admin_telegram_ids=_parse_admin_ids(os.getenv("ADMIN_TELEGRAM_IDS", "")),
        timezone=os.getenv("TIMEZONE", "Asia/Tashkent").strip() or "Asia/Tashkent",
        google_sheet_id=os.getenv("GOOGLE_SHEET_ID", "").strip() or None,
        google_credentials_file=os.getenv("GOOGLE_CREDENTIALS_FILE", "").strip() or None,
        realtycalendar_webhook_enabled=webhook_enabled,
        realtycalendar_webhook_host=os.getenv(
            "REALTYCALENDAR_WEBHOOK_HOST",
            "0.0.0.0",
        ).strip() or "0.0.0.0",
        realtycalendar_webhook_port=webhook_port_value,
        realtycalendar_webhook_token=webhook_token or None,
        analytics_webhook_url=os.getenv("ANALYTICS_WEBHOOK_URL", "").strip() or None,
        analytics_webhook_token=os.getenv("ANALYTICS_WEBHOOK_TOKEN", "").strip() or None,
        cleaning_reconcile_interval_seconds=max(60, reconcile_interval_value),
        dashboard_enabled=dashboard_enabled,
        dashboard_token=dashboard_token or None,
    )
