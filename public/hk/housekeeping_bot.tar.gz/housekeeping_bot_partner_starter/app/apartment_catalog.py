from __future__ import annotations

import re


UNKNOWN_APARTMENT_MINUTES = 60
APARTMENT_MINIMUM_MINUTES = {
    "studio": 40,
    "one_bedroom": 60,
    "large_one_bedroom": 75,
    "two_bedroom": 90,
    "three_bedroom": 90,
}
APARTMENT_TYPE_LABELS = {
    "studio": "студия",
    "one_bedroom": "двухкомнатная",
    "large_one_bedroom": "большая двухкомнатная",
    "two_bedroom": "трёхкомнатная",
    "three_bedroom": "четырёхкомнатная",
}

# Add a code prefix here only if that complex must stay visible to booking
# managers while being excluded from the housekeeping schedule.
HOUSEKEEPING_EXCLUDED_CODE_PREFIXES: tuple[str, ...] = ()

# Apartment types and buildings should normally be imported from the new
# company's own CSV. These optional mappings apply to new RealtyCalendar
# objects that have not yet been imported.
_TYPE_BY_CODE: dict[str, str] = {}
_BUILDING_BY_CODE: dict[str, str] = {}


def normalize_apartment_code(code: str | None) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(code or "").upper())


def classified_apartment_type(code: str | None) -> str | None:
    return _TYPE_BY_CODE.get(normalize_apartment_code(code))


def is_housekeeping_excluded(code: str | None) -> bool:
    normalized = normalize_apartment_code(code)
    return any(
        normalized.startswith(prefix)
        for prefix in HOUSEKEEPING_EXCLUDED_CODE_PREFIXES
    )


def classified_apartment_building(code: str | None) -> str | None:
    return _BUILDING_BY_CODE.get(normalize_apartment_code(code))


def minimum_cleaning_minutes(apartment_type: str | None) -> int:
    normalized = str(apartment_type or "unknown").strip().lower()
    return APARTMENT_MINIMUM_MINUTES.get(normalized, UNKNOWN_APARTMENT_MINUTES)
