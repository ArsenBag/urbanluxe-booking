from pathlib import Path

import aiosqlite

from .config import PROJECT_ROOT, Settings


async def connect(settings: Settings) -> aiosqlite.Connection:
    settings.database_path.parent.mkdir(parents=True, exist_ok=True)
    db = await aiosqlite.connect(str(settings.database_path))
    db.row_factory = aiosqlite.Row
    await db.execute("PRAGMA foreign_keys = ON")
    return db


async def run_migrations(settings: Settings) -> None:
    migrations_dir = PROJECT_ROOT / "app" / "migrations"
    db = await connect(settings)
    try:
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS schema_migrations (
                name TEXT PRIMARY KEY,
                applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        applied_rows = await db.execute_fetchall("SELECT name FROM schema_migrations")
        applied = {row["name"] for row in applied_rows}

        for migration_path in sorted(Path(migrations_dir).glob("*.sql")):
            if migration_path.name in applied:
                continue
            sql = migration_path.read_text(encoding="utf-8")
            await db.executescript(sql)
            await db.execute(
                "INSERT OR IGNORE INTO schema_migrations (name) VALUES (?)",
                (migration_path.name,),
            )
        await db.commit()
    finally:
        await db.close()


async def seed_data(settings: Settings) -> None:
    db = await connect(settings)
    try:
        for telegram_id in settings.admin_telegram_ids:
            await db.execute(
                """
                INSERT INTO users (telegram_id, full_name, role)
                VALUES (?, ?, 'admin')
                ON CONFLICT(telegram_id) DO UPDATE SET
                    role = 'admin',
                    is_active = 1
                """,
                (telegram_id, "Admin"),
            )

        await db.commit()
    finally:
        await db.close()


async def initialize_database(settings: Settings) -> None:
    await run_migrations(settings)
    await seed_data(settings)
