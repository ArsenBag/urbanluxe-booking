from __future__ import annotations

import hmac
from collections import defaultdict
from datetime import datetime, timezone as dt_timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from aiohttp import web

from app.services.formatting import compact_apartment_code


DASHBOARD_DIR = Path(__file__).with_name("dashboard_assets")
DONE_STATUSES = {"completed", "waiting_check", "verified"}
OPEN_TASK_STATUSES = {"assigned", "guest_checked_out", "in_progress", "rework", "problem"}


def _parse_datetime(value: str | None, timezone: str) -> datetime | None:
    if not value:
        return None
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=ZoneInfo(timezone))
    return parsed


def _seconds_since(value: str | None, current: datetime, timezone: str) -> int:
    parsed = _parse_datetime(value, timezone)
    if not parsed:
        return 0
    return max(0, int((current - parsed).total_seconds()))


def _initials(name: str) -> str:
    parts = [part for part in name.split() if part]
    return "".join(part[0].upper() for part in parts[:2]) or "?"


def _task_payload(task) -> dict | None:
    if not task:
        return None
    return {
        "id": task["id"],
        "apartment": compact_apartment_code(task["apartment_code"]),
        "building": task["building"] or "Без ЖК",
        "address": task["address"] or "",
        "floor": task["floor"],
        "status": task["status"],
        "cleaning_type": task["cleaning_type"],
        "estimated_minutes": int(task["estimated_duration_min"] or 0),
        "actual_minutes": task["actual_duration_min"],
        "started_at": task["started_at"],
        "finished_at": task["finished_at"],
        "deadline_at": task["deadline_at"],
    }


async def build_live_state(db, timezone: str) -> dict:
    current = datetime.now(ZoneInfo(timezone)).replace(microsecond=0)
    work_date = current.date().isoformat()

    people_cursor = await db.execute(
        """
        SELECT
            u.id,
            u.full_name,
            s.started_at AS shift_started_at
        FROM users u
        LEFT JOIN maid_shifts s ON s.id = (
            SELECT candidate.id
            FROM maid_shifts candidate
            WHERE candidate.maid_id = u.id
              AND candidate.work_date = ?
              AND candidate.ended_at IS NULL
            ORDER BY candidate.started_at DESC
            LIMIT 1
        )
        WHERE u.role = 'maid'
          AND u.is_active = 1
        ORDER BY CASE WHEN s.id IS NULL THEN 1 ELSE 0 END, u.full_name
        """,
        (work_date,),
    )
    people = await people_cursor.fetchall()

    tasks_cursor = await db.execute(
        """
        SELECT
            t.*,
            a.code AS apartment_code,
            a.building AS building,
            a.address AS address,
            a.floor AS floor,
            u.full_name AS maid_name
        FROM cleaning_tasks t
        JOIN apartments a ON a.id = t.apartment_id
        LEFT JOIN users u ON u.id = t.assigned_maid_id
        WHERE t.planned_date = ?
          AND t.status != 'canceled'
          AND a.is_active = 1
        ORDER BY COALESCE(t.deadline_at, '9999-12-31T23:59:59'), a.code
        """,
        (work_date,),
    )
    tasks = await tasks_cursor.fetchall()

    buildings_cursor = await db.execute(
        """
        SELECT COALESCE(building, 'Без ЖК') AS building, COUNT(*) AS apartment_count
        FROM apartments
        WHERE is_active = 1
        GROUP BY COALESCE(building, 'Без ЖК')
        ORDER BY building
        """
    )
    building_rows = await buildings_cursor.fetchall()

    tasks_by_maid = defaultdict(list)
    tasks_by_building = defaultdict(list)
    for task in tasks:
        if task["assigned_maid_id"]:
            tasks_by_maid[task["assigned_maid_id"]].append(task)
        tasks_by_building[task["building"] or "Без ЖК"].append(task)

    maids = []
    for person in people:
        maid_tasks = tasks_by_maid[person["id"]]
        active = next((task for task in maid_tasks if task["status"] == "in_progress"), None)
        shift_started = _parse_datetime(person["shift_started_at"], timezone)
        last_finished = max(
            (
                task
                for task in maid_tasks
                if task["finished_at"]
                and (
                    not shift_started
                    or _parse_datetime(task["finished_at"], timezone) >= shift_started
                )
            ),
            key=lambda task: task["finished_at"],
            default=None,
        )
        attention_task = next(
            (task for task in maid_tasks if task["status"] in {"problem", "rework", "overdue"}),
            None,
        )
        next_task = next(
            (task for task in maid_tasks if task["status"] in OPEN_TASK_STATUSES and task is not active),
            None,
        )
        on_shift = bool(person["shift_started_at"])

        if active:
            state = "cleaning"
            state_label = "Убирает"
            focus_task = active
            elapsed_seconds = _seconds_since(active["started_at"], current, timezone)
            break_seconds = 0
        elif on_shift and attention_task:
            state = "attention"
            state_label = "Нужна помощь"
            focus_task = attention_task
            elapsed_seconds = 0
            break_seconds = 0
        elif on_shift and last_finished:
            state = "break"
            state_label = "Перерыв"
            focus_task = next_task or last_finished
            elapsed_seconds = 0
            break_seconds = _seconds_since(last_finished["finished_at"], current, timezone)
        elif on_shift:
            state = "ready"
            state_label = "Готова к работе"
            focus_task = next_task
            elapsed_seconds = 0
            break_seconds = 0
        else:
            state = "off_shift"
            state_label = "Не на смене"
            focus_task = next_task
            elapsed_seconds = 0
            break_seconds = 0

        estimate_seconds = int(active["estimated_duration_min"] or 0) * 60 if active else 0
        maids.append(
            {
                "id": person["id"],
                "name": person["full_name"],
                "initials": _initials(person["full_name"]),
                "state": state,
                "state_label": state_label,
                "on_shift": on_shift,
                "shift_started_at": person["shift_started_at"],
                "shift_seconds": _seconds_since(person["shift_started_at"], current, timezone),
                "elapsed_seconds": elapsed_seconds,
                "break_seconds": break_seconds,
                "progress": min(100, round(elapsed_seconds / estimate_seconds * 100)) if estimate_seconds else 0,
                "over_estimate": bool(estimate_seconds and elapsed_seconds > estimate_seconds),
                "task": _task_payload(focus_task),
                "next_task": _task_payload(next_task),
                "completed_count": sum(task["status"] in DONE_STATUSES for task in maid_tasks),
                "total_count": len(maid_tasks),
            }
        )

    properties = []
    known_buildings = {row["building"]: int(row["apartment_count"]) for row in building_rows}
    for name in sorted(set(known_buildings) | set(tasks_by_building)):
        building_tasks = tasks_by_building[name]
        occupants = [
            {"id": maid["id"], "name": maid["name"], "initials": maid["initials"], "state": maid["state"]}
            for maid in maids
            if maid["on_shift"] and maid["task"] and maid["task"]["building"] == name
        ]
        properties.append(
            {
                "name": name,
                "apartment_count": known_buildings.get(name, 0),
                "task_count": len(building_tasks),
                "active_count": sum(task["status"] == "in_progress" for task in building_tasks),
                "done_count": sum(task["status"] in DONE_STATUSES for task in building_tasks),
                "attention_count": sum(task["status"] in {"problem", "rework", "overdue"} for task in building_tasks),
                "occupants": occupants,
                "apartments": [_task_payload(task) for task in building_tasks[:8]],
            }
        )

    day_start_utc = current.replace(hour=0, minute=0, second=0).astimezone(dt_timezone.utc)
    activity_cursor = await db.execute(
        """
        SELECT
            ce.event_type,
            ce.created_at,
            COALESCE(actor.full_name, maid.full_name, 'Система') AS actor_name,
            a.code AS apartment_code,
            a.building AS building
        FROM cleaning_events ce
        JOIN cleaning_tasks t ON t.id = ce.task_id
        JOIN apartments a ON a.id = t.apartment_id
        LEFT JOIN users actor ON actor.id = ce.user_id
        LEFT JOIN users maid ON maid.id = t.assigned_maid_id
        WHERE datetime(ce.created_at) >= datetime(?)
        ORDER BY ce.created_at DESC, ce.id DESC
        LIMIT 12
        """,
        (day_start_utc.strftime("%Y-%m-%d %H:%M:%S"),),
    )
    activity_rows = await activity_cursor.fetchall()
    activity_labels = {
        "started": ("info", "{actor} начала уборку {apartment}"),
        "finished": ("success", "{actor} завершила {apartment}"),
        "verified": ("success", "{apartment} принята супервизором"),
        "assigned": ("neutral", "{actor} назначена на {apartment}"),
        "reassigned": ("neutral", "Исполнитель {apartment} изменён"),
        "rework": ("warning", "{apartment} отправлена на переделку"),
        "rework_done": ("success", "Переделка {apartment} завершена"),
        "problem": ("warning", "{actor} сообщила о проблеме в {apartment}"),
        "problem_resolved": ("success", "Проблема в {apartment} решена"),
        "guest_checked_out": ("neutral", "Гость выехал из {apartment}"),
    }
    activities = []
    for row in activity_rows:
        tone, template = activity_labels.get(
            row["event_type"],
            ("neutral", "Обновлена уборка {apartment}"),
        )
        created_at = _parse_datetime(row["created_at"], "UTC")
        if created_at:
            created_at = created_at.astimezone(ZoneInfo(timezone)).isoformat()
        activities.append(
            {
                "at": created_at,
                "tone": tone,
                "text": template.format(
                    actor=row["actor_name"],
                    apartment=compact_apartment_code(row["apartment_code"]),
                    building=row["building"] or "Без ЖК",
                ),
            }
        )

    completed_tasks = sum(task["status"] in DONE_STATUSES for task in tasks)
    return {
        "mode": "live",
        "generated_at": current.isoformat(),
        "date": work_date,
        "summary": {
            "on_shift": sum(maid["on_shift"] for maid in maids),
            "cleaning": sum(maid["state"] == "cleaning" for maid in maids),
            "break": sum(maid["state"] == "break" for maid in maids),
            "tasks_total": len(tasks),
            "completed": completed_tasks,
            "attention": sum(task["status"] in {"problem", "rework", "overdue"} for task in tasks),
        },
        "maids": maids,
        "properties": properties,
        "activities": activities,
    }


def build_demo_state(timezone: str) -> dict:
    current = datetime.now(ZoneInfo(timezone)).replace(microsecond=0)
    return {
        "mode": "demo",
        "generated_at": current.isoformat(),
        "date": current.date().isoformat(),
        "summary": {"on_shift": 0, "cleaning": 0, "break": 0, "tasks_total": 0, "completed": 0, "attention": 0},
        "maids": [],
        "properties": [],
        "activities": [],
    }


def _authorized(request: web.Request) -> bool:
    configured = request.app["settings"].dashboard_token
    if configured:
        supplied = (
            request.query.get("token")
            or request.cookies.get("housekeeping_dashboard")
            or request.headers.get("Authorization", "").removeprefix("Bearer ")
        )
        return bool(supplied) and hmac.compare_digest(configured, supplied)
    return request.remote in {"127.0.0.1", "::1", None}


async def dashboard_index(request: web.Request) -> web.StreamResponse:
    if not _authorized(request):
        raise web.HTTPUnauthorized(text="Нужен ключ доступа к панели")
    response = web.FileResponse(DASHBOARD_DIR / "index.html")
    response.headers["Cache-Control"] = "no-store"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self'; script-src 'self'; "
        "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    if request.app["settings"].dashboard_token and request.query.get("token"):
        response.set_cookie(
            "housekeeping_dashboard",
            request.app["settings"].dashboard_token,
            max_age=8 * 60 * 60,
            httponly=True,
            secure=request.secure,
            samesite="Strict",
            path="/",
        )
    return response


async def dashboard_live(request: web.Request) -> web.Response:
    if not _authorized(request):
        raise web.HTTPUnauthorized(text="unauthorized")
    settings = request.app["settings"]
    if request.query.get("demo") == "1":
        payload = build_demo_state(settings.timezone)
    else:
        payload = await build_live_state(request.app["db"], settings.timezone)
    return web.json_response(payload, headers={"Cache-Control": "no-store"})


def setup_dashboard_routes(app: web.Application) -> None:
    app.router.add_get("/dashboard", dashboard_index)
    app.router.add_get("/api/dashboard/live", dashboard_live)
    app.router.add_static("/dashboard/assets", DASHBOARD_DIR, show_index=False)
