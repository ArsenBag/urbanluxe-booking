from typing import Iterable, Optional

import aiosqlite


async def get_by_telegram_id(db: aiosqlite.Connection, telegram_id: int):
    cursor = await db.execute(
        "SELECT * FROM users WHERE telegram_id = ? AND is_active = 1",
        (telegram_id,),
    )
    return await cursor.fetchone()


async def get_by_id(db: aiosqlite.Connection, user_id: int):
    cursor = await db.execute(
        "SELECT * FROM users WHERE id = ? AND is_active = 1",
        (user_id,),
    )
    return await cursor.fetchone()


async def get_any_by_id(db: aiosqlite.Connection, user_id: int):
    cursor = await db.execute(
        "SELECT * FROM users WHERE id = ?",
        (user_id,),
    )
    return await cursor.fetchone()


async def list_by_roles(db: aiosqlite.Connection, roles: Iterable[str]):
    role_values = list(roles)
    placeholders = ",".join(["?"] * len(role_values))
    cursor = await db.execute(
        f"""
        SELECT *
        FROM users
        WHERE role IN ({placeholders}) AND is_active = 1
        ORDER BY role, full_name
        """,
        role_values,
    )
    return await cursor.fetchall()


async def list_maids(db: aiosqlite.Connection):
    return await list_by_roles(db, ["maid"])


async def list_supervisors_and_admins(db: aiosqlite.Connection):
    return await list_by_roles(db, ["supervisor", "admin"])


async def list_admins(db: aiosqlite.Connection):
    return await list_by_roles(db, ["admin"])


async def list_booking_managers(db: aiosqlite.Connection):
    return await list_by_roles(db, ["booking_manager"])


async def list_supervisors_on_shift(db: aiosqlite.Connection, work_date: str):
    cursor = await db.execute(
        """
        SELECT DISTINCT u.*
        FROM users u
        JOIN maid_shifts s ON s.maid_id = u.id
        WHERE u.role = 'supervisor'
          AND u.is_active = 1
          AND u.telegram_id IS NOT NULL
          AND s.work_date = ?
          AND s.ended_at IS NULL
        ORDER BY u.full_name
        """,
        (work_date,),
    )
    return await cursor.fetchall()


async def ensure_admin(
    db: aiosqlite.Connection,
    telegram_id: int,
    full_name: Optional[str],
):
    existing = await get_by_telegram_id(db, telegram_id)
    if existing:
        if existing["role"] != "admin":
            await db.execute(
                "UPDATE users SET role = 'admin', is_active = 1 WHERE id = ?",
                (existing["id"],),
            )
            await db.commit()
            return await get_by_id(db, existing["id"])
        return existing

    await db.execute(
        """
        INSERT INTO users (telegram_id, full_name, role)
        VALUES (?, ?, 'admin')
        """,
        (telegram_id, full_name or "Admin"),
    )
    await db.commit()
    return await get_by_telegram_id(db, telegram_id)


async def create_or_update_user(
    db: aiosqlite.Connection,
    role: str,
    telegram_id: Optional[int],
    full_name: str,
    phone: Optional[str] = None,
):
    if telegram_id:
        cursor = await db.execute(
            """
            SELECT id
            FROM users
            WHERE telegram_id IS NULL
              AND full_name = ?
              AND role = ?
              AND is_active = 1
            LIMIT 1
            """,
            (full_name, role),
        )
        placeholder = await cursor.fetchone()
        if placeholder:
            await db.execute(
                """
                UPDATE users
                SET telegram_id = ?, phone = COALESCE(?, phone)
                WHERE id = ?
                """,
                (telegram_id, phone, placeholder["id"]),
            )
            await db.commit()
            return

        await db.execute(
            """
            INSERT INTO users (telegram_id, full_name, role, phone, is_active)
            VALUES (?, ?, ?, ?, 1)
            ON CONFLICT(telegram_id) DO UPDATE SET
                full_name = excluded.full_name,
                role = excluded.role,
                phone = excluded.phone,
                is_active = 1
            """,
            (telegram_id, full_name, role, phone),
        )
    else:
        await db.execute(
            """
            INSERT INTO users (full_name, role, phone, is_active)
            VALUES (?, ?, ?, 1)
            """,
            (full_name, role, phone),
        )
    await db.commit()


async def list_active(db: aiosqlite.Connection):
    cursor = await db.execute(
        """
        SELECT *
        FROM users
        WHERE is_active = 1
        ORDER BY role, full_name
        """
    )
    return await cursor.fetchall()


async def list_all(db: aiosqlite.Connection):
    cursor = await db.execute(
        """
        SELECT *
        FROM users
        ORDER BY is_active DESC, role, full_name
        """
    )
    return await cursor.fetchall()


async def set_active(db: aiosqlite.Connection, user_id: int, is_active: bool):
    await db.execute(
        "UPDATE users SET is_active = ? WHERE id = ?",
        (1 if is_active else 0, user_id),
    )
    await db.commit()
    return await get_any_by_id(db, user_id)


async def deactivate_user(db: aiosqlite.Connection, user_id: int):
    return await set_active(db, user_id, False)


async def reactivate_user(db: aiosqlite.Connection, user_id: int):
    return await set_active(db, user_id, True)


async def set_language(db: aiosqlite.Connection, user_id: int, language: str):
    if language not in ("ru", "uz"):
        raise ValueError("Unsupported language")
    await db.execute(
        "UPDATE users SET language = ? WHERE id = ?",
        (language, user_id),
    )
    await db.commit()
    return await get_by_id(db, user_id)
