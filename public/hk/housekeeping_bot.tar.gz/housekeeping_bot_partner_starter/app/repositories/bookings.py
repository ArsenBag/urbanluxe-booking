from typing import Optional

import aiosqlite


BOOKING_FIELDS = """
    b.*,
    a.code AS apartment_code,
    a.building AS building,
    a.address AS address,
    a.floor AS floor,
    t.status AS cleaning_status,
    t.planned_date AS cleaning_planned_date,
    t.deadline_at AS cleaning_deadline_at,
    t.assigned_maid_id AS cleaning_maid_id,
    maid.full_name AS maid_name,
    maid.telegram_id AS maid_telegram_id,
    maid.language AS maid_language
"""

BOOKING_JOIN = """
    FROM bookings b
    JOIN apartments a ON a.id = b.apartment_id
    LEFT JOIN cleaning_tasks t ON t.id = b.cleaning_task_id
    LEFT JOIN users maid ON maid.id = t.assigned_maid_id
"""


async def get_by_id(db: aiosqlite.Connection, booking_id: int):
    cursor = await db.execute(
        f"""
        SELECT {BOOKING_FIELDS}
        {BOOKING_JOIN}
        WHERE b.id = ?
        """,
        (booking_id,),
    )
    return await cursor.fetchone()


async def get_by_external_booking_id(db: aiosqlite.Connection, external_booking_id: str):
    cursor = await db.execute(
        f"""
        SELECT {BOOKING_FIELDS}
        {BOOKING_JOIN}
        WHERE b.external_booking_id = ?
        """,
        (external_booking_id,),
    )
    return await cursor.fetchone()


async def create_booking(
    db: aiosqlite.Connection,
    apartment_id: int,
    checkin_date: Optional[str],
    checkin_time: Optional[str],
    checkout_date: str,
    checkout_time: Optional[str],
    guests_count: Optional[int],
    created_by: int,
):
    cursor = await db.execute(
        """
        INSERT INTO bookings (
            apartment_id, checkin_date, checkin_time, checkout_date,
            checkout_time, guests_count, created_by
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            apartment_id,
            checkin_date,
            checkin_time,
            checkout_date,
            checkout_time,
            guests_count,
            created_by,
        ),
    )
    await db.commit()
    return await get_by_id(db, cursor.lastrowid)


async def upsert_external_booking(
    db: aiosqlite.Connection,
    external_booking_id: str,
    realty_id: Optional[int],
    apartment_id: int,
    checkin_date: Optional[str],
    checkin_time: Optional[str],
    checkout_date: str,
    checkout_time: Optional[str],
    guests_count: Optional[int],
    external_status: Optional[str],
    raw_payload_json: str,
):
    existing = await get_by_external_booking_id(db, external_booking_id)
    if existing:
        await db.execute(
            """
            UPDATE bookings
            SET realty_id = ?,
                apartment_id = ?,
                checkin_date = ?,
                checkin_time = ?,
                checkout_date = ?,
                checkout_time = ?,
                guests_count = ?,
                external_status = ?,
                raw_payload_json = ?,
                source = 'realtycalendar',
                status = CASE
                    WHEN status = 'canceled' THEN 'planned'
                    ELSE status
                END,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (
                realty_id,
                apartment_id,
                checkin_date,
                checkin_time,
                checkout_date,
                checkout_time,
                guests_count,
                external_status,
                raw_payload_json,
                existing["id"],
            ),
        )
        await db.commit()
        return await get_by_id(db, existing["id"])

    cursor = await db.execute(
        """
        INSERT INTO bookings (
            external_booking_id, realty_id, apartment_id, checkin_date,
            checkin_time, checkout_date, checkout_time, guests_count,
            source, external_status, raw_payload_json
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'realtycalendar', ?, ?)
        """,
        (
            external_booking_id,
            realty_id,
            apartment_id,
            checkin_date,
            checkin_time,
            checkout_date,
            checkout_time,
            guests_count,
            external_status,
            raw_payload_json,
        ),
    )
    await db.commit()
    return await get_by_id(db, cursor.lastrowid)


async def create_checkout_only_booking(
    db: aiosqlite.Connection,
    apartment_id: int,
    checkout_date: str,
    checkout_time: Optional[str],
    created_by: int,
):
    return await create_booking(
        db,
        apartment_id=apartment_id,
        checkin_date=None,
        checkin_time=None,
        checkout_date=checkout_date,
        checkout_time=checkout_time,
        guests_count=None,
        created_by=created_by,
    )


async def list_checkout_date(db: aiosqlite.Connection, checkout_date: str):
    cursor = await db.execute(
        f"""
        SELECT {BOOKING_FIELDS}
        {BOOKING_JOIN}
        WHERE b.checkout_date = ?
          AND a.is_active = 1
          AND b.status != 'canceled'
        ORDER BY COALESCE(b.checkout_time, ''), a.building, a.code
        """,
        (checkout_date,),
    )
    return await cursor.fetchall()


async def list_inconsistent_realty_cleaning_links(
    db: aiosqlite.Connection,
    checkout_date_from: str,
    checkout_date_to: str,
):
    cursor = await db.execute(
        f"""
        SELECT {BOOKING_FIELDS}
        {BOOKING_JOIN}
        WHERE b.source = 'realtycalendar'
          AND b.status != 'canceled'
          AND b.checkout_date BETWEEN ? AND ?
          AND a.is_active = 1
          AND (
              b.cleaning_task_id IS NULL
              OR t.id IS NULL
              OR t.status = 'canceled'
              OR t.apartment_id != b.apartment_id
              OR t.planned_date != b.checkout_date
              OR COALESCE(t.external_booking_id, '') != COALESCE(b.external_booking_id, '')
          )
        ORDER BY b.checkout_date, b.id
        """,
        (checkout_date_from, checkout_date_to),
    )
    return await cursor.fetchall()


async def cancel_external_booking(db: aiosqlite.Connection, external_booking_id: str):
    booking = await get_by_external_booking_id(db, external_booking_id)
    if not booking:
        return None
    await db.execute(
        """
        UPDATE bookings
        SET status = 'canceled',
            external_status = 'canceled',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (booking["id"],),
    )
    await db.commit()
    return await get_by_id(db, booking["id"])


async def update_checkout_plan(
    db: aiosqlite.Connection,
    booking_id: int,
    checkout_time: str,
    next_checkin_time: Optional[str],
    no_next_booking: bool,
    updated_at: str,
):
    await db.execute(
        """
        UPDATE bookings
        SET checkout_time = ?,
            next_checkin_time = ?,
            no_next_booking = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (
            checkout_time,
            next_checkin_time,
            1 if no_next_booking else 0,
            updated_at,
            booking_id,
        ),
    )
    await db.commit()
    return await get_by_id(db, booking_id)


async def update_next_checkin(
    db: aiosqlite.Connection,
    booking_id: int,
    next_checkin_time: Optional[str],
    no_next_booking: bool,
    updated_at: str,
):
    await db.execute(
        """
        UPDATE bookings
        SET next_checkin_time = ?,
            no_next_booking = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (next_checkin_time, 1 if no_next_booking else 0, updated_at, booking_id),
    )
    await db.commit()
    return await get_by_id(db, booking_id)


async def find_next_checkin_same_day(
    db: aiosqlite.Connection,
    apartment_id: int,
    checkout_date: str,
    exclude_booking_id: Optional[int] = None,
):
    params = [apartment_id, checkout_date]
    exclude_filter = ""
    if exclude_booking_id:
        exclude_filter = "AND id != ?"
        params.append(exclude_booking_id)

    cursor = await db.execute(
        f"""
        SELECT *
        FROM bookings
        WHERE apartment_id = ?
          AND checkin_date = ?
          AND status != 'canceled'
          {exclude_filter}
        ORDER BY COALESCE(checkin_time, '99:99'), id
        LIMIT 1
        """,
        params,
    )
    return await cursor.fetchone()


async def list_previous_checkouts_same_day(
    db: aiosqlite.Connection,
    apartment_id: int,
    checkin_date: str,
    exclude_booking_id: Optional[int] = None,
):
    params = [apartment_id, checkin_date]
    exclude_filter = ""
    if exclude_booking_id:
        exclude_filter = "AND id != ?"
        params.append(exclude_booking_id)

    cursor = await db.execute(
        f"""
        SELECT *
        FROM bookings
        WHERE apartment_id = ?
          AND checkout_date = ?
          AND status != 'canceled'
          {exclude_filter}
        ORDER BY COALESCE(checkout_time, ''), id
        """,
        params,
    )
    return await cursor.fetchall()


async def log_realty_webhook_event(
    db: aiosqlite.Connection,
    event_type: Optional[str],
    external_booking_id: Optional[str],
    payload_json: str,
):
    await db.execute(
        """
        INSERT INTO realty_webhook_events (event_type, external_booking_id, payload_json)
        VALUES (?, ?, ?)
        """,
        (event_type, external_booking_id, payload_json),
    )
    await db.commit()


async def mark_checked_out(
    db: aiosqlite.Connection,
    booking_id: int,
    actual_checkout_at: str,
):
    await db.execute(
        """
        UPDATE bookings
        SET status = 'checked_out',
            actual_checkout_at = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (actual_checkout_at, actual_checkout_at, booking_id),
    )
    await db.commit()
    return await get_by_id(db, booking_id)


async def attach_cleaning_task(
    db: aiosqlite.Connection,
    booking_id: int,
    cleaning_task_id: int,
    status: str,
    updated_at: str,
):
    await db.execute(
        """
        UPDATE bookings
        SET cleaning_task_id = ?,
            status = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (cleaning_task_id, status, updated_at, booking_id),
    )
    await db.commit()
    return await get_by_id(db, booking_id)


async def list_readiness_for_date(db: aiosqlite.Connection, planned_date: str):
    cursor = await db.execute(
        """
        SELECT
            t.id AS task_id,
            t.status AS cleaning_status,
            t.deadline_at AS deadline_at,
            t.started_at AS started_at,
            t.finished_at AS finished_at,
            t.verified_at AS verified_at,
            t.keys_missing_reported_at AS keys_missing_reported_at,
            t.keys_missing_resolved_at AS keys_missing_resolved_at,
            EXISTS (
                SELECT 1
                FROM cleaning_tasks key_issue
                WHERE key_issue.apartment_id = t.apartment_id
                  AND key_issue.keys_missing_reported_at IS NOT NULL
                  AND key_issue.keys_missing_resolved_at IS NULL
            ) AS apartment_keys_missing,
            a.code AS apartment_code,
            a.building AS building,
            maid.full_name AS maid_name,
            COALESCE(next_booking.checkin_time, b.next_checkin_time) AS checkin_time,
            CASE
                WHEN next_booking.id IS NOT NULL THEN 0
                WHEN b.id IS NULL THEN 1
                ELSE COALESCE(b.no_next_booking, 0)
            END AS no_next_booking,
            b.guests_count AS guests_count
        FROM cleaning_tasks t
        JOIN apartments a ON a.id = t.apartment_id
        LEFT JOIN users maid ON maid.id = t.assigned_maid_id
        LEFT JOIN bookings b ON b.cleaning_task_id = t.id
        LEFT JOIN bookings next_booking ON next_booking.id = (
            SELECT candidate.id
            FROM bookings candidate
            WHERE candidate.apartment_id = t.apartment_id
              AND candidate.checkin_date = t.planned_date
              AND candidate.status != 'canceled'
              AND (b.id IS NULL OR candidate.id != b.id)
            ORDER BY COALESCE(candidate.checkin_time, '99:99'), candidate.id
            LIMIT 1
        )
        WHERE t.planned_date = ?
          AND a.is_active = 1
          AND t.status != 'canceled'
        ORDER BY
            CASE
                WHEN next_booking.id IS NOT NULL THEN 0
                WHEN COALESCE(b.no_next_booking, 0) = 1 THEN 1
                ELSE 0
            END,
            COALESCE(next_booking.checkin_time, b.next_checkin_time, t.deadline_at, ''),
            a.building,
            a.code
        """,
        (planned_date,),
    )
    return await cursor.fetchall()
