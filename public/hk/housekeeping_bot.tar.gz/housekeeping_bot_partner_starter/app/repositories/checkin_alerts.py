import aiosqlite


async def was_delivered(
    db: aiosqlite.Connection,
    task_id: int,
    checkin_at: str,
    recipient_user_id: int,
) -> bool:
    cursor = await db.execute(
        """
        SELECT 1
        FROM checkin_start_alert_deliveries
        WHERE task_id = ?
          AND checkin_at = ?
          AND recipient_user_id = ?
        LIMIT 1
        """,
        (task_id, checkin_at, recipient_user_id),
    )
    return await cursor.fetchone() is not None


async def record_delivery(
    db: aiosqlite.Connection,
    task_id: int,
    checkin_at: str,
    recipient_user_id: int,
    delivered_at: str,
) -> bool:
    cursor = await db.execute(
        """
        INSERT OR IGNORE INTO checkin_start_alert_deliveries (
            task_id, checkin_at, recipient_user_id, delivered_at
        )
        VALUES (?, ?, ?, ?)
        """,
        (task_id, checkin_at, recipient_user_id, delivered_at),
    )
    return bool(cursor.rowcount)
