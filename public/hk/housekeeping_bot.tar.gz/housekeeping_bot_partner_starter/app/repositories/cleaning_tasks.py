from typing import Optional, Sequence

import aiosqlite


TASK_FIELDS = """
    t.*,
    EXISTS (
        SELECT 1
        FROM cleaning_tasks key_issue
        WHERE key_issue.apartment_id = t.apartment_id
          AND key_issue.keys_missing_reported_at IS NOT NULL
          AND key_issue.keys_missing_resolved_at IS NULL
    ) AS apartment_keys_missing,
    a.code AS apartment_code,
    a.building AS building,
    a.address AS address,
    a.floor AS floor,
    a.apartment_type AS apartment_type,
    b.id AS local_booking_id,
    b.checkout_time AS booking_checkout_time,
    COALESCE(next_booking.checkin_time, b.next_checkin_time) AS booking_next_checkin_time,
    CASE
        WHEN next_booking.id IS NOT NULL THEN 0
        WHEN b.id IS NULL THEN 1
        ELSE COALESCE(b.no_next_booking, 0)
    END AS booking_no_next_booking,
    b.source AS booking_source,
    next_booking.id AS next_booking_id,
    maid.full_name AS maid_name,
    maid.telegram_id AS maid_telegram_id,
    maid.language AS maid_language,
    supervisor.full_name AS supervisor_name,
    supervisor.telegram_id AS supervisor_telegram_id,
    verifier.full_name AS verified_by_name,
    creator.full_name AS created_by_name
"""


TASK_JOIN = """
    FROM cleaning_tasks t
    JOIN apartments a ON a.id = t.apartment_id
    LEFT JOIN bookings b ON b.cleaning_task_id = t.id
    LEFT JOIN bookings next_booking ON next_booking.id = (
        SELECT candidate.id
        FROM bookings candidate
        WHERE candidate.apartment_id = t.apartment_id
          AND candidate.checkin_date = t.planned_date
          AND candidate.status != 'canceled'
          AND (b.id IS NULL OR candidate.id != b.id)
        ORDER BY COALESCE(candidate.checkin_time, '99:99'), candidate.id
        LIMIT 1
    )
    LEFT JOIN users maid ON maid.id = t.assigned_maid_id
    LEFT JOIN users supervisor ON supervisor.id = t.supervisor_id
    LEFT JOIN users verifier ON verifier.id = t.verified_by_user_id
    LEFT JOIN users creator ON creator.id = t.created_by
"""


async def get_by_id(db: aiosqlite.Connection, task_id: int):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.id = ?
        """,
        (task_id,),
    )
    return await cursor.fetchone()


async def has_open_missing_keys_for_apartment(db: aiosqlite.Connection, apartment_id: int) -> bool:
    cursor = await db.execute(
        """
        SELECT 1
        FROM cleaning_tasks
        WHERE apartment_id = ?
          AND keys_missing_reported_at IS NOT NULL
          AND keys_missing_resolved_at IS NULL
        LIMIT 1
        """,
        (apartment_id,),
    )
    return await cursor.fetchone() is not None


async def get_by_external_booking_key(
    db: aiosqlite.Connection,
    external_booking_id: str,
    apartment_id: int,
    planned_date: str,
):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.external_booking_id = ?
          AND t.apartment_id = ?
          AND t.planned_date = ?
        LIMIT 1
        """,
        (external_booking_id, apartment_id, planned_date),
    )
    return await cursor.fetchone()


async def list_recoverable_realty_orphans(
    db: aiosqlite.Connection,
    apartment_id: int,
    planned_date: str,
):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.external_booking_id IS NULL
          AND t.apartment_id = ?
          AND t.planned_date = ?
          AND t.status = 'plan'
          AND t.created_by IS NULL
          AND t.comment LIKE 'Источник: RealtyCalendar.%'
        ORDER BY t.id
        """,
        (apartment_id, planned_date),
    )
    return await cursor.fetchall()


async def list_for_date(
    db: aiosqlite.Connection,
    planned_date: str,
    statuses: Optional[Sequence[str]] = None,
):
    params = [planned_date]
    status_filter = ""
    if statuses:
        placeholders = ",".join(["?"] * len(statuses))
        status_filter = f"AND t.status IN ({placeholders})"
        params.extend(statuses)

    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.planned_date = ?
          AND a.is_active = 1
          AND t.status != 'canceled'
        {status_filter}
        ORDER BY COALESCE(t.deadline_at, '9999-12-31T23:59:59'), a.code
        """,
        params,
    )
    return await cursor.fetchall()


async def list_for_date_range(
    db: aiosqlite.Connection,
    start_date: str,
    end_date: str,
):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.planned_date BETWEEN ? AND ?
          AND a.is_active = 1
          AND t.status != 'canceled'
        ORDER BY t.planned_date, COALESCE(t.deadline_at, '9999-12-31T23:59:59'), a.code
        """,
        (start_date, end_date),
    )
    return await cursor.fetchall()


async def list_for_apartment_date(db: aiosqlite.Connection, apartment_id: int, planned_date: str):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.apartment_id = ?
          AND t.planned_date = ?
          AND a.is_active = 1
          AND t.status != 'canceled'
        ORDER BY COALESCE(t.deadline_at, '9999-12-31T23:59:59'), t.id
        """,
        (apartment_id, planned_date),
    )
    return await cursor.fetchall()


async def list_dates_for_apartment(db: aiosqlite.Connection, apartment_id: int, limit: int = 10):
    cursor = await db.execute(
        """
        SELECT DISTINCT planned_date
        FROM cleaning_tasks
        WHERE apartment_id = ?
          AND status != 'canceled'
        ORDER BY planned_date DESC
        LIMIT ?
        """,
        (apartment_id, limit),
    )
    rows = await cursor.fetchall()
    return [row["planned_date"] for row in rows]


async def list_active_for_date(db: aiosqlite.Connection, planned_date: str):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.planned_date = ?
          AND a.is_active = 1
          AND t.status = 'in_progress'
        ORDER BY COALESCE(maid.full_name, ''), COALESCE(t.started_at, ''), a.code
        """,
        (planned_date,),
    )
    return await cursor.fetchall()


async def list_for_maid(db: aiosqlite.Connection, maid_id: int, planned_date: str):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.assigned_maid_id = ?
          AND t.planned_date = ?
          AND a.is_active = 1
          AND t.status NOT IN ('verified', 'canceled')
        ORDER BY COALESCE(t.deadline_at, '9999-12-31T23:59:59'), a.code
        """,
        (maid_id, planned_date),
    )
    return await cursor.fetchall()


async def list_unfinished_for_maid_through_date(
    db: aiosqlite.Connection,
    maid_id: int,
    planned_date: str,
):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.assigned_maid_id = ?
          AND t.planned_date <= ?
          AND a.is_active = 1
          AND t.status NOT IN ('completed', 'waiting_check', 'verified', 'canceled')
        ORDER BY t.planned_date, COALESCE(t.deadline_at, '9999-12-31T23:59:59'), a.code
        """,
        (maid_id, planned_date),
    )
    return await cursor.fetchall()


async def list_shift_end_blockers(
    db: aiosqlite.Connection,
    maid_id: int,
    work_date: str,
):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.assigned_maid_id = ?
          AND a.is_active = 1
          AND (
                (
                    t.planned_date = ?
                    AND t.status NOT IN ('completed', 'waiting_check', 'verified', 'canceled')
                )
                OR t.status IN ('in_progress', 'rework')
          )
        ORDER BY t.planned_date, COALESCE(t.deadline_at, '9999-12-31T23:59:59'), a.code
        """,
        (maid_id, work_date),
    )
    return await cursor.fetchall()


async def list_active_for_maid(db: aiosqlite.Connection, maid_id: int):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.assigned_maid_id = ?
          AND a.is_active = 1
          AND t.status = 'in_progress'
        ORDER BY t.updated_at DESC
        """,
        (maid_id,),
    )
    return await cursor.fetchall()


async def list_reworks_for_maid(db: aiosqlite.Connection, maid_id: int):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.assigned_maid_id = ?
          AND a.is_active = 1
          AND t.status = 'rework'
        ORDER BY t.updated_at DESC
        """,
        (maid_id,),
    )
    return await cursor.fetchall()


async def list_unassigned_for_date(db: aiosqlite.Connection, planned_date: str):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.planned_date = ?
          AND a.is_active = 1
          AND t.assigned_maid_id IS NULL
          AND t.status NOT IN ('verified', 'canceled')
        ORDER BY COALESCE(t.deadline_at, '9999-12-31T23:59:59'), a.code
        """,
        (planned_date,),
    )
    return await cursor.fetchall()


async def list_waiting_check(db: aiosqlite.Connection, planned_date: Optional[str] = None):
    params = []
    date_filter = ""
    if planned_date:
        date_filter = "AND t.planned_date = ?"
        params.append(planned_date)
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.status = 'waiting_check'
          AND a.is_active = 1
        {date_filter}
        ORDER BY t.finished_at DESC
        """,
        params,
    )
    return await cursor.fetchall()


async def list_problems(db: aiosqlite.Connection):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE (
            (t.problem_type IS NOT NULL AND t.problem_resolved_at IS NULL)
            OR (t.keys_missing_reported_at IS NOT NULL AND t.keys_missing_resolved_at IS NULL)
        )
          AND a.is_active = 1
        ORDER BY t.updated_at DESC
        """
    )
    return await cursor.fetchall()


async def list_extra_cleanings(db: aiosqlite.Connection, from_date: str):
    cursor = await db.execute(
        f"""
        SELECT {TASK_FIELDS}
        {TASK_JOIN}
        WHERE t.cleaning_type = 'daily'
          AND t.planned_date >= ?
          AND a.is_active = 1
          AND t.status != 'canceled'
        ORDER BY t.planned_date, COALESCE(t.deadline_at, ''), a.code
        """,
        (from_date,),
    )
    return await cursor.fetchall()


async def list_media(db: aiosqlite.Connection, task_id: int):
    cursor = await db.execute(
        """
        SELECT cp.*, uploader.full_name AS uploaded_by_name
        FROM cleaning_photos cp
        LEFT JOIN users uploader ON uploader.id = cp.uploaded_by
        WHERE cp.task_id = ?
        ORDER BY cp.created_at, cp.id
        """,
        (task_id,),
    )
    return await cursor.fetchall()


async def list_media_by_type(db: aiosqlite.Connection, task_id: int, photo_type: str):
    cursor = await db.execute(
        """
        SELECT cp.*, uploader.full_name AS uploaded_by_name
        FROM cleaning_photos cp
        LEFT JOIN users uploader ON uploader.id = cp.uploaded_by
        WHERE cp.task_id = ?
          AND cp.photo_type = ?
        ORDER BY cp.created_at, cp.id
        """,
        (task_id, photo_type),
    )
    return await cursor.fetchall()


async def list_media_by_types(db: aiosqlite.Connection, task_id: int, photo_types: Sequence[str]):
    if not photo_types:
        return []

    placeholders = ",".join(["?"] * len(photo_types))
    cursor = await db.execute(
        f"""
        SELECT cp.*, uploader.full_name AS uploaded_by_name
        FROM cleaning_photos cp
        LEFT JOIN users uploader ON uploader.id = cp.uploaded_by
        WHERE cp.task_id = ?
          AND cp.photo_type IN ({placeholders})
        ORDER BY cp.created_at, cp.id
        """,
        (task_id, *photo_types),
    )
    return await cursor.fetchall()


async def report_for_date(db: aiosqlite.Connection, planned_date: str):
    cursor = await db.execute(
        """
        SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN status IN ('waiting_check', 'verified') THEN 1 ELSE 0 END) AS finished,
            SUM(CASE WHEN status = 'verified' THEN 1 ELSE 0 END) AS verified,
            SUM(CASE WHEN rework_required = 1 THEN 1 ELSE 0 END) AS reworks,
            SUM(CASE
                WHEN (problem_type IS NOT NULL AND problem_resolved_at IS NULL)
                  OR (keys_missing_reported_at IS NOT NULL AND keys_missing_resolved_at IS NULL)
                THEN 1
                ELSE 0
            END) AS problems,
            AVG(CASE WHEN actual_duration_min IS NOT NULL THEN actual_duration_min END) AS avg_duration
        FROM cleaning_tasks
        WHERE planned_date = ?
        """,
        (planned_date,),
    )
    return await cursor.fetchone()
