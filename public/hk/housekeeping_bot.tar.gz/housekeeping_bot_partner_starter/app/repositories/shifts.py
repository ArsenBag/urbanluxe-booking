from typing import Optional, Sequence

import aiosqlite


async def get_active_shift(db: aiosqlite.Connection, maid_id: int):
    cursor = await db.execute(
        """
        SELECT *
        FROM maid_shifts
        WHERE maid_id = ?
          AND ended_at IS NULL
        ORDER BY started_at DESC
        LIMIT 1
        """,
        (maid_id,),
    )
    return await cursor.fetchone()


async def get_latest_shift_for_date(db: aiosqlite.Connection, maid_id: int, work_date: str):
    cursor = await db.execute(
        """
        SELECT *
        FROM maid_shifts
        WHERE maid_id = ?
          AND work_date = ?
        ORDER BY started_at DESC
        LIMIT 1
        """,
        (maid_id, work_date),
    )
    return await cursor.fetchone()


async def create_shift(
    db: aiosqlite.Connection,
    maid_id: int,
    work_date: str,
    started_at: str,
):
    cursor = await db.execute(
        """
        INSERT OR IGNORE INTO maid_shifts (maid_id, work_date, started_at)
        VALUES (?, ?, ?)
        """,
        (maid_id, work_date, started_at),
    )
    await db.commit()
    if cursor.rowcount:
        return await get_by_id(db, cursor.lastrowid), True
    return await get_active_shift(db, maid_id), False


async def get_by_id(db: aiosqlite.Connection, shift_id: int):
    cursor = await db.execute(
        "SELECT * FROM maid_shifts WHERE id = ?",
        (shift_id,),
    )
    return await cursor.fetchone()


async def close_shift(
    db: aiosqlite.Connection,
    shift_id: int,
    ended_at: str,
    auto_closed: bool = False,
    end_cart_photo_file_id: Optional[str] = None,
    end_cart_photo_uploaded_at: Optional[str] = None,
    supervisor_nightlights_photo_file_id: Optional[str] = None,
    supervisor_nightlights_photo_uploaded_at: Optional[str] = None,
    supervisor_purchase_list_photo_file_id: Optional[str] = None,
    supervisor_purchase_list_photo_uploaded_at: Optional[str] = None,
):
    await db.execute(
        """
        UPDATE maid_shifts
        SET ended_at = ?,
            auto_closed = ?,
            end_cart_photo_file_id = COALESCE(?, end_cart_photo_file_id),
            end_cart_photo_uploaded_at = COALESCE(?, end_cart_photo_uploaded_at),
            supervisor_nightlights_photo_file_id = COALESCE(
                ?, supervisor_nightlights_photo_file_id
            ),
            supervisor_nightlights_photo_uploaded_at = COALESCE(
                ?, supervisor_nightlights_photo_uploaded_at
            ),
            supervisor_purchase_list_photo_file_id = COALESCE(
                ?, supervisor_purchase_list_photo_file_id
            ),
            supervisor_purchase_list_photo_uploaded_at = COALESCE(
                ?, supervisor_purchase_list_photo_uploaded_at
            )
        WHERE id = ?
          AND ended_at IS NULL
        """,
        (
            ended_at,
            1 if auto_closed else 0,
            end_cart_photo_file_id,
            end_cart_photo_uploaded_at,
            supervisor_nightlights_photo_file_id,
            supervisor_nightlights_photo_uploaded_at,
            supervisor_purchase_list_photo_file_id,
            supervisor_purchase_list_photo_uploaded_at,
            shift_id,
        ),
    )
    await db.commit()
    return await get_by_id(db, shift_id)


async def close_open_shifts(
    db: aiosqlite.Connection,
    ended_at: str,
    before_work_date: Optional[str] = None,
    include_work_date: Optional[str] = None,
    user_roles: Optional[Sequence[str]] = None,
):
    conditions = ["ended_at IS NULL"]
    params = []
    if before_work_date:
        conditions.append("work_date < ?")
        params.append(before_work_date)
    if include_work_date:
        conditions.append("work_date = ?")
        params.append(include_work_date)
    if user_roles:
        placeholders = ", ".join("?" for _ in user_roles)
        conditions.append(
            f"maid_id IN (SELECT id FROM users WHERE role IN ({placeholders}))"
        )
        params.extend(user_roles)

    where_clause = " AND ".join(conditions)
    await db.execute(
        f"""
        UPDATE maid_shifts
        SET ended_at = ?,
            auto_closed = 1
        WHERE {where_clause}
        """,
        [ended_at] + params,
    )
    await db.commit()


async def list_active_maids_workload(db: aiosqlite.Connection, work_date: str):
    cursor = await db.execute(
        """
        SELECT
            u.id,
            u.full_name,
            u.telegram_id,
            MIN(s.started_at) AS started_at,
            COUNT(DISTINCT CASE WHEN a.is_active = 1 THEN t.id END) AS assigned_count,
            COUNT(DISTINCT CASE
                WHEN a.is_active = 1 AND t.status = 'verified' THEN t.id
            END) AS verified_count,
            COUNT(DISTINCT CASE
                WHEN a.is_active = 1 AND t.status = 'in_progress' THEN t.id
            END) AS in_progress_count,
            COUNT(DISTINCT CASE
                WHEN a.is_active = 1 AND t.status = 'waiting_check' THEN t.id
            END) AS waiting_check_count
        FROM users u
        JOIN maid_shifts s
          ON s.maid_id = u.id
         AND s.work_date = ?
         AND s.ended_at IS NULL
        LEFT JOIN cleaning_tasks t
          ON t.assigned_maid_id = u.id
         AND t.planned_date = ?
         AND t.status != 'canceled'
        LEFT JOIN apartments a ON a.id = t.apartment_id
        WHERE u.role = 'maid'
          AND u.is_active = 1
        GROUP BY u.id, u.full_name, u.telegram_id
        ORDER BY u.full_name
        """,
        (work_date, work_date),
    )
    return await cursor.fetchall()


async def get_cleaning_workload_summary(db: aiosqlite.Connection, work_date: str):
    cursor = await db.execute(
        """
        SELECT
            COUNT(*) AS total_count,
            SUM(CASE WHEN t.assigned_maid_id IS NOT NULL THEN 1 ELSE 0 END) AS assigned_count,
            SUM(CASE WHEN t.assigned_maid_id IS NULL THEN 1 ELSE 0 END) AS unassigned_count,
            SUM(CASE
                WHEN t.assigned_maid_id IS NOT NULL
                 AND NOT EXISTS (
                    SELECT 1
                    FROM maid_shifts s
                    WHERE s.maid_id = t.assigned_maid_id
                      AND s.work_date = ?
                      AND s.ended_at IS NULL
                 )
                THEN 1 ELSE 0
            END) AS assigned_off_shift_count
        FROM cleaning_tasks t
        JOIN apartments a ON a.id = t.apartment_id
        WHERE t.planned_date = ?
          AND t.status != 'canceled'
          AND a.is_active = 1
        """,
        (work_date, work_date),
    )
    return await cursor.fetchone()


async def list_report_for_range(
    db: aiosqlite.Connection,
    start_date: str,
    end_date: str,
):
    cursor = await db.execute(
        """
        WITH cleaning_totals AS (
            SELECT
                assigned_maid_id AS maid_id,
                planned_date AS work_date,
                COUNT(CASE WHEN status != 'canceled' THEN 1 END) AS assigned_count,
                COUNT(CASE
                    WHEN status IN ('completed', 'waiting_check', 'verified') THEN 1
                END) AS completed_count,
                COUNT(CASE WHEN status = 'verified' THEN 1 END) AS verified_count
            FROM cleaning_tasks
            WHERE assigned_maid_id IS NOT NULL
              AND planned_date BETWEEN ? AND ?
            GROUP BY assigned_maid_id, planned_date
        )
        SELECT
            s.work_date,
            u.id AS maid_id,
            u.full_name AS maid_name,
            MIN(s.started_at) AS started_at,
            CASE
                WHEN SUM(CASE WHEN s.ended_at IS NULL THEN 1 ELSE 0 END) > 0
                THEN NULL
                ELSE MAX(s.ended_at)
            END AS ended_at,
            MAX(s.auto_closed) AS auto_closed,
            COUNT(s.id) AS shift_entries,
            COALESCE(MAX(ct.assigned_count), 0) AS assigned_count,
            COALESCE(MAX(ct.completed_count), 0) AS completed_count,
            COALESCE(MAX(ct.verified_count), 0) AS verified_count
        FROM maid_shifts s
        JOIN users u ON u.id = s.maid_id
        LEFT JOIN cleaning_totals ct
          ON ct.maid_id = s.maid_id
         AND ct.work_date = s.work_date
        WHERE s.work_date BETWEEN ? AND ?
          AND u.role = 'maid'
        GROUP BY s.work_date, u.id, u.full_name
        ORDER BY s.work_date, u.full_name
        """,
        (start_date, end_date, start_date, end_date),
    )
    return await cursor.fetchall()
