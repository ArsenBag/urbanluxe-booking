from typing import Optional

import aiosqlite

from app.apartment_catalog import classified_apartment_building, classified_apartment_type


async def list_active(db: aiosqlite.Connection):
    cursor = await db.execute(
        """
        SELECT *
        FROM apartments
        WHERE is_active = 1
        ORDER BY building, code
        """
    )
    return await cursor.fetchall()


async def list_by_building_keyword(db: aiosqlite.Connection, keyword: str):
    cursor = await db.execute(
        """
        SELECT *
        FROM apartments
        WHERE is_active = 1
          AND LOWER(building) LIKE '%' || LOWER(?) || '%'
        ORDER BY code
        """,
        (keyword,),
    )
    return await cursor.fetchall()


async def get_by_id(db: aiosqlite.Connection, apartment_id: int):
    cursor = await db.execute(
        "SELECT * FROM apartments WHERE id = ? AND is_active = 1",
        (apartment_id,),
    )
    return await cursor.fetchone()


async def get_by_realty_id(db: aiosqlite.Connection, realty_id: int):
    cursor = await db.execute(
        "SELECT * FROM apartments WHERE realty_id = ? AND is_active = 1",
        (realty_id,),
    )
    return await cursor.fetchone()


async def get_any_by_realty_id(db: aiosqlite.Connection, realty_id: int):
    cursor = await db.execute(
        "SELECT * FROM apartments WHERE realty_id = ? LIMIT 1",
        (realty_id,),
    )
    return await cursor.fetchone()


async def get_by_code(db: aiosqlite.Connection, code: str):
    cursor = await db.execute(
        """
        SELECT *
        FROM apartments
        WHERE is_active = 1
          AND LOWER(REPLACE(REPLACE(REPLACE(code, ' ', ''), '-', ''), '_', '')) =
              LOWER(REPLACE(REPLACE(REPLACE(?, ' ', ''), '-', ''), '_', ''))
        """,
        (code,),
    )
    return await cursor.fetchone()


async def get_any_by_code(db: aiosqlite.Connection, code: str):
    cursor = await db.execute(
        """
        SELECT *
        FROM apartments
        WHERE LOWER(REPLACE(REPLACE(REPLACE(code, ' ', ''), '-', ''), '_', '')) =
              LOWER(REPLACE(REPLACE(REPLACE(?, ' ', ''), '-', ''), '_', ''))
        LIMIT 1
        """,
        (code,),
    )
    return await cursor.fetchone()


async def set_realty_id(db: aiosqlite.Connection, apartment_id: int, realty_id: int):
    await db.execute(
        "UPDATE apartments SET realty_id = ? WHERE id = ?",
        (realty_id, apartment_id),
    )
    await db.commit()
    return await get_by_id(db, apartment_id)


async def create_from_realty(
    db: aiosqlite.Connection,
    realty_id: int,
    code: str,
    address: str,
    building: str = "",
):
    apartment_type = classified_apartment_type(code) or "unknown"
    building = building or classified_apartment_building(code) or ""
    await db.execute(
        """
        INSERT INTO apartments (
            realty_id, code, building, address, floor, apartment_type,
            area_m2, bathrooms_count, beds_count, sofa_beds_count, is_active
        )
        VALUES (?, ?, ?, ?, NULL, ?, NULL, 1, 1, 0, 1)
        ON CONFLICT(code) DO UPDATE SET
            realty_id = COALESCE(excluded.realty_id, apartments.realty_id),
            building = COALESCE(NULLIF(apartments.building, ''), excluded.building),
            address = COALESCE(NULLIF(apartments.address, ''), excluded.address),
            apartment_type = CASE
                WHEN apartments.apartment_type = 'unknown'
                THEN excluded.apartment_type
                ELSE apartments.apartment_type
            END,
            is_active = 1
        """,
        (realty_id, code, building, address, apartment_type),
    )
    await db.commit()
    return await get_by_realty_id(db, realty_id)


async def refresh_from_realty(
    db: aiosqlite.Connection,
    apartment_id: int,
    realty_id: Optional[int],
    code: str,
    address: str,
    building: str = "",
):
    apartment_type = classified_apartment_type(code)
    building = building or classified_apartment_building(code) or ""
    if realty_id:
        await db.execute(
            "UPDATE apartments SET realty_id = NULL WHERE realty_id = ? AND id != ?",
            (realty_id, apartment_id),
        )
    await db.execute(
        """
        UPDATE apartments
        SET realty_id = COALESCE(?, realty_id),
            code = CASE
                WHEN (code LIKE 'RC-%' OR TRIM(code) = '') AND TRIM(?) != ''
                THEN ?
                ELSE code
            END,
            building = COALESCE(NULLIF(building, ''), NULLIF(?, ''), ''),
            address = COALESCE(NULLIF(address, ''), NULLIF(?, ''), ''),
            apartment_type = CASE
                WHEN apartment_type = 'unknown' AND ? IS NOT NULL THEN ?
                ELSE apartment_type
            END,
            is_active = 1
        WHERE id = ?
        """,
        (
            realty_id,
            code,
            code,
            building,
            address,
            apartment_type,
            apartment_type,
            apartment_id,
        ),
    )
    await db.commit()
    return await get_by_id(db, apartment_id)


async def upsert_apartment(
    db: aiosqlite.Connection,
    code: str,
    building: str,
    address: str,
    floor: int,
    apartment_type: str,
    area_m2: int,
    bathrooms_count: int,
    beds_count: int,
    sofa_beds_count: int,
):
    building = building or classified_apartment_building(code) or ""
    apartment_type = (
        classified_apartment_type(code)
        if apartment_type == "unknown"
        else apartment_type
    ) or apartment_type
    await db.execute(
        """
        INSERT INTO apartments (
            code, building, address, floor, apartment_type, area_m2,
            bathrooms_count, beds_count, sofa_beds_count, is_active
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
        ON CONFLICT(code) DO UPDATE SET
            building = excluded.building,
            address = excluded.address,
            floor = excluded.floor,
            apartment_type = excluded.apartment_type,
            area_m2 = excluded.area_m2,
            bathrooms_count = excluded.bathrooms_count,
            beds_count = excluded.beds_count,
            sofa_beds_count = excluded.sofa_beds_count,
            is_active = 1
        """,
        (
            code,
            building,
            address,
            floor,
            apartment_type,
            area_m2,
            bathrooms_count,
            beds_count,
            sofa_beds_count,
        ),
    )
    await db.commit()
