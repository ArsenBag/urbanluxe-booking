from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import aiosqlite
from aiohttp import ClientError, ClientSession, ClientTimeout, web
from aiogram import Bot

from app.config import Settings
from app.dashboard import setup_dashboard_routes
from app.i18n import tr
from app.services import booking_service, cleaning_service, realtycalendar_service
from app.services.formatting import compact_apartment_code
from app.services.notifications import (
    notify_booking_managers,
    notify_supervisors_on_shift,
    notify_telegram_id,
)


logger = logging.getLogger(__name__)


def _result_apartment(result: dict, fallback: str = "-") -> str:
    value = result.get("apartment_code")
    return compact_apartment_code(value) if value else fallback


async def _forward_to_analytics(settings: Settings, payload: dict) -> None:
    if not settings.analytics_webhook_url:
        return

    headers = {}
    if settings.analytics_webhook_token:
        headers["X-Webhook-Token"] = settings.analytics_webhook_token

    timeout = ClientTimeout(total=8)
    try:
        async with ClientSession(timeout=timeout) as session:
            async with session.post(
                settings.analytics_webhook_url,
                json=payload,
                headers=headers,
            ) as response:
                body = await response.text()
                if response.status >= 400:
                    logger.warning(
                        "Analytics webhook returned %s: %s",
                        response.status,
                        body[:500],
                    )
    except (ClientError, TimeoutError):
        logger.exception("Analytics webhook forward failed")


async def _forward_to_analytics_safe(settings: Settings, payload: dict) -> None:
    try:
        await _forward_to_analytics(settings, payload)
    except Exception:
        logger.exception("Unexpected analytics webhook forward failure")


def _today_cleaning_notification(result: dict) -> str:
    checkout_time = result.get("checkout_time") or "12:00"
    lines = [
        "RealtyCalendar: уборка на сегодня",
        f"Объект: {_result_apartment(result)}",
        f"Бронь: {result.get('booking_id')}",
        f"Выезд сегодня: {checkout_time}",
    ]
    if result.get("no_next_booking"):
        lines.append("Следующего заезда нет.")
    else:
        checkin_time = result.get("next_checkin_time") or result.get("checkin_time") or "15:00"
        lines.append(f"Заезд сегодня: {checkin_time}")
    lines.append("Нужно назначить горничную.")
    return "\n".join(lines)


def _today_checkin_notification(result: dict) -> str:
    checkin_time = result.get("checkin_time") or "15:00"
    lines = [
        "RealtyCalendar: заезд сегодня",
        f"Объект: {_result_apartment(result)}",
        f"Бронь: {result.get('booking_id')}",
        f"Заезд сегодня: {checkin_time}",
    ]
    previous_checkout_time = result.get("previous_checkout_time")
    if previous_checkout_time:
        lines.append(f"Выезд сегодня: {previous_checkout_time}")
        if result.get("previous_cleaning_task_id"):
            lines.append("Уборка уже есть в расписании.")
        else:
            lines.append("Проверьте, нужна ли уборка перед заездом.")
    else:
        lines.append("Апартаменты свободны, уборка не требуется.")
    return "\n".join(lines)


def _reconciliation_notification(result: dict, today: str) -> str | None:
    lines = []
    for summary in result.get("reconciliation") or []:
        if summary.get("date") != today:
            continue
        recovered_items = (summary.get("created") or []) + (summary.get("repaired") or [])
        for item in recovered_items:
            if item.get("no_next_booking"):
                checkin_label = "заезда нет"
            else:
                checkin_label = item.get("next_checkin_time") or "15:00"
            lines.append(
                f"{compact_apartment_code(item.get('apartment_code'))}: "
                f"выезд {item.get('checkout_time') or '12:00'}, "
                f"заезд {checkin_label}, бронь {item.get('external_booking_id') or item.get('booking_id')}"
            )

    if not lines:
        return None

    return "\n".join(
        [
            "Контрольная сверка: восстановлены уборки на сегодня.",
            "Проверьте и назначьте горничную:",
            *lines,
        ]
    )


def _stay_extension_notification(result: dict, old_checkout: str, new_checkout: str) -> str:
    lines = [
        "RealtyCalendar: гость продлил проживание",
        f"Объект: {_result_apartment(result)}",
        f"Бронь: {result.get('booking_id')}",
        f"Было: выезд {old_checkout}",
        f"Стало: выезд {new_checkout}",
    ]
    if result.get("followup_cleaning_created"):
        lines.extend(
            [
                "Предыдущая уборка уже была начата или завершена и сохранена в истории.",
                "На новую дату выезда создана отдельная уборка — назначьте горничную.",
            ]
        )
    elif result.get("schedule_update_blocked"):
        lines.extend(
            [
                "⚠️ Уборка не перенесена автоматически, потому что ее уже начали или завершили.",
                f"Текущий статус: {result.get('cleaning_status') or '-'}.",
                "Нужна ручная проверка.",
            ]
        )
    elif result.get("task_rescheduled"):
        lines.append("Уборка перенесена на новую дату и убрана из прежнего графика.")
    elif result.get("cleaning_created"):
        lines.append("Уборка создана на новую дату выезда.")
    else:
        lines.append("График уборок обновлен.")
    return "\n".join(lines)


def _late_checkout_notification(result: dict) -> str:
    old_time = result.get("old_checkout_time") or "12:00"
    new_time = result.get("new_checkout_time") or "12:00"
    schedule_line = (
        "Предыдущая уборка уже была начата или завершена; создана отдельная новая уборка."
        if result.get("followup_cleaning_created")
        else "Уборка остается в графике, время выезда обновлено."
    )
    return "\n".join(
        [
            "RealtyCalendar: поздний выезд",
            f"Объект: {_result_apartment(result)}",
            f"Бронь: {result.get('booking_id')}",
            f"Было: выезд {old_time}",
            f"Стало: выезд {new_time}",
            schedule_line,
        ]
    )


def _booking_manager_realty_notification(result: dict) -> str | None:
    apartment = _result_apartment(result, "не определен")
    booking_id = result.get("booking_id") or "-"

    if result.get("canceled"):
        if not result.get("booking_found") or not result.get("cancellation_changed"):
            return None
        lines = [
            "RealtyCalendar: бронь отменена",
            f"Объект: {apartment}",
            f"Бронь: {booking_id}",
        ]
        if result.get("checkout_date"):
            lines.append(
                f"Выезд был: {result.get('checkout_date')} "
                f"{result.get('checkout_time') or '12:00'}"
            )
        if result.get("housekeeping_excluded"):
            lines.append("Объект не входит в график housekeeping.")
        else:
            lines.append(
                "Плановая уборка отменена."
                if result.get("cleaning_canceled")
                else "Проверьте состояние уборки вручную."
            )
        return "\n".join(lines)

    if result.get("booking_created"):
        lines = [
            "RealtyCalendar: новая бронь",
            f"Объект: {apartment}",
            f"Бронь: {booking_id}",
            f"Заезд: {result.get('checkin_date') or '-'} {result.get('checkin_time') or '15:00'}",
            f"Выезд: {result.get('checkout_date') or '-'} {result.get('checkout_time') or '12:00'}",
        ]
        return "\n".join(lines)

    changes = []
    if result.get("checkin_changed"):
        changes.extend(
            [
                "Изменен заезд:",
                f"Было: {result.get('old_checkin_date') or '-'} "
                f"{result.get('old_checkin_time') or '15:00'}",
                f"Стало: {result.get('new_checkin_date') or '-'} "
                f"{result.get('new_checkin_time') or '15:00'}",
            ]
        )
    if result.get("checkout_changed"):
        if changes:
            changes.append("")
        changes.extend(
            [
                "Изменен выезд:",
                f"Было: {result.get('old_checkout_date') or '-'} "
                f"{result.get('old_checkout_time') or '12:00'}",
                f"Стало: {result.get('checkout_date') or '-'} "
                f"{result.get('checkout_time') or '12:00'}",
            ]
        )

    if not changes:
        return None

    return "\n".join(
        [
            "RealtyCalendar: бронь обновлена",
            f"Объект: {apartment}",
            f"Бронь: {booking_id}",
            "",
            *changes,
        ]
    )


async def _send_realty_notifications(bot: Bot, db, settings: Settings, result: dict) -> None:
    booking_manager_message = _booking_manager_realty_notification(result)
    if booking_manager_message:
        await notify_booking_managers(bot, db, booking_manager_message)

    if result.get("housekeeping_excluded"):
        logger.info(
            "Housekeeping notifications skipped for excluded apartment %s",
            result.get("apartment_code"),
        )
        return

    supervisor_notice_sent = False
    today = cleaning_service.today_iso(settings.timezone)
    if result.get("ok") and result.get("cleaning_created"):
        if result.get("planned_date") == today:
            await notify_supervisors_on_shift(
                bot,
                db,
                settings,
                _today_cleaning_notification(result),
            )
            supervisor_notice_sent = True
        else:
            logger.info(
                "RealtyCalendar cleaning created for %s; supervisor notification skipped",
                result.get("planned_date"),
            )

    if result.get("ok") and not supervisor_notice_sent and result.get("checkin_date") == today:
        await notify_supervisors_on_shift(
            bot,
            db,
            settings,
            _today_checkin_notification(result),
        )

    if result.get("ok"):
        reconciliation_message = _reconciliation_notification(result, today)
        if reconciliation_message:
            await notify_supervisors_on_shift(
                bot,
                db,
                settings,
                reconciliation_message,
            )

    if result.get("ok") and result.get("checkout_change_kind") == "stay_extended":
        old_checkout = (
            f"{result.get('old_checkout_date')} {result.get('old_checkout_time') or '12:00'}"
        )
        new_checkout = (
            f"{result.get('new_checkout_date')} {result.get('new_checkout_time') or '12:00'}"
        )
        await notify_supervisors_on_shift(
            bot,
            db,
            settings,
            _stay_extension_notification(result, old_checkout, new_checkout),
        )

        if result.get("maid_telegram_id"):
            if result.get("followup_cleaning_created"):
                maid_message_key = "stay_extended_followup_maid"
            elif result.get("schedule_update_blocked"):
                maid_message_key = "stay_extended_blocked_maid"
            else:
                maid_message_key = "stay_extended_maid"
            await notify_telegram_id(
                bot,
                result.get("maid_telegram_id"),
                tr(
                    result.get("maid_language"),
                    maid_message_key,
                    apartment=_result_apartment(result),
                    old_checkout=old_checkout,
                    new_checkout=new_checkout,
                ),
            )

    if result.get("ok") and result.get("checkout_change_kind") == "late_checkout":
        await notify_supervisors_on_shift(
            bot,
            db,
            settings,
            _late_checkout_notification(result),
        )
        if result.get("maid_telegram_id"):
            maid_message_key = (
                "late_checkout_followup_maid"
                if result.get("followup_cleaning_created")
                else "late_checkout_maid"
            )
            await notify_telegram_id(
                bot,
                result.get("maid_telegram_id"),
                tr(
                    result.get("maid_language"),
                    maid_message_key,
                    apartment=_result_apartment(result),
                    old_time=result.get("old_checkout_time") or "12:00",
                    new_time=result.get("new_checkout_time") or "12:00",
                ),
            )


async def _send_realty_notifications_safe(bot: Bot, db, settings: Settings, result: dict) -> None:
    try:
        await _send_realty_notifications(bot, db, settings, result)
    except Exception:
        logger.exception("RealtyCalendar notification failed")


async def realtycalendar_webhook(request: web.Request) -> web.Response:
    settings: Settings = request.app["settings"]
    db = request.app["db"]
    bot: Bot = request.app["bot"]

    if settings.realtycalendar_webhook_token:
        header_token = request.headers.get("X-Webhook-Token")
        query_token = request.query.get("token")
        if settings.realtycalendar_webhook_token not in (header_token, query_token):
            return web.json_response({"ok": False, "error": "unauthorized"}, status=401)

    try:
        payload = await request.json()
    except Exception:
        logger.warning("RealtyCalendar webhook ignored: invalid json")
        return web.json_response(
            {"ok": True, "ignored": True, "reason": "invalid json"},
            status=200,
        )

    asyncio.create_task(_forward_to_analytics_safe(settings, payload))

    async with request.app["realty_sync_lock"]:
        try:
            result = await realtycalendar_service.process_webhook(db, settings, payload)
        except aiosqlite.IntegrityError:
            # Old partial deliveries may have committed the booking first and then
            # failed while moving its cleaning task.  Repair all recent/future
            # Realty links and retry the same event once before asking RealtyCalendar
            # to deliver it again.
            logger.exception("RealtyCalendar webhook hit a database conflict; repairing links")
            await db.rollback()
            today = datetime.now(ZoneInfo(settings.timezone)).date()
            try:
                await booking_service.repair_inconsistent_realty_cleaning_links(
                    db,
                    settings.timezone,
                    (today - timedelta(days=7)).isoformat(),
                    (today + timedelta(days=365)).isoformat(),
                    user_id=None,
                )
                result = await realtycalendar_service.process_webhook(db, settings, payload)
            except Exception as exc:
                logger.exception("RealtyCalendar webhook retry failed")
                return web.json_response({"ok": False, "error": str(exc)}, status=500)
        except Exception as exc:
            logger.exception("RealtyCalendar webhook failed")
            return web.json_response({"ok": False, "error": str(exc)}, status=500)

    if not result.get("ok"):
        logger.warning("RealtyCalendar webhook was not processed: %s", result)
        return web.json_response(
            {
                **result,
                "ok": True,
                "ignored": True,
                "reason": result.get("reason") or "unrecognized webhook payload",
            },
            status=200,
        )

    if result.get("ignored"):
        logger.warning("RealtyCalendar webhook safely ignored: %s", result)
        return web.json_response(result, status=200)

    logger.info(
        "RealtyCalendar webhook processed: event=%s booking_id=%s apartment=%s "
        "checkout=%s %s cleaning_task_id=%s",
        result.get("event"),
        result.get("booking_id"),
        result.get("apartment_code"),
        result.get("checkout_date"),
        result.get("checkout_time"),
        result.get("cleaning_task_id"),
    )
    asyncio.create_task(_send_realty_notifications_safe(bot, db, settings, result))

    return web.json_response(result, status=200)


async def healthcheck(request: web.Request) -> web.Response:
    return web.json_response({"ok": True, "service": "housekeeping_bot"})


async def start_webhook_server(settings: Settings, db, bot: Bot, realty_sync_lock=None):
    app = web.Application()
    app["settings"] = settings
    app["db"] = db
    app["bot"] = bot
    app["realty_sync_lock"] = realty_sync_lock or asyncio.Lock()
    app.router.add_get("/health", healthcheck)
    app.router.add_post("/webhooks/realtycalendar", realtycalendar_webhook)
    if settings.dashboard_enabled:
        setup_dashboard_routes(app)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(
        runner,
        settings.realtycalendar_webhook_host,
        settings.realtycalendar_webhook_port,
    )
    await site.start()
    logger.info(
        "Webhook server started at http://%s:%s",
        settings.realtycalendar_webhook_host,
        settings.realtycalendar_webhook_port,
    )
    return runner
