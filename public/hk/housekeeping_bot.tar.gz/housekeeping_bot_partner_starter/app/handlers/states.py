from aiogram.fsm.state import State, StatesGroup


class MaidShiftEnd(StatesGroup):
    waiting_cart_photo = State()


class SupervisorShiftEnd(StatesGroup):
    waiting_nightlights_photo = State()
    waiting_purchase_list_photo = State()
