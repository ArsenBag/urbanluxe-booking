from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Any, Awaitable, Callable, Dict

import aiosqlite
from aiogram import BaseMiddleware, Bot, F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, FSInputFile, Message

from app.config import Settings
from app.handlers.access import require_callback_user, require_user, resolve_user
from app.handlers.states import SupervisorShiftEnd
from app.keyboards import common as common_kb
from app.keyboards.supervisor import (
    apartments_keyboard,
    cancel_task_confirm_keyboard,
    cleaning_types_keyboard,
    deadlines_keyboard,
    keys_missing_resolve_confirm_keyboard,
    maids_keyboard,
    materials_apartments_keyboard,
    materials_dates_keyboard,
    materials_tasks_keyboard,
    problem_actions_keyboard,
    problem_resolve_confirm_keyboard,
    problems_keyboard,
    quality_keyboard,
    verification_method_keyboard,
    rework_reasons_keyboard,
    shift_end_confirm_keyboard,
    shift_end_photo_keyboard,
    shift_start_confirm_keyboard,
    supervisor_problem_types_keyboard,
    supervisor_task_actions,
    tasks_keyboard,
)
from app.models import (
    CLEANING_TYPE_LABELS,
    PROBLEM_TYPES,
    REWORK_REASONS,
    Role,
    TaskStatus,
    normalize_cleaning_type,
)
from app.repositories import apartments as apartment_repo
from app.repositories import cleaning_tasks as task_repo
from app.repositories import users as user_repo
from app.services import booking_service, cleaning_service, shift_service
from app.services.formatting import apartment_label, compact_apartment_code, format_date, format_datetime, format_time, problem_card, task_card
from app.services.notifications import (
    notify_booking_managers,
    notify_maid,
    notify_ready_for_checkin,
    notify_task_assigned,
    notify_telegram_id,
)
from app.services.sheets_export import export_csv, export_shifts_xlsx, export_xlsx, sync_google_sheets


router = Router()
SUPERVISOR_ROLES = [Role.SUPERVISOR.value, Role.ADMIN.value]


async def _is_materials_browse_event(event: Any, data: Dict[str, Any]) -> bool:
    if isinstance(event, Message) and event.text == common_kb.SUP_MATERIALS:
        return True

    if isinstance(event, CallbackQuery) and (event.data or "").startswith("materials_"):
        return True

    if isinstance(event, Message):
        state = data.get("state")
        current_state = await state.get_state() if state else None
        return bool(current_state and current_state.startswith("MaterialsSearch:"))

    return False


class SupervisorShiftMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[Any, Dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: Dict[str, Any],
    ) -> Any:
        db = data.get("db")
        settings = data.get("settings")
        telegram_user = getattr(event, "from_user", None)
        if not db or not settings or not telegram_user:
            return await handler(event, data)

        user = await resolve_user(db, settings, telegram_user)
        if not user or user["role"] != Role.SUPERVISOR.value:
            return await handler(event, data)

        if await _is_materials_browse_event(event, data):
            return await handler(event, data)

        if isinstance(event, Message):
            if event.text in (common_kb.SUP_SHIFT_START, common_kb.SUP_SHIFT_END):
                return await handler(event, data)
            shift = await shift_service.active_shift(db, settings.timezone, user["id"])
            if not shift:
                await event.answer(
                    "Сначала отметьте приход на смену.",
                    reply_markup=common_kb.supervisor_shift_start_menu(),
                )
                return None

        if isinstance(event, CallbackQuery):
            callback_data = event.data or ""
            if callback_data.startswith("sup_shift_"):
                return await handler(event, data)
            shift = await shift_service.active_shift(db, settings.timezone, user["id"])
            if not shift:
                await event.answer("Сначала отметьте приход на смену.", show_alert=True)
                return None

        return await handler(event, data)


class SupervisorNavigationMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[Any, Dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: Dict[str, Any],
    ) -> Any:
        if isinstance(event, Message) and event.text in common_kb.SUPERVISOR_NAVIGATION_BUTTONS:
            state = data.get("state")
            if state:
                await state.clear()
        return await handler(event, data)


router.message.outer_middleware(SupervisorNavigationMiddleware())
router.message.middleware(SupervisorShiftMiddleware())
router.callback_query.middleware(SupervisorShiftMiddleware())


REASSIGNABLE_STATUSES = (
    TaskStatus.PLAN.value,
    TaskStatus.GUEST_CHECKED_OUT.value,
    TaskStatus.ASSIGNED.value,
    TaskStatus.REWORK.value,
)


class CreateCleaning(StatesGroup):
    choosing_apartment = State()
    choosing_type = State()
    choosing_deadline = State()
    choosing_maid = State()
    waiting_comment = State()


class ReworkRequest(StatesGroup):
    collecting = State()


class ExportRange(StatesGroup):
    waiting_dates = State()


class ShiftExportRange(StatesGroup):
    waiting_dates = State()


class MaterialsSearch(StatesGroup):
    choosing_apartment = State()
    waiting_date = State()


class RestoreSchedule(StatesGroup):
    waiting_codes = State()


def _role_allowed_roles():
    return SUPERVISOR_ROLES


def _status_legend() -> str:
    return "Значки: 🧹 идет уборка, 🔍 на проверке, ✅ готово, 🛑 переделка, ⚠️ проблема."


def _parse_report_date(value: str):
    value = value.strip()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y"):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    return None


def _parse_report_range(value: str):
    value = value.strip()
    single_date = _parse_report_date(value)
    if single_date:
        return single_date, single_date

    patterns = (
        r"^\s*(\d{4}-\d{2}-\d{2})\s+(\d{4}-\d{2}-\d{2})\s*$",
        r"^\s*(\d{2}\.\d{2}\.\d{4})\s*[-–—]\s*(\d{2}\.\d{2}\.\d{4})\s*$",
        r"^\s*(\d{2}\.\d{2}\.\d{2})\s*[-–—]\s*(\d{2}\.\d{2}\.\d{2})\s*$",
    )
    for pattern in patterns:
        match = re.match(pattern, value)
        if not match:
            continue
        start = _parse_report_date(match.group(1))
        end = _parse_report_date(match.group(2))
        if start and end:
            return (start, end) if start <= end else (end, start)

    parts = value.split()
    if len(parts) == 2:
        start = _parse_report_date(parts[0])
        end = _parse_report_date(parts[1])
        if start and end:
            return (start, end) if start <= end else (end, start)
    return None


def _unique_dates(*date_groups):
    seen = set()
    result = []
    for date_group in date_groups:
        for value in date_group:
            if value and value not in seen:
                seen.add(value)
                result.append(value)
    return result


def _parse_schedule_codes(value: str) -> list[str]:
    return [
        item.strip()
        for item in re.split(r"[\n,;]+", value or "")
        if item.strip()
    ]


def _restore_schedule_summary(result: dict) -> str:
    lines = [
        f"Восстановление графика за {result['date']}:",
        f"Объектов в списке Realty: {result['requested_count']}",
        f"Уже были в графике: {len(result['existing'])}",
        f"Создано недостающих уборок: {len(result['created'])}",
    ]

    if result["created"]:
        lines.extend(["", "Созданы:"])
        lines.extend(
            f"• {compact_apartment_code(task['apartment_code'])}"
            for task in result["created"]
        )

    if result["extra_tasks"]:
        lines.extend(
            [
                "",
                "Есть задания, которых нет в присланном списке. Они не удалены автоматически:",
            ]
        )
        lines.extend(
            f"• {compact_apartment_code(task['apartment_code'])}"
            for task in result["extra_tasks"]
        )
        lines.append("Проверьте их в «Уборки сегодня» и отмените ошибочные до начала работы.")

    if result["duplicate_tasks"]:
        lines.extend(["", "Найдены дубли заданий, требуется проверка:"])
        lines.extend(
            f"• {compact_apartment_code(task['apartment_code'])} · задание №{task['id']}"
            for task in result["duplicate_tasks"]
        )

    if result["unknown_codes"]:
        lines.extend(["", "Не найдены в справочнике объектов:"])
        lines.extend(
            f"• {compact_apartment_code(code)}" for code in result["unknown_codes"]
        )

    if result["excluded_codes"]:
        lines.extend(["", "Пропущены объекты вне зоны обслуживания:"])
        lines.extend(
            f"• {compact_apartment_code(code)}" for code in result["excluded_codes"]
        )

    lines.extend(
        [
            "",
            "Теперь нажмите «Назначить» и распределите новые уборки между горничными.",
        ]
    )
    return "\n".join(lines)


MEDIA_TYPE_LABELS = {
    "before_video": "Видео ДО уборки",
    "before_keys": "Фото ключей ДО уборки",
    "before_tv": "Фото включённого телевизора ДО уборки",
    "before_extra": "Дополнительное фото ДО / повреждения",
    "before_photo": "Фото ДО / ключи / повреждения (старый формат)",
    "after_video": "Видео ПОСЛЕ уборки",
    "after_drain": "Фото чистого слива ПОСЛЕ уборки",
    "after_vacuum": "Фото чистого пылесоса ПОСЛЕ уборки",
    "after_photo": "Фото ПОСЛЕ уборки",
    "after": "Фото ПОСЛЕ уборки",
    "problem": "Фото проблемы",
    "problem_video": "Видео проблемы",
    "forgotten_items": "Фото забытых вещей",
    "forgotten_items_video": "Видео забытых вещей",
    "rework": "Материал по переделке",
    "rework_done": "Фото исправленной переделки",
}


def _rework_reason_labels(selected_reasons):
    labels = dict(REWORK_REASONS)
    return [labels.get(reason, reason) for reason in selected_reasons]


def _rework_text(reason_labels, comments):
    parts = []
    if reason_labels:
        parts.append("Причины: " + ", ".join(reason_labels))
    if comments:
        parts.append("Комментарий: " + "\n".join(comments))
    return "\n".join(parts) or "Переделка"


def _row_value(row, key: str):
    try:
        return row[key]
    except (KeyError, IndexError):
        return None


def _media_caption(item) -> str:
    caption = MEDIA_TYPE_LABELS.get(item["photo_type"], item["photo_type"])
    details = []
    uploaded_by = _row_value(item, "uploaded_by_name")
    if uploaded_by:
        details.append(f"загрузил: {uploaded_by}")
    created_at = format_datetime(_row_value(item, "created_at"))
    if created_at:
        details.append(created_at)
    if details:
        caption += "\n" + " · ".join(details)
    return caption


async def send_task_media(
    message: Message,
    db: aiosqlite.Connection,
    task_id: int,
    empty_text: str | None = None,
):
    media_items = await task_repo.list_media(db, task_id)
    if not media_items:
        if empty_text:
            await message.answer(empty_text)
        return

    await message.answer("Материалы по задаче:")
    for item in media_items:
        caption = _media_caption(item)
        try:
            if "video" in item["photo_type"]:
                await message.answer_video(item["telegram_file_id"], caption=caption)
            else:
                await message.answer_photo(item["telegram_file_id"], caption=caption)
        except Exception:
            await message.answer(f"{caption}: не удалось открыть файл.")


async def send_problem_media(message: Message, db: aiosqlite.Connection, task_id: int):
    media_items = await task_repo.list_media_by_types(db, task_id, ("problem", "problem_video"))
    if not media_items:
        await message.answer("Материалы к проблеме не прикреплены.")
        return

    await message.answer("Материалы по проблеме:")
    for item in media_items:
        caption = _media_caption(item)
        try:
            if "video" in item["photo_type"]:
                await message.answer_video(item["telegram_file_id"], caption=caption)
            else:
                await message.answer_photo(item["telegram_file_id"], caption=caption)
        except Exception:
            await message.answer(f"{caption}: не удалось открыть файл.")


@router.message(F.text == common_kb.SUP_SHIFT_START)
async def supervisor_shift_start_request(
    message: Message,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=[Role.SUPERVISOR.value])
    if not user:
        return

    current = shift_service.now(settings.timezone)
    if current.time() >= shift_service.AUTO_CLOSE_TIME:
        await message.answer("После 21:00 смену открыть нельзя. Обратитесь к администратору.")
        return

    active = await shift_service.active_shift(db, settings.timezone, user["id"])
    if active:
        await message.answer(
            f"Смена уже открыта. Время прихода: {shift_service.format_shift_time(active['started_at'])}",
            reply_markup=common_kb.supervisor_menu(include_shift=True),
        )
        return

    await message.answer(
        "Подтвердите приход на смену.",
        reply_markup=shift_start_confirm_keyboard(),
    )


@router.callback_query(F.data == "sup_shift_start_confirm")
async def supervisor_shift_start_confirm(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.SUPERVISOR.value])
    if not user:
        return

    current = shift_service.now(settings.timezone)
    if current.time() >= shift_service.AUTO_CLOSE_TIME:
        await callback.message.answer("После 21:00 смену открыть нельзя. Обратитесь к администратору.")
        await callback.answer()
        return

    shift, _ = await shift_service.start_shift(db, settings.timezone, user["id"])
    await callback.message.answer(
        f"Смена открыта. Время прихода: {shift_service.format_shift_time(shift['started_at'])}",
        reply_markup=common_kb.supervisor_menu(include_shift=True),
    )
    await callback.answer()


@router.message(F.text == common_kb.SUP_SHIFT_END)
async def supervisor_shift_end_request(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=[Role.SUPERVISOR.value])
    if not user:
        return

    active = await shift_service.active_shift(db, settings.timezone, user["id"])
    if not active:
        await message.answer(
            "Открытой смены сейчас нет.",
            reply_markup=common_kb.supervisor_shift_start_menu(),
        )
        return

    await state.clear()
    await message.answer(
        "Подтвердите завершение смены.",
        reply_markup=shift_end_confirm_keyboard(),
    )


@router.callback_query(F.data == "sup_shift_end_confirm")
async def supervisor_shift_end_confirm(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.SUPERVISOR.value])
    if not user:
        return

    shift = await shift_service.active_shift(db, settings.timezone, user["id"])
    if not shift:
        await state.clear()
        await callback.message.answer(
            "Открытой смены сейчас нет.",
            reply_markup=common_kb.supervisor_shift_start_menu(),
        )
        await callback.answer()
        return

    await state.set_state(SupervisorShiftEnd.waiting_nightlights_photo)
    await callback.message.answer(
        "Отправьте одно фото ночников. "
        "Без этого фото смена не закроется.",
        reply_markup=shift_end_photo_keyboard(),
    )
    await callback.answer()


async def _finish_supervisor_shift(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
    user,
    nightlights_photo_file_id: str,
    purchase_list_photo_file_id: str | None = None,
) -> None:
    try:
        shift = await shift_service.end_supervisor_shift(
            db,
            settings.timezone,
            user["id"],
            nightlights_photo_file_id,
            purchase_list_photo_file_id,
        )
    except ValueError:
        await state.clear()
        await message.answer(
            "Не хватает обязательного фото. "
            "Повторите закрытие смены.",
            reply_markup=common_kb.supervisor_menu(include_shift=True),
        )
        return

    await state.clear()
    if not shift:
        await message.answer(
            "Открытой смены сейчас нет.",
            reply_markup=common_kb.supervisor_shift_start_menu(),
        )
        return
    await message.answer(
        f"Смена завершена. "
        f"Время ухода: {shift_service.format_shift_time(shift['ended_at'])}",
        reply_markup=common_kb.supervisor_shift_start_menu(),
    )


@router.message(SupervisorShiftEnd.waiting_nightlights_photo, F.photo)
async def supervisor_shift_end_nightlights_photo(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=[Role.SUPERVISOR.value])
    if not user:
        await state.clear()
        return
    shift = await shift_service.active_shift(db, settings.timezone, user["id"])
    if not shift:
        await state.clear()
        await message.answer(
            "Открытой смены сейчас нет.",
            reply_markup=common_kb.supervisor_shift_start_menu(),
        )
        return

    nightlights_photo_file_id = message.photo[-1].file_id
    if shift_service.supervisor_purchase_list_required(shift):
        await state.update_data(
            nightlights_photo_file_id=nightlights_photo_file_id,
        )
        await state.set_state(SupervisorShiftEnd.waiting_purchase_list_photo)
        await message.answer(
            "Сегодня вторник. Теперь отправьте "
            "одно фото листа закупок.",
            reply_markup=shift_end_photo_keyboard(),
        )
        return

    await _finish_supervisor_shift(
        message,
        state,
        db,
        settings,
        user,
        nightlights_photo_file_id,
    )


@router.message(SupervisorShiftEnd.waiting_nightlights_photo)
async def supervisor_shift_end_nightlights_photo_required(message: Message):
    await message.answer(
        "Нужно отправить именно фото ночников.",
        reply_markup=shift_end_photo_keyboard(),
    )


@router.message(SupervisorShiftEnd.waiting_purchase_list_photo, F.photo)
async def supervisor_shift_end_purchase_list_photo(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=[Role.SUPERVISOR.value])
    if not user:
        await state.clear()
        return
    data = await state.get_data()
    nightlights_photo_file_id = data.get("nightlights_photo_file_id")
    if not nightlights_photo_file_id:
        await state.set_state(SupervisorShiftEnd.waiting_nightlights_photo)
        await message.answer(
            "Сначала отправьте фото ночников.",
            reply_markup=shift_end_photo_keyboard(),
        )
        return
    await _finish_supervisor_shift(
        message,
        state,
        db,
        settings,
        user,
        nightlights_photo_file_id,
        message.photo[-1].file_id,
    )


@router.message(SupervisorShiftEnd.waiting_purchase_list_photo)
async def supervisor_shift_end_purchase_list_photo_required(message: Message):
    await message.answer(
        "Сегодня вторник: нужно отправить именно "
        "фото листа закупок.",
        reply_markup=shift_end_photo_keyboard(),
    )


@router.callback_query(F.data == "sup_shift_action_cancel")
async def supervisor_shift_action_cancel(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.SUPERVISOR.value])
    if not user:
        return

    await state.clear()
    shift = await shift_service.active_shift(db, settings.timezone, user["id"])
    if shift:
        await callback.message.answer("Действие отменено.", reply_markup=common_kb.supervisor_menu())
    else:
        await callback.message.answer("Действие отменено.", reply_markup=common_kb.supervisor_shift_start_menu())
    await callback.answer()


async def show_today_tasks(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    tasks = await task_repo.list_for_date(db, today)
    if not tasks:
        await message.answer("На сегодня уборок пока нет.")
        return

    await message.answer(
        f"Уборки сегодня: {len(tasks)}\n" + _status_legend(),
        reply_markup=tasks_keyboard(tasks, "sup_task"),
    )


@router.message(F.text == common_kb.SUP_TODAY)
async def today_tasks(message: Message, db: aiosqlite.Connection, settings: Settings):
    await show_today_tasks(message, db, settings)


@router.message(Command("restore_today"))
@router.message(F.text == common_kb.SUP_RESTORE)
async def restore_schedule_start(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    await state.clear()
    await state.set_state(RestoreSchedule.waiting_codes)
    await message.answer(
        "Пришлите полный список объектов с выездом сегодня из RealtyCalendar.\n\n"
        "Каждый объект — с новой строки или через запятую. Например:\n"
        "A-101\nA-102\nB-205\n\n"
        "Бот сохранит существующие уборки, создаст только недостающие и покажет лишние."
    )


@router.message(RestoreSchedule.waiting_codes, F.text)
async def restore_schedule_finish(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    raw_codes = _parse_schedule_codes(message.text or "")
    if not raw_codes:
        await message.answer("Список пуст. Пришлите коды объектов с новой строки или через запятую.")
        return
    if len(raw_codes) > 100:
        await message.answer("В списке больше 100 строк. Проверьте формат и отправьте только коды объектов.")
        return

    today = cleaning_service.today_iso(settings.timezone)
    result = await booking_service.restore_cleaning_schedule_from_codes(
        db,
        settings.timezone,
        today,
        raw_codes,
        user["id"],
    )
    await state.clear()
    reply_markup = (
        common_kb.admin_menu()
        if user["role"] == Role.ADMIN.value
        else common_kb.supervisor_menu()
    )
    await message.answer(_restore_schedule_summary(result), reply_markup=reply_markup)


@router.message(Command("tasks"))
async def tasks_command(message: Message, db: aiosqlite.Connection, settings: Settings):
    await show_today_tasks(message, db, settings)


@router.message(F.text == common_kb.SUP_ACTIVE)
async def active_tasks(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    tasks = await task_repo.list_active_for_date(db, today)
    if not tasks:
        await message.answer("Сейчас активных уборок нет.")
        return

    lines = ["Активные уборки сейчас:"]
    for task in tasks:
        maid_name = task["maid_name"] or "горничная не назначена"
        started = format_time(task["started_at"]) or "-"
        lines.append(f"{apartment_label(task)} — {maid_name}, с {started}")

    await message.answer(
        "\n".join(lines),
        reply_markup=tasks_keyboard(tasks, "sup_task"),
    )


@router.message(F.text == common_kb.SUP_SHIFT_LOAD)
async def shift_load(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    report = await shift_service.shift_workload(db, settings.timezone)
    await message.answer(shift_service.format_shift_workload(report))


async def _send_tomorrow_forecast(
    message: Message,
    db: aiosqlite.Connection,
    settings: Settings,
) -> None:
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    today = datetime.fromisoformat(cleaning_service.today_iso(settings.timezone)).date()
    tomorrow = (today + timedelta(days=1)).isoformat()
    await booking_service.reconcile_cleaning_tasks_for_date(
        db,
        settings.timezone,
        tomorrow,
        user_id=user["id"],
    )
    report = await shift_service.cleaning_forecast_for_date(db, tomorrow)
    await message.answer(shift_service.format_cleaning_forecast(report))


@router.message(Command("forecast_tomorrow"))
async def tomorrow_forecast_command(
    message: Message,
    db: aiosqlite.Connection,
    settings: Settings,
):
    await _send_tomorrow_forecast(message, db, settings)


@router.message(F.text == common_kb.SUP_TOMORROW_FORECAST)
async def tomorrow_forecast_button(
    message: Message,
    db: aiosqlite.Connection,
    settings: Settings,
):
    await _send_tomorrow_forecast(message, db, settings)


async def _send_materials_apartments(
    message: Message,
    db: aiosqlite.Connection,
    page: int = 0,
):
    apartments = await apartment_repo.list_active(db)
    if not apartments:
        await message.answer("Справочник объектов пуст.")
        return

    await message.answer(
        "Выберите объект, по которому нужно найти материалы:",
        reply_markup=materials_apartments_keyboard(apartments, page),
    )


async def _edit_materials_apartments(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    page: int = 0,
):
    apartments = await apartment_repo.list_active(db)
    if not apartments:
        await callback.message.edit_text("Справочник объектов пуст.")
        return

    await callback.message.edit_text(
        "Выберите объект, по которому нужно найти материалы:",
        reply_markup=materials_apartments_keyboard(apartments, page),
    )


async def _send_materials_for_task(
    message: Message,
    db: aiosqlite.Connection,
    task,
):
    await message.answer("Карточка уборки:\n\n" + task_card(task))
    await send_task_media(
        message,
        db,
        task["id"],
        empty_text="Материалы по этой уборке пока не найдены.",
    )


async def _send_materials_for_apartment_date(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    date_value: str,
):
    data = await state.get_data()
    apartment_id = data.get("apartment_id")
    if not apartment_id:
        await state.clear()
        await message.answer("Сначала выберите объект.")
        return

    apartment = await apartment_repo.get_by_id(db, int(apartment_id))
    tasks = await task_repo.list_for_apartment_date(db, int(apartment_id), date_value)
    if not tasks:
        label_text = apartment_label(apartment, "code") if apartment else "выбранному объекту"
        await state.clear()
        await message.answer(f"За {format_date(date_value)} по {label_text} уборок и материалов не найдено.")
        return

    if len(tasks) > 1:
        await message.answer(
            f"За {format_date(date_value)} найдено уборок: {len(tasks)}. Выберите нужную:",
            reply_markup=materials_tasks_keyboard(tasks),
        )
        return

    await _send_materials_for_task(message, db, tasks[0])
    await state.clear()


@router.message(F.text == common_kb.SUP_MATERIALS)
async def materials_search_start(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    await state.clear()
    await state.set_state(MaterialsSearch.choosing_apartment)
    await _send_materials_apartments(message, db)


@router.callback_query(F.data.startswith("materials_apartments_page:"))
async def materials_apartments_page(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    page = int(callback.data.split(":", 1)[1])
    await _edit_materials_apartments(callback, db, page)
    await callback.answer()


@router.callback_query(F.data == "materials_restart")
async def materials_restart(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    await state.clear()
    await state.set_state(MaterialsSearch.choosing_apartment)
    await _edit_materials_apartments(callback, db)
    await callback.answer()


@router.callback_query(MaterialsSearch.choosing_apartment, F.data.startswith("materials_apartment:"))
async def materials_choose_apartment(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    apartment_id = int(callback.data.split(":", 1)[1])
    apartment = await apartment_repo.get_by_id(db, apartment_id)
    if not apartment:
        await callback.answer("Объект не найден.", show_alert=True)
        return

    today = datetime.fromisoformat(cleaning_service.today_iso(settings.timezone)).date()
    yesterday = today - timedelta(days=1)
    stored_dates = await task_repo.list_dates_for_apartment(db, apartment_id, limit=12)
    date_values = _unique_dates(
        [today.isoformat(), yesterday.isoformat()],
        stored_dates,
    )

    await state.update_data(apartment_id=apartment_id)
    await state.set_state(MaterialsSearch.waiting_date)
    await callback.message.edit_text(
        f"Объект: {apartment_label(apartment, 'code')}\nВыберите дату уборки или введите вручную:",
        reply_markup=materials_dates_keyboard(date_values),
    )
    await callback.answer()


@router.callback_query(MaterialsSearch.waiting_date, F.data == "materials_date_manual")
async def materials_date_manual(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    await state.set_state(MaterialsSearch.waiting_date)
    await callback.message.answer("Введите дату уборки: 2026-07-09 или 09.07.2026")
    await callback.answer()


@router.callback_query(MaterialsSearch.waiting_date, F.data.startswith("materials_date:"))
async def materials_choose_date(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    date_value = callback.data.split(":", 1)[1]
    await _send_materials_for_apartment_date(callback.message, state, db, date_value)
    await callback.answer()


@router.message(MaterialsSearch.waiting_date, F.text)
async def materials_date_text(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    date_value = _parse_report_date(message.text or "")
    if not date_value:
        await message.answer("Не понял дату. Введите, например: 2026-07-09 или 09.07.2026")
        return

    await _send_materials_for_apartment_date(message, state, db, date_value.isoformat())


@router.callback_query(F.data.startswith("materials_task:"))
async def materials_choose_task(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        await callback.answer("Уборка не найдена.", show_alert=True)
        return

    await _send_materials_for_task(callback.message, db, task)
    await state.clear()
    await callback.answer()


@router.callback_query(F.data == "materials_cancel")
async def materials_cancel(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    await state.clear()
    await callback.message.edit_text("Поиск материалов отменен.")
    await callback.answer()


@router.callback_query(F.data.startswith("sup_task:"))
async def supervisor_task_card(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        await callback.answer("Задача не найдена.", show_alert=True)
        return
    await callback.message.edit_text(task_card(task))
    await send_task_media(callback.message, db, task_id)
    await callback.message.answer("Действия по уборке:", reply_markup=supervisor_task_actions(task))
    await callback.answer()


@router.callback_query(F.data.startswith("sup_cancel:"))
async def cancel_task_start(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        await callback.answer("Уборка не найдена.", show_alert=True)
        return
    if task["started_at"] or task["status"] not in (
        TaskStatus.PLAN.value,
        TaskStatus.GUEST_CHECKED_OUT.value,
        TaskStatus.ASSIGNED.value,
    ):
        await callback.answer("Эту уборку уже нельзя отменить.", show_alert=True)
        return

    await callback.message.edit_text(
        "Отменить ошибочно созданную уборку?\n\n" + task_card(task),
        reply_markup=cancel_task_confirm_keyboard(task_id),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("sup_cancel_yes:"))
async def cancel_task_finish(
    callback: CallbackQuery,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    task_before = await task_repo.get_by_id(db, task_id)
    if not task_before:
        await callback.answer("Уборка не найдена.", show_alert=True)
        return
    try:
        await cleaning_service.cancel_scheduled_task(
            db,
            settings.timezone,
            task_id,
            user["id"],
            "Ошибочно присутствует в сегодняшнем графике.",
        )
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return

    if task_before["maid_telegram_id"]:
        await notify_maid(
            bot,
            task_before,
            f"Уборка {apartment_label(task_before)} отменена супервайзером. Не приступайте к работе.",
        )
    await callback.message.edit_text(
        f"Уборка {apartment_label(task_before)} отменена и убрана из сегодняшнего графика."
    )
    await callback.answer("Уборка отменена.")


@router.message(Command("new_cleaning"))
@router.message(F.text == common_kb.SUP_NEW)
async def create_cleaning_start(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    apartments = await apartment_repo.list_active(db)
    if not apartments:
        await message.answer("Справочник объектов пуст.")
        return

    await state.set_state(CreateCleaning.choosing_apartment)
    await state.update_data(created_by=user["id"], supervisor_id=user["id"])
    await message.answer("Выберите объект:", reply_markup=apartments_keyboard(apartments))


@router.callback_query(
    CreateCleaning.choosing_apartment,
    F.data.startswith("new_apartments_page:"),
)
async def create_cleaning_apartment_page(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
):
    page = int(callback.data.rsplit(":", 1)[1])
    apartments = await apartment_repo.list_active(db)
    await callback.message.edit_text(
        "Выберите объект:",
        reply_markup=apartments_keyboard(apartments, page=page),
    )
    await callback.answer()


@router.callback_query(CreateCleaning.choosing_apartment, F.data.startswith("new_apartment:"))
async def create_choose_apartment(callback: CallbackQuery, state: FSMContext):
    apartment_id = int(callback.data.split(":", 1)[1])
    await state.update_data(apartment_id=apartment_id)
    await state.set_state(CreateCleaning.choosing_type)
    await callback.message.edit_text("Выберите тип уборки:", reply_markup=cleaning_types_keyboard())
    await callback.answer()


@router.callback_query(CreateCleaning.choosing_type, F.data.startswith("new_type:"))
async def create_choose_type(callback: CallbackQuery, state: FSMContext):
    try:
        cleaning_type = normalize_cleaning_type(callback.data.split(":", 1)[1])
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return
    await state.update_data(cleaning_type=cleaning_type)
    await state.set_state(CreateCleaning.choosing_deadline)
    await callback.message.edit_text(
        "Выберите дедлайн на сегодня или отправьте время текстом в формате 14:30:",
        reply_markup=deadlines_keyboard(),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("sup_change_type:"))
async def change_cleaning_type_start(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        await callback.answer("Уборка не найдена.", show_alert=True)
        return
    if task["started_at"] or task["status"] in (
        TaskStatus.COMPLETED.value,
        TaskStatus.WAITING_CHECK.value,
        TaskStatus.VERIFIED.value,
        TaskStatus.REWORK.value,
        TaskStatus.CANCELED.value,
    ):
        await callback.answer("Тип можно изменить только до начала уборки.", show_alert=True)
        return

    await callback.message.edit_text(
        "Выберите новый тип уборки:\n\n" + task_card(task),
        reply_markup=cleaning_types_keyboard(f"sup_set_type:{task_id}"),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("sup_set_type:"))
async def change_cleaning_type_finish(
    callback: CallbackQuery,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    _, task_id, raw_type = callback.data.split(":", 2)
    try:
        task = await cleaning_service.change_cleaning_type(
            db,
            settings.timezone,
            int(task_id),
            user["id"],
            raw_type,
        )
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return

    cleaning_type_label = CLEANING_TYPE_LABELS[task["cleaning_type"]]
    if task["maid_telegram_id"]:
        await notify_maid(
            bot,
            task,
            f"Изменен тип уборки {apartment_label(task)}: {cleaning_type_label}.",
        )
    await callback.message.edit_text(
        "Тип уборки изменен:\n" + task_card(task),
        reply_markup=supervisor_task_actions(task),
    )
    await callback.answer("Тип уборки изменен.")


async def _store_deadline_and_ask_maid(
    message_or_callback,
    state: FSMContext,
    db: aiosqlite.Connection,
    deadline_value: str,
):
    await state.update_data(deadline=deadline_value)
    await state.set_state(CreateCleaning.choosing_maid)
    maids = await user_repo.list_maids(db)
    text = "Назначьте горничную или оставьте без назначения:"
    keyboard = maids_keyboard(maids, "new_maid", include_skip=True)
    if isinstance(message_or_callback, CallbackQuery):
        await message_or_callback.message.edit_text(text, reply_markup=keyboard)
        await message_or_callback.answer()
    else:
        await message_or_callback.answer(text, reply_markup=keyboard)


@router.callback_query(CreateCleaning.choosing_deadline, F.data.startswith("new_deadline:"))
async def create_choose_deadline(callback: CallbackQuery, state: FSMContext, db: aiosqlite.Connection):
    deadline_value = callback.data.split(":", 1)[1]
    await _store_deadline_and_ask_maid(callback, state, db, deadline_value)


@router.message(CreateCleaning.choosing_deadline, F.text)
async def create_deadline_text(message: Message, state: FSMContext, db: aiosqlite.Connection):
    value = (message.text or "").strip()
    if not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", value):
        await message.answer("Пожалуйста, отправьте время в формате 14:30.")
        return
    await _store_deadline_and_ask_maid(message, state, db, value)


@router.callback_query(CreateCleaning.choosing_maid, F.data.startswith("new_maid:"))
async def create_choose_maid(callback: CallbackQuery, state: FSMContext):
    maid_id = int(callback.data.split(":", 1)[1])
    await state.update_data(maid_id=None if maid_id == 0 else maid_id)
    await state.set_state(CreateCleaning.waiting_comment)
    await callback.message.edit_text(
        "Комментарий можно отправить обычным сообщением."
    )
    await callback.message.answer(
        "Если комментарий не нужен, нажмите кнопку.",
        reply_markup=_no_comment_keyboard(),
    )
    await callback.answer()


def _no_comment_keyboard():
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Без комментария", callback_data="new_comment_skip")]
        ]
    )


async def _finish_create_cleaning(
    message_or_callback,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
    comment,
):
    data = await state.get_data()
    today = cleaning_service.today_iso(settings.timezone)
    deadline_at = cleaning_service.deadline_iso(settings.timezone, today, data["deadline"])

    task = await cleaning_service.create_task(
        db,
        settings.timezone,
        apartment_id=data["apartment_id"],
        cleaning_type=data["cleaning_type"],
        planned_date=today,
        deadline_at=deadline_at,
        maid_id=data.get("maid_id"),
        supervisor_id=data.get("supervisor_id"),
        comment=comment,
        created_by=data["created_by"],
    )
    await state.clear()
    if task["assigned_maid_id"]:
        await notify_task_assigned(bot, task)

    text = "Уборка создана:\n" + task_card(task)
    if isinstance(message_or_callback, CallbackQuery):
        await message_or_callback.message.answer(text)
        await message_or_callback.answer()
    else:
        await message_or_callback.answer(text)


@router.callback_query(CreateCleaning.waiting_comment, F.data == "new_comment_skip")
async def create_without_comment(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    await _finish_create_cleaning(callback, state, bot, db, settings, None)


@router.message(CreateCleaning.waiting_comment, F.text)
async def create_with_comment(
    message: Message,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    await _finish_create_cleaning(message, state, bot, db, settings, message.text)


@router.message(F.text == common_kb.SUP_ASSIGN)
async def assign_start(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    tasks = await task_repo.list_unassigned_for_date(db, today)
    if not tasks:
        await message.answer("На сегодня нет уборок без назначения.")
        return
    await message.answer("Выберите уборку:", reply_markup=tasks_keyboard(tasks, "assign_task"))


@router.callback_query(F.data.startswith("assign_task:"))
async def assign_choose_task(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    maids = await user_repo.list_maids(db)
    await callback.message.edit_text(
        "Выберите горничную:",
        reply_markup=maids_keyboard(maids, f"assign_maid:{task_id}"),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("assign_maid:"))
async def assign_choose_maid(
    callback: CallbackQuery,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    _, task_id, maid_id = callback.data.split(":")
    task = await cleaning_service.assign_task(
        db,
        settings.timezone,
        int(task_id),
        int(maid_id),
        user["id"],
    )
    await notify_task_assigned(bot, task)
    await callback.message.edit_text(
        "Горничная назначена:\n" + task_card(task),
        reply_markup=supervisor_task_actions(task),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("sup_reassign:"))
async def reassign_start(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        await callback.answer("Задача не найдена.", show_alert=True)
        return
    if task["status"] not in REASSIGNABLE_STATUSES:
        await callback.answer("Эту уборку уже нельзя переназначить.", show_alert=True)
        return

    maids = await user_repo.list_maids(db)
    if not maids:
        await callback.answer("В списке нет активных горничных.", show_alert=True)
        return
    current_maid = task["maid_name"] or "не назначена"
    await callback.message.edit_text(
        f"Текущая горничная: {current_maid}\nВыберите новую горничную:",
        reply_markup=maids_keyboard(maids, f"reassign_maid:{task_id}"),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("reassign_maid:"))
async def reassign_choose_maid(
    callback: CallbackQuery,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    _, task_id, maid_id = callback.data.split(":")
    task_before = await task_repo.get_by_id(db, int(task_id))
    if not task_before:
        await callback.answer("Задача не найдена.", show_alert=True)
        return
    if task_before["status"] not in REASSIGNABLE_STATUSES:
        await callback.answer("Эту уборку уже нельзя переназначить.", show_alert=True)
        return

    new_maid_id = int(maid_id)
    if task_before["assigned_maid_id"] == new_maid_id:
        await callback.answer("Эта горничная уже назначена.", show_alert=True)
        return

    old_maid_telegram_id = task_before["maid_telegram_id"]
    old_maid_name = task_before["maid_name"]
    task = await cleaning_service.reassign_task(
        db,
        settings.timezone,
        int(task_id),
        new_maid_id,
        user["id"],
    )

    if task["status"] == TaskStatus.REWORK.value:
        await notify_maid(bot, task, f"Вам переназначена переделка: {apartment_label(task)}")
    else:
        await notify_task_assigned(bot, task)

    if old_maid_telegram_id:
        await notify_telegram_id(
            bot,
            old_maid_telegram_id,
            f"Назначение изменено: {apartment_label(task_before)} теперь передано другой горничной.",
        )

    previous = f"\nРанее была: {old_maid_name}" if old_maid_name else ""
    await callback.message.edit_text(
        "Горничная изменена:\n" + task_card(task) + previous,
        reply_markup=supervisor_task_actions(task),
    )
    await callback.answer()


@router.message(F.text == common_kb.SUP_WAITING)
async def waiting_check(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    tasks = await task_repo.list_waiting_check(db, today)
    if not tasks:
        await message.answer("Сейчас нет уборок, которые ждут проверки.")
        return
    await message.answer("Ждут проверки:", reply_markup=tasks_keyboard(tasks, "sup_task"))


@router.callback_query(F.data.startswith("sup_accept:"))
async def accept_start(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        await callback.answer("Уборка не найдена.", show_alert=True)
        return
    if task["status"] != TaskStatus.WAITING_CHECK.value:
        await callback.answer("Эта уборка сейчас не ожидает проверки.", show_alert=True)
        return
    if await task_repo.has_open_missing_keys_for_apartment(db, task["apartment_id"]):
        await callback.answer("Нельзя принять: в квартире нет ключей. Сначала положите их и закройте проблему.", show_alert=True)
        return
    await callback.message.edit_text("Поставьте оценку качества:", reply_markup=quality_keyboard(task_id))
    await callback.answer()


@router.callback_query(F.data.startswith("sup_quality:"))
async def accept_with_quality(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    try:
        _, task_id_text, score_text = callback.data.split(":")
        task_id = int(task_id_text)
        score = int(score_text)
    except (ValueError, TypeError):
        await callback.answer("Некорректная оценка.", show_alert=True)
        return
    if not 0 <= score <= 10:
        await callback.answer("Оценка должна быть от 0 до 10.", show_alert=True)
        return
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["status"] != TaskStatus.WAITING_CHECK.value:
        await callback.answer("Эта уборка сейчас не ожидает проверки.", show_alert=True)
        return
    if await task_repo.has_open_missing_keys_for_apartment(db, task["apartment_id"]):
        await callback.answer("Нельзя принять: в квартире нет ключей.", show_alert=True)
        return
    await callback.message.edit_text(
        f"Оценка {score}/10. Как вы проверили квартиру?",
        reply_markup=verification_method_keyboard(task_id, score),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("sup_verify:"))
async def accept_with_verification_method(
    callback: CallbackQuery,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    try:
        _, task_id_text, score_text, method = callback.data.split(":")
        task_id = int(task_id_text)
        score = int(score_text)
    except (ValueError, TypeError):
        await callback.answer("Некорректная кнопка проверки.", show_alert=True)
        return
    try:
        task = await cleaning_service.verify_task(
            db,
            settings.timezone,
            task_id,
            user["id"],
            score,
            method,
        )
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return
    await notify_maid(
        bot,
        task,
        f"{apartment_label(task)} принята. Время уборки: {task['actual_duration_min'] or '-'} мин",
    )
    await notify_ready_for_checkin(bot, db, task)
    await callback.message.edit_text("Уборка принята:\n" + task_card(task))
    await callback.answer()


@router.callback_query(F.data.startswith("sup_rework:"))
async def rework_start(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        await callback.answer("Задача не найдена.", show_alert=True)
        return

    await state.set_state(ReworkRequest.collecting)
    await state.update_data(task_id=task_id, selected_reasons=[], photos=[], comments=[])
    await callback.message.answer(
        "Переделка:\n"
        "1. Отметьте одну или несколько причин.\n"
        "2. Можно отправить комментарий текстом.\n"
        "3. Можно приложить фото проблемного места.\n\n"
        "Когда все готово, нажмите «Отправить на переделку».",
        reply_markup=rework_reasons_keyboard([]),
    )
    await callback.answer()


@router.callback_query(ReworkRequest.collecting, F.data.startswith("sup_rework_toggle:"))
async def rework_toggle_reason(callback: CallbackQuery, state: FSMContext):
    reason = callback.data.split(":", 1)[1]
    data = await state.get_data()
    selected = list(data.get("selected_reasons") or [])
    if reason in selected:
        selected.remove(reason)
    else:
        selected.append(reason)
    await state.update_data(selected_reasons=selected)
    await callback.message.edit_reply_markup(reply_markup=rework_reasons_keyboard(selected))
    await callback.answer()


@router.message(ReworkRequest.collecting, F.photo)
async def rework_collect_photo(message: Message, state: FSMContext):
    data = await state.get_data()
    photos = list(data.get("photos") or [])
    photos.append(message.photo[-1].file_id)
    comments = list(data.get("comments") or [])
    if message.caption:
        comments.append(message.caption)
    await state.update_data(photos=photos, comments=comments)
    await message.answer(f"Фото к переделке добавлено: {len(photos)}.")


@router.message(ReworkRequest.collecting, F.text)
async def rework_collect_comment(message: Message, state: FSMContext):
    data = await state.get_data()
    comments = list(data.get("comments") or [])
    comments.append(message.text)
    await state.update_data(comments=comments)
    await message.answer("Комментарий к переделке сохранен.")


@router.callback_query(ReworkRequest.collecting, F.data == "sup_rework_cancel")
async def rework_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.answer("Переделка отменена.")
    await callback.answer()


@router.callback_query(ReworkRequest.collecting, F.data == "sup_rework_send")
async def rework_apply(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    data = await state.get_data()
    task_id = data.get("task_id")
    selected = list(data.get("selected_reasons") or [])
    photos = list(data.get("photos") or [])
    comments = list(data.get("comments") or [])
    reason_labels = _rework_reason_labels(selected)
    if not task_id:
        await callback.answer("Задача не найдена.", show_alert=True)
        await state.clear()
        return
    if not selected and not comments and not photos:
        await callback.answer("Добавьте причину, комментарий или фото.", show_alert=True)
        return

    rework_text = _rework_text(reason_labels, comments)
    task = await cleaning_service.send_to_rework(
        db,
        settings.timezone,
        int(task_id),
        user["id"],
        ", ".join(reason_labels) or "Другое",
        comment="\n".join(comments) if comments else None,
        photo_file_ids=photos,
    )
    await state.clear()
    await notify_maid(bot, task, f"{apartment_label(task)} отправлена на переделку.\n{rework_text}")
    if task["maid_telegram_id"]:
        for photo_id in photos:
            try:
                await bot.send_photo(int(task["maid_telegram_id"]), photo_id, caption="Фото к переделке")
            except Exception:
                pass
    await callback.message.answer("Уборка отправлена на переделку:\n" + task_card(task))
    await callback.answer()


@router.callback_query(F.data.startswith("sup_problem:"))
async def supervisor_problem_start(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    await callback.message.edit_text(
        "Выберите тип проблемы:",
        reply_markup=supervisor_problem_types_keyboard(task_id),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("sup_problem_type:"))
async def supervisor_problem_apply(
    callback: CallbackQuery,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    _, task_id, problem_type = callback.data.split(":", 2)
    problem_label = dict(PROBLEM_TYPES).get(problem_type, problem_type)
    task = await cleaning_service.mark_problem(
        db,
        settings.timezone,
        int(task_id),
        user["id"],
        problem_type,
        None,
        [],
    )
    await notify_maid(bot, task, f"{apartment_label(task)}: отмечена проблема ({problem_label})")
    await callback.message.edit_text("Проблема отмечена:\n" + task_card(task))
    await callback.answer()


@router.message(F.text == common_kb.SUP_PROBLEMS)
async def problems_list(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    tasks = await task_repo.list_problems(db)
    if not tasks:
        await message.answer("Открытых проблем нет.")
        return
    await message.answer("Проблемы:", reply_markup=problems_keyboard(tasks))


@router.callback_query(F.data.startswith("sup_problem_view:"))
async def problem_view(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        await callback.answer("Проблема не найдена.", show_alert=True)
        return
    if not (
        (task["problem_type"] and not task["problem_resolved_at"])
        or cleaning_service.keys_missing_open(task)
    ):
        await callback.answer("Эта проблема уже закрыта.", show_alert=True)
        await callback.message.answer("Проблема уже закрыта:\n" + problem_card(task))
        return

    await callback.message.answer(problem_card(task), reply_markup=problem_actions_keyboard(task))
    await send_problem_media(callback.message, db, task_id)
    await callback.answer()


@router.callback_query(F.data.startswith("sup_keys_resolved:"))
async def keys_missing_resolved_confirm(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return
    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task or not cleaning_service.keys_missing_open(task):
        await callback.answer("Проблема с ключами уже закрыта или не найдена.", show_alert=True)
        return
    await callback.message.answer(
        f"Вы положили ключи в квартиру {apartment_label(task)}? После подтверждения можно будет принять уборку.",
        reply_markup=keys_missing_resolve_confirm_keyboard(task_id),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("sup_keys_resolved_yes:"))
async def keys_missing_resolved_yes(
    callback: CallbackQuery,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return
    task_id = int(callback.data.split(":", 1)[1])
    try:
        task = await cleaning_service.resolve_keys_missing(
            db, settings.timezone, task_id, user["id"]
        )
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return
    await notify_booking_managers(
        bot, db,
        f"Ключи положены, проблема решена.\nОбъект: {apartment_label(task)}\nУборка ещё требует обычной приёмки супервайзером.",
    )
    await callback.message.edit_text(
        "Проблема с ключами закрыта:\n" + task_card(task),
        reply_markup=supervisor_task_actions(task),
    )
    await callback.answer("Ключи отмечены как положенные.")


@router.callback_query(F.data.startswith("sup_problem_resolved:"))
async def problem_resolved(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task or not task["problem_type"] or task["problem_resolved_at"]:
        await callback.answer("Проблема уже закрыта или не найдена.", show_alert=True)
        return

    await callback.message.answer(
        f"Проблема решена?\n\n{problem_card(task)}",
        reply_markup=problem_resolve_confirm_keyboard(task),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("sup_problem_resolved_yes:"))
async def problem_resolved_confirmed(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    task_id = int(callback.data.split(":", 1)[1])
    try:
        task = await cleaning_service.resolve_problem(db, settings.timezone, task_id, user["id"])
    except ValueError:
        await callback.answer("Проблема не найдена.", show_alert=True)
        return

    await callback.message.edit_text("Проблема закрыта:\n" + problem_card(task))
    await callback.answer("Проблема закрыта.")


@router.message(Command("report"))
@router.message(F.text == common_kb.SUP_REPORT)
async def report(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    row = await task_repo.report_for_date(db, today)
    avg = row["avg_duration"]
    avg_text = "-" if avg is None else f"{round(avg)} мин"
    await message.answer(
        f"Отчет за {today}:\n"
        f"Создано задач: {row['total'] or 0}\n"
        f"Завершено: {row['finished'] or 0}\n"
        f"Принято: {row['verified'] or 0}\n"
        f"Переделки: {row['reworks'] or 0}\n"
        f"Проблемы: {row['problems'] or 0}\n"
        f"Среднее время: {avg_text}"
    )


@router.message(F.text == common_kb.SUP_EXPORT)
async def export_today_csv(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    path = await export_csv(db, today)
    await message.answer_document(FSInputFile(path), caption=f"CSV-экспорт за {today}")


async def _send_excel_report(
    message: Message,
    db: aiosqlite.Connection,
    start_date: str,
    end_date: str,
):
    try:
        path = await export_xlsx(db, start_date, end_date)
    except RuntimeError as exc:
        await message.answer(str(exc))
        return

    caption = f"Excel-отчет за {start_date}" if start_date == end_date else f"Excel-отчет за {start_date} — {end_date}"
    await message.answer_document(FSInputFile(path), caption=caption)


@router.message(F.text == common_kb.SUP_EXPORT_TODAY)
async def export_today_excel(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    await _send_excel_report(message, db, today, today)


@router.message(F.text == common_kb.SUP_EXPORT_YESTERDAY)
async def export_yesterday_excel(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    today = datetime.fromisoformat(cleaning_service.today_iso(settings.timezone)).date()
    yesterday = (today - timedelta(days=1)).isoformat()
    await _send_excel_report(message, db, yesterday, yesterday)


@router.message(F.text == common_kb.SUP_EXPORT_RANGE)
async def export_range_start(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    await state.clear()
    await state.set_state(ExportRange.waiting_dates)
    await message.answer(
        "Отправьте одну дату или период.\n"
        "Например: 01.07.2026\n"
        "или: 01.07.2026-07.07.2026"
    )


@router.message(ExportRange.waiting_dates, F.text)
async def export_range_finish(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    report_range = _parse_report_range(message.text or "")
    if not report_range:
        await message.answer(
            "Не понял дату или период. "
            "Отправьте, например: 01.07.2026 "
            "или 01.07.2026-07.07.2026"
        )
        return

    start, end = report_range
    await state.clear()
    await _send_excel_report(message, db, start.isoformat(), end.isoformat())


@router.message(F.text == common_kb.SUP_SHIFT_REPORT)
async def export_shifts_start(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    await state.clear()
    await state.set_state(ShiftExportRange.waiting_dates)
    await message.answer(
        "Отправьте одну дату или период смен.\n"
        "Например: 01.07.2026\n"
        "или: 01.07.2026-07.07.2026"
    )


@router.message(ShiftExportRange.waiting_dates, F.text)
async def export_shifts_finish(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    report_range = _parse_report_range(message.text or "")
    if not report_range:
        await message.answer(
            "Не понял дату или период. "
            "Отправьте, например: 01.07.2026 "
            "или 01.07.2026-07.07.2026"
        )
        return

    start, end = report_range
    await state.clear()
    try:
        path = await export_shifts_xlsx(db, start.isoformat(), end.isoformat())
    except RuntimeError as exc:
        await message.answer(str(exc))
        return

    caption = (
        f"Смены за {format_date(start.isoformat())}"
        if start == end
        else (
            f"Смены за {format_date(start.isoformat())} — "
            f"{format_date(end.isoformat())}"
        )
    )
    await message.answer_document(FSInputFile(path), caption=caption)


@router.message(F.text == common_kb.SUP_SHEETS)
async def sync_sheets(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=_role_allowed_roles())
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    ok, text = await sync_google_sheets(settings, db, today)
    prefix = "Готово. " if ok else "Не удалось. "
    await message.answer(prefix + text)
