import aiosqlite
from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from app.config import Settings
from app.handlers.access import require_callback_user, require_user
from app.handlers.states import MaidShiftEnd
from app.i18n import button_values, language_of, tr
from app.keyboards import common as common_kb
from app.keyboards.maid import (
    before_materials_keyboard,
    finish_photos_keyboard,
    forgotten_items_done_keyboard,
    maid_task_actions,
    maid_tasks_keyboard,
    problem_done_keyboard,
    problem_resolve_confirm_keyboard,
    problem_types_keyboard,
    rework_materials_keyboard,
    shift_cart_photo_keyboard,
    shift_start_confirm_keyboard,
)
from app.models import Role, TaskStatus
from app.repositories import cleaning_tasks as task_repo
from app.services import cleaning_service, shift_service
from app.services.formatting import apartment_label, maid_task_card as format_maid_task_card
from app.services.notifications import (
    notify_forgotten_items_stakeholders,
    notify_missing_keys_stakeholders,
    notify_maid_shift_started,
    notify_problem_stakeholders,
    notify_supervisors_and_admins,
    notify_task_finished,
    notify_task_started,
)


router = Router()


class StartCleaning(StatesGroup):
    waiting_before_materials = State()


class FinishCleaning(StatesGroup):
    waiting_after_materials = State()


class FinishRework(StatesGroup):
    waiting_materials = State()


class ReportProblem(StatesGroup):
    waiting_details = State()


class ReportForgottenItems(StatesGroup):
    waiting_details = State()


async def require_open_shift_message(message: Message, db: aiosqlite.Connection, settings: Settings, user):
    shift = await shift_service.active_shift(db, settings.timezone, user["id"])
    if shift:
        return shift
    language = language_of(user)
    await message.answer(
        tr(language, "shift_required"),
        reply_markup=common_kb.maid_shift_start_menu(language),
    )
    return None


async def require_open_shift_callback(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings, user):
    shift = await shift_service.active_shift(db, settings.timezone, user["id"])
    if shift:
        return shift
    await callback.answer(tr(language_of(user), "shift_required"), show_alert=True)
    return None


@router.message(F.text.in_(button_values("menu_shift_start")))
async def shift_start_request(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=[Role.MAID.value])
    if not user:
        return

    language = language_of(user)
    current = shift_service.now(settings.timezone)
    if current.time() >= shift_service.AUTO_CLOSE_TIME:
        await message.answer(tr(language, "shift_after_21"))
        return

    active = await shift_service.active_shift(db, settings.timezone, user["id"])
    if active:
        await message.answer(
            tr(language, "shift_already_open", time=shift_service.format_shift_time(active["started_at"])),
            reply_markup=common_kb.maid_menu(language),
        )
        return

    await message.answer(
        tr(language, "shift_confirm"),
        reply_markup=shift_start_confirm_keyboard(language),
    )


@router.callback_query(F.data == "shift_start_confirm")
async def shift_start_confirm(
    callback: CallbackQuery,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return

    language = language_of(user)
    current = shift_service.now(settings.timezone)
    if current.time() >= shift_service.AUTO_CLOSE_TIME:
        await callback.message.answer(tr(language, "shift_after_21"))
        await callback.answer()
        return

    shift, created = await shift_service.start_shift(db, settings.timezone, user["id"])
    if created:
        await notify_maid_shift_started(
            bot,
            db,
            settings,
            user["full_name"],
            shift["started_at"],
        )
    await callback.message.answer(
        tr(language, "shift_opened", time=shift_service.format_shift_time(shift["started_at"])),
        reply_markup=common_kb.maid_menu(language),
    )
    await callback.answer()


@router.message(F.text.in_(button_values("menu_shift_end")))
async def shift_end_request(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=[Role.MAID.value])
    if not user:
        return

    language = language_of(user)
    active = await shift_service.active_shift(db, settings.timezone, user["id"])
    if not active:
        await message.answer(
            tr(language, "shift_not_open"),
            reply_markup=common_kb.maid_shift_start_menu(language),
        )
        return

    blockers = await shift_service.maid_shift_end_blockers(
        db,
        settings.timezone,
        user["id"],
    )
    if blockers:
        await state.clear()
        await message.answer(
            shift_service.format_maid_shift_end_blockers(blockers, language),
            reply_markup=common_kb.maid_menu(language),
        )
        return

    await state.set_state(MaidShiftEnd.waiting_cart_photo)
    await state.update_data(language=language)
    await message.answer(
        tr(language, "shift_cart_photo_prompt"),
        reply_markup=shift_cart_photo_keyboard(language),
    )


@router.callback_query(F.data == "shift_end_confirm")
async def shift_end_confirm(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return

    language = language_of(user)
    shift = await shift_service.active_shift(db, settings.timezone, user["id"])
    if not shift:
        await callback.message.answer(
            tr(language, "shift_not_open"),
            reply_markup=common_kb.maid_shift_start_menu(language),
        )
        await callback.answer()
        return

    blockers = await shift_service.maid_shift_end_blockers(
        db,
        settings.timezone,
        user["id"],
    )
    if blockers:
        await state.clear()
        await callback.message.answer(
            shift_service.format_maid_shift_end_blockers(blockers, language),
            reply_markup=common_kb.maid_menu(language),
        )
        await callback.answer()
        return

    await state.set_state(MaidShiftEnd.waiting_cart_photo)
    await state.update_data(language=language)
    await callback.message.answer(
        tr(language, "shift_cart_photo_prompt"),
        reply_markup=shift_cart_photo_keyboard(language),
    )
    await callback.answer()


@router.callback_query(F.data == "shift_action_cancel")
async def shift_action_cancel(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return

    language = language_of(user)
    await state.clear()
    shift = await shift_service.active_shift(db, settings.timezone, user["id"])
    if shift:
        await callback.message.answer(tr(language, "action_canceled"), reply_markup=common_kb.maid_menu(language))
    else:
        await callback.message.answer(
            tr(language, "action_canceled"),
            reply_markup=common_kb.maid_shift_start_menu(language),
        )
    await callback.answer()


async def show_my_tasks(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_message(message, db, settings, user):
        return

    today = cleaning_service.today_iso(settings.timezone)
    tasks = await task_repo.list_for_maid(db, user["id"], today)
    if not tasks:
        await message.answer(tr(language, "no_tasks_today"))
        return

    await message.answer(
        tr(language, "tasks_today"),
        reply_markup=maid_tasks_keyboard(tasks, language=language),
    )


@router.message(F.text.in_(button_values("menu_today")))
async def my_tasks_button(message: Message, db: aiosqlite.Connection, settings: Settings):
    await show_my_tasks(message, db, settings)


@router.message(F.text.in_(button_values("menu_active")))
async def active_task(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_message(message, db, settings, user):
        return

    tasks = await task_repo.list_active_for_maid(db, user["id"])
    if not tasks:
        await message.answer(tr(language, "no_active_task"))
        return

    for task in tasks:
        await message.answer(
            format_maid_task_card(task, language),
            reply_markup=maid_task_actions(task, language),
        )


@router.message(F.text.in_(button_values("menu_reworks")))
async def reworks_button(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_message(message, db, settings, user):
        return

    tasks = await task_repo.list_reworks_for_maid(db, user["id"])
    if not tasks:
        await message.answer(tr(language, "no_reworks"))
        return
    await message.answer(
        tr(language, "reworks"),
        reply_markup=maid_tasks_keyboard(tasks, "maid_task", language),
    )


@router.message(F.text.in_(button_values("menu_result")))
async def maid_result(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    shift = await require_open_shift_message(message, db, settings, user)
    if not shift:
        return

    today = cleaning_service.today_iso(settings.timezone)
    day_tasks = await task_repo.list_for_date(db, today)
    tasks = [task for task in day_tasks if task["assigned_maid_id"] == user["id"]]
    completed = [task for task in tasks if task["status"] in ("waiting_check", "verified")]
    verified = [task for task in tasks if task["status"] == "verified"]
    minutes = sum(task["actual_duration_min"] or 0 for task in tasks)
    shift_time = (
        f"{shift_service.format_shift_time(shift['started_at'])} - "
        f"{shift_service.format_shift_time(shift['ended_at'])}"
    )
    await message.answer(
        tr(
            language,
            "result",
            shift=shift_time,
            total=len(tasks),
            completed=len(completed),
            verified=len(verified),
            minutes=minutes,
        )
    )


@router.callback_query(F.data.startswith("maid_task:"))
async def maid_task_card(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["assigned_maid_id"] != user["id"]:
        await callback.answer(tr(language, "task_not_found"), show_alert=True)
        return

    await callback.message.edit_text(
        format_maid_task_card(task, language),
        reply_markup=maid_task_actions(task, language),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("maid_start:"))
async def start_task_start(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["assigned_maid_id"] != user["id"]:
        await callback.answer(tr(language, "task_not_found"), show_alert=True)
        return
    if task["status"] != "assigned":
        await callback.answer(tr(language, "cannot_start"), show_alert=True)
        return

    keys_missing = await task_repo.has_open_missing_keys_for_apartment(db, task["apartment_id"])
    await state.set_state(StartCleaning.waiting_before_materials)
    await state.update_data(
        task_id=task_id,
        before_videos=[],
        before_photos=[],
        keys_photo_id=None,
        keys_missing=keys_missing,
        tv_photo_id=None,
        language=language,
    )
    await callback.message.answer(
        tr(language, "start_instructions_no_keys" if keys_missing else "start_instructions"),
        reply_markup=before_materials_keyboard(task_id, language, keys_missing=keys_missing),
    )
    await callback.answer()


@router.callback_query(StartCleaning.waiting_before_materials, F.data.startswith("before_keys_missing:"))
async def before_keys_missing(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    data = await state.get_data()
    task_id = data.get("task_id")
    if not task_id:
        await callback.answer(tr(language, "cleaning_not_found"), show_alert=True)
        await state.clear()
        return
    if callback.data != f"before_keys_missing:{task_id}":
        await callback.answer(tr(language, "stale_materials_button"), show_alert=True)
        return
    try:
        task, newly_reported = await cleaning_service.mark_keys_missing(
            db, settings.timezone, int(task_id), user["id"]
        )
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return

    await callback.answer()
    await state.update_data(keys_missing=True, keys_photo_id=None)
    delivered = True
    if newly_reported:
        delivered = await notify_missing_keys_stakeholders(bot, db, task, user["full_name"])
    await callback.message.answer(
        tr(language, "keys_missing_reported" if delivered else "keys_missing_delivery_failed"),
        reply_markup=before_materials_keyboard(int(task_id), language, keys_missing=True),
    )


@router.callback_query(
    StartCleaning.waiting_before_materials,
    F.data.in_({"before_keys_missing", "before_materials_done"}),
)
async def outdated_before_materials_button(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    await callback.answer(
        tr(data.get("language"), "stale_materials_button"),
        show_alert=True,
    )


@router.message(StartCleaning.waiting_before_materials, F.video)
async def collect_before_video(message: Message, state: FSMContext):
    data = await state.get_data()
    videos = data.get("before_videos", [])
    videos.append(message.video.file_id)
    await state.update_data(before_videos=videos)
    await message.answer(tr(data.get("language"), "before_video_added", count=len(videos)))


@router.message(StartCleaning.waiting_before_materials, F.photo)
async def collect_before_photo(message: Message, state: FSMContext):
    data = await state.get_data()
    photo_id = message.photo[-1].file_id
    if not data.get("keys_missing") and not data.get("keys_photo_id"):
        await state.update_data(keys_photo_id=photo_id)
        await message.answer(tr(data.get("language"), "keys_photo_added"))
        return
    if not data.get("tv_photo_id"):
        await state.update_data(tv_photo_id=photo_id)
        await message.answer(tr(data.get("language"), "tv_photo_added"))
        return
    photos = data.get("before_photos", [])
    photos.append(photo_id)
    await state.update_data(before_photos=photos)
    await message.answer(tr(data.get("language"), "before_photo_added", count=len(photos)))


@router.callback_query(StartCleaning.waiting_before_materials, F.data.startswith("before_materials_done:"))
async def before_materials_done(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    data = await state.get_data()
    language = data.get("language") or language_of(user)
    task_id = data.get("task_id")
    before_videos = data.get("before_videos", [])
    before_photos = data.get("before_photos", [])
    keys_photo_id = data.get("keys_photo_id")
    tv_photo_id = data.get("tv_photo_id")
    if not task_id:
        await callback.answer(tr(language, "cleaning_not_found"), show_alert=True)
        await state.clear()
        return
    if callback.data != f"before_materials_done:{task_id}":
        await callback.answer(tr(language, "stale_materials_button"), show_alert=True)
        return
    if data.get("keys_missing") and not keys_photo_id:
        task = await task_repo.get_by_id(db, int(task_id))
        if task and not await task_repo.has_open_missing_keys_for_apartment(db, task["apartment_id"]):
            await state.update_data(keys_missing=False)
            await callback.message.answer(
                tr(language, "keys_available_now"),
                reply_markup=before_materials_keyboard(int(task_id), language),
            )
            await callback.answer()
            return
    if not keys_photo_id and not data.get("keys_missing"):
        await callback.answer(tr(language, "keys_photo_required"), show_alert=True)
        return
    if not tv_photo_id:
        await callback.answer(tr(language, "tv_photo_required"), show_alert=True)
        return
    if not before_videos:
        await callback.answer(tr(language, "before_video_required"), show_alert=True)
        return

    try:
        updated = await cleaning_service.start_task(
            db,
            settings.timezone,
            int(task_id),
            user["id"],
            before_video_ids=before_videos,
            before_photo_ids=before_photos,
            keys_photo_id=keys_photo_id,
            tv_photo_id=tv_photo_id,
        )
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return

    await state.clear()
    await notify_task_started(bot, db, settings, updated)
    await callback.message.answer(
        format_maid_task_card(updated, language),
        reply_markup=maid_task_actions(updated, language),
    )
    await callback.answer(tr(language, "cleaning_started"))


@router.callback_query(F.data.startswith("maid_rework_start:"))
async def finish_rework_start(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["assigned_maid_id"] != user["id"]:
        await callback.answer(tr(language, "task_not_found"), show_alert=True)
        return
    if task["status"] != "rework":
        await callback.answer(tr(language, "rework_wrong_status"), show_alert=True)
        return

    await state.set_state(FinishRework.waiting_materials)
    await state.update_data(task_id=task_id, photos=[], comments=[], language=language)
    await callback.message.answer(
        format_maid_task_card(task, language)
        + "\n\n"
        + tr(language, "rework_instructions"),
        reply_markup=rework_materials_keyboard(language),
    )
    await callback.answer()


@router.message(FinishRework.waiting_materials, F.photo)
async def collect_rework_photo(message: Message, state: FSMContext):
    data = await state.get_data()
    photos = list(data.get("photos") or [])
    photos.append(message.photo[-1].file_id)
    comments = list(data.get("comments") or [])
    if message.caption:
        comments.append(message.caption)
    await state.update_data(photos=photos, comments=comments)
    await message.answer(tr(data.get("language"), "rework_photo_added", count=len(photos)))


@router.message(FinishRework.waiting_materials, F.text)
async def collect_rework_comment(message: Message, state: FSMContext):
    data = await state.get_data()
    comments = list(data.get("comments") or [])
    comments.append(message.text)
    await state.update_data(comments=comments)
    await message.answer(tr(data.get("language"), "rework_comment_saved"))


@router.callback_query(FinishRework.waiting_materials, F.data == "rework_materials_done")
async def finish_rework_done(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    data = await state.get_data()
    language = data.get("language") or language_of(user)
    photos = list(data.get("photos") or [])
    comments = list(data.get("comments") or [])
    task_id = data.get("task_id")
    if not task_id:
        await callback.answer(tr(language, "rework_not_found"), show_alert=True)
        await state.clear()
        return
    if not photos:
        await callback.answer(tr(language, "rework_photo_required"), show_alert=True)
        return

    try:
        task = await cleaning_service.complete_rework(
            db,
            settings.timezone,
            int(task_id),
            user["id"],
            photos,
            comment="\n".join(comments) if comments else None,
        )
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return

    await state.clear()
    await notify_supervisors_and_admins(
        bot,
        db,
        settings,
        f"{user['full_name']} завершила переделку {apartment_label(task)}, ждет проверки",
    )
    await callback.message.answer(tr(language, "rework_sent"))
    await callback.answer()


@router.callback_query(F.data.startswith("maid_finish:"))
async def finish_task_start(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["assigned_maid_id"] != user["id"]:
        await callback.answer(tr(language, "task_not_found"), show_alert=True)
        return
    if task["status"] != "in_progress":
        await callback.answer(tr(language, "start_first"), show_alert=True)
        return

    await state.set_state(FinishCleaning.waiting_after_materials)
    await state.update_data(
        task_id=task_id,
        photos=[],
        videos=[],
        drain_photo_id=None,
        vacuum_photo_id=None,
        language=language,
    )
    await callback.message.answer(
        tr(language, "finish_instructions"),
        reply_markup=finish_photos_keyboard(language),
    )
    await callback.answer()


@router.message(FinishCleaning.waiting_after_materials, F.video)
async def collect_finish_video(message: Message, state: FSMContext):
    data = await state.get_data()
    videos = data.get("videos", [])
    videos.append(message.video.file_id)
    await state.update_data(videos=videos)
    await message.answer(tr(data.get("language"), "after_video_added", count=len(videos)))


@router.message(FinishCleaning.waiting_after_materials, F.photo)
async def collect_finish_photo(message: Message, state: FSMContext):
    data = await state.get_data()
    photo_id = message.photo[-1].file_id
    if not data.get("drain_photo_id"):
        await state.update_data(drain_photo_id=photo_id)
        await message.answer(tr(data.get("language"), "drain_photo_added"))
        return
    if not data.get("vacuum_photo_id"):
        await state.update_data(vacuum_photo_id=photo_id)
        await message.answer(tr(data.get("language"), "vacuum_photo_added"))
        return
    photos = data.get("photos", [])
    if len(photos) >= 8:
        await message.answer(tr(data.get("language"), "photo_limit"))
        return
    photos.append(photo_id)
    await state.update_data(photos=photos)
    await message.answer(tr(data.get("language"), "after_photo_added", count=len(photos)))


@router.callback_query(FinishCleaning.waiting_after_materials, F.data == "finish_materials_done")
async def finish_photos_done(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    data = await state.get_data()
    language = data.get("language") or language_of(user)
    photos = data.get("photos", [])
    videos = data.get("videos", [])
    drain_photo_id = data.get("drain_photo_id")
    vacuum_photo_id = data.get("vacuum_photo_id")
    task_id = data.get("task_id")
    if not task_id:
        await callback.answer(tr(language, "active_cleaning_not_found"), show_alert=True)
        await state.clear()
        return
    if not drain_photo_id:
        await callback.answer(tr(language, "drain_photo_required"), show_alert=True)
        return
    if not vacuum_photo_id:
        await callback.answer(tr(language, "vacuum_photo_required"), show_alert=True)
        return
    if not videos:
        await callback.answer(tr(language, "after_video_required"), show_alert=True)
        return

    try:
        task = await cleaning_service.finish_task(
            db,
            settings.timezone,
            int(task_id),
            user["id"],
            photos,
            video_file_ids=videos,
            drain_photo_id=drain_photo_id,
            vacuum_photo_id=vacuum_photo_id,
        )
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return

    await state.clear()
    await notify_task_finished(bot, db, settings, task)
    await callback.message.answer(tr(language, "cleaning_finished"))
    await callback.answer()


@router.message(F.text.in_(button_values("menu_problem")))
async def problem_button(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_message(message, db, settings, user):
        return

    today = cleaning_service.today_iso(settings.timezone)
    tasks = await task_repo.list_for_maid(db, user["id"], today)
    active_tasks = [task for task in tasks if task["status"] not in ("verified", "canceled")]
    if not active_tasks:
        await message.answer(tr(language, "no_active_for_problem"))
        return
    await message.answer(
        tr(language, "choose_cleaning"),
        reply_markup=maid_tasks_keyboard(active_tasks, language=language),
    )


@router.callback_query(F.data.startswith("maid_forgotten_task:"))
async def forgotten_items_start(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["assigned_maid_id"] != user["id"]:
        await callback.answer(tr(language, "task_not_found"), show_alert=True)
        return
    if task["status"] in (TaskStatus.VERIFIED.value, TaskStatus.CANCELED.value):
        await callback.answer(tr(language, "forgotten_not_allowed"), show_alert=True)
        return

    await state.set_state(ReportForgottenItems.waiting_details)
    await state.update_data(
        task_id=task_id,
        photos=[],
        videos=[],
        comments=[],
        language=language,
    )
    await callback.message.answer(
        tr(language, "forgotten_instructions"),
        reply_markup=forgotten_items_done_keyboard(language),
    )
    await callback.answer()


@router.message(ReportForgottenItems.waiting_details, F.photo)
async def collect_forgotten_items_photo(message: Message, state: FSMContext):
    data = await state.get_data()
    photos = list(data.get("photos") or [])
    photos.append(message.photo[-1].file_id)
    comments = list(data.get("comments") or [])
    if message.caption:
        comments.append(message.caption)
    await state.update_data(photos=photos, comments=comments)
    await message.answer(tr(data.get("language"), "forgotten_photo_added", count=len(photos)))


@router.message(ReportForgottenItems.waiting_details, F.video)
async def collect_forgotten_items_video(message: Message, state: FSMContext):
    data = await state.get_data()
    videos = list(data.get("videos") or [])
    videos.append(message.video.file_id)
    comments = list(data.get("comments") or [])
    if message.caption:
        comments.append(message.caption)
    await state.update_data(videos=videos, comments=comments)
    await message.answer(tr(data.get("language"), "forgotten_video_added", count=len(videos)))


@router.message(ReportForgottenItems.waiting_details, F.text)
async def collect_forgotten_items_comment(message: Message, state: FSMContext):
    data = await state.get_data()
    comments = list(data.get("comments") or [])
    comments.append(message.text)
    await state.update_data(comments=comments)
    await message.answer(tr(data.get("language"), "forgotten_comment_saved"))


@router.callback_query(ReportForgottenItems.waiting_details, F.data == "maid_forgotten_done")
async def forgotten_items_done(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    data = await state.get_data()
    language = data.get("language") or language_of(user)
    task_id = data.get("task_id")
    photos = list(data.get("photos") or [])
    videos = list(data.get("videos") or [])
    comments = list(data.get("comments") or [])
    if not task_id:
        await callback.answer(tr(language, "cleaning_not_found"), show_alert=True)
        await state.clear()
        return
    if not photos and not videos:
        await callback.answer(tr(language, "forgotten_media_required"), show_alert=True)
        return

    comment = "\n".join(comments) if comments else None
    try:
        task = await cleaning_service.report_forgotten_items(
            db,
            settings.timezone,
            int(task_id),
            user["id"],
            comment=comment,
            photo_file_ids=photos,
            video_file_ids=videos,
        )
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
        return

    await state.clear()
    await notify_forgotten_items_stakeholders(
        bot,
        db,
        settings,
        task,
        user["full_name"],
        comment,
        photos,
        videos,
    )
    await callback.message.answer(tr(language, "forgotten_sent"))
    await callback.answer()


@router.callback_query(F.data.startswith("maid_problem_resolve:"))
async def maid_problem_resolve_confirm(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["assigned_maid_id"] != user["id"]:
        await callback.answer(tr(language, "task_not_found"), show_alert=True)
        return
    if not task["problem_type"] or task["problem_resolved_at"]:
        await callback.answer(tr(language, "problem_not_active"), show_alert=True)
        return

    question = tr(language, "problem_question")
    if task["problem_type"] == "guest_not_left":
        question = tr(language, "guest_left_question")
    elif task["problem_type"] == "no_access":
        question = tr(language, "access_question")

    await callback.message.answer(
        question + "\n\n" + format_maid_task_card(task, language),
        reply_markup=problem_resolve_confirm_keyboard(task_id, language),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("maid_problem_resolve_yes:"))
async def maid_problem_resolve_yes(
    callback: CallbackQuery,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["assigned_maid_id"] != user["id"]:
        await callback.answer(tr(language, "task_not_found"), show_alert=True)
        return
    if not task["problem_type"] or task["problem_resolved_at"]:
        await callback.answer(tr(language, "problem_not_active"), show_alert=True)
        return

    task = await cleaning_service.resolve_problem(db, settings.timezone, task_id, user["id"])
    await notify_supervisors_and_admins(
        bot,
        db,
        settings,
        f"{user['full_name']} закрыла проблему {apartment_label(task)}",
    )
    await callback.message.edit_text(
        tr(language, "problem_closed") + "\n\n" + format_maid_task_card(task, language),
        reply_markup=maid_task_actions(task, language),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("maid_problem_resolve_no:"))
async def maid_problem_resolve_no(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["assigned_maid_id"] != user["id"]:
        await callback.answer(tr(language, "task_not_found"), show_alert=True)
        return
    await callback.message.edit_text(
        tr(language, "problem_kept") + "\n\n" + format_maid_task_card(task, language),
        reply_markup=maid_task_actions(task, language),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("maid_problem_task:"))
async def problem_choose_type(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    task_id = int(callback.data.split(":", 1)[1])
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["assigned_maid_id"] != user["id"]:
        await callback.answer(tr(language, "task_not_found"), show_alert=True)
        return
    await callback.message.answer(
        tr(language, "choose_problem_type"),
        reply_markup=problem_types_keyboard(task_id, language),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("maid_problem_type:"))
async def problem_details_start(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = language_of(user)
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    _, task_id, problem_type = callback.data.split(":", 2)
    await state.set_state(ReportProblem.waiting_details)
    await state.update_data(
        task_id=int(task_id),
        problem_type=problem_type,
        photos=[],
        videos=[],
        comments=[],
        language=language,
    )
    await callback.message.answer(
        tr(language, "problem_instructions"),
        reply_markup=problem_done_keyboard(language),
    )
    await callback.answer()


@router.message(ReportProblem.waiting_details, F.photo)
async def collect_problem_photo(message: Message, state: FSMContext):
    data = await state.get_data()
    photos = list(data.get("photos") or [])
    photos.append(message.photo[-1].file_id)
    comments = list(data.get("comments") or [])
    if message.caption:
        comments.append(message.caption)
    await state.update_data(photos=photos, comments=comments)
    await message.answer(tr(data.get("language"), "problem_photo_added", count=len(photos)))


@router.message(ReportProblem.waiting_details, F.video)
async def collect_problem_video(message: Message, state: FSMContext):
    data = await state.get_data()
    videos = list(data.get("videos") or [])
    videos.append(message.video.file_id)
    comments = list(data.get("comments") or [])
    if message.caption:
        comments.append(message.caption)
    await state.update_data(videos=videos, comments=comments)
    await message.answer(tr(data.get("language"), "problem_video_added", count=len(videos)))


@router.message(ReportProblem.waiting_details, F.text)
async def collect_problem_comment(message: Message, state: FSMContext):
    data = await state.get_data()
    comments = list(data.get("comments") or [])
    comments.append(message.text)
    await state.update_data(comments=comments)
    await message.answer(tr(data.get("language"), "problem_comment_saved"))


@router.callback_query(F.data == "maid_problem_done")
async def problem_done(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    if not await require_open_shift_callback(callback, db, settings, user):
        return

    data = await state.get_data()
    language = data.get("language") or language_of(user)
    if not data.get("task_id"):
        await callback.answer(tr(language, "problem_not_found"), show_alert=True)
        await state.clear()
        return

    comments = list(data.get("comments") or [])
    comment = "\n".join(comments) if comments else None
    photos = list(data.get("photos") or [])
    videos = list(data.get("videos") or [])
    task = await cleaning_service.mark_problem(
        db,
        settings.timezone,
        int(data["task_id"]),
        user["id"],
        data["problem_type"],
        comment,
        photos,
        video_file_ids=videos,
    )
    await state.clear()
    await notify_problem_stakeholders(
        bot,
        db,
        settings,
        task,
        user["full_name"],
        data["problem_type"],
        comment,
        photos,
        videos,
    )
    message_key = (
        "problem_sent_blocked"
        if cleaning_service.problem_blocks_cleaning(data["problem_type"])
        else "problem_sent_continue"
    )
    await callback.message.answer(
        tr(language, message_key) + "\n\n" + format_maid_task_card(task, language),
        reply_markup=maid_task_actions(task, language),
    )
    await callback.answer()
