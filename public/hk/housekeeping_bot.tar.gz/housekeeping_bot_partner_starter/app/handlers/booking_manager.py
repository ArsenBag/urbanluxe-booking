import aiosqlite
from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from app.config import Settings
from app.handlers.access import require_callback_user, require_user
from app.keyboards import common as common_kb
from app.keyboards.booking_manager import (
    apartments_keyboard,
    bookings_keyboard,
    buildings_keyboard,
    checkin_times_keyboard,
    checkout_times_keyboard,
    extra_cleaning_times_keyboard,
    guests_keyboard,
)
from app.models import CleaningType, STATUS_LABELS, Role, label
from app.repositories import apartments as apartment_repo
from app.repositories import bookings as booking_repo
from app.repositories import cleaning_tasks as task_repo
from app.services import booking_service, cleaning_service
from app.services.formatting import apartment_label, format_date, task_title
from app.services.notifications import notify_supervisors_and_admins


router = Router()
BOOKING_MANAGER_ROLES = [Role.BOOKING_MANAGER.value, Role.ADMIN.value]


class PlanCheckout(StatesGroup):
    choosing_checkout_time = State()
    waiting_checkout_time = State()
    choosing_next_checkin_time = State()


class MarkCheckedOut(StatesGroup):
    choosing_building = State()
    choosing_apartment = State()


class AddBooking(StatesGroup):
    choosing_building = State()
    choosing_apartment = State()
    waiting_checkin_date = State()
    choosing_checkin_time = State()
    waiting_checkout_date = State()
    choosing_checkout_time = State()
    waiting_checkout_time = State()
    choosing_guests = State()


class ExtraCleaning(StatesGroup):
    choosing_building = State()
    choosing_apartment = State()
    waiting_date = State()
    choosing_time = State()
    waiting_time = State()


def _format_iso_time(value: str) -> str:
    try:
        return value.split("T", 1)[1][:5]
    except Exception:
        return value or "-"


def _booking_line(booking) -> str:
    next_checkin = booking_service.next_checkin_label(
        booking["next_checkin_time"],
        bool(booking["no_next_booking"]),
    )
    return (
        f"{apartment_label(booking)} · выезд {booking['checkout_time'] or '-'} · "
        f"следующий заезд {next_checkin}"
    )


async def _notify_checkout_plan(
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
    booking,
) -> None:
    if not booking_service.housekeeping_cleaning_enabled(booking):
        return
    await notify_supervisors_and_admins(
        bot,
        db,
        settings,
        "Создана уборка после выезда:\n"
        f"{_booking_line(booking)}\n"
        "Нужно назначить горничную.",
    )


async def _notify_checked_out(
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
    booking,
) -> None:
    if not booking_service.housekeeping_cleaning_enabled(booking):
        return
    actual = _format_iso_time(booking["actual_checkout_at"])
    await notify_supervisors_and_admins(
        bot,
        db,
        settings,
        "Гость выехал:\n"
        f"{apartment_label(booking)}\n"
        f"Плановый выезд: {booking['checkout_time'] or '-'}\n"
        f"Фактически: {actual}\n"
        "Уборка создана и доступна к назначению.",
    )


def _extra_task_line(task) -> str:
    status = label(STATUS_LABELS, task["status"])
    return (
        f"{format_date(task['planned_date'])} · {task_title(task)} · "
        f"{status} · {task['maid_name'] or 'не назначена'}"
    )


async def _create_extra_cleaning(
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
    user_id: int,
    apartment_id: int,
    planned_date: str,
    time_value: str,
):
    task = await cleaning_service.create_task(
        db,
        settings.timezone,
        apartment_id=apartment_id,
        cleaning_type=CleaningType.DAILY.value,
        planned_date=planned_date,
        deadline_at=cleaning_service.deadline_iso(settings.timezone, planned_date, time_value),
        maid_id=None,
        supervisor_id=None,
        comment=f"Ежедневная уборка от менеджера бронирований. Можно прийти с {time_value}.",
        created_by=user_id,
    )
    await notify_supervisors_and_admins(
        bot,
        db,
        settings,
        "Создана ежедневная уборка:\n"
        f"{_extra_task_line(task)}\n"
        "Нужно назначить горничную.",
    )
    return task


async def _extra_cleaning_apartments(
    db: aiosqlite.Connection,
    building_key: str,
):
    if building_key == "all":
        return await apartment_repo.list_active(db)
    return await apartment_repo.list_by_building_keyword(
        db,
        booking_service.building_keyword(building_key),
    )


@router.message(F.text == common_kb.BM_CHECKOUTS)
async def checkouts_today(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    bookings = await booking_repo.list_checkout_date(db, today)
    if not bookings:
        await message.answer("На сегодня выездов пока нет. Можно добавить бронь через кнопку «Добавить бронь».")
        return

    await message.answer("Выберите объект:", reply_markup=bookings_keyboard(bookings, "bm_checkout_select"))


@router.callback_query(F.data.startswith("bm_checkout_select:"))
async def checkout_select(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    booking_id = int(callback.data.split(":", 1)[1])
    await state.set_state(PlanCheckout.choosing_checkout_time)
    await state.update_data(booking_id=booking_id)
    await callback.message.edit_text(
        "Укажите время выезда:",
        reply_markup=checkout_times_keyboard("bm_checkout_time"),
    )
    await callback.answer()


@router.callback_query(PlanCheckout.choosing_checkout_time, F.data.startswith("bm_checkout_time:"))
async def checkout_time_selected(callback: CallbackQuery, state: FSMContext):
    value = callback.data.split(":", 1)[1]
    if value == "manual":
        await state.set_state(PlanCheckout.waiting_checkout_time)
        await callback.message.edit_text("Введите время выезда вручную в формате 10:30.")
        await callback.answer()
        return

    await state.update_data(checkout_time=value)
    await state.set_state(PlanCheckout.choosing_next_checkin_time)
    await callback.message.edit_text(
        "Укажите время заезда следующих гостей:",
        reply_markup=checkin_times_keyboard("bm_next_checkin", include_no_booking=True),
    )
    await callback.answer()


@router.message(PlanCheckout.waiting_checkout_time, F.text)
async def checkout_time_manual(message: Message, state: FSMContext):
    try:
        checkout_time = booking_service.parse_time(message.text)
    except ValueError as exc:
        await message.answer(str(exc))
        return

    await state.update_data(checkout_time=checkout_time)
    await state.set_state(PlanCheckout.choosing_next_checkin_time)
    await message.answer(
        "Укажите время заезда следующих гостей:",
        reply_markup=checkin_times_keyboard("bm_next_checkin", include_no_booking=True),
    )


@router.callback_query(PlanCheckout.choosing_next_checkin_time, F.data.startswith("bm_next_checkin:"))
async def next_checkin_selected(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    value = callback.data.split(":", 1)[1]
    data = await state.get_data()
    no_next_booking = value == "none"
    next_checkin_time = None if no_next_booking else value

    booking = await booking_service.update_checkout_plan_and_create_cleaning(
        db,
        settings.timezone,
        booking_id=int(data["booking_id"]),
        checkout_time=data["checkout_time"],
        next_checkin_time=next_checkin_time,
        no_next_booking=no_next_booking,
        user_id=user["id"],
    )
    await state.clear()
    await _notify_checkout_plan(bot, db, settings, booking)
    if booking_service.housekeeping_cleaning_enabled(booking):
        text = "Выезд сохранен, уборка создана автоматически:\n"
    else:
        text = "Выезд сохранен. Объект вне зоны обслуживания не добавляется в график уборок:\n"
    await callback.message.edit_text(text + _booking_line(booking))
    await callback.answer()


@router.message(F.text == common_kb.BM_CHECKED_OUT)
async def checked_out_start(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    bookings = await booking_repo.list_checkout_date(db, today)
    await message.answer(
        "Выберите объект, откуда гость уже выехал:",
        reply_markup=bookings_keyboard(bookings, "bm_left_select", include_other=True),
    )


@router.callback_query(F.data.startswith("bm_left_select:"))
async def checked_out_select(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    value = callback.data.split(":", 1)[1]
    if value == "other":
        await state.set_state(MarkCheckedOut.choosing_building)
        await callback.message.edit_text(
            "Выберите ЖК:",
            reply_markup=buildings_keyboard("bm_left_building"),
        )
        await callback.answer()
        return

    booking = await booking_service.mark_booking_checked_out(
        db,
        settings.timezone,
        booking_id=int(value),
        user_id=user["id"],
    )
    await _notify_checked_out(bot, db, settings, booking)
    if booking_service.housekeeping_cleaning_enabled(booking):
        text = "Готово. Дежурному супервайзеру отправлено уведомление:\n"
    else:
        text = "Готово. Выезд сохранен; в график housekeeping объект не добавлен:\n"
    await callback.message.edit_text(text + _booking_line(booking))
    await callback.answer()


@router.callback_query(MarkCheckedOut.choosing_building, F.data.startswith("bm_left_building:"))
async def checked_out_building(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    building_key = callback.data.split(":", 1)[1]
    apartments = await apartment_repo.list_by_building_keyword(
        db,
        booking_service.building_keyword(building_key),
    )
    if not apartments:
        await callback.message.edit_text("По этому ЖК пока нет объектов в базе.")
        await callback.answer()
        return

    await state.set_state(MarkCheckedOut.choosing_apartment)
    await callback.message.edit_text(
        "Выберите объект:",
        reply_markup=apartments_keyboard(apartments, "bm_left_apartment"),
    )
    await callback.answer()


@router.callback_query(MarkCheckedOut.choosing_apartment, F.data.startswith("bm_left_apartment:"))
async def checked_out_apartment(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    apartment_id = int(callback.data.split(":", 1)[1])
    booking = await booking_service.create_ad_hoc_checkout(
        db,
        settings.timezone,
        apartment_id=apartment_id,
        user_id=user["id"],
    )
    await state.clear()
    await _notify_checked_out(bot, db, settings, booking)
    if booking_service.housekeeping_cleaning_enabled(booking):
        text = "Готово. Выезд добавлен, уборка создана:\n"
    else:
        text = "Готово. Выезд добавлен; в график housekeeping объект не добавлен:\n"
    await callback.message.edit_text(text + _booking_line(booking))
    await callback.answer()


@router.message(F.text == common_kb.BM_READY)
async def ready_for_checkin(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    rows = await booking_repo.list_readiness_for_date(db, today)
    if not rows:
        await message.answer("На сегодня уборок для заезда пока нет.")
        return

    text_rows = [f"Готовность к заезду: {len(rows)}"]
    for row in rows:
        no_next_booking = bool(row["no_next_booking"])
        checkin = booking_service.readiness_checkin_label(row["checkin_time"], no_next_booking)
        checkin_part = checkin if no_next_booking else f"заезд {checkin}"
        keys_missing = bool(row["apartment_keys_missing"])
        status = booking_service.readiness_label_with_icon(row["cleaning_status"], keys_missing)
        maid = f" · {row['maid_name']}" if row["maid_name"] else ""
        text_rows.append(f"{apartment_label(row)} · {checkin_part} · {status}{maid}")
    await message.answer("\n".join(text_rows))


@router.message(F.text == common_kb.BM_EXTRA_LIST_LEGACY)
@router.message(F.text == common_kb.BM_EXTRA_LIST)
async def extra_cleanings_list(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    today = cleaning_service.today_iso(settings.timezone)
    tasks = await task_repo.list_extra_cleanings(db, today)
    if not tasks:
        await message.answer("Запланированных ежедневных уборок пока нет.")
        return

    rows = ["Запланированные ежедневные уборки:"]
    rows.extend(_extra_task_line(task) for task in tasks)
    await message.answer("\n".join(rows))


@router.message(F.text == common_kb.BM_EXTRA_CLEANING_LEGACY)
@router.message(F.text == common_kb.BM_EXTRA_CLEANING)
async def extra_cleaning_start(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    await state.set_state(ExtraCleaning.choosing_building)
    await state.update_data(created_by=user["id"])
    await message.answer(
        "Выберите ЖК для ежедневной уборки:",
        reply_markup=buildings_keyboard("bm_extra_building", include_all=True),
    )


@router.callback_query(ExtraCleaning.choosing_building, F.data.startswith("bm_extra_building:"))
async def extra_cleaning_building(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    building_key = callback.data.split(":", 1)[1]
    apartments = await _extra_cleaning_apartments(db, building_key)
    if not apartments:
        await callback.message.edit_text("По этому ЖК пока нет объектов в базе.")
        await callback.answer()
        return

    await state.update_data(building_key=building_key)
    await state.set_state(ExtraCleaning.choosing_apartment)
    await callback.message.edit_text(
        "Выберите объект:",
        reply_markup=apartments_keyboard(
            apartments,
            "bm_extra_apartment",
            page=0,
        ),
    )
    await callback.answer()


@router.callback_query(
    ExtraCleaning.choosing_apartment,
    F.data.startswith("bm_extra_apartment_page:"),
)
async def extra_cleaning_apartment_page(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
):
    page = int(callback.data.rsplit(":", 1)[1])
    data = await state.get_data()
    apartments = await _extra_cleaning_apartments(
        db,
        data.get("building_key") or "all",
    )
    await callback.message.edit_text(
        "Выберите объект:",
        reply_markup=apartments_keyboard(
            apartments,
            "bm_extra_apartment",
            page=page,
        ),
    )
    await callback.answer()


@router.callback_query(ExtraCleaning.choosing_apartment, F.data.startswith("bm_extra_apartment:"))
async def extra_cleaning_apartment(callback: CallbackQuery, state: FSMContext):
    apartment_id = int(callback.data.split(":", 1)[1])
    await state.update_data(apartment_id=apartment_id)
    await state.set_state(ExtraCleaning.waiting_date)
    await callback.message.edit_text("Введите дату ежедневной уборки в формате 29.06.2026.")
    await callback.answer()


@router.message(ExtraCleaning.waiting_date, F.text)
async def extra_cleaning_date(message: Message, state: FSMContext, settings: Settings):
    try:
        planned_date = booking_service.parse_date(message.text)
    except ValueError as exc:
        await message.answer(str(exc))
        return

    today = cleaning_service.today_iso(settings.timezone)
    if planned_date < today:
        await message.answer("Дата не может быть в прошлом.")
        return

    await state.update_data(planned_date=planned_date)
    await state.set_state(ExtraCleaning.choosing_time)
    await message.answer(
        "Укажите время, с которого можно прийти:",
        reply_markup=extra_cleaning_times_keyboard("bm_extra_time"),
    )


@router.callback_query(ExtraCleaning.choosing_time, F.data.startswith("bm_extra_time:"))
async def extra_cleaning_time(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    value = callback.data.split(":", 1)[1]
    if value == "manual":
        await state.set_state(ExtraCleaning.waiting_time)
        await callback.message.edit_text("Введите время вручную в формате 14:30.")
        await callback.answer()
        return

    data = await state.get_data()
    task = await _create_extra_cleaning(
        bot,
        db,
        settings,
        user_id=int(data["created_by"]),
        apartment_id=int(data["apartment_id"]),
        planned_date=data["planned_date"],
        time_value=value,
    )
    await state.clear()
    await callback.message.edit_text("Ежедневная уборка создана:\n" + _extra_task_line(task))
    await callback.answer()


@router.message(ExtraCleaning.waiting_time, F.text)
async def extra_cleaning_time_manual(
    message: Message,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    try:
        time_value = booking_service.parse_time(message.text)
    except ValueError as exc:
        await message.answer(str(exc))
        return

    data = await state.get_data()
    task = await _create_extra_cleaning(
        bot,
        db,
        settings,
        user_id=int(data["created_by"]),
        apartment_id=int(data["apartment_id"]),
        planned_date=data["planned_date"],
        time_value=time_value,
    )
    await state.clear()
    await message.answer("Ежедневная уборка создана:\n" + _extra_task_line(task))


@router.message(F.text == common_kb.BM_ADD_BOOKING)
async def add_booking_start(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    await state.set_state(AddBooking.choosing_building)
    await state.update_data(created_by=user["id"])
    await message.answer("Выберите ЖК:", reply_markup=buildings_keyboard("bm_add_building"))


@router.callback_query(AddBooking.choosing_building, F.data.startswith("bm_add_building:"))
async def add_booking_building(
    callback: CallbackQuery,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    building_key = callback.data.split(":", 1)[1]
    apartments = await apartment_repo.list_by_building_keyword(
        db,
        booking_service.building_keyword(building_key),
    )
    if not apartments:
        await callback.message.edit_text("По этому ЖК пока нет объектов в базе.")
        await callback.answer()
        return

    await state.update_data(building_key=building_key)
    await state.set_state(AddBooking.choosing_apartment)
    await callback.message.edit_text(
        "Выберите объект:",
        reply_markup=apartments_keyboard(apartments, "bm_add_apartment"),
    )
    await callback.answer()


@router.callback_query(AddBooking.choosing_apartment, F.data.startswith("bm_add_apartment:"))
async def add_booking_apartment(callback: CallbackQuery, state: FSMContext):
    apartment_id = int(callback.data.split(":", 1)[1])
    await state.update_data(apartment_id=apartment_id)
    await state.set_state(AddBooking.waiting_checkin_date)
    await callback.message.edit_text("Введите дату заезда в формате 29.06.2026.")
    await callback.answer()


@router.message(AddBooking.waiting_checkin_date, F.text)
async def add_booking_checkin_date(message: Message, state: FSMContext):
    try:
        checkin_date = booking_service.parse_date(message.text)
    except ValueError as exc:
        await message.answer(str(exc))
        return

    await state.update_data(checkin_date=checkin_date)
    await state.set_state(AddBooking.choosing_checkin_time)
    await message.answer(
        "Выберите время заезда:",
        reply_markup=checkin_times_keyboard("bm_add_checkin_time", include_no_booking=False),
    )


@router.callback_query(AddBooking.choosing_checkin_time, F.data.startswith("bm_add_checkin_time:"))
async def add_booking_checkin_time(callback: CallbackQuery, state: FSMContext):
    checkin_time = callback.data.split(":", 1)[1]
    await state.update_data(checkin_time=checkin_time)
    await state.set_state(AddBooking.waiting_checkout_date)
    await callback.message.edit_text("Введите дату выезда в формате 29.06.2026.")
    await callback.answer()


@router.message(AddBooking.waiting_checkout_date, F.text)
async def add_booking_checkout_date(message: Message, state: FSMContext):
    try:
        checkout_date = booking_service.parse_date(message.text)
    except ValueError as exc:
        await message.answer(str(exc))
        return

    data = await state.get_data()
    if checkout_date < data["checkin_date"]:
        await message.answer("Дата выезда не может быть раньше даты заезда.")
        return

    await state.update_data(checkout_date=checkout_date)
    await state.set_state(AddBooking.choosing_checkout_time)
    await message.answer(
        "Выберите время выезда:",
        reply_markup=checkout_times_keyboard("bm_add_checkout_time"),
    )


@router.callback_query(AddBooking.choosing_checkout_time, F.data.startswith("bm_add_checkout_time:"))
async def add_booking_checkout_time(callback: CallbackQuery, state: FSMContext):
    value = callback.data.split(":", 1)[1]
    if value == "manual":
        await state.set_state(AddBooking.waiting_checkout_time)
        await callback.message.edit_text("Введите время выезда вручную в формате 10:30.")
        await callback.answer()
        return

    await state.update_data(checkout_time=value)
    await state.set_state(AddBooking.choosing_guests)
    await callback.message.edit_text(
        "Укажите количество гостей:",
        reply_markup=guests_keyboard("bm_add_guests"),
    )
    await callback.answer()


@router.message(AddBooking.waiting_checkout_time, F.text)
async def add_booking_checkout_time_manual(message: Message, state: FSMContext):
    try:
        checkout_time = booking_service.parse_time(message.text)
    except ValueError as exc:
        await message.answer(str(exc))
        return

    await state.update_data(checkout_time=checkout_time)
    await state.set_state(AddBooking.choosing_guests)
    await message.answer("Укажите количество гостей:", reply_markup=guests_keyboard("bm_add_guests"))


@router.callback_query(AddBooking.choosing_guests, F.data.startswith("bm_add_guests:"))
async def add_booking_guests(
    callback: CallbackQuery,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=BOOKING_MANAGER_ROLES)
    if not user:
        return

    guests_count = int(callback.data.split(":", 1)[1])
    data = await state.get_data()
    booking = await booking_service.create_booking(
        db,
        settings.timezone,
        apartment_id=int(data["apartment_id"]),
        checkin_date=data["checkin_date"],
        checkin_time=data["checkin_time"],
        checkout_date=data["checkout_date"],
        checkout_time=data["checkout_time"],
        guests_count=guests_count,
        created_by=user["id"],
    )
    await state.clear()

    if booking["cleaning_task_id"]:
        await _notify_checkout_plan(bot, db, settings, booking)

    checkin = booking_service.next_checkin_label(booking["checkin_time"])
    await callback.message.edit_text(
        "Бронь добавлена:\n"
        f"{apartment_label(booking)}\n"
        f"Заезд: {booking['checkin_date']} {checkin}\n"
        f"Выезд: {booking['checkout_date']} {booking['checkout_time']}\n"
        f"Гостей: {guests_count}"
    )
    await callback.answer()
