from typing import Iterable, Optional

import aiosqlite
from aiogram.types import Message, User

from app.config import Settings
from app.models import ROLE_LABELS
from app.repositories import users as user_repo


async def resolve_user(db: aiosqlite.Connection, settings: Settings, telegram_user: User):
    if telegram_user.id in settings.admin_telegram_ids:
        return await user_repo.ensure_admin(db, telegram_user.id, telegram_user.full_name)
    return await user_repo.get_by_telegram_id(db, telegram_user.id)


async def require_user(
    message: Message,
    db: aiosqlite.Connection,
    settings: Settings,
    roles: Optional[Iterable[str]] = None,
):
    user = await resolve_user(db, settings, message.from_user)
    if not user:
        await message.answer(
            "Вы пока не зарегистрированы в боте.\n"
            f"Ваш Telegram ID: {message.from_user.id}\n"
            "Передайте этот ID администратору."
        )
        return None
    if roles and user["role"] not in roles:
        allowed = ", ".join(ROLE_LABELS.get(role, role) for role in roles)
        await message.answer(f"Это действие доступно только для роли: {allowed}.")
        return None
    return user


async def require_callback_user(callback, db, settings, roles: Optional[Iterable[str]] = None):
    user = await resolve_user(db, settings, callback.from_user)
    if not user:
        await callback.answer("Вы не зарегистрированы.", show_alert=True)
        return None
    if roles and user["role"] not in roles:
        await callback.answer("Недостаточно прав.", show_alert=True)
        return None
    return user

