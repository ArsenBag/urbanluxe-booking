import aiosqlite
from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.handlers.access import require_callback_user, require_user, resolve_user
from app.handlers.states import MaidShiftEnd
from app.i18n import button_values, language_of, tr
from app.keyboards import common as common_kb
from app.keyboards.common import main_menu
from app.keyboards.booking_manager import bookings_keyboard
from app.keyboards.maid import (
    maid_tasks_keyboard,
    shift_cart_photo_keyboard,
    shift_start_confirm_keyboard as maid_shift_start_confirm_keyboard,
)
from app.keyboards.supervisor import (
    shift_end_confirm_keyboard as supervisor_shift_end_confirm_keyboard,
    shift_start_confirm_keyboard as supervisor_shift_start_confirm_keyboard,
    tasks_keyboard,
)
from app.models import ROLE_LABELS, Role
from app.repositories import bookings as booking_repo
from app.repositories import cleaning_tasks as task_repo
from app.repositories import users as user_repo
from app.services import booking_service, cleaning_service, shift_service
from app.services.formatting import compact_apartment_code
from app.services.notifications import notify_maid_shift_ended


router = Router()


def _admin_users_keyboard(rows) -> InlineKeyboardMarkup:
    keyboard = []
    for row in rows:
        status = "✅" if row["is_active"] else "🚫"
        role = ROLE_LABELS.get(row["role"], row["role"])
        keyboard.append(
            [
                InlineKeyboardButton(
                    text=f"{status} {row['full_name']} · {role}",
                    callback_data=f"admin_user:{row['id']}",
                )
            ]
        )
    keyboard.append(
        [InlineKeyboardButton(text="Добавить пользователя", callback_data="admin_user_add_help")]
    )
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


def _admin_user_actions(row, current_user_id: int) -> InlineKeyboardMarkup:
    keyboard = []
    if row["is_active"]:
        if row["id"] != current_user_id:
            keyboard.append(
                [InlineKeyboardButton(text="Отключить", callback_data=f"admin_deactivate:{row['id']}")]
            )
    else:
        keyboard.append(
            [InlineKeyboardButton(text="Включить", callback_data=f"admin_reactivate:{row['id']}")]
        )
    keyboard.append([InlineKeyboardButton(text="К списку", callback_data="admin_users_list")])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


def _admin_user_text(row) -> str:
    status = "активен" if row["is_active"] else "отключен"
    role = ROLE_LABELS.get(row["role"], row["role"])
    telegram_id = row["telegram_id"] or "ID не указан"
    return (
        f"{row['full_name']}\n"
        f"Роль: {role}\n"
        f"Статус: {status}\n"
        f"Telegram ID: {telegram_id}"
    )


async def _send_admin_users(message: Message, db: aiosqlite.Connection):
    rows = await user_repo.list_all(db)
    if not rows:
        await message.answer("Пользователей пока нет.")
        return
    await message.answer("Пользователи:", reply_markup=_admin_users_keyboard(rows))


def _reconcile_summary_text(result: dict) -> str:
    created_count = len(result["created"])
    repaired_count = len(result["repaired"])
    restored = result["created"] + result["repaired"]
    unlinked_tasks = result.get("unlinked_tasks") or []

    lines = [
        f"Сверка уборок за {result['date']}:",
        f"Уборок в графике: {result.get('task_count', result['checked'])}",
        f"Локальных броней с выездом: {result['checked']}",
        f"Связано с бронями: {result.get('linked_task_count', result['checked'])}",
        f"Без локальной брони: {result.get('unlinked_task_count', 0)}",
        f"Создано уборок: {created_count}",
        f"Восстановлено уборок: {repaired_count}",
        f"Обновлено следующих заездов: {result.get('checkins_updated', 0)}",
    ]

    daily_task_count = result.get("daily_task_count", 0)
    if daily_task_count:
        lines.append(f"Ежедневных уборок в графике: {daily_task_count}")

    if restored:
        lines.extend(["", "Нужно проверить назначение:"])
        for item in restored[:15]:
            checkin_text = "заезда нет" if item["no_next_booking"] else (item["next_checkin_time"] or "-")
            lines.append(
                f"{compact_apartment_code(item['apartment_code'])}: "
                f"выезд {item['checkout_time']}, заезд {checkin_text}"
            )
        if len(restored) > 15:
            lines.append(f"...и еще {len(restored) - 15}")
    else:
        lines.append("По имеющимся локальным броням пропавших уборок не найдено.")

    if unlinked_tasks:
        lines.extend(
            [
                "",
                "Уборки без локальной брони есть в графике, но сверка не может проверить их по данным RealtyCalendar:",
            ]
        )
        for item in unlinked_tasks[:15]:
            type_label = "ежедневная" if item["cleaning_type"] == "daily" else "без брони"
            lines.append(
                f"{compact_apartment_code(item['apartment_code'])} · {type_label}"
            )
        if len(unlinked_tasks) > 15:
            lines.append(f"...и еще {len(unlinked_tasks) - 15}")

    return "\n".join(lines)


async def _run_today_reconcile(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(
        message,
        db,
        settings,
        roles=[Role.ADMIN.value, Role.SUPERVISOR.value],
    )
    if not user:
        return

    today_value = cleaning_service.today_iso(settings.timezone)
    result = await booking_service.reconcile_cleaning_tasks_for_date(
        db,
        settings.timezone,
        today_value,
        user_id=user["id"],
    )
    await message.answer(_reconcile_summary_text(result))


@router.message(Command("start"))
async def start(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    await state.clear()
    user = await resolve_user(db, settings, message.from_user)
    if not user:
        await message.answer(
            "Здравствуйте. Вы пока не зарегистрированы в боте.\n\n"
            f"Ваш Telegram ID: {message.from_user.id}\n"
            "Передайте этот ID администратору, чтобы он добавил вас в список сотрудников."
        )
        return

    role_label = ROLE_LABELS.get(user["role"], user["role"])
    language = language_of(user)
    reply_markup = main_menu(user["role"], language)
    if user["role"] == Role.MAID.value:
        if not user["language"]:
            await message.answer(
                tr(language, "language_prompt"),
                reply_markup=common_kb.language_keyboard(),
            )
            return
        shift = await shift_service.active_shift(db, settings.timezone, user["id"])
        reply_markup = (
            common_kb.maid_menu(language)
            if shift
            else common_kb.maid_shift_start_menu(language)
        )
    elif user["role"] == Role.SUPERVISOR.value:
        shift = await shift_service.active_shift(db, settings.timezone, user["id"])
        reply_markup = common_kb.supervisor_menu() if shift else common_kb.supervisor_shift_start_menu()

    text = (
        tr(language, "greeting", name=user["full_name"])
        if user["role"] == Role.MAID.value
        else f"Здравствуйте, {user['full_name']}.\nРоль: {role_label}"
    )
    await message.answer(text, reply_markup=reply_markup)


@router.message(F.text.in_(button_values("menu_language")))
async def choose_maid_language(
    message: Message,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    await message.answer(
        tr(language_of(user), "language_prompt"),
        reply_markup=common_kb.language_keyboard(),
    )


@router.callback_query(F.data.startswith("maid_language:"))
async def save_maid_language(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.MAID.value])
    if not user:
        return
    language = callback.data.split(":", 1)[1]
    if language not in ("ru", "uz"):
        await callback.answer("Unsupported language", show_alert=True)
        return

    user = await user_repo.set_language(db, user["id"], language)
    shift = await shift_service.active_shift(db, settings.timezone, user["id"])
    reply_markup = (
        common_kb.maid_menu(language)
        if shift
        else common_kb.maid_shift_start_menu(language)
    )
    await callback.message.edit_text(tr(language, "language_saved"))
    await callback.message.answer(
        tr(language, "greeting", name=user["full_name"]),
        reply_markup=reply_markup,
    )
    await callback.answer()


@router.message(Command("help"))
async def help_command(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings)
    if not user:
        return

    if user["role"] == Role.MAID.value:
        await message.answer(tr(language_of(user), "help"))
        return

    await message.answer(
        "Основные команды:\n"
        "/start - главное меню\n"
        "/today - задачи на сегодня\n"
        "/sync_today - сверить и восстановить уборки за сегодня\n"
        "/report - отчет за день\n"
        "/whoami - показать ваш Telegram ID"
    )


@router.message(Command("whoami"))
async def whoami(message: Message):
    await message.answer(f"Ваш Telegram ID: {message.from_user.id}")


@router.message(F.text.in_(button_values("menu_shift_start") | {common_kb.SUP_SHIFT_START}))
async def shift_start_request(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings)
    if not user:
        return

    if user["role"] not in (Role.MAID.value, Role.SUPERVISOR.value):
        await message.answer("Это действие доступно только для роли: Горничная или Супервизор.")
        return

    language = language_of(user)
    current = shift_service.now(settings.timezone)
    if current.time() >= shift_service.AUTO_CLOSE_TIME:
        if user["role"] == Role.MAID.value:
            await message.answer(tr(language, "shift_after_21"))
        else:
            await message.answer("После 21:00 смену открыть нельзя. Обратитесь к администратору.")
        return

    active = await shift_service.active_shift(db, settings.timezone, user["id"])
    if active:
        reply_markup = (
            common_kb.maid_menu(language)
            if user["role"] == Role.MAID.value
            else common_kb.supervisor_menu(include_shift=True)
        )
        text = (
            tr(language, "shift_already_open", time=shift_service.format_shift_time(active["started_at"]))
            if user["role"] == Role.MAID.value
            else f"Смена уже открыта. Время прихода: {shift_service.format_shift_time(active['started_at'])}"
        )
        await message.answer(text, reply_markup=reply_markup)
        return

    reply_markup = (
        maid_shift_start_confirm_keyboard(language)
        if user["role"] == Role.MAID.value
        else supervisor_shift_start_confirm_keyboard()
    )
    text = tr(language, "shift_confirm") if user["role"] == Role.MAID.value else "Подтвердите приход на смену."
    await message.answer(text, reply_markup=reply_markup)


@router.message(F.text.in_(button_values("menu_shift_end") | {common_kb.SUP_SHIFT_END}))
async def shift_end_request(
    message: Message,
    state: FSMContext,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings)
    if not user:
        return

    if user["role"] not in (Role.MAID.value, Role.SUPERVISOR.value):
        await message.answer("Это действие доступно только для роли: Горничная или Супервизор.")
        return

    language = language_of(user)
    active = await shift_service.active_shift(db, settings.timezone, user["id"])
    if not active:
        reply_markup = (
            common_kb.maid_shift_start_menu(language)
            if user["role"] == Role.MAID.value
            else common_kb.supervisor_shift_start_menu()
        )
        text = tr(language, "shift_not_open") if user["role"] == Role.MAID.value else "Открытой смены сейчас нет."
        await message.answer(text, reply_markup=reply_markup)
        return

    if user["role"] == Role.MAID.value:
        blockers = await shift_service.maid_shift_end_blockers(
            db,
            settings.timezone,
            user["id"],
        )
        if blockers:
            await state.clear()
            await message.answer(
                shift_service.format_maid_shift_end_blockers(blockers, language),
                reply_markup=common_kb.maid_menu(language),
            )
            return
        await state.set_state(MaidShiftEnd.waiting_cart_photo)
        await state.update_data(language=language)
        await message.answer(
            tr(language, "shift_cart_photo_prompt"),
            reply_markup=shift_cart_photo_keyboard(language),
        )
        return

    await state.clear()
    await message.answer(
        "Подтвердите завершение смены.",
        reply_markup=supervisor_shift_end_confirm_keyboard(),
    )


@router.message(MaidShiftEnd.waiting_cart_photo, F.photo)
async def maid_shift_end_cart_photo(
    message: Message,
    state: FSMContext,
    bot: Bot,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_user(message, db, settings, roles=[Role.MAID.value])
    if not user:
        await state.clear()
        return
    language = language_of(user)
    cart_photo_file_id = message.photo[-1].file_id
    try:
        shift = await shift_service.end_maid_shift(
            db,
            settings.timezone,
            user["id"],
            cart_photo_file_id,
        )
    except ValueError:
        blockers = await shift_service.maid_shift_end_blockers(
            db,
            settings.timezone,
            user["id"],
        )
        await state.clear()
        await message.answer(
            shift_service.format_maid_shift_end_blockers(blockers, language),
            reply_markup=common_kb.maid_menu(language),
        )
        return

    await state.clear()
    if not shift:
        await message.answer(
            tr(language, "shift_not_open"),
            reply_markup=common_kb.maid_shift_start_menu(language),
        )
        return
    await notify_maid_shift_ended(
        bot,
        db,
        settings,
        user["full_name"],
        shift["ended_at"],
        cart_photo_file_id,
    )
    await message.answer(
        tr(language, "shift_closed", time=shift_service.format_shift_time(shift["ended_at"])),
        reply_markup=common_kb.maid_shift_start_menu(language),
    )


@router.message(MaidShiftEnd.waiting_cart_photo)
async def maid_shift_end_cart_photo_required(message: Message, state: FSMContext):
    data = await state.get_data()
    language = data.get("language")
    await message.answer(
        tr(language, "shift_cart_photo_required"),
        reply_markup=shift_cart_photo_keyboard(language),
    )


@router.message(Command("today"))
async def today(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings)
    if not user:
        return

    today_value = cleaning_service.today_iso(settings.timezone)
    if user["role"] == Role.MAID.value:
        language = language_of(user)
        shift = await shift_service.active_shift(db, settings.timezone, user["id"])
        if not shift:
            await message.answer(
                tr(language, "shift_required"),
                reply_markup=common_kb.maid_shift_start_menu(language),
            )
            return
        tasks = await task_repo.list_for_maid(db, user["id"], today_value)
        if not tasks:
            await message.answer(tr(language, "no_tasks_today"))
            return
        await message.answer(
            tr(language, "tasks_today"),
            reply_markup=maid_tasks_keyboard(tasks, language=language),
        )
        return

    if user["role"] == Role.BOOKING_MANAGER.value:
        bookings = await booking_repo.list_checkout_date(db, today_value)
        if not bookings:
            await message.answer("На сегодня выездов пока нет.")
            return
        await message.answer("Выезды сегодня:", reply_markup=bookings_keyboard(bookings, "bm_checkout_select"))
        return

    if user["role"] == Role.SUPERVISOR.value:
        shift = await shift_service.active_shift(db, settings.timezone, user["id"])
        if not shift:
            await message.answer(
                "Сначала отметьте приход на смену.",
                reply_markup=common_kb.supervisor_shift_start_menu(),
            )
            return

    tasks = await task_repo.list_for_date(db, today_value)
    if not tasks:
        await message.answer("На сегодня уборок пока нет.")
        return
    await message.answer(f"Уборки сегодня: {len(tasks)}", reply_markup=tasks_keyboard(tasks, "sup_task"))


@router.message(Command("sync_today"))
async def sync_today_command(message: Message, db: aiosqlite.Connection, settings: Settings):
    await _run_today_reconcile(message, db, settings)


@router.message(F.text == common_kb.SUP_RECONCILE)
async def sync_today_button(message: Message, db: aiosqlite.Connection, settings: Settings):
    await _run_today_reconcile(message, db, settings)


@router.message(Command("users"))
async def list_users(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=[Role.ADMIN.value])
    if not user:
        return

    await _send_admin_users(message, db)


@router.message(F.text == common_kb.ADMIN_USERS)
async def admin_users_button(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=[Role.ADMIN.value])
    if not user:
        return

    await _send_admin_users(message, db)


@router.message(F.text == common_kb.ADMIN_ADD_USER)
async def admin_add_user_button(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=[Role.ADMIN.value])
    if not user:
        return

    await message.answer(
        "Чтобы добавить пользователя, отправьте команду:\n"
        "/add_user role telegram_id Имя Фамилия\n\n"
        "Роли: maid, supervisor, booking_manager, admin\n"
        "Если Telegram ID пока нет, укажите 0."
    )


@router.callback_query(F.data == "admin_users_list")
async def admin_users_list_callback(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.ADMIN.value])
    if not user:
        return

    rows = await user_repo.list_all(db)
    if callback.message:
        await callback.message.edit_text("Пользователи:", reply_markup=_admin_users_keyboard(rows))
    await callback.answer()


@router.callback_query(F.data == "admin_user_add_help")
async def admin_user_add_help(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=[Role.ADMIN.value])
    if not user:
        return

    if callback.message:
        await callback.message.answer(
            "Чтобы добавить пользователя, отправьте команду:\n"
            "/add_user role telegram_id Имя Фамилия\n\n"
            "Роли: maid, supervisor, booking_manager, admin\n"
            "Если Telegram ID пока нет, укажите 0."
        )
    await callback.answer()


@router.callback_query(F.data.startswith("admin_user:"))
async def admin_user_card(callback: CallbackQuery, db: aiosqlite.Connection, settings: Settings):
    user = await require_callback_user(callback, db, settings, roles=[Role.ADMIN.value])
    if not user:
        return

    user_id = int(callback.data.split(":", 1)[1])
    row = await user_repo.get_any_by_id(db, user_id)
    if not row:
        await callback.answer("Пользователь не найден.", show_alert=True)
        return
    if callback.message:
        await callback.message.edit_text(
            _admin_user_text(row),
            reply_markup=_admin_user_actions(row, user["id"]),
        )
    await callback.answer()


@router.callback_query(F.data.startswith("admin_deactivate:"))
async def admin_deactivate_user(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.ADMIN.value])
    if not user:
        return

    user_id = int(callback.data.split(":", 1)[1])
    if user_id == user["id"]:
        await callback.answer("Себя отключить нельзя.", show_alert=True)
        return
    row = await user_repo.deactivate_user(db, user_id)
    if not row:
        await callback.answer("Пользователь не найден.", show_alert=True)
        return
    if callback.message:
        await callback.message.edit_text(
            _admin_user_text(row),
            reply_markup=_admin_user_actions(row, user["id"]),
        )
    await callback.answer("Пользователь отключен.")


@router.callback_query(F.data.startswith("admin_reactivate:"))
async def admin_reactivate_user(
    callback: CallbackQuery,
    db: aiosqlite.Connection,
    settings: Settings,
):
    user = await require_callback_user(callback, db, settings, roles=[Role.ADMIN.value])
    if not user:
        return

    user_id = int(callback.data.split(":", 1)[1])
    row = await user_repo.reactivate_user(db, user_id)
    if not row:
        await callback.answer("Пользователь не найден.", show_alert=True)
        return
    if callback.message:
        await callback.message.edit_text(
            _admin_user_text(row),
            reply_markup=_admin_user_actions(row, user["id"]),
        )
    await callback.answer("Пользователь включен.")


@router.message(Command("add_user"))
async def add_user(message: Message, db: aiosqlite.Connection, settings: Settings):
    user = await require_user(message, db, settings, roles=[Role.ADMIN.value])
    if not user:
        return

    parts = (message.text or "").split(maxsplit=3)
    if len(parts) < 4:
        await message.answer(
            "Формат:\n"
            "/add_user role telegram_id Имя Фамилия\n\n"
            "Роли: maid, supervisor, booking_manager, admin"
        )
        return

    _, role, telegram_id_raw, full_name = parts
    if role not in {item.value for item in Role}:
        await message.answer("Неизвестная роль. Используйте maid, supervisor, booking_manager или admin.")
        return

    telegram_id = None
    if telegram_id_raw not in ("0", "-", "none"):
        try:
            telegram_id = int(telegram_id_raw)
        except ValueError:
            await message.answer("Telegram ID должен быть числом. Если ID пока нет, укажите 0.")
            return

    await user_repo.create_or_update_user(db, role, telegram_id, full_name)
    await message.answer(f"Пользователь добавлен: {full_name} · {ROLE_LABELS.get(role, role)}")
