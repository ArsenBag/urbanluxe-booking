CREATE TABLE IF NOT EXISTS maid_shifts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    maid_id INTEGER NOT NULL,
    work_date TEXT NOT NULL,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    auto_closed INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (maid_id) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_maid_shifts_maid_date ON maid_shifts(maid_id, work_date);
CREATE INDEX IF NOT EXISTS idx_maid_shifts_open ON maid_shifts(ended_at);

