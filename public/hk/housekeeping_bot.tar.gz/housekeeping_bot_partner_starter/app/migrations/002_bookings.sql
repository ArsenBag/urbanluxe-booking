CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    apartment_id INTEGER NOT NULL,
    checkin_date TEXT,
    checkin_time TEXT,
    checkout_date TEXT NOT NULL,
    checkout_time TEXT,
    guests_count INTEGER,
    status TEXT NOT NULL DEFAULT 'planned'
        CHECK (status IN ('planned', 'checked_out', 'cleaning_created', 'ready', 'canceled')),
    actual_checkout_at TEXT,
    next_checkin_time TEXT,
    no_next_booking INTEGER NOT NULL DEFAULT 0,
    cleaning_task_id INTEGER,
    created_by INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (apartment_id) REFERENCES apartments(id),
    FOREIGN KEY (cleaning_task_id) REFERENCES cleaning_tasks(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_bookings_checkout_date ON bookings(checkout_date);
CREATE INDEX IF NOT EXISTS idx_bookings_checkin_date ON bookings(checkin_date);
CREATE INDEX IF NOT EXISTS idx_bookings_apartment ON bookings(apartment_id);
CREATE INDEX IF NOT EXISTS idx_bookings_cleaning_task ON bookings(cleaning_task_id);

