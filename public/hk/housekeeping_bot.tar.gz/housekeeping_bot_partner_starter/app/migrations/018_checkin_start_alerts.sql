CREATE TABLE IF NOT EXISTS checkin_start_alert_deliveries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    checkin_at TEXT NOT NULL,
    recipient_user_id INTEGER NOT NULL,
    delivered_at TEXT NOT NULL,
    FOREIGN KEY (task_id) REFERENCES cleaning_tasks(id),
    FOREIGN KEY (recipient_user_id) REFERENCES users(id),
    UNIQUE(task_id, checkin_at, recipient_user_id)
);

CREATE INDEX IF NOT EXISTS idx_checkin_start_alert_task
ON checkin_start_alert_deliveries(task_id, checkin_at);
