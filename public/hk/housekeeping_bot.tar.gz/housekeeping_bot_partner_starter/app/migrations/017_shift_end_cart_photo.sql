ALTER TABLE maid_shifts ADD COLUMN end_cart_photo_file_id TEXT;
ALTER TABLE maid_shifts ADD COLUMN end_cart_photo_uploaded_at TEXT;
