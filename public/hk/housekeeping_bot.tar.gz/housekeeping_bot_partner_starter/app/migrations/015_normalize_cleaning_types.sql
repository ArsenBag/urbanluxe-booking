UPDATE cleaning_tasks
SET cleaning_type = CASE cleaning_type
    WHEN 'standard' THEN 'standard'
    WHEN 'light_deep_clean' THEN 'general'
    WHEN 'full_deep_clean' THEN 'general'
    WHEN 'heavy_recovery' THEN 'general'
    WHEN 'pre_checkin_refresh' THEN 'daily'
    WHEN 'general' THEN 'general'
    WHEN 'daily' THEN 'daily'
    ELSE 'standard'
END
WHERE cleaning_type NOT IN ('standard', 'general', 'daily');

CREATE TRIGGER IF NOT EXISTS validate_cleaning_type_insert
BEFORE INSERT ON cleaning_tasks
WHEN NEW.cleaning_type NOT IN ('standard', 'general', 'daily')
BEGIN
    SELECT RAISE(ABORT, 'invalid cleaning_type');
END;

CREATE TRIGGER IF NOT EXISTS validate_cleaning_type_update
BEFORE UPDATE OF cleaning_type ON cleaning_tasks
WHEN NEW.cleaning_type NOT IN ('standard', 'general', 'daily')
BEGIN
    SELECT RAISE(ABORT, 'invalid cleaning_type');
END;
