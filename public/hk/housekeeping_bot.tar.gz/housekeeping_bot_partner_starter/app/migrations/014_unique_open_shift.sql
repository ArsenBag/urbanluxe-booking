UPDATE maid_shifts
SET ended_at = CURRENT_TIMESTAMP,
    auto_closed = 1
WHERE ended_at IS NULL
  AND id NOT IN (
      SELECT MAX(id)
      FROM maid_shifts
      WHERE ended_at IS NULL
      GROUP BY maid_id
  );

CREATE UNIQUE INDEX IF NOT EXISTS idx_maid_shifts_one_open
ON maid_shifts(maid_id)
WHERE ended_at IS NULL;
