ALTER TABLE apartments ADD COLUMN realty_id INTEGER;
CREATE INDEX IF NOT EXISTS idx_apartments_realty_id ON apartments(realty_id);

ALTER TABLE bookings ADD COLUMN external_booking_id TEXT;
ALTER TABLE bookings ADD COLUMN realty_id INTEGER;
ALTER TABLE bookings ADD COLUMN source TEXT;
ALTER TABLE bookings ADD COLUMN external_status TEXT;
ALTER TABLE bookings ADD COLUMN raw_payload_json TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS idx_bookings_external_booking
ON bookings(external_booking_id)
WHERE external_booking_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS realty_webhook_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT,
    external_booking_id TEXT,
    payload_json TEXT NOT NULL,
    processed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_realty_webhook_events_booking
ON realty_webhook_events(external_booking_id);

