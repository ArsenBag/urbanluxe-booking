UPDATE bookings
SET checkin_time = '15:00'
WHERE source = 'realtycalendar'
  AND (checkin_time IS NULL OR checkin_time = '');

UPDATE bookings
SET checkout_time = '12:00'
WHERE source = 'realtycalendar'
  AND (checkout_time IS NULL OR checkout_time = '');

UPDATE bookings
SET next_checkin_time = '15:00',
    no_next_booking = 0
WHERE source = 'realtycalendar'
  AND (next_checkin_time IS NULL OR next_checkin_time = '');

UPDATE cleaning_tasks
SET deadline_at = (
        SELECT b.checkout_date || 'T' ||
            CASE
                WHEN COALESCE(NULLIF(b.next_checkin_time, ''), '15:00') = 'after_18' THEN '18:00'
                ELSE COALESCE(NULLIF(b.next_checkin_time, ''), '15:00')
            END || ':00+05:00'
        FROM bookings b
        WHERE b.cleaning_task_id = cleaning_tasks.id
          AND b.source = 'realtycalendar'
        LIMIT 1
    ),
    updated_at = CURRENT_TIMESTAMP
WHERE id IN (
    SELECT cleaning_task_id
    FROM bookings
    WHERE source = 'realtycalendar'
      AND cleaning_task_id IS NOT NULL
)
  AND (deadline_at IS NULL OR deadline_at = '');
