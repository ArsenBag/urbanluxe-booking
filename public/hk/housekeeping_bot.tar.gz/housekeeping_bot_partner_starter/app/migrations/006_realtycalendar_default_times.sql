UPDATE bookings
SET checkin_time = '15:00'
WHERE source = 'realtycalendar'
  AND (checkin_time IS NULL OR checkin_time = '');

UPDATE bookings
SET checkout_time = '12:00'
WHERE source = 'realtycalendar'
  AND (checkout_time IS NULL OR checkout_time = '');
