UPDATE bookings
SET next_checkin_time = NULL,
    no_next_booking = 1,
    updated_at = CURRENT_TIMESTAMP
WHERE source = 'realtycalendar'
  AND status != 'canceled'
  AND checkout_date IS NOT NULL
  AND NOT EXISTS (
      SELECT 1
      FROM bookings next_booking
      WHERE next_booking.apartment_id = bookings.apartment_id
        AND next_booking.checkin_date = bookings.checkout_date
        AND next_booking.status != 'canceled'
        AND next_booking.id != bookings.id
  );

UPDATE bookings
SET next_checkin_time = (
        SELECT COALESCE(NULLIF(next_booking.checkin_time, ''), '15:00')
        FROM bookings next_booking
        WHERE next_booking.apartment_id = bookings.apartment_id
          AND next_booking.checkin_date = bookings.checkout_date
          AND next_booking.status != 'canceled'
          AND next_booking.id != bookings.id
        ORDER BY COALESCE(NULLIF(next_booking.checkin_time, ''), '99:99'), next_booking.id
        LIMIT 1
    ),
    no_next_booking = 0,
    updated_at = CURRENT_TIMESTAMP
WHERE source = 'realtycalendar'
  AND status != 'canceled'
  AND checkout_date IS NOT NULL
  AND EXISTS (
      SELECT 1
      FROM bookings next_booking
      WHERE next_booking.apartment_id = bookings.apartment_id
        AND next_booking.checkin_date = bookings.checkout_date
        AND next_booking.status != 'canceled'
        AND next_booking.id != bookings.id
  );

UPDATE cleaning_tasks
SET deadline_at = NULL,
    comment = (
        SELECT 'Источник: RealtyCalendar.' || char(10) ||
               'Автоматически создано из выезда.' || char(10) ||
               'Плановый выезд: ' || COALESCE(NULLIF(bookings.checkout_time, ''), '12:00') || char(10) ||
               'Следующей брони нет.'
        FROM bookings
        WHERE bookings.cleaning_task_id = cleaning_tasks.id
          AND bookings.source = 'realtycalendar'
          AND bookings.no_next_booking = 1
        LIMIT 1
    ),
    updated_at = CURRENT_TIMESTAMP
WHERE id IN (
    SELECT cleaning_task_id
    FROM bookings
    WHERE source = 'realtycalendar'
      AND no_next_booking = 1
      AND cleaning_task_id IS NOT NULL
)
  AND status IN ('plan', 'guest_checked_out', 'assigned');
