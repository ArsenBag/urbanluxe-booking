ALTER TABLE cleaning_tasks ADD COLUMN problem_reported_at TEXT;
ALTER TABLE cleaning_tasks ADD COLUMN problem_resolved_at TEXT;

UPDATE cleaning_tasks
SET problem_reported_at = updated_at
WHERE status = 'problem'
  AND problem_reported_at IS NULL;
