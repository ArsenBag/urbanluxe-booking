ALTER TABLE users ADD COLUMN language TEXT;

UPDATE users
SET language = 'ru'
WHERE language IS NULL;

CREATE TRIGGER IF NOT EXISTS validate_user_language_insert
BEFORE INSERT ON users
WHEN NEW.language IS NOT NULL AND NEW.language NOT IN ('ru', 'uz')
BEGIN
    SELECT RAISE(ABORT, 'invalid user language');
END;

CREATE TRIGGER IF NOT EXISTS validate_user_language_update
BEFORE UPDATE OF language ON users
WHEN NEW.language IS NOT NULL AND NEW.language NOT IN ('ru', 'uz')
BEGIN
    SELECT RAISE(ABORT, 'invalid user language');
END;
