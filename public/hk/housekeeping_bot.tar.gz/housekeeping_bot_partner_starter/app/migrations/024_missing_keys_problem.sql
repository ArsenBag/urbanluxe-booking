ALTER TABLE cleaning_tasks ADD COLUMN keys_missing_reported_at TEXT;
ALTER TABLE cleaning_tasks ADD COLUMN keys_missing_resolved_at TEXT;

CREATE INDEX IF NOT EXISTS idx_cleaning_tasks_open_missing_keys
    ON cleaning_tasks(apartment_id)
    WHERE keys_missing_reported_at IS NOT NULL
      AND keys_missing_resolved_at IS NULL;
