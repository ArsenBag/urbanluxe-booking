ALTER TABLE cleaning_tasks
    ADD COLUMN verification_method TEXT
    CHECK (verification_method IN ('in_person', 'video'));

ALTER TABLE cleaning_tasks
    ADD COLUMN verified_by_user_id INTEGER REFERENCES users(id);

UPDATE cleaning_tasks
SET verified_by_user_id = (
    SELECT event.user_id
    FROM cleaning_events event
    WHERE event.task_id = cleaning_tasks.id
      AND event.event_type = 'verified'
      AND event.user_id IS NOT NULL
    ORDER BY event.id DESC
    LIMIT 1
)
WHERE verified_at IS NOT NULL
  AND verified_by_user_id IS NULL;
