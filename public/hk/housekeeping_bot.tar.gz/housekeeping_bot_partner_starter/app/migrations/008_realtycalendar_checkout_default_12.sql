UPDATE bookings
SET checkout_time = '12:00'
WHERE source = 'realtycalendar'
  AND checkout_time = '15:00'
  AND (
      raw_payload_json IS NULL
      OR raw_payload_json NOT LIKE '%departure_time%'
      OR raw_payload_json LIKE '%"departure_time": null%'
      OR raw_payload_json LIKE '%"departure_time": ""%'
  );
