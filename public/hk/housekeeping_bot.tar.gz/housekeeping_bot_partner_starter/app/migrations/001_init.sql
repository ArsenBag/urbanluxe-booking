CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER UNIQUE,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('maid', 'supervisor', 'booking_manager', 'admin')),
    phone TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS apartments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    building TEXT,
    address TEXT,
    floor INTEGER,
    apartment_type TEXT NOT NULL,
    area_m2 INTEGER,
    bathrooms_count INTEGER DEFAULT 1,
    beds_count INTEGER DEFAULT 1,
    sofa_beds_count INTEGER DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS cleaning_tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    external_booking_id TEXT,
    apartment_id INTEGER NOT NULL,
    cleaning_type TEXT NOT NULL DEFAULT 'standard',
    status TEXT NOT NULL DEFAULT 'plan',
    assigned_maid_id INTEGER,
    supervisor_id INTEGER,
    planned_date TEXT NOT NULL,
    planned_start_at TEXT,
    deadline_at TEXT,
    started_at TEXT,
    finished_at TEXT,
    verified_at TEXT,
    estimated_duration_min INTEGER,
    actual_duration_min INTEGER,
    quality_score INTEGER,
    rework_required INTEGER NOT NULL DEFAULT 0,
    rework_reason TEXT,
    problem_type TEXT,
    comment TEXT,
    created_by INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (apartment_id) REFERENCES apartments(id),
    FOREIGN KEY (assigned_maid_id) REFERENCES users(id),
    FOREIGN KEY (supervisor_id) REFERENCES users(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    UNIQUE(external_booking_id, apartment_id, planned_date)
);

CREATE TABLE IF NOT EXISTS cleaning_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    user_id INTEGER,
    event_type TEXT NOT NULL,
    old_status TEXT,
    new_status TEXT,
    payload_json TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES cleaning_tasks(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS cleaning_photos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    telegram_file_id TEXT NOT NULL,
    file_path TEXT,
    photo_type TEXT NOT NULL DEFAULT 'after',
    uploaded_by INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES cleaning_tasks(id),
    FOREIGN KEY (uploaded_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS inventory_checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    towels_ok INTEGER,
    shampoo_ok INTEGER,
    soap_ok INTEGER,
    toilet_paper_ok INTEGER,
    water_ok INTEGER,
    tea_coffee_ok INTEGER,
    comment TEXT,
    FOREIGN KEY (task_id) REFERENCES cleaning_tasks(id)
);

CREATE INDEX IF NOT EXISTS idx_cleaning_tasks_date ON cleaning_tasks(planned_date);
CREATE INDEX IF NOT EXISTS idx_cleaning_tasks_status ON cleaning_tasks(status);
CREATE INDEX IF NOT EXISTS idx_cleaning_tasks_maid ON cleaning_tasks(assigned_maid_id);
CREATE INDEX IF NOT EXISTS idx_cleaning_tasks_apartment ON cleaning_tasks(apartment_id);
CREATE INDEX IF NOT EXISTS idx_cleaning_events_task ON cleaning_events(task_id);
CREATE INDEX IF NOT EXISTS idx_cleaning_photos_task ON cleaning_photos(task_id);
