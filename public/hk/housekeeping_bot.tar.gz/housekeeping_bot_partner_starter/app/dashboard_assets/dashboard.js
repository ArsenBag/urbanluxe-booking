const initialUrl = new URL(location.href);
const incomingToken = initialUrl.searchParams.get("token");
if (incomingToken) {
  initialUrl.searchParams.delete("token");
  history.replaceState(null, "", initialUrl);
}
const state = { data: null, selectedMaidId: null, demo: initialUrl.searchParams.get("demo") === "1", building: "" };

const escapeHtml = (value) => String(value ?? "").replace(/[&<>'"]/g, (character) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;",
})[character]);

const formatDuration = (seconds = 0) => {
  const total = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  return hours ? `${hours} ч ${String(minutes).padStart(2, "0")} мин` : `${minutes}:${String(secs).padStart(2, "0")}`;
};

const clockTime = (value) => value ? new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(new Date(value)) : "—";
const statusText = { assigned: "Назначена", in_progress: "Идёт уборка", waiting_check: "Ждёт проверки", verified: "Принята", problem: "Проблема", rework: "Переделка" };

function renderStats() {
  const items = [
    ["На смене", state.data.summary.on_shift],
    ["Сейчас убирают", state.data.summary.cleaning],
    ["На перерыве", state.data.summary.break],
    ["Уборок сегодня", state.data.summary.tasks_total],
    ["Готово", state.data.summary.completed],
    ["Требует внимания", state.data.summary.attention],
  ];
  document.querySelector("#stats").innerHTML = items.map(([label, value]) => `<article class="stat"><span>${label}</span><strong>${value}</strong></article>`).join("");
}

function renderRoster() {
  document.querySelector("#shift-count").textContent = `${state.data.summary.on_shift} на смене`;
  document.querySelector("#maid-list").innerHTML = state.data.maids.map((maid) => {
    const timer = maid.state === "cleaning" ? formatDuration(maid.elapsed_seconds) : maid.state === "break" ? formatDuration(maid.break_seconds) : "";
    const location = maid.task ? `${maid.task.building} · ${maid.task.apartment}` : maid.state_label;
    return `<button class="maid-card state-${maid.state} ${state.selectedMaidId === maid.id ? "selected" : ""}" data-maid-id="${maid.id}">
      <span class="avatar">${escapeHtml(maid.initials)}</span><span class="maid-meta"><strong>${escapeHtml(maid.name)}</strong><span>${escapeHtml(location)}</span></span><span class="maid-time" data-timer-maid="${maid.id}">${timer}</span>
    </button>`;
  }).join("") || `<div class="loading">Никого нет на смене</div>`;
  document.querySelectorAll("[data-maid-id]").forEach((button) => button.addEventListener("click", () => selectMaid(Number(button.dataset.maidId))));
}

function renderWorld() {
  const filteredProperties = state.building ? state.data.properties.filter((property) => property.name === state.building) : state.data.properties;
  const activeProperties = filteredProperties.filter((property) => property.task_count || property.occupants.length);
  const properties = activeProperties.length ? activeProperties : filteredProperties.slice(0, 5);
  document.querySelector("#property-world").innerHTML = properties.map((property) => `<article class="property-card">
    <div class="property-head"><strong>${escapeHtml(property.name)}</strong><span>${property.task_count} уборок · ${property.apartment_count} апарт.</span></div>
    <div class="rooms">${property.apartments.map((task) => `<span class="room ${task.status}" title="${escapeHtml(statusText[task.status] || task.status)}">${escapeHtml(task.apartment)}</span>`).join("") || `<span class="room">Спокойно</span>`}</div>
    <div class="occupants">${property.occupants.map((maid, index) => `<button class="mini-avatar ${maid.state}" style="animation-delay:${index * .2}s" data-maid-id="${maid.id}" title="${escapeHtml(maid.name)}">${escapeHtml(maid.initials)}</button>`).join("")}</div>
  </article>`).join("");
  document.querySelectorAll(".property-world [data-maid-id]").forEach((button) => button.addEventListener("click", () => selectMaid(Number(button.dataset.maidId))));
}

function selectMaid(id) {
  state.selectedMaidId = id;
  renderRoster();
  const maid = state.data.maids.find((item) => item.id === id);
  if (!maid) return;
  const task = maid.task;
  const timerLabel = maid.state === "cleaning" ? "Время в уборке" : maid.state === "break" ? "Перерыв между уборками" : "Статус";
  const seconds = maid.state === "cleaning" ? maid.elapsed_seconds : maid.break_seconds;
  const activities = state.data.activities.slice(0, 6).map((item) => `<div class="activity-item ${item.tone}">${escapeHtml(item.text)}<time>${clockTime(item.at)}</time></div>`).join("") || `<div class="activity-item">Событий за сегодня пока нет</div>`;
  document.querySelector("#detail-panel").innerHTML = `<div class="detail-name state-${maid.state}"><span class="avatar">${escapeHtml(maid.initials)}</span><div><h2>${escapeHtml(maid.name)}</h2><p>${escapeHtml(maid.state_label)}</p></div></div>
    <div class="detail-card"><label>${task ? `${escapeHtml(task.building)} · апартамент` : "Текущее место"}</label><h3>${task ? escapeHtml(task.apartment) : "—"}</h3><p>${task ? `Этаж ${task.floor || "—"} · ${escapeHtml(statusText[task.status] || maid.state_label)}` : "Нет активной уборки"}</p><span class="big-timer" id="detail-timer">${seconds ? formatDuration(seconds) : escapeHtml(maid.state_label)}</span><small>${timerLabel}</small>
    ${maid.state === "cleaning" ? `<div class="progress"><i style="width:${maid.progress}%"></i></div>` : ""}</div>
    <div class="detail-grid"><div class="detail-metric"><span>Смена начата</span><strong>${clockTime(maid.shift_started_at)}</strong></div><div class="detail-metric"><span>Время на смене</span><strong>${formatDuration(maid.shift_seconds)}</strong></div><div class="detail-metric"><span>Уборок готово</span><strong>${maid.completed_count} / ${maid.total_count}</strong></div><div class="detail-metric"><span>План</span><strong class="${maid.over_estimate ? "overrun" : ""}">${task?.estimated_minutes ? `${task.estimated_minutes} мин` : "—"}</strong></div></div>
    ${maid.next_task && maid.next_task.id !== task?.id ? `<div class="detail-card"><label>Следующая уборка</label><h3>${escapeHtml(maid.next_task.apartment)}</h3><p>${escapeHtml(maid.next_task.building)} · план ${maid.next_task.estimated_minutes || "—"} мин</p></div>` : ""}
    <section class="activity"><h3>Последние события</h3><div class="activity-list">${activities}</div></section>`;
}

function renderFilters() {
  const select = document.querySelector("#building-filter");
  const options = state.data.properties.map((property) => `<option value="${escapeHtml(property.name)}">${escapeHtml(property.name)}</option>`).join("");
  select.innerHTML = `<option value="">Все объекты</option>${options}`;
  select.value = state.building;
}

async function loadData() {
  const query = new URLSearchParams();
  if (state.demo) query.set("demo", "1");
  try {
    const response = await fetch(`/api/dashboard/live?${query}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    state.data = await response.json();
    if (state.selectedMaidId && !state.data.maids.some((maid) => maid.id === state.selectedMaidId)) state.selectedMaidId = null;
    renderStats(); renderRoster(); renderFilters(); renderWorld();
    if (state.selectedMaidId) selectMaid(state.selectedMaidId);
    document.querySelector("#demo-toggle").classList.toggle("active", state.demo);
    document.querySelector("#sync-label").textContent = state.demo ? "Демо · обновлено сейчас" : "В реальном времени";
  } catch (error) {
    document.querySelector("#property-world").innerHTML = `<div class="loading">Не удалось обновить данные. Повторяем…</div>`;
  }
}

document.querySelector("#demo-toggle").addEventListener("click", () => { state.demo = !state.demo; state.selectedMaidId = null; loadData(); });
document.querySelector("#building-filter").addEventListener("change", (event) => { state.building = event.target.value; renderWorld(); });
setInterval(() => {
  document.querySelector("#clock").textContent = new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit", second: "2-digit" }).format(new Date());
  if (!state.data) return;
  state.data.maids.forEach((maid) => { if (maid.state === "cleaning") maid.elapsed_seconds += 1; if (maid.state === "break") maid.break_seconds += 1; if (maid.on_shift) maid.shift_seconds += 1; });
  renderRoster();
  if (state.selectedMaidId) selectMaid(state.selectedMaidId);
}, 1000);
setInterval(loadData, 5000);
loadData();
