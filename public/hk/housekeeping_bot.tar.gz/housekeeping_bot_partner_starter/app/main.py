from __future__ import annotations

import asyncio
import logging
import socket
from contextlib import suppress
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from aiogram import Bot, Dispatcher
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.fsm.storage.memory import MemoryStorage

from app.config import load_settings
from app.db import connect, initialize_database
from app.handlers import booking_manager, common, maid, supervisor
from app.services import booking_service, checkin_alert_service, notifications, shift_service
from app.services.formatting import compact_apartment_code
from app.webhooks import start_webhook_server


logger = logging.getLogger(__name__)


def _reconciliation_alert_text(result: dict) -> str:
    restored = result["created"] + result["repaired"]
    lines = [
        "Контрольная сверка: восстановлены уборки.",
        f"Дата: {result['date']}",
        "",
    ]
    for item in restored[:12]:
        checkin_text = "заезда нет" if item["no_next_booking"] else item["next_checkin_time"]
        lines.append(
            f"{compact_apartment_code(item['apartment_code'])}: "
            f"выезд {item['checkout_time']}, заезд {checkin_text}, "
            f"бронь {item['external_booking_id']}"
        )
    if len(restored) > 12:
        lines.append(f"...и еще {len(restored) - 12}")
    lines.append("")
    lines.append("Проверьте назначение горничной.")
    return "\n".join(lines)


def _link_repair_alert_text(repaired: list[dict]) -> str:
    lines = [
        "Автовосстановление RealtyCalendar: график уборок исправлен.",
        "",
    ]
    for item in repaired[:12]:
        lines.append(
            f"{compact_apartment_code(item['apartment_code'])}: "
            f"выезд {item['checkout_date']} "
            f"{item['checkout_time']}"
        )
    if len(repaired) > 12:
        lines.append(f"...и еще {len(repaired) - 12}")
    lines.extend(("", "Проверьте назначение горничной."))
    return "\n".join(lines)


async def _reconcile_operational_cleanings(db, settings, bot: Bot | None = None) -> None:
    today = datetime.now(ZoneInfo(settings.timezone)).date()
    try:
        link_repairs = await booking_service.repair_inconsistent_realty_cleaning_links(
            db,
            settings.timezone,
            (today - timedelta(days=7)).isoformat(),
            (today + timedelta(days=365)).isoformat(),
            user_id=None,
        )
    except Exception:
        logger.exception("RealtyCalendar cleaning-link recovery failed")
        link_repairs = []

    if link_repairs:
        logger.warning(
            "RealtyCalendar cleaning-link recovery repaired %s bookings",
            len(link_repairs),
        )
        today_repairs = [
            item for item in link_repairs if item["checkout_date"] == today.isoformat()
        ]
        if bot and today_repairs:
            await notifications.notify_supervisors_on_shift(
                bot,
                db,
                settings,
                _link_repair_alert_text(today_repairs),
                fallback_to_admins=True,
            )

    for offset in (0, 1):
        date_value = (today + timedelta(days=offset)).isoformat()
        try:
            result = await booking_service.reconcile_cleaning_tasks_for_date(
                db,
                settings.timezone,
                date_value,
                user_id=None,
            )
        except Exception:
            logger.exception("Startup cleaning reconciliation failed for %s", date_value)
            continue

        recovered_count = len(result["created"]) + len(result["repaired"])
        if recovered_count:
            logger.warning(
                "Cleaning reconciliation restored %s tasks for %s",
                recovered_count,
                date_value,
            )
            if bot and offset == 0:
                await notifications.notify_supervisors_on_shift(
                    bot,
                    db,
                    settings,
                    _reconciliation_alert_text(result),
                    fallback_to_admins=True,
                )


async def _periodic_reconcile_cleanings(db, settings, bot: Bot, realty_sync_lock) -> None:
    while True:
        try:
            await asyncio.sleep(settings.cleaning_reconcile_interval_seconds)
            async with realty_sync_lock:
                await _reconcile_operational_cleanings(db, settings, bot)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Periodic cleaning reconciliation failed")


async def main() -> None:
    logging.basicConfig(level=logging.INFO)
    settings = load_settings()
    if not settings.bot_token:
        raise RuntimeError("BOT_TOKEN is empty. Put your Telegram bot token into .env")

    await initialize_database(settings)
    db = await connect(settings)

    session = AiohttpSession(timeout=settings.telegram_request_timeout)
    if settings.telegram_force_ipv4:
        session._connector_init["family"] = socket.AF_INET

    bot = Bot(token=settings.bot_token, session=session)
    await _reconcile_operational_cleanings(db, settings, bot)
    realty_sync_lock = asyncio.Lock()

    dispatcher = Dispatcher(storage=MemoryStorage())
    dispatcher["settings"] = settings
    dispatcher["db"] = db

    dispatcher.include_router(common.router)
    dispatcher.include_router(booking_manager.router)
    dispatcher.include_router(maid.router)
    dispatcher.include_router(supervisor.router)

    webhook_runner = None
    if settings.realtycalendar_webhook_enabled or settings.dashboard_enabled:
        try:
            webhook_runner = await start_webhook_server(
                settings,
                db,
                bot,
                realty_sync_lock,
            )
        except OSError:
            logging.exception("Webhook server could not start")

    auto_close_task = asyncio.create_task(shift_service.auto_close_loop(settings))
    reconcile_task = asyncio.create_task(
        _periodic_reconcile_cleanings(db, settings, bot, realty_sync_lock)
    )
    checkin_alert_task = asyncio.create_task(
        checkin_alert_service.checkin_start_alert_loop(settings, bot)
    )
    try:
        polling_attempt = 0
        while True:
            try:
                await dispatcher.start_polling(bot)
                break
            except Exception:
                polling_attempt += 1
                delay = min(60, 5 * polling_attempt)
                logging.exception("Telegram polling failed; retrying in %s seconds", delay)
                await asyncio.sleep(delay)
    finally:
        auto_close_task.cancel()
        reconcile_task.cancel()
        checkin_alert_task.cancel()
        with suppress(asyncio.CancelledError):
            await auto_close_task
        with suppress(asyncio.CancelledError):
            await reconcile_task
        with suppress(asyncio.CancelledError):
            await checkin_alert_task
        if webhook_runner:
            await webhook_runner.cleanup()
        await db.close()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
