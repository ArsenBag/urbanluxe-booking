from enum import Enum
from typing import Dict, List, Tuple


class Role(str, Enum):
    MAID = "maid"
    SUPERVISOR = "supervisor"
    BOOKING_MANAGER = "booking_manager"
    ADMIN = "admin"


class TaskStatus(str, Enum):
    PLAN = "plan"
    GUEST_CHECKED_OUT = "guest_checked_out"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    WAITING_CHECK = "waiting_check"
    VERIFIED = "verified"
    REWORK = "rework"
    PROBLEM = "problem"
    OVERDUE = "overdue"
    CANCELED = "canceled"


class CleaningType(str, Enum):
    STANDARD = "standard"
    GENERAL = "general"
    DAILY = "daily"


class BookingStatus(str, Enum):
    PLANNED = "planned"
    CHECKED_OUT = "checked_out"
    CLEANING_CREATED = "cleaning_created"
    READY = "ready"
    CANCELED = "canceled"


ROLE_LABELS: Dict[str, str] = {
    Role.MAID.value: "Горничная",
    Role.SUPERVISOR.value: "Супервизор",
    Role.BOOKING_MANAGER.value: "Менеджер бронирований",
    Role.ADMIN.value: "Администратор",
}

BOOKING_STATUS_LABELS: Dict[str, str] = {
    BookingStatus.PLANNED.value: "Запланирована",
    BookingStatus.CHECKED_OUT.value: "Гость выехал",
    BookingStatus.CLEANING_CREATED.value: "Уборка создана",
    BookingStatus.READY.value: "Готово",
    BookingStatus.CANCELED.value: "Отменена",
}

STATUS_LABELS: Dict[str, str] = {
    TaskStatus.PLAN.value: "Запланирована",
    TaskStatus.GUEST_CHECKED_OUT.value: "Гость выехал",
    TaskStatus.ASSIGNED.value: "Назначена",
    TaskStatus.IN_PROGRESS.value: "В работе",
    TaskStatus.COMPLETED.value: "Завершена",
    TaskStatus.WAITING_CHECK.value: "Ждет проверки",
    TaskStatus.VERIFIED.value: "Принята",
    TaskStatus.REWORK.value: "Переделка",
    TaskStatus.PROBLEM.value: "Проблема",
    TaskStatus.OVERDUE.value: "Просрочена",
    TaskStatus.CANCELED.value: "Отменена",
}

CLEANING_TYPE_LABELS: Dict[str, str] = {
    CleaningType.STANDARD.value: "Стандартная",
    CleaningType.GENERAL.value: "Генеральная",
    CleaningType.DAILY.value: "Ежедневная",
}

CLEANING_TYPE_CHOICES: List[Tuple[str, str]] = [
    (CleaningType.STANDARD.value, CLEANING_TYPE_LABELS[CleaningType.STANDARD.value]),
    (CleaningType.GENERAL.value, CLEANING_TYPE_LABELS[CleaningType.GENERAL.value]),
    (CleaningType.DAILY.value, CLEANING_TYPE_LABELS[CleaningType.DAILY.value]),
]

VERIFICATION_METHOD_LABELS: Dict[str, str] = {
    "in_person": "Лично",
    "video": "По видео",
}

LEGACY_CLEANING_TYPE_MAP: Dict[str, str] = {
    "light_deep_clean": CleaningType.GENERAL.value,
    "full_deep_clean": CleaningType.GENERAL.value,
    "heavy_recovery": CleaningType.GENERAL.value,
    "pre_checkin_refresh": CleaningType.DAILY.value,
}


def normalize_cleaning_type(value: str) -> str:
    normalized = LEGACY_CLEANING_TYPE_MAP.get(value, value)
    allowed = {item.value for item in CleaningType}
    if normalized not in allowed:
        raise ValueError("Неизвестный тип уборки")
    return normalized

REWORK_REASONS: List[Tuple[str, str]] = [
    ("dust", "Пыль"),
    ("hair", "Волосы"),
    ("kitchen", "Кухня"),
    ("bathroom", "Санузел"),
    ("balcony", "Балкон"),
    ("supplies", "Косметика/расходники"),
    ("other", "Другое"),
]

PROBLEM_TYPES: List[Tuple[str, str]] = [
    ("forgotten_items", "Забытые вещи"),
    ("damage", "Поломка"),
    ("damaged_linen", "Испорченный текстиль"),
    ("cigarette_smell", "Запах сигарет"),
    ("supplies_missing", "Нет расходников"),
    ("guest_not_left", "Гость не выехал"),
    ("no_access", "Нет доступа"),
    ("heavy_dirty", "Сильное загрязнение"),
    ("property_damage", "Ущерб имуществу"),
    ("other", "Другое"),
]

PROBLEM_TYPE_LABELS: Dict[str, str] = dict(PROBLEM_TYPES)


def label(mapping: Dict[str, str], value: str) -> str:
    return mapping.get(value, value or "-")
