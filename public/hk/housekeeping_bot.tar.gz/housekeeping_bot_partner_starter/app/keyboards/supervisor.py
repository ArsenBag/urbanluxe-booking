from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.models import (
    CLEANING_TYPE_CHOICES,
    PROBLEM_TYPE_LABELS,
    PROBLEM_TYPES,
    REWORK_REASONS,
    TaskStatus,
    label,
)
from app.services.cleaning_service import default_deadline_options
from app.services.formatting import apartment_label, format_date, format_time, task_title


STATUS_ICONS = {
    TaskStatus.PLAN.value: "🕒",
    TaskStatus.GUEST_CHECKED_OUT.value: "🚪",
    TaskStatus.ASSIGNED.value: "👤",
    TaskStatus.IN_PROGRESS.value: "🧹",
    TaskStatus.COMPLETED.value: "🔍",
    TaskStatus.WAITING_CHECK.value: "🔍",
    TaskStatus.VERIFIED.value: "✅",
    TaskStatus.REWORK.value: "🛑",
    TaskStatus.PROBLEM.value: "⚠️",
    TaskStatus.OVERDUE.value: "⏰",
}


def task_button_title(task) -> str:
    icon = STATUS_ICONS.get(task["status"], "")
    title = task_title(task, compact=True)
    if (
        ("apartment_keys_missing" in task.keys() and task["apartment_keys_missing"])
        or (
            "keys_missing_reported_at" in task.keys()
            and task["keys_missing_reported_at"]
            and not task["keys_missing_resolved_at"]
        )
    ):
        return f"⚠️ Нет ключей · {icon} {title}" if icon else f"⚠️ Нет ключей · {title}"
    return f"{icon} {title}" if icon else title


def apartments_keyboard(apartments, page: int = 0, page_size: int = 12) -> InlineKeyboardMarkup:
    apartments = list(apartments)
    page = max(page, 0)
    start = page * page_size
    rows = [
        [
            InlineKeyboardButton(
                text=f"{apartment_label(apartment, 'code')} · {apartment['building'] or '-'}",
                callback_data=f"new_apartment:{apartment['id']}",
            )
        ]
        for apartment in apartments[start : start + page_size]
    ]
    nav = []
    if page > 0:
        nav.append(
            InlineKeyboardButton(
                text="Назад",
                callback_data=f"new_apartments_page:{page - 1}",
            )
        )
    if start + page_size < len(apartments):
        nav.append(
            InlineKeyboardButton(
                text="Дальше",
                callback_data=f"new_apartments_page:{page + 1}",
            )
        )
    if nav:
        rows.append(nav)
    return InlineKeyboardMarkup(inline_keyboard=rows)


def cleaning_types_keyboard(prefix: str = "new_type") -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=label, callback_data=f"{prefix}:{value}")]
        for value, label in CLEANING_TYPE_CHOICES
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def deadlines_keyboard() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=label, callback_data=f"new_deadline:{value}")]
        for value, label in default_deadline_options()
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def maids_keyboard(maids, prefix: str, include_skip: bool = False) -> InlineKeyboardMarkup:
    rows = []
    if include_skip:
        rows.append([InlineKeyboardButton(text="Не назначать", callback_data=f"{prefix}:0")])
    for maid in maids:
        rows.append(
            [InlineKeyboardButton(text=maid["full_name"], callback_data=f"{prefix}:{maid['id']}")]
        )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def tasks_keyboard(tasks, prefix: str) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=task_button_title(task), callback_data=f"{prefix}:{task['id']}")]
        for task in tasks
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def materials_apartments_keyboard(apartments, page: int = 0, page_size: int = 10) -> InlineKeyboardMarkup:
    total = len(apartments)
    page = max(page, 0)
    start = page * page_size
    end = start + page_size
    rows = [
        [
            InlineKeyboardButton(
                text=f"{apartment_label(apartment, 'code')} · {apartment['building'] or '-'}",
                callback_data=f"materials_apartment:{apartment['id']}",
            )
        ]
        for apartment in apartments[start:end]
    ]

    nav = []
    if start > 0:
        nav.append(InlineKeyboardButton(text="Назад", callback_data=f"materials_apartments_page:{page - 1}"))
    if end < total:
        nav.append(InlineKeyboardButton(text="Дальше", callback_data=f"materials_apartments_page:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="Отмена", callback_data="materials_cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def materials_dates_keyboard(date_values) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=format_date(date_value), callback_data=f"materials_date:{date_value}")]
        for date_value in date_values
    ]
    rows.append([InlineKeyboardButton(text="Ввести дату вручную", callback_data="materials_date_manual")])
    rows.append([InlineKeyboardButton(text="Выбрать другой объект", callback_data="materials_restart")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def materials_tasks_keyboard(tasks) -> InlineKeyboardMarkup:
    rows = []
    for task in tasks:
        deadline = format_time(task["deadline_at"]) or "-"
        status = STATUS_ICONS.get(task["status"], "")
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{status} {deadline} · {task_title(task, compact=True)}",
                    callback_data=f"materials_task:{task['id']}",
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="Отмена", callback_data="materials_cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def problems_keyboard(tasks) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=(
                    f"⚠️ {apartment_label(task)} · Нет ключей"
                    if task["keys_missing_reported_at"] and not task["keys_missing_resolved_at"]
                    else f"⚠️ {apartment_label(task)} · {label(PROBLEM_TYPE_LABELS, task['problem_type'])}"
                ),
                callback_data=f"sup_problem_view:{task['id']}",
            )
        ]
        for task in tasks
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def problem_actions_keyboard(task) -> InlineKeyboardMarkup:
    rows = []
    if task["keys_missing_reported_at"] and not task["keys_missing_resolved_at"]:
        rows.append([InlineKeyboardButton(
            text="Ключи положены — проблема решена",
            callback_data=f"sup_keys_resolved:{task['id']}",
        )])
    if task["problem_type"] and not task["problem_resolved_at"]:
        rows.append([InlineKeyboardButton(
            text="Другая проблема решена",
            callback_data=f"sup_problem_resolved:{task['id']}",
        )])
    rows.append([InlineKeyboardButton(text="Открыть уборку", callback_data=f"sup_task:{task['id']}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def keys_missing_resolve_confirm_keyboard(task_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Да, ключи положены", callback_data=f"sup_keys_resolved_yes:{task_id}"),
            InlineKeyboardButton(text="Нет", callback_data=f"sup_problem_view:{task_id}"),
        ]
    ])


def problem_resolve_confirm_keyboard(task) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Да, проблема решена", callback_data=f"sup_problem_resolved_yes:{task['id']}"),
                InlineKeyboardButton(text="Нет", callback_data=f"sup_problem_view:{task['id']}"),
            ]
        ]
    )


def supervisor_task_actions(task) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="Принять", callback_data=f"sup_accept:{task['id']}"),
            InlineKeyboardButton(text="Переделка", callback_data=f"sup_rework:{task['id']}"),
        ],
        [InlineKeyboardButton(text="Проблема", callback_data=f"sup_problem:{task['id']}")],
    ]
    if task["status"] in (
        TaskStatus.PLAN.value,
        TaskStatus.GUEST_CHECKED_OUT.value,
        TaskStatus.ASSIGNED.value,
        TaskStatus.REWORK.value,
    ):
        rows.append(
            [InlineKeyboardButton(text="Сменить горничную", callback_data=f"sup_reassign:{task['id']}")]
        )
    if not task["started_at"] and task["status"] not in (
        TaskStatus.COMPLETED.value,
        TaskStatus.WAITING_CHECK.value,
        TaskStatus.VERIFIED.value,
        TaskStatus.REWORK.value,
        TaskStatus.CANCELED.value,
    ):
        rows.append(
            [InlineKeyboardButton(text="Изменить тип уборки", callback_data=f"sup_change_type:{task['id']}")]
        )
    if not task["started_at"] and task["status"] in (
        TaskStatus.PLAN.value,
        TaskStatus.GUEST_CHECKED_OUT.value,
        TaskStatus.ASSIGNED.value,
    ):
        rows.append(
            [
                InlineKeyboardButton(
                    text="Отменить ошибочную уборку",
                    callback_data=f"sup_cancel:{task['id']}",
                )
            ]
        )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def cancel_task_confirm_keyboard(task_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="Да, отменить уборку",
                    callback_data=f"sup_cancel_yes:{task_id}",
                ),
                InlineKeyboardButton(
                    text="Нет",
                    callback_data=f"sup_task:{task_id}",
                ),
            ]
        ]
    )


def quality_keyboard(task_id: int) -> InlineKeyboardMarkup:
    rows = []
    for start in (0, 4, 8):
        rows.append(
            [
                InlineKeyboardButton(text=str(score), callback_data=f"sup_quality:{task_id}:{score}")
                for score in range(start, min(start + 4, 11))
            ]
        )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def verification_method_keyboard(task_id: int, quality_score: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="👣 Проверено лично",
            callback_data=f"sup_verify:{task_id}:{quality_score}:in_person",
        )],
        [InlineKeyboardButton(
            text="📹 Проверено по видео",
            callback_data=f"sup_verify:{task_id}:{quality_score}:video",
        )],
        [InlineKeyboardButton(text="Изменить оценку", callback_data=f"sup_accept:{task_id}")],
    ])


def shift_start_confirm_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Да, пришел", callback_data="sup_shift_start_confirm"),
                InlineKeyboardButton(text="Назад", callback_data="sup_shift_action_cancel"),
            ]
        ]
    )


def shift_end_confirm_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Да, завершить", callback_data="sup_shift_end_confirm"),
                InlineKeyboardButton(text="Назад", callback_data="sup_shift_action_cancel"),
            ]
        ]
    )


def shift_end_photo_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="Отмена",
                    callback_data="sup_shift_action_cancel",
                )
            ]
        ]
    )


def rework_reasons_keyboard(selected=None) -> InlineKeyboardMarkup:
    selected = set(selected or [])
    rows = []
    for value, label in REWORK_REASONS:
        prefix = "✓ " if value in selected else ""
        rows.append([InlineKeyboardButton(text=prefix + label, callback_data=f"sup_rework_toggle:{value}")])
    rows.append([InlineKeyboardButton(text="Отправить на переделку", callback_data="sup_rework_send")])
    rows.append([InlineKeyboardButton(text="Отмена", callback_data="sup_rework_cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def supervisor_problem_types_keyboard(task_id: int) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=label, callback_data=f"sup_problem_type:{task_id}:{value}")]
        for value, label in PROBLEM_TYPES
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)
