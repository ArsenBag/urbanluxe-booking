from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup

from app.i18n import tr
from app.models import Role


MAID_TODAY = "Мои уборки сегодня"
MAID_ACTIVE = "Активная уборка"
MAID_REWORKS = "Переделки"
MAID_PROBLEM = "Сообщить проблему"
MAID_RESULT = "Мой результат за день"
MAID_SHIFT_START = "На смену пришел"
MAID_SHIFT_END = "Смену завершил"

SUP_TODAY = "Уборки сегодня"
SUP_ACTIVE = "Активные уборки"
SUP_SHIFT_LOAD = "Нагрузка смены"
SUP_TOMORROW_FORECAST = "Прогноз уборок на завтра"
SUP_RECONCILE = "Сверить уборки"
SUP_RESTORE = "Восстановить график"
SUP_NEW = "Создать уборку"
SUP_ASSIGN = "Назначить"
SUP_WAITING = "Ждут проверки"
SUP_PROBLEMS = "Проблемы"
SUP_MATERIALS = "Материалы уборки"
SUP_REPORT = "Отчет за день"
SUP_EXPORT = "Экспорт CSV"
SUP_EXPORT_TODAY = "Excel сегодня"
SUP_EXPORT_YESTERDAY = "Excel вчера"
SUP_EXPORT_RANGE = "Excel период"
SUP_SHIFT_REPORT = "Смены за период"
SUP_SHEETS = "Google Sheets"
SUP_SHIFT_START = "На смену пришел"
SUP_SHIFT_END = "Смену завершил"

ADMIN_USERS = "Пользователи"
ADMIN_ADD_USER = "Добавить пользователя"

BM_CHECKOUTS = "Выезды сегодня"
BM_CHECKED_OUT = "Выехали"
BM_READY = "Готовы к заезду"
BM_ADD_BOOKING = "Добавить бронь"
BM_EXTRA_CLEANING = "Создать ежедневную уборку"
BM_EXTRA_LIST = "Ежедневные уборки"
BM_EXTRA_CLEANING_LEGACY = "Создать доп. уборку"
BM_EXTRA_LIST_LEGACY = "Доп. уборки"


SUPERVISOR_NAVIGATION_BUTTONS = frozenset(
    {
        SUP_TODAY,
        SUP_ACTIVE,
        SUP_SHIFT_LOAD,
        SUP_TOMORROW_FORECAST,
        SUP_RECONCILE,
        SUP_RESTORE,
        SUP_NEW,
        SUP_ASSIGN,
        SUP_WAITING,
        SUP_PROBLEMS,
        SUP_MATERIALS,
        SUP_REPORT,
        SUP_EXPORT,
        SUP_EXPORT_TODAY,
        SUP_EXPORT_YESTERDAY,
        SUP_EXPORT_RANGE,
        SUP_SHIFT_REPORT,
        SUP_SHEETS,
        SUP_SHIFT_START,
        SUP_SHIFT_END,
        ADMIN_USERS,
        ADMIN_ADD_USER,
    }
)


def maid_menu(language: str = "ru") -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=tr(language, "menu_today")), KeyboardButton(text=tr(language, "menu_active"))],
            [KeyboardButton(text=tr(language, "menu_reworks")), KeyboardButton(text=tr(language, "menu_problem"))],
            [KeyboardButton(text=tr(language, "menu_result"))],
            [KeyboardButton(text=tr(language, "menu_language"))],
            [KeyboardButton(text=tr(language, "menu_shift_end"))],
        ],
        resize_keyboard=True,
    )


def maid_shift_start_menu(language: str = "ru") -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=tr(language, "menu_shift_start"))],
            [KeyboardButton(text=tr(language, "menu_language"))],
        ],
        resize_keyboard=True,
    )


def language_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Русский", callback_data="maid_language:ru"),
                InlineKeyboardButton(text="O‘zbekcha", callback_data="maid_language:uz"),
            ]
        ]
    )


def supervisor_menu(include_shift: bool = True) -> ReplyKeyboardMarkup:
    keyboard = [
        [KeyboardButton(text=SUP_TODAY), KeyboardButton(text=SUP_ACTIVE)],
        [KeyboardButton(text=SUP_SHIFT_LOAD)],
        [KeyboardButton(text=SUP_TOMORROW_FORECAST)],
        [KeyboardButton(text=SUP_RECONCILE), KeyboardButton(text=SUP_RESTORE)],
        [KeyboardButton(text=SUP_NEW)],
        [KeyboardButton(text=SUP_ASSIGN), KeyboardButton(text=SUP_WAITING)],
        [KeyboardButton(text=SUP_PROBLEMS), KeyboardButton(text=SUP_MATERIALS)],
        [KeyboardButton(text=SUP_REPORT)],
        [KeyboardButton(text=SUP_EXPORT_TODAY), KeyboardButton(text=SUP_EXPORT_YESTERDAY)],
        [KeyboardButton(text=SUP_EXPORT_RANGE), KeyboardButton(text=SUP_SHEETS)],
        [KeyboardButton(text=SUP_SHIFT_REPORT)],
    ]
    if include_shift:
        keyboard.append([KeyboardButton(text=SUP_SHIFT_END)])
    return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)


def supervisor_shift_start_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=SUP_SHIFT_START)],
            [KeyboardButton(text=SUP_MATERIALS)],
        ],
        resize_keyboard=True,
    )


def booking_manager_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BM_CHECKOUTS), KeyboardButton(text=BM_CHECKED_OUT)],
            [KeyboardButton(text=BM_READY), KeyboardButton(text=BM_ADD_BOOKING)],
            [KeyboardButton(text=BM_EXTRA_CLEANING), KeyboardButton(text=BM_EXTRA_LIST)],
        ],
        resize_keyboard=True,
    )


def admin_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=ADMIN_USERS), KeyboardButton(text=ADMIN_ADD_USER)],
            [KeyboardButton(text=SUP_TODAY), KeyboardButton(text=SUP_ACTIVE)],
            [KeyboardButton(text=SUP_SHIFT_LOAD)],
            [KeyboardButton(text=SUP_TOMORROW_FORECAST)],
            [KeyboardButton(text=SUP_RECONCILE), KeyboardButton(text=SUP_RESTORE)],
            [KeyboardButton(text=SUP_NEW)],
            [KeyboardButton(text=SUP_ASSIGN), KeyboardButton(text=SUP_WAITING)],
            [KeyboardButton(text=SUP_PROBLEMS), KeyboardButton(text=SUP_MATERIALS)],
            [KeyboardButton(text=SUP_REPORT)],
            [KeyboardButton(text=SUP_EXPORT_TODAY), KeyboardButton(text=SUP_EXPORT_YESTERDAY)],
            [KeyboardButton(text=SUP_EXPORT_RANGE), KeyboardButton(text=SUP_SHEETS)],
            [KeyboardButton(text=SUP_SHIFT_REPORT)],
        ],
        resize_keyboard=True,
    )


def main_menu(role: str, language: str = "ru") -> ReplyKeyboardMarkup:
    if role == Role.MAID.value:
        return maid_menu(language)
    if role == Role.BOOKING_MANAGER.value:
        return booking_manager_menu()
    if role == Role.SUPERVISOR.value:
        return supervisor_menu(include_shift=True)
    if role == Role.ADMIN.value:
        return admin_menu()
    return supervisor_menu(include_shift=False)
