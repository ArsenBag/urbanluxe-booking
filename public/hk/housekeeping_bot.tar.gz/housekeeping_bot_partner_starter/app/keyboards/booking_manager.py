from typing import Optional

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.services import booking_service
from app.services.formatting import apartment_label


def bookings_keyboard(bookings, prefix: str, include_other: bool = False) -> InlineKeyboardMarkup:
    rows = []
    for booking in bookings:
        time = booking["checkout_time"] or "время не задано"
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{apartment_label(booking)} · выезд {time}",
                    callback_data=f"{prefix}:{booking['id']}",
                )
            ]
        )
    if include_other:
        rows.append([InlineKeyboardButton(text="Другой объект", callback_data=f"{prefix}:other")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def checkout_times_keyboard(prefix: str, include_manual: bool = True) -> InlineKeyboardMarkup:
    rows = []
    times = booking_service.CHECKOUT_TIMES
    for index in range(0, len(times), 3):
        rows.append(
            [
                InlineKeyboardButton(text=value, callback_data=f"{prefix}:{value}")
                for value in times[index : index + 3]
            ]
        )
    if include_manual:
        rows.append([InlineKeyboardButton(text="Выбрать вручную", callback_data=f"{prefix}:manual")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def checkin_times_keyboard(prefix: str, include_no_booking: bool) -> InlineKeyboardMarkup:
    rows = []
    times = booking_service.CHECKIN_TIMES
    for index in range(0, len(times), 3):
        rows.append(
            [
                InlineKeyboardButton(text=value, callback_data=f"{prefix}:{value}")
                for value in times[index : index + 3]
            ]
        )
    rows.append([InlineKeyboardButton(text="После 18:00", callback_data=f"{prefix}:after_18")])
    if include_no_booking:
        rows.append([InlineKeyboardButton(text="Нет брони", callback_data=f"{prefix}:none")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def buildings_keyboard(prefix: str, include_all: bool = False) -> InlineKeyboardMarkup:
    rows = []
    if include_all or not booking_service.BUILDING_CHOICES:
        rows.append(
            [InlineKeyboardButton(text="Все объекты", callback_data=f"{prefix}:all")]
        )
    rows.extend(
        [InlineKeyboardButton(text=label, callback_data=f"{prefix}:{key}")]
        for key, label, _ in booking_service.BUILDING_CHOICES
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def apartments_keyboard(
    apartments,
    prefix: str,
    page: Optional[int] = None,
    page_size: int = 12,
) -> InlineKeyboardMarkup:
    apartments = list(apartments)
    if page is None:
        visible = apartments
    else:
        page = max(page, 0)
        start = page * page_size
        visible = apartments[start : start + page_size]
    rows = [
        [
            InlineKeyboardButton(
                text=f"{apartment_label(apartment, 'code')} · {apartment['building'] or '-'}",
                callback_data=f"{prefix}:{apartment['id']}",
            )
        ]
        for apartment in visible
    ]
    if page is not None:
        nav = []
        if page > 0:
            nav.append(
                InlineKeyboardButton(
                    text="Назад",
                    callback_data=f"{prefix}_page:{page - 1}",
                )
            )
        if (page + 1) * page_size < len(apartments):
            nav.append(
                InlineKeyboardButton(
                    text="Дальше",
                    callback_data=f"{prefix}_page:{page + 1}",
                )
            )
        if nav:
            rows.append(nav)
    return InlineKeyboardMarkup(inline_keyboard=rows)


def guests_keyboard(prefix: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="1", callback_data=f"{prefix}:1"),
                InlineKeyboardButton(text="2", callback_data=f"{prefix}:2"),
                InlineKeyboardButton(text="3", callback_data=f"{prefix}:3"),
            ],
            [
                InlineKeyboardButton(text="4", callback_data=f"{prefix}:4"),
                InlineKeyboardButton(text="5", callback_data=f"{prefix}:5"),
                InlineKeyboardButton(text="6+", callback_data=f"{prefix}:6"),
            ],
        ]
    )


def extra_cleaning_times_keyboard(prefix: str) -> InlineKeyboardMarkup:
    times = ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"]
    rows = []
    for index in range(0, len(times), 3):
        rows.append(
            [
                InlineKeyboardButton(text=value, callback_data=f"{prefix}:{value}")
                for value in times[index : index + 3]
            ]
        )
    rows.append([InlineKeyboardButton(text="Ввести вручную", callback_data=f"{prefix}:manual")])
    return InlineKeyboardMarkup(inline_keyboard=rows)
