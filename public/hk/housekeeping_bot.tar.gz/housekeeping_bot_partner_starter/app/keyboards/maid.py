from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.i18n import problem_type_text, tr
from app.models import PROBLEM_TYPES, TaskStatus
from app.services.formatting import maid_task_title


def maid_tasks_keyboard(tasks, prefix: str = "maid_task", language: str = "ru") -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=maid_task_title(task, language, compact=True), callback_data=f"{prefix}:{task['id']}")]
        for task in tasks
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def maid_task_actions(task, language: str = "ru") -> InlineKeyboardMarkup:
    rows = []
    if task["status"] == TaskStatus.ASSIGNED.value:
        rows.append([InlineKeyboardButton(text=tr(language, "action_start"), callback_data=f"maid_start:{task['id']}")])
    if task["status"] == TaskStatus.REWORK.value:
        rows.append([InlineKeyboardButton(text=tr(language, "action_rework"), callback_data=f"maid_rework_start:{task['id']}")])
    if task["status"] == TaskStatus.IN_PROGRESS.value:
        rows.append([InlineKeyboardButton(text=tr(language, "action_finish"), callback_data=f"maid_finish:{task['id']}")])
    if task["problem_type"] and not task["problem_resolved_at"]:
        resolve_text = tr(language, "action_problem_resolved")
        if task["problem_type"] == "guest_not_left":
            resolve_text = tr(language, "action_guest_left")
        elif task["problem_type"] == "no_access":
            resolve_text = tr(language, "action_access")
        rows.append([InlineKeyboardButton(text=resolve_text, callback_data=f"maid_problem_resolve:{task['id']}")])
    if task["status"] not in (TaskStatus.VERIFIED.value, TaskStatus.CANCELED.value):
        rows.append([InlineKeyboardButton(text=tr(language, "action_forgotten"), callback_data=f"maid_forgotten_task:{task['id']}")])
        rows.append([InlineKeyboardButton(text=tr(language, "action_problem"), callback_data=f"maid_problem_task:{task['id']}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def finish_photos_keyboard(language: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=tr(language, "action_materials_done"), callback_data="finish_materials_done")]
        ]
    )


def rework_materials_keyboard(language: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=tr(language, "action_rework_done"), callback_data="rework_materials_done")]
        ]
    )


def before_materials_keyboard(task_id: int, language: str = "ru", keys_missing: bool = False) -> InlineKeyboardMarkup:
    rows = []
    if not keys_missing:
        rows.append(
            [InlineKeyboardButton(text=tr(language, "action_no_keys"), callback_data=f"before_keys_missing:{task_id}")]
        )
    rows.append(
        [InlineKeyboardButton(text=tr(language, "action_before_done"), callback_data=f"before_materials_done:{task_id}")]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def shift_start_confirm_keyboard(language: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=tr(language, "action_yes_shift"), callback_data="shift_start_confirm"),
                InlineKeyboardButton(text=tr(language, "action_back"), callback_data="shift_action_cancel"),
            ]
        ]
    )


def shift_end_confirm_keyboard(language: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=tr(language, "action_yes_end"), callback_data="shift_end_confirm"),
                InlineKeyboardButton(text=tr(language, "action_back"), callback_data="shift_action_cancel"),
            ]
        ]
    )


def shift_cart_photo_keyboard(language: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=tr(language, "action_back"),
                    callback_data="shift_action_cancel",
                )
            ]
        ]
    )


def problem_types_keyboard(task_id: int, language: str = "ru") -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=problem_type_text(language, value),
                callback_data=f"maid_problem_type:{task_id}:{value}",
            )
        ]
        for value, _ in PROBLEM_TYPES
        if value != "forgotten_items"
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def problem_done_keyboard(language: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=tr(language, "action_problem_send"), callback_data="maid_problem_done")]
        ]
    )


def forgotten_items_done_keyboard(language: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=tr(language, "action_forgotten_send"), callback_data="maid_forgotten_done")]
        ]
    )


def problem_resolve_confirm_keyboard(task_id: int, language: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=tr(language, "action_yes_resolved"), callback_data=f"maid_problem_resolve_yes:{task_id}"),
                InlineKeyboardButton(text=tr(language, "action_no"), callback_data=f"maid_problem_resolve_no:{task_id}"),
            ]
        ]
    )
