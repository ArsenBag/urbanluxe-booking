import asyncio
import math
from datetime import date, datetime, time, timedelta
from typing import Optional
from zoneinfo import ZoneInfo

import aiosqlite

from app.config import Settings
from app.db import connect
from app.i18n import status_text, tr
from app.models import CLEANING_TYPE_LABELS, CleaningType, TaskStatus
from app.repositories import cleaning_tasks as task_repo
from app.repositories import shifts as shift_repo
from app.repositories import users as user_repo
from app.services import cleaning_service
from app.services.formatting import compact_apartment_code


AUTO_CLOSE_TIME = time(21, 0)
FORECAST_TASKS_PER_MAID = 4
FORECAST_MINUTES_PER_MAID = 360
FORECAST_URGENT_TASKS_PER_MAID = 2

DEFAULT_TASK_MINUTES = {
    CleaningType.STANDARD.value: 60,
    CleaningType.GENERAL.value: 100,
    CleaningType.DAILY.value: 30,
}


def now(timezone: str) -> datetime:
    return datetime.now(ZoneInfo(timezone)).replace(microsecond=0)


def work_date(timezone: str) -> str:
    return now(timezone).date().isoformat()


async def close_stale_shifts(db: aiosqlite.Connection, timezone: str) -> None:
    current = now(timezone)
    today = current.date().isoformat()
    ended_at = current.isoformat()
    await shift_repo.close_open_shifts(
        db,
        ended_at,
        before_work_date=today,
        user_roles=("maid",),
    )


async def active_shift(db: aiosqlite.Connection, timezone: str, maid_id: int):
    await close_stale_shifts(db, timezone)
    shift = await shift_repo.get_active_shift(db, maid_id)
    if not shift:
        return None
    return shift


async def start_shift(db: aiosqlite.Connection, timezone: str, maid_id: int):
    shift = await active_shift(db, timezone, maid_id)
    if shift:
        return shift, False
    current = now(timezone)
    shift, created = await shift_repo.create_shift(
        db,
        maid_id=maid_id,
        work_date=current.date().isoformat(),
        started_at=current.isoformat(),
    )
    return shift, created


def supervisor_purchase_list_required(shift) -> bool:
    return date.fromisoformat(shift["work_date"]).weekday() == 1


async def end_supervisor_shift(
    db: aiosqlite.Connection,
    timezone: str,
    supervisor_id: int,
    nightlights_photo_file_id: str,
    purchase_list_photo_file_id: Optional[str] = None,
):
    if not nightlights_photo_file_id:
        raise ValueError("nightlights photo is required")
    shift = await active_shift(db, timezone, supervisor_id)
    if not shift:
        return None
    if supervisor_purchase_list_required(shift) and not purchase_list_photo_file_id:
        raise ValueError("purchase list photo is required on Tuesday")
    ended_at = now(timezone).isoformat()
    return await shift_repo.close_shift(
        db,
        shift["id"],
        ended_at,
        supervisor_nightlights_photo_file_id=nightlights_photo_file_id,
        supervisor_nightlights_photo_uploaded_at=ended_at,
        supervisor_purchase_list_photo_file_id=purchase_list_photo_file_id,
        supervisor_purchase_list_photo_uploaded_at=(
            ended_at if purchase_list_photo_file_id else None
        ),
    )


async def maid_shift_end_blockers(
    db: aiosqlite.Connection,
    timezone: str,
    maid_id: int,
):
    shift = await active_shift(db, timezone, maid_id)
    shift_date = shift["work_date"] if shift else work_date(timezone)
    return await task_repo.list_shift_end_blockers(
        db,
        maid_id,
        shift_date,
    )


def format_maid_shift_end_blockers(tasks, language: str) -> str:
    lines = [tr(language, "shift_end_blocked", count=len(tasks))]
    for task in tasks[:15]:
        lines.append(
            f"• {compact_apartment_code(task['apartment_code'])} — "
            f"{status_text(language, task['status'])}"
        )
    if len(tasks) > 15:
        lines.append(f"... +{len(tasks) - 15}")
    return "\n".join(lines)


async def end_maid_shift(
    db: aiosqlite.Connection,
    timezone: str,
    maid_id: int,
    cart_photo_file_id: str,
):
    if not cart_photo_file_id:
        raise ValueError("cart photo is required")
    blockers = await maid_shift_end_blockers(db, timezone, maid_id)
    if blockers:
        raise ValueError("unfinished cleaning tasks")
    shift = await active_shift(db, timezone, maid_id)
    if not shift:
        return None
    ended_at = now(timezone).isoformat()
    return await shift_repo.close_shift(
        db,
        shift["id"],
        ended_at,
        end_cart_photo_file_id=cart_photo_file_id,
        end_cart_photo_uploaded_at=ended_at,
    )


async def latest_shift_for_today(db: aiosqlite.Connection, timezone: str, maid_id: int):
    await close_stale_shifts(db, timezone)
    return await shift_repo.get_latest_shift_for_date(db, maid_id, work_date(timezone))


async def supervisors_on_shift(db: aiosqlite.Connection, timezone: str):
    await close_stale_shifts(db, timezone)
    return await user_repo.list_supervisors_on_shift(db, work_date(timezone))


async def shift_workload(db: aiosqlite.Connection, timezone: str) -> dict:
    await close_stale_shifts(db, timezone)
    date_value = work_date(timezone)
    maids = await shift_repo.list_active_maids_workload(db, date_value)
    summary = await shift_repo.get_cleaning_workload_summary(db, date_value)

    total_count = int(summary["total_count"] or 0)
    maid_count = len(maids)
    return {
        "date": date_value,
        "maid_count": maid_count,
        "total_count": total_count,
        "assigned_count": int(summary["assigned_count"] or 0),
        "unassigned_count": int(summary["unassigned_count"] or 0),
        "assigned_off_shift_count": int(summary["assigned_off_shift_count"] or 0),
        "average_per_maid": total_count / maid_count if maid_count else 0,
        "maids": maids,
    }


def _clock_minutes(value: Optional[str]) -> Optional[int]:
    if not value or value == "after_18":
        return None
    value = value.split("T", 1)[-1][:5]
    try:
        hour, minute = (int(part) for part in value.split(":", 1))
    except (TypeError, ValueError):
        return None
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        return None
    return hour * 60 + minute


async def cleaning_forecast_for_date(
    db: aiosqlite.Connection,
    date_value: str,
) -> dict:
    tasks = await task_repo.list_for_date(db, date_value)
    work_tasks = [task for task in tasks if task["status"] != TaskStatus.VERIFIED.value]

    type_counts = {
        cleaning_type: sum(
            task["cleaning_type"] == cleaning_type for task in work_tasks
        )
        for cleaning_type in DEFAULT_TASK_MINUTES
    }
    estimated_minutes = sum(
        int(task["estimated_duration_min"] or DEFAULT_TASK_MINUTES.get(task["cleaning_type"], 60))
        for task in work_tasks
    )

    urgent_tasks = []
    afternoon_tasks = []
    after_18_tasks = []
    no_checkin_tasks = []
    late_checkout_tasks = []
    tight_window_tasks = []
    for task in work_tasks:
        checkout_time = task["booking_checkout_time"] or "12:00"
        checkin_time = task["booking_next_checkin_time"]
        no_checkin = bool(task["booking_no_next_booking"])
        item = {
            "apartment_code": task["apartment_code"],
            "checkout_time": checkout_time,
            "checkin_time": None if no_checkin else checkin_time,
        }

        checkout_minutes = _clock_minutes(checkout_time)
        checkin_minutes = None if no_checkin else _clock_minutes(checkin_time)
        if checkout_minutes is not None and checkout_minutes > 12 * 60:
            late_checkout_tasks.append(item)

        if no_checkin or not checkin_time:
            no_checkin_tasks.append(item)
        elif checkin_time == "after_18":
            after_18_tasks.append(item)
        elif checkin_minutes is not None and checkin_minutes <= 15 * 60:
            urgent_tasks.append(item)
        elif checkin_minutes is not None and checkin_minutes <= 18 * 60:
            afternoon_tasks.append(item)
        else:
            after_18_tasks.append(item)

        if checkout_minutes is not None and checkin_minutes is not None:
            window_minutes = checkin_minutes - checkout_minutes
            if window_minutes <= 180:
                tight_window_tasks.append({**item, "window_minutes": window_minutes})

    work_count = len(work_tasks)
    recommended_maids = 0
    if work_count:
        recommended_maids = max(
            math.ceil(work_count / FORECAST_TASKS_PER_MAID),
            math.ceil(estimated_minutes / FORECAST_MINUTES_PER_MAID),
            math.ceil(len(urgent_tasks) / FORECAST_URGENT_TASKS_PER_MAID),
        )

    return {
        "date": date_value,
        "total_count": len(tasks),
        "work_count": work_count,
        "ready_count": len(tasks) - work_count,
        "assigned_count": sum(task["assigned_maid_id"] is not None for task in work_tasks),
        "unassigned_count": sum(task["assigned_maid_id"] is None for task in work_tasks),
        "linked_count": sum(task["local_booking_id"] is not None for task in tasks),
        "manual_count": sum(task["local_booking_id"] is None for task in tasks),
        "type_counts": type_counts,
        "estimated_minutes": estimated_minutes,
        "recommended_maids": recommended_maids,
        "urgent_tasks": urgent_tasks,
        "afternoon_tasks": afternoon_tasks,
        "after_18_tasks": after_18_tasks,
        "no_checkin_tasks": no_checkin_tasks,
        "late_checkout_tasks": late_checkout_tasks,
        "tight_window_tasks": tight_window_tasks,
    }


async def tomorrow_cleaning_forecast(db: aiosqlite.Connection, timezone: str) -> dict:
    tomorrow = (now(timezone).date() + timedelta(days=1)).isoformat()
    return await cleaning_forecast_for_date(db, tomorrow)


def _duration_text(minutes: int) -> str:
    hours, remainder = divmod(minutes, 60)
    if hours and remainder:
        return f"{hours} ч {remainder} мин"
    if hours:
        return f"{hours} ч"
    return f"{remainder} мин"


def _maid_count_text(count: int) -> str:
    if count % 10 == 1 and count % 100 != 11:
        noun = "горничная"
    elif count % 10 in (2, 3, 4) and count % 100 not in (12, 13, 14):
        noun = "горничные"
    else:
        noun = "горничных"
    return f"{count} {noun}"


def format_cleaning_forecast(report: dict) -> str:
    date_label = datetime.fromisoformat(report["date"]).strftime("%d.%m.%Y")
    lines = [
        f"Прогноз уборок на завтра — {date_label}",
        "",
        f"Всего уборок: {report['total_count']}",
        f"Осталось выполнить: {report['work_count']}",
    ]

    if not report["total_count"]:
        lines.extend(
            (
                "",
                "По полученным данным RealtyCalendar уборок пока нет.",
                "Прогноз предварительный и обновится после новых бронирований и изменений.",
            )
        )
        return "\n".join(lines)

    type_parts = [
        f"{CLEANING_TYPE_LABELS[cleaning_type].lower()}: {count}"
        for cleaning_type, count in report["type_counts"].items()
        if count
    ]
    if type_parts:
        lines.append("По типам: " + ", ".join(type_parts))

    lines.extend(
        (
            f"Назначено заранее: {report['assigned_count']}",
            f"Без горничной: {report['unassigned_count']}",
            f"Расчётный объём: {_duration_text(report['estimated_minutes'])}",
            "",
            "По времени следующего заезда:",
            f"• до 15:00 включительно: {len(report['urgent_tasks'])}",
            f"• с 15:01 до 18:00: {len(report['afternoon_tasks'])}",
            f"• после 18:00: {len(report['after_18_tasks'])}",
            f"• следующего заезда нет: {len(report['no_checkin_tasks'])}",
            f"Поздних выездов после 12:00: {len(report['late_checkout_tasks'])}",
            "",
            f"Ориентир по команде: {_maid_count_text(report['recommended_maids'])}.",
            "Расчёт: не более 4 уборок и около 6 расчётных часов на одну горничную; срочные заезды учитываются отдельно.",
        )
    )

    if report["tight_window_tasks"]:
        lines.extend(("", "⚠️ Короткие окна между выездом и заездом:"))
        for task in report["tight_window_tasks"][:10]:
            lines.append(
                f"• {compact_apartment_code(task['apartment_code'])}: "
                f"выезд {task['checkout_time']}, "
                f"заезд {task['checkin_time']}"
            )
        if len(report["tight_window_tasks"]) > 10:
            lines.append(f"...и ещё {len(report['tight_window_tasks']) - 10}")

    lines.extend(
        (
            "",
            "Прогноз предварительный: повторно проверьте его утром после ночных изменений RealtyCalendar.",
        )
    )
    return "\n".join(lines)


def format_shift_workload(report: dict) -> str:
    date_label = datetime.fromisoformat(report["date"]).strftime("%d.%m.%Y")
    lines = [
        f"Нагрузка смены на {date_label}",
        f"Горничных на смене: {report['maid_count']}",
        f"Уборок сегодня: {report['total_count']}",
        f"Назначено: {report['assigned_count']}",
        f"Не назначено: {report['unassigned_count']}",
        f"Средняя нагрузка: {report['average_per_maid']:.1f} уборки на горничную",
    ]

    if report["assigned_off_shift_count"]:
        lines.append(
            f"Назначено горничным не на смене: {report['assigned_off_shift_count']}"
        )

    lines.append("")
    if not report["maids"]:
        lines.append("Сейчас ни одной горничной на смене нет.")
        return "\n".join(lines)

    lines.append("По горничным:")
    for maid in report["maids"]:
        assigned = int(maid["assigned_count"] or 0)
        verified = int(maid["verified_count"] or 0)
        remaining = max(0, assigned - verified)
        lines.append(
            f"• {maid['full_name']} — {assigned}; готово {verified}, осталось {remaining}"
        )
    return "\n".join(lines)


def format_shift_time(value: Optional[str]) -> str:
    if not value:
        return "-"
    return cleaning_service.display_time(value) if len(value) <= 5 else value.split("T", 1)[1][:5]


async def auto_close_loop(settings: Settings) -> None:
    while True:
        db = await connect(settings)
        try:
            await close_stale_shifts(db, settings.timezone)
        finally:
            await db.close()
        await asyncio.sleep(300)
