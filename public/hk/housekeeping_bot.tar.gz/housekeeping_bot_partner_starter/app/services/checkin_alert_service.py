from __future__ import annotations

import asyncio
import logging
import math
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import aiosqlite
from aiogram import Bot

from app.apartment_catalog import APARTMENT_TYPE_LABELS, minimum_cleaning_minutes
from app.config import Settings
from app.db import connect
from app.i18n import tr
from app.models import CleaningType, TaskStatus
from app.repositories import checkin_alerts as alert_repo
from app.repositories import cleaning_tasks as task_repo
from app.repositories import users as user_repo
from app.services import cleaning_service, notifications
from app.services.formatting import apartment_label, maid_apartment_label


logger = logging.getLogger(__name__)

CHECK_INTERVAL_SECONDS = 60
UNSTARTED_STATUSES = {
    TaskStatus.PLAN.value,
    TaskStatus.GUEST_CHECKED_OUT.value,
    TaskStatus.ASSIGNED.value,
    TaskStatus.PROBLEM.value,
    TaskStatus.OVERDUE.value,
}
STARTED_UNFINISHED_STATUSES = {
    TaskStatus.IN_PROGRESS.value,
    TaskStatus.PROBLEM.value,
    TaskStatus.OVERDUE.value,
    TaskStatus.REWORK.value,
}


def _checkin_datetime(task, timezone: str) -> tuple[datetime, str] | None:
    if bool(task["booking_no_next_booking"]):
        return None

    zone = ZoneInfo(timezone)
    raw_time = task["booking_next_checkin_time"]
    display_time = raw_time
    if raw_time == "after_18":
        raw_time = "18:00"
        display_time = "после 18:00"

    if raw_time:
        try:
            hour, minute = (int(part) for part in raw_time[:5].split(":", 1))
            checkin = datetime.fromisoformat(task["planned_date"]).replace(
                hour=hour,
                minute=minute,
                second=0,
                microsecond=0,
                tzinfo=zone,
            )
            return checkin, display_time or raw_time[:5]
        except (TypeError, ValueError):
            pass

    deadline_at = task["deadline_at"]
    if not deadline_at:
        return None
    try:
        checkin = datetime.fromisoformat(deadline_at)
    except (TypeError, ValueError):
        return None
    if checkin.tzinfo is None:
        checkin = checkin.replace(tzinfo=zone)
    else:
        checkin = checkin.astimezone(zone)
    return checkin, checkin.strftime("%H:%M")


def _remaining_minutes(current: datetime, checkin: datetime) -> int:
    seconds = (checkin - current).total_seconds()
    if seconds >= 0:
        return math.ceil(seconds / 60)
    return -math.ceil(abs(seconds) / 60)


def _timing_text(remaining_minutes: int, language: str = "ru") -> str:
    if language == "uz":
        if remaining_minutes > 0:
            return f"{remaining_minutes} daqiqa qoldi"
        if remaining_minutes == 0:
            return "kirish vaqti hozir"
        return f"kirish vaqtidan {abs(remaining_minutes)} daqiqa o‘tdi"
    if remaining_minutes > 0:
        return f"осталось {remaining_minutes} мин."
    if remaining_minutes == 0:
        return "заезд сейчас"
    return f"заезд был {abs(remaining_minutes)} мин. назад"


def _maid_alert_text(
    task,
    checkin_display: str,
    remaining_minutes: int,
    required_minutes: int,
) -> str:
    language = task["maid_language"] or "ru"
    return tr(
        language,
        "checkin_cleaning_not_started_maid",
        apartment=maid_apartment_label(task, language),
        checkin=checkin_display,
        timing=_timing_text(remaining_minutes, language),
        required=required_minutes,
    )


def _staff_alert_text(
    task,
    checkin_display: str,
    remaining_minutes: int,
    required_minutes: int,
) -> str:
    apartment_type = str(task["apartment_type"] or "unknown").strip().lower()
    type_label = APARTMENT_TYPE_LABELS.get(apartment_type)
    if type_label:
        standard_text = f"{required_minutes} мин. (тип: {type_label})"
    else:
        standard_text = f"{required_minutes} мин. (тип не указан, резерв 1 час)"

    maid_name = task["maid_name"] or "не назначена"
    action = (
        "Нужно срочно начать уборку."
        if task["assigned_maid_id"]
        else "Нужно срочно назначить горничную и начать уборку."
    )
    return (
        "🚨 Скоро заселение, уборка ещё не начата\n"
        f"Объект: {apartment_label(task)}\n"
        f"Заезд: {checkin_display} — {_timing_text(remaining_minutes)}\n"
        f"Минимум на уборку: {standard_text}\n"
        f"Горничная: {maid_name}\n"
        f"{action}"
    )


def _in_progress_supervisor_alert_text(
    task,
    checkin_display: str,
    remaining_minutes: int,
    required_minutes: int,
) -> str:
    apartment_type = str(task["apartment_type"] or "unknown").strip().lower()
    type_label = APARTMENT_TYPE_LABELS.get(apartment_type)
    if type_label:
        standard_text = f"{required_minutes} мин. (тип: {type_label})"
    else:
        standard_text = f"{required_minutes} мин. (тип не указан, резерв 1 час)"

    maid_name = task["maid_name"] or "не назначена"
    return (
        "🚨 Скоро заселение — уборка ещё идёт\n"
        f"Объект: {apartment_label(task)}\n"
        f"Заезд: {checkin_display} — {_timing_text(remaining_minutes)}\n"
        f"Норматив уборки: {standard_text}\n"
        f"Горничная: {maid_name}\n"
        "Уборка начата, но ещё не завершена. Проверьте, успевает ли "
        "горничная, и при необходимости подключите помощь."
    )


def _due_alert(task, current: datetime, timezone: str):
    if task["cleaning_type"] == CleaningType.DAILY.value:
        return None

    is_in_progress = bool(
        task["status"] == TaskStatus.IN_PROGRESS.value
        or (
            task["started_at"]
            and task["status"] in STARTED_UNFINISHED_STATUSES
        )
    )
    if not is_in_progress and (
        task["started_at"] or task["status"] not in UNSTARTED_STATUSES
    ):
        return None

    checkin_value = _checkin_datetime(task, timezone)
    if not checkin_value:
        return None
    checkin, checkin_display = checkin_value
    required_minutes = minimum_cleaning_minutes(task["apartment_type"])
    if current < checkin - timedelta(minutes=required_minutes):
        return None
    return {
        "task": task,
        "checkin": checkin,
        "checkin_display": checkin_display,
        "required_minutes": required_minutes,
        "remaining_minutes": _remaining_minutes(current, checkin),
        "alert_kind": "in_progress" if is_in_progress else "not_started",
    }


async def _stakeholder_recipients(db: aiosqlite.Connection, work_date: str):
    supervisors = [
        user
        for user in await user_repo.list_supervisors_on_shift(db, work_date)
        if user["telegram_id"]
    ]
    managers = [
        user for user in await user_repo.list_booking_managers(db) if user["telegram_id"]
    ]
    admins = []
    if not supervisors or not managers:
        admins = [user for user in await user_repo.list_admins(db) if user["telegram_id"]]

    recipients = {}
    for user in [*supervisors, *managers, *admins]:
        recipients[user["id"]] = user
    return recipients


async def _supervisor_recipients(db: aiosqlite.Connection, work_date: str):
    supervisors = [
        user
        for user in await user_repo.list_supervisors_on_shift(db, work_date)
        if user["telegram_id"]
    ]
    recipients = {user["id"]: user for user in supervisors}
    if not recipients:
        recipients = {
            user["id"]: user
            for user in await user_repo.list_admins(db)
            if user["telegram_id"]
        }
    return recipients


async def send_due_checkin_start_alerts(
    db: aiosqlite.Connection,
    settings: Settings,
    bot: Bot,
    current: datetime | None = None,
) -> dict:
    zone = ZoneInfo(settings.timezone)
    current = current or datetime.now(zone).replace(microsecond=0)
    if current.tzinfo is None:
        current = current.replace(tzinfo=zone)
    else:
        current = current.astimezone(zone)

    tasks = await task_repo.list_for_date(db, current.date().isoformat())
    due_alerts = [
        due
        for task in tasks
        if (due := _due_alert(task, current, settings.timezone)) is not None
    ]
    if not due_alerts:
        return {"due_tasks": 0, "delivered": 0}

    work_date = current.date().isoformat()
    stakeholders = await _stakeholder_recipients(db, work_date)
    supervisors = await _supervisor_recipients(db, work_date)
    delivered_count = 0
    delivered_at = current.replace(microsecond=0).isoformat()

    for due in due_alerts:
        task = due["task"]
        checkin_at = due["checkin"].replace(microsecond=0).isoformat()
        is_in_progress = due["alert_kind"] == "in_progress"
        recipients = dict(supervisors if is_in_progress else stakeholders)

        maid = None
        if not is_in_progress and task["assigned_maid_id"]:
            maid = await user_repo.get_by_id(db, task["assigned_maid_id"])
            if maid and maid["telegram_id"]:
                recipients[maid["id"]] = maid

        for recipient_id, recipient in recipients.items():
            if await alert_repo.was_delivered(db, task["id"], checkin_at, recipient_id):
                continue

            is_assigned_maid = bool(maid and recipient_id == maid["id"])
            text = (
                _maid_alert_text(
                    task,
                    due["checkin_display"],
                    due["remaining_minutes"],
                    due["required_minutes"],
                )
                if is_assigned_maid
                else _in_progress_supervisor_alert_text(
                    task,
                    due["checkin_display"],
                    due["remaining_minutes"],
                    due["required_minutes"],
                )
                if is_in_progress
                else _staff_alert_text(
                    task,
                    due["checkin_display"],
                    due["remaining_minutes"],
                    due["required_minutes"],
                )
            )
            sent = await notifications.notify_telegram_id(
                bot,
                recipient["telegram_id"],
                text,
            )
            if not sent:
                continue

            recorded = await alert_repo.record_delivery(
                db,
                task["id"],
                checkin_at,
                recipient_id,
                delivered_at,
            )
            if not recorded:
                continue
            await cleaning_service.log_event(
                db,
                task["id"],
                None,
                (
                    "checkin_cleaning_in_progress_alert"
                    if is_in_progress
                    else "checkin_cleaning_not_started_alert"
                ),
                task["status"],
                task["status"],
                {
                    "checkin_at": checkin_at,
                    "recipient_user_id": recipient_id,
                    "recipient_role": recipient["role"],
                    "required_minutes": due["required_minutes"],
                    "alert_kind": due["alert_kind"],
                },
            )
            await db.commit()
            delivered_count += 1

    return {"due_tasks": len(due_alerts), "delivered": delivered_count}


async def checkin_start_alert_loop(settings: Settings, bot: Bot) -> None:
    while True:
        db = None
        try:
            db = await connect(settings)
            result = await send_due_checkin_start_alerts(db, settings, bot)
            if result["delivered"]:
                logger.warning(
                    "Check-in cleaning alerts delivered: due_tasks=%s recipients=%s",
                    result["due_tasks"],
                    result["delivered"],
                )
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Check-in cleaning alert cycle failed")
        finally:
            if db is not None:
                await db.close()
        await asyncio.sleep(CHECK_INTERVAL_SECONDS)
