from datetime import datetime
from typing import Optional
from zoneinfo import ZoneInfo

import aiosqlite

from app.apartment_catalog import is_housekeeping_excluded
from app.models import BookingStatus, CleaningType, TaskStatus
from app.repositories import apartments as apartment_repo
from app.repositories import bookings as booking_repo
from app.repositories import cleaning_tasks as task_repo
from app.services import cleaning_service


CHECKOUT_TIMES = [
    "09:00",
    "09:30",
    "10:00",
    "10:30",
    "11:00",
    "11:30",
    "12:00",
    "12:30",
    "13:00",
    "13:30",
    "14:00",
    "14:30",
    "15:00",
]

CHECKIN_TIMES = ["12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"]
DEFAULT_REALTY_CHECKOUT_TIME = "12:00"
DEFAULT_REALTY_NEXT_CHECKIN_TIME = "15:00"

# These task states have not completed a cleaning yet, so a booking schedule
# update may safely move the same task.  Once work has started or finished, the
# old task must stay in history and a new follow-up cleaning is required for a
# later checkout date.
MOVABLE_BOOKING_TASK_STATUSES = {
    TaskStatus.PLAN.value,
    TaskStatus.GUEST_CHECKED_OUT.value,
    TaskStatus.ASSIGNED.value,
    TaskStatus.PROBLEM.value,
    TaskStatus.OVERDUE.value,
}

# Optional quick filters for the new company's complexes. An empty list keeps
# the universal "All properties" button available in booking workflows.
BUILDING_CHOICES = [  # Urban Luxe: (ключ, подпись кнопки, ключевое слово в коде квартиры)
    ("nest", "Nest One", "Nest One"),
    ("utower", "U-Tower", "U-Tower"),
    ("kislorod", "Kislorod", "Kislorod"),
    ("mirabad", "Mirabad", "Mirabad"),
    ("gardens", "Gardens", "Gardens"),
    ("modera", "Modera", "Modera"),
]


def parse_date(value: str) -> str:
    value = (value or "").strip()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y"):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            continue
    raise ValueError("Введите дату в формате 2026-06-29 или 29.06.2026")


def parse_time(value: str) -> str:
    value = (value or "").strip()
    try:
        parsed = datetime.strptime(value, "%H:%M")
    except ValueError:
        raise ValueError("Введите время в формате 14:30")
    return parsed.strftime("%H:%M")


def building_keyword(building_key: str) -> str:
    if building_key == "all":
        return ""
    for key, _, keyword in BUILDING_CHOICES:
        if key == building_key:
            return keyword
    return building_key


def next_checkin_label(value: Optional[str], no_next_booking: bool = False) -> str:
    if no_next_booking:
        return "нет брони"
    if value == "after_18":
        return "после 18:00"
    return value or "-"


def readiness_checkin_label(value: Optional[str], no_next_booking: bool = False) -> str:
    if no_next_booking:
        return "заезда нет"
    return next_checkin_label(value)


def deadline_from_next_checkin(timezone: str, date_value: str, next_checkin_time: Optional[str]):
    if not next_checkin_time:
        return None
    if next_checkin_time == "after_18":
        return cleaning_service.deadline_iso(timezone, date_value, "18:00")
    return cleaning_service.deadline_iso(timezone, date_value, next_checkin_time)


def effective_checkout_time(booking) -> str:
    if booking["checkout_time"]:
        return booking["checkout_time"]
    if booking["source"] == "realtycalendar":
        return DEFAULT_REALTY_CHECKOUT_TIME
    return "-"


def effective_next_checkin_time(booking) -> Optional[str]:
    if booking["no_next_booking"]:
        return None
    if booking["next_checkin_time"]:
        return booking["next_checkin_time"]
    if booking["source"] == "realtycalendar":
        return DEFAULT_REALTY_NEXT_CHECKIN_TIME
    return None


def readiness_label(cleaning_status: Optional[str]) -> str:
    if cleaning_status in (
        TaskStatus.PLAN.value,
        TaskStatus.GUEST_CHECKED_OUT.value,
        TaskStatus.ASSIGNED.value,
    ):
        return "не убрано"
    if cleaning_status == TaskStatus.IN_PROGRESS.value:
        return "идет уборка"
    if cleaning_status == TaskStatus.WAITING_CHECK.value:
        return "на проверке"
    if cleaning_status == TaskStatus.VERIFIED.value:
        return "готов к заезду"
    if cleaning_status == TaskStatus.REWORK.value:
        return "переделка"
    if cleaning_status == TaskStatus.PROBLEM.value:
        return "проблема"
    return "не убрано"


def readiness_label_with_icon(cleaning_status: Optional[str], keys_missing: bool = False) -> str:
    if keys_missing and cleaning_status == TaskStatus.VERIFIED.value:
        return "⚠️ Нет ключей — не готов к заезду"

    label = readiness_label(cleaning_status)
    icon_by_status = {
        TaskStatus.IN_PROGRESS.value: "🧹",
        TaskStatus.WAITING_CHECK.value: "🔍",
        TaskStatus.VERIFIED.value: "✅",
        TaskStatus.REWORK.value: "🔴",
        TaskStatus.PROBLEM.value: "🔴",
    }
    status = f"{icon_by_status.get(cleaning_status, '⚪')} {label}"
    return f"{status} · ⚠️ Нет ключей" if keys_missing else status


def _booking_status_for_task(task, checked_out: bool) -> str:
    if task["status"] == TaskStatus.VERIFIED.value and not task["apartment_keys_missing"]:
        return BookingStatus.READY.value
    if checked_out:
        return BookingStatus.CHECKED_OUT.value
    return BookingStatus.CLEANING_CREATED.value


def _is_disposable_realty_task(task) -> bool:
    return bool(
        task
        and task["status"] == TaskStatus.PLAN.value
        and task["assigned_maid_id"] is None
        and task["created_by"] is None
        and (task["comment"] or "").startswith("Источник: RealtyCalendar.")
    )


def housekeeping_cleaning_enabled(booking) -> bool:
    return not is_housekeeping_excluded(booking["apartment_code"])


async def _suppress_excluded_housekeeping_task(
    db: aiosqlite.Connection,
    timezone: str,
    booking,
    user_id: Optional[int],
):
    """Cancel an unstarted linked task and keep the booking itself intact."""
    task = None
    if booking["cleaning_task_id"]:
        task = await task_repo.get_by_id(db, booking["cleaning_task_id"])

    can_cancel = bool(
        task
        and task["status"] != TaskStatus.CANCELED.value
        and not task["started_at"]
        and task["status"] in MOVABLE_BOOKING_TASK_STATUSES
    )
    if can_cancel:
        old_status = task["status"]
        await db.execute(
            """
            UPDATE cleaning_tasks
            SET status = 'canceled',
                updated_at = ?
            WHERE id = ?
            """,
            (cleaning_service.now_iso(timezone), task["id"]),
        )
        await cleaning_service.log_event(
            db,
            task["id"],
            user_id,
            "housekeeping_scope_excluded",
            old_status,
            TaskStatus.CANCELED.value,
            {"apartment_code": booking["apartment_code"]},
        )

    if not task or task["status"] == TaskStatus.CANCELED.value or can_cancel:
        await db.execute(
            """
            UPDATE bookings
            SET cleaning_task_id = NULL,
                status = CASE
                    WHEN status IN ('cleaning_created', 'ready') THEN 'planned'
                    ELSE status
                END,
                updated_at = ?
            WHERE id = ?
            """,
            (cleaning_service.now_iso(timezone), booking["id"]),
        )

    await db.commit()
    return await booking_repo.get_by_id(db, booking["id"])


async def _cancel_replaced_realty_task(
    db: aiosqlite.Connection,
    timezone: str,
    task,
    user_id: Optional[int],
    keep_task_id: int,
) -> None:
    old_status = task["status"]
    await db.execute(
        """
        UPDATE cleaning_tasks
        SET status = 'canceled',
            external_booking_id = NULL,
            updated_at = ?
        WHERE id = ?
        """,
        (cleaning_service.now_iso(timezone), task["id"]),
    )
    await cleaning_service.log_event(
        db,
        task["id"],
        user_id,
        "duplicate_realty_task_replaced",
        old_status,
        TaskStatus.CANCELED.value,
        {"kept_task_id": keep_task_id},
    )
    await db.commit()


async def _detach_task_with_keys_issue_after_apartment_change(
    db: aiosqlite.Connection,
    timezone: str,
    booking,
    task,
    user_id: Optional[int],
):
    """Keep an open keys issue on its original apartment when a booking moves."""
    current_time = cleaning_service.now_iso(timezone)
    old_status = task["status"]
    can_cancel = old_status in MOVABLE_BOOKING_TASK_STATUSES and not task["started_at"]
    if can_cancel:
        await db.execute(
            """
            UPDATE cleaning_tasks
            SET status = 'canceled',
                external_booking_id = NULL,
                updated_at = ?
            WHERE id = ?
            """,
            (current_time, task["id"]),
        )
    await cleaning_service.log_event(
        db,
        task["id"],
        user_id,
        "booking_apartment_changed_keys_issue_kept",
        old_status,
        TaskStatus.CANCELED.value if can_cancel else old_status,
        {
            "old_apartment_id": task["apartment_id"],
            "new_apartment_id": booking["apartment_id"],
        },
    )
    await db.execute(
        """
        UPDATE bookings
        SET cleaning_task_id = NULL,
            status = CASE
                WHEN status IN ('cleaning_created', 'ready') THEN 'planned'
                ELSE status
            END,
            updated_at = ?
        WHERE id = ?
        """,
        (current_time, booking["id"]),
    )
    await db.commit()
    return await booking_repo.get_by_id(db, booking["id"])


async def _merge_unstarted_assignment(
    db: aiosqlite.Connection,
    timezone: str,
    source_task,
    target_task,
) -> None:
    target_status = target_task["status"]
    if (
        target_status in (TaskStatus.PLAN.value, TaskStatus.GUEST_CHECKED_OUT.value)
        and source_task["assigned_maid_id"] is not None
    ):
        target_status = TaskStatus.ASSIGNED.value
    elif (
        target_status == TaskStatus.PLAN.value
        and source_task["status"] == TaskStatus.GUEST_CHECKED_OUT.value
    ):
        target_status = TaskStatus.GUEST_CHECKED_OUT.value

    await db.execute(
        """
        UPDATE cleaning_tasks
        SET assigned_maid_id = COALESCE(assigned_maid_id, ?),
            supervisor_id = COALESCE(supervisor_id, ?),
            status = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (
            source_task["assigned_maid_id"],
            source_task["supervisor_id"],
            target_status,
            cleaning_service.now_iso(timezone),
            target_task["id"],
        ),
    )
    await db.commit()


async def _cancel_failed_realty_duplicates(
    db: aiosqlite.Connection,
    timezone: str,
    tasks,
    user_id: Optional[int],
    keep_task_id: int,
) -> None:
    updated_at = cleaning_service.now_iso(timezone)
    changed = False
    for task in tasks:
        if task["id"] == keep_task_id:
            continue
        await db.execute(
            """
            UPDATE cleaning_tasks
            SET status = 'canceled',
                updated_at = ?
            WHERE id = ? AND status = 'plan'
            """,
            (updated_at, task["id"]),
        )
        await cleaning_service.log_event(
            db,
            task["id"],
            user_id,
            "duplicate_realty_task_canceled",
            task["status"],
            TaskStatus.CANCELED.value,
            {"kept_task_id": keep_task_id},
        )
        changed = True
    if changed:
        await db.commit()


async def create_booking(
    db: aiosqlite.Connection,
    timezone: str,
    apartment_id: int,
    checkin_date: str,
    checkin_time: str,
    checkout_date: str,
    checkout_time: str,
    guests_count: int,
    created_by: int,
):
    booking = await booking_repo.create_booking(
        db,
        apartment_id=apartment_id,
        checkin_date=checkin_date,
        checkin_time=checkin_time,
        checkout_date=checkout_date,
        checkout_time=checkout_time,
        guests_count=guests_count,
        created_by=created_by,
    )

    if checkout_date == cleaning_service.today_iso(timezone):
        booking = await ensure_cleaning_task(
            db,
            timezone,
            booking["id"],
            created_by,
            checked_out=False,
        )
    return booking


async def ensure_cleaning_task(
    db: aiosqlite.Connection,
    timezone: str,
    booking_id: int,
    user_id: Optional[int],
    checked_out: bool,
):
    booking = await booking_repo.get_by_id(db, booking_id)
    if not booking:
        raise ValueError("Booking not found")

    if not housekeeping_cleaning_enabled(booking):
        return await _suppress_excluded_housekeeping_task(
            db,
            timezone,
            booking,
            user_id,
        )

    if booking["cleaning_task_id"]:
        task = await task_repo.get_by_id(db, booking["cleaning_task_id"])
        if (
            task
            and task["status"] != TaskStatus.CANCELED.value
            and task["apartment_id"] != booking["apartment_id"]
            and cleaning_service.keys_missing_open(task)
        ):
            transferable_assignment = (
                task
                if task["status"] in MOVABLE_BOOKING_TASK_STATUSES and not task["started_at"]
                else None
            )
            await _detach_task_with_keys_issue_after_apartment_change(
                db, timezone, booking, task, user_id
            )
            updated_booking = await ensure_cleaning_task(
                db, timezone, booking_id, user_id, checked_out
            )
            if transferable_assignment and updated_booking["cleaning_task_id"]:
                new_task = await task_repo.get_by_id(db, updated_booking["cleaning_task_id"])
                if new_task and not new_task["started_at"] and new_task["status"] in (
                    TaskStatus.PLAN.value,
                    TaskStatus.GUEST_CHECKED_OUT.value,
                    TaskStatus.ASSIGNED.value,
                ) and new_task["assigned_maid_id"] in (
                    None,
                    transferable_assignment["assigned_maid_id"],
                ):
                    await _merge_unstarted_assignment(
                        db, timezone, transferable_assignment, new_task
                    )
            return await booking_repo.get_by_id(db, booking_id)

    if booking["cleaning_task_id"]:
        task = await task_repo.get_by_id(db, booking["cleaning_task_id"])
        if task and task["status"] != TaskStatus.CANCELED.value:
            task_date_changed = task["planned_date"] != booking["checkout_date"]
            task_can_move = task["status"] in MOVABLE_BOOKING_TASK_STATUSES

            if task_can_move and booking["external_booking_id"]:
                matching_task = await task_repo.get_by_external_booking_key(
                    db,
                    booking["external_booking_id"],
                    booking["apartment_id"],
                    booking["checkout_date"],
                )
                if matching_task and matching_task["id"] != task["id"]:
                    if (
                        matching_task["status"] == TaskStatus.CANCELED.value
                        or _is_disposable_realty_task(matching_task)
                    ):
                        # A previous partial webhook already occupied the target
                        # unique key.  The linked task carries the operational
                        # assignment, so preserve it and remove the empty shell.
                        await _cancel_replaced_realty_task(
                            db,
                            timezone,
                            matching_task,
                            user_id,
                            task["id"],
                        )
                    else:
                        # Both rows contain useful state.  Keep the row already
                        # on the correct date and move an unstarted assignment
                        # onto it before dropping the stale schedule entry.
                        await _merge_unstarted_assignment(
                            db,
                            timezone,
                            task,
                            matching_task,
                        )
                        await _cancel_replaced_realty_task(
                            db,
                            timezone,
                            task,
                            user_id,
                            matching_task["id"],
                        )
                        await booking_repo.attach_cleaning_task(
                            db,
                            booking_id,
                            matching_task["id"],
                            _booking_status_for_task(matching_task, checked_out),
                            cleaning_service.now_iso(timezone),
                        )
                        return await ensure_cleaning_task(
                            db,
                            timezone,
                            booking_id,
                            user_id,
                            checked_out,
                        )

            if task_date_changed and not task_can_move:
                # The linked task represents a cleaning that already started
                # or finished before the guest's new checkout.  Preserve that
                # task as history and create a fresh turnover task below.
                await db.execute(
                    """
                    UPDATE bookings
                    SET cleaning_task_id = NULL,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (booking_id,),
                )
                await cleaning_service.log_event(
                    db,
                    task["id"],
                    user_id,
                    "booking_followup_required",
                    task["status"],
                    task["status"],
                    {
                        "source": booking["source"],
                        "old_planned_date": task["planned_date"],
                        "new_checkout_date": booking["checkout_date"],
                        "reason": "linked cleaning already started or finished",
                    },
                )
                await db.commit()
                booking = await booking_repo.get_by_id(db, booking_id)
            else:
                next_checkin_time = effective_next_checkin_time(booking)
                deadline_at = deadline_from_next_checkin(
                    timezone,
                    booking["checkout_date"],
                    next_checkin_time,
                )
                comment_parts = [
                    "Автоматически создано из выезда.",
                    f"Плановый выезд: {effective_checkout_time(booking)}",
                ]
                if booking["source"] == "realtycalendar":
                    comment_parts.insert(0, "Источник: RealtyCalendar.")
                if booking["no_next_booking"]:
                    comment_parts.append("Следующей брони нет.")
                elif next_checkin_time:
                    comment_parts.append(f"Следующий заезд: {next_checkin_label(next_checkin_time)}.")
                updated_comment = "\n".join(comment_parts)
                updated_at = cleaning_service.now_iso(timezone)
                await db.execute(
                    """
                    UPDATE cleaning_tasks
                    SET apartment_id = ?,
                        external_booking_id = ?,
                        planned_date = ?,
                        deadline_at = ?,
                        comment = ?,
                        updated_at = ?
                    WHERE id = ?
                      AND status IN ('plan', 'guest_checked_out', 'assigned', 'problem', 'overdue')
                    """,
                    (
                        booking["apartment_id"],
                        booking["external_booking_id"],
                        booking["checkout_date"],
                        deadline_at,
                        updated_comment,
                        updated_at,
                        task["id"],
                    ),
                )
                updated_task = await task_repo.get_by_id(db, task["id"])
                schedule_changed = bool(
                    updated_task
                    and (
                        updated_task["planned_date"] != task["planned_date"]
                        or updated_task["deadline_at"] != task["deadline_at"]
                        or updated_task["comment"] != task["comment"]
                    )
                )
                if schedule_changed:
                    await cleaning_service.log_event(
                        db,
                        task["id"],
                        user_id,
                        "booking_schedule_updated",
                        task["status"],
                        updated_task["status"],
                        {
                            "source": booking["source"],
                            "old_planned_date": task["planned_date"],
                            "new_planned_date": updated_task["planned_date"],
                            "checkout_time": effective_checkout_time(booking),
                            "old_deadline_at": task["deadline_at"],
                            "new_deadline_at": updated_task["deadline_at"],
                        },
                    )
                await db.commit()
                if checked_out and task["status"] == TaskStatus.PLAN.value:
                    await cleaning_service.mark_guest_checked_out(
                        db,
                        timezone,
                        task["id"],
                        user_id,
                        "Гость выехал. Уборка доступна к назначению.",
                    )
                return await booking_repo.get_by_id(db, booking_id)

        if task and task["status"] == TaskStatus.CANCELED.value:
            if task["external_booking_id"]:
                await db.execute(
                    """
                    UPDATE cleaning_tasks
                    SET external_booking_id = NULL,
                        updated_at = ?
                    WHERE id = ?
                    """,
                    (cleaning_service.now_iso(timezone), task["id"]),
                )
                await cleaning_service.log_event(
                    db,
                    task["id"],
                    user_id,
                    "booking_task_replaced",
                    task["status"],
                    task["status"],
                    {"external_booking_id": task["external_booking_id"]},
                )

        await db.execute(
            """
            UPDATE bookings
            SET cleaning_task_id = NULL,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (booking_id,),
        )
        await db.commit()
        booking = await booking_repo.get_by_id(db, booking_id)

    next_checkin_time = effective_next_checkin_time(booking)
    deadline_at = deadline_from_next_checkin(
        timezone,
        booking["checkout_date"],
        next_checkin_time,
    )
    comment_parts = [
        "Автоматически создано из выезда.",
        f"Плановый выезд: {effective_checkout_time(booking)}",
    ]
    if booking["source"] == "realtycalendar":
        comment_parts.insert(0, "Источник: RealtyCalendar.")
    if booking["no_next_booking"]:
        comment_parts.append("Следующей брони нет.")
    elif next_checkin_time:
        comment_parts.append(f"Следующий заезд: {next_checkin_label(next_checkin_time)}.")

    if booking["external_booking_id"]:
        matching_task = await task_repo.get_by_external_booking_key(
            db,
            booking["external_booking_id"],
            booking["apartment_id"],
            booking["checkout_date"],
        )
        recoverable_orphans = await task_repo.list_recoverable_realty_orphans(
            db,
            booking["apartment_id"],
            booking["checkout_date"],
        )

        if matching_task and matching_task["status"] != TaskStatus.CANCELED.value:
            await booking_repo.attach_cleaning_task(
                db,
                booking_id,
                matching_task["id"],
                _booking_status_for_task(matching_task, checked_out),
                cleaning_service.now_iso(timezone),
            )
            await _cancel_failed_realty_duplicates(
                db,
                timezone,
                recoverable_orphans,
                user_id,
                matching_task["id"],
            )
            return await ensure_cleaning_task(
                db,
                timezone,
                booking_id,
                user_id,
                checked_out,
            )

        if matching_task and matching_task["status"] == TaskStatus.CANCELED.value:
            await db.execute(
                """
                UPDATE cleaning_tasks
                SET external_booking_id = NULL,
                    updated_at = ?
                WHERE id = ?
                """,
                (cleaning_service.now_iso(timezone), matching_task["id"]),
            )
            await db.commit()

        if recoverable_orphans:
            task = recoverable_orphans[0]
            await db.execute(
                """
                UPDATE cleaning_tasks
                SET external_booking_id = ?,
                    updated_at = ?
                WHERE id = ?
                """,
                (
                    booking["external_booking_id"],
                    cleaning_service.now_iso(timezone),
                    task["id"],
                ),
            )
            await cleaning_service.log_event(
                db,
                task["id"],
                user_id,
                "realty_task_recovered",
                task["status"],
                task["status"],
                {"external_booking_id": booking["external_booking_id"]},
            )
            await db.commit()
            await booking_repo.attach_cleaning_task(
                db,
                booking_id,
                task["id"],
                _booking_status_for_task(task, checked_out),
                cleaning_service.now_iso(timezone),
            )
            await _cancel_failed_realty_duplicates(
                db,
                timezone,
                recoverable_orphans,
                user_id,
                task["id"],
            )
            return await ensure_cleaning_task(
                db,
                timezone,
                booking_id,
                user_id,
                checked_out,
            )

    try:
        task = await cleaning_service.create_task(
            db,
            timezone,
            apartment_id=booking["apartment_id"],
            cleaning_type=CleaningType.STANDARD.value,
            planned_date=booking["checkout_date"],
            deadline_at=deadline_at,
            maid_id=None,
            supervisor_id=None,
            comment="\n".join(comment_parts),
            created_by=user_id,
            external_booking_id=booking["external_booking_id"],
        )
    except aiosqlite.IntegrityError:
        await db.rollback()
        if not booking["external_booking_id"]:
            raise
        task = await task_repo.get_by_external_booking_key(
            db,
            booking["external_booking_id"],
            booking["apartment_id"],
            booking["checkout_date"],
        )
        if not task or task["status"] == TaskStatus.CANCELED.value:
            raise

    if checked_out:
        task = await cleaning_service.mark_guest_checked_out(
            db,
            timezone,
            task["id"],
            user_id,
            "Гость уже выехал.",
        )

    return await booking_repo.attach_cleaning_task(
        db,
        booking_id,
        task["id"],
        _booking_status_for_task(task, checked_out),
        cleaning_service.now_iso(timezone),
    )


async def refresh_turnover_links(
    db: aiosqlite.Connection,
    timezone: str,
    booking,
):
    next_booking = await booking_repo.find_next_checkin_same_day(
        db,
        booking["apartment_id"],
        booking["checkout_date"],
        exclude_booking_id=booking["id"],
    )
    next_checkin_time = (
        (next_booking["checkin_time"] or DEFAULT_REALTY_NEXT_CHECKIN_TIME)
        if next_booking
        else None
    )
    no_next_booking = not bool(next_booking)
    if (
        booking["next_checkin_time"] != next_checkin_time
        or bool(booking["no_next_booking"]) != no_next_booking
    ):
        booking = await booking_repo.update_next_checkin(
            db,
            booking["id"],
            next_checkin_time,
            no_next_booking,
            cleaning_service.now_iso(timezone),
        )

    previous_bookings = []
    if booking["checkin_date"]:
        previous_bookings = await booking_repo.list_previous_checkouts_same_day(
            db,
            booking["apartment_id"],
            booking["checkin_date"],
            exclude_booking_id=booking["id"],
        )
    incoming_checkin_time = booking["checkin_time"] or DEFAULT_REALTY_NEXT_CHECKIN_TIME
    for previous in previous_bookings:
        if (
            previous["next_checkin_time"] != incoming_checkin_time
            or bool(previous["no_next_booking"])
        ):
            previous = await booking_repo.update_next_checkin(
                db,
                previous["id"],
                incoming_checkin_time,
                False,
                cleaning_service.now_iso(timezone),
            )
        if previous["cleaning_task_id"]:
            await ensure_cleaning_task(
                db,
                timezone,
                previous["id"],
                None,
                checked_out=previous["status"] == BookingStatus.CHECKED_OUT.value,
            )

    return booking


def _reconciliation_item(booking, previous_task_id: Optional[int], previous_status: Optional[str]) -> dict:
    next_checkin_time = effective_next_checkin_time(booking)
    return {
        "booking_id": booking["id"],
        "external_booking_id": booking["external_booking_id"],
        "apartment_code": booking["apartment_code"],
        "checkout_date": booking["checkout_date"],
        "checkout_time": effective_checkout_time(booking),
        "next_checkin_time": next_checkin_time,
        "no_next_booking": bool(booking["no_next_booking"]),
        "cleaning_task_id": booking["cleaning_task_id"],
        "previous_cleaning_task_id": previous_task_id,
        "previous_cleaning_status": previous_status,
    }


async def reconcile_cleaning_tasks_for_date(
    db: aiosqlite.Connection,
    timezone: str,
    date_value: str,
    user_id: Optional[int] = None,
) -> dict:
    all_bookings = await booking_repo.list_checkout_date(db, date_value)
    bookings = [booking for booking in all_bookings if housekeeping_cleaning_enabled(booking)]
    created = []
    repaired = []
    refreshed = 0
    checkins_updated = 0

    for booking in bookings:
        previous_next_checkin_time = booking["next_checkin_time"]
        previous_no_next_booking = bool(booking["no_next_booking"])
        booking = await refresh_turnover_links(db, timezone, booking)
        if (
            booking["next_checkin_time"] != previous_next_checkin_time
            or bool(booking["no_next_booking"]) != previous_no_next_booking
        ):
            checkins_updated += 1

        previous_task_id = booking["cleaning_task_id"]
        previous_status = booking["cleaning_status"]
        needs_task = (
            not previous_task_id
            or previous_status is None
            or previous_status == TaskStatus.CANCELED.value
            or booking["cleaning_planned_date"] != booking["checkout_date"]
        )

        updated = await ensure_cleaning_task(
            db,
            timezone,
            booking["id"],
            user_id,
            checked_out=booking["status"] == BookingStatus.CHECKED_OUT.value,
        )

        if needs_task and updated and updated["cleaning_task_id"]:
            item = _reconciliation_item(updated, previous_task_id, previous_status)
            if previous_task_id:
                repaired.append(item)
            else:
                created.append(item)
        else:
            refreshed += 1

    tasks = await task_repo.list_for_date(db, date_value)
    unlinked_tasks = [task for task in tasks if not task["local_booking_id"]]
    unlinked_items = [
        {
            "task_id": task["id"],
            "apartment_code": task["apartment_code"],
            "cleaning_type": task["cleaning_type"],
            "status": task["status"],
        }
        for task in unlinked_tasks
    ]

    return {
        "date": date_value,
        "checked": len(bookings),
        "excluded_booking_count": len(all_bookings) - len(bookings),
        "task_count": len(tasks),
        "linked_task_count": len(tasks) - len(unlinked_tasks),
        "unlinked_task_count": len(unlinked_tasks),
        "unlinked_standard_count": sum(
            task["cleaning_type"] != CleaningType.DAILY.value for task in unlinked_tasks
        ),
        "daily_task_count": sum(
            task["cleaning_type"] == CleaningType.DAILY.value for task in tasks
        ),
        "unlinked_tasks": unlinked_items,
        "checkins_updated": checkins_updated,
        "created": created,
        "repaired": repaired,
        "refreshed": refreshed,
    }


async def repair_inconsistent_realty_cleaning_links(
    db: aiosqlite.Connection,
    timezone: str,
    checkout_date_from: str,
    checkout_date_to: str,
    user_id: Optional[int] = None,
) -> list[dict]:
    bookings = await booking_repo.list_inconsistent_realty_cleaning_links(
        db,
        checkout_date_from,
        checkout_date_to,
    )
    repaired = []
    for booking in bookings:
        if not housekeeping_cleaning_enabled(booking):
            await _suppress_excluded_housekeeping_task(
                db,
                timezone,
                booking,
                user_id,
            )
            continue
        previous_task_id = booking["cleaning_task_id"]
        previous_task_date = booking["cleaning_planned_date"]
        booking = await refresh_turnover_links(db, timezone, booking)
        updated = await ensure_cleaning_task(
            db,
            timezone,
            booking["id"],
            user_id,
            checked_out=booking["status"] == BookingStatus.CHECKED_OUT.value,
        )
        if not updated or not updated["cleaning_task_id"]:
            continue
        repaired.append(
            {
                "booking_id": updated["id"],
                "external_booking_id": updated["external_booking_id"],
                "apartment_code": updated["apartment_code"],
                "checkout_date": updated["checkout_date"],
                "checkout_time": effective_checkout_time(updated),
                "cleaning_task_id": updated["cleaning_task_id"],
                "previous_cleaning_task_id": previous_task_id,
                "previous_cleaning_planned_date": previous_task_date,
            }
        )
    return repaired


def _normalize_schedule_code(value: str) -> str:
    return "".join(character for character in value.casefold() if character.isalnum())


def _match_schedule_apartment(raw_code: str, apartments):
    normalized = _normalize_schedule_code(raw_code)
    if not normalized:
        return None
    normalized_without_index = normalized.lstrip("0123456789")

    candidates = sorted(
        apartments,
        key=lambda apartment: len(_normalize_schedule_code(apartment["code"])),
        reverse=True,
    )
    for apartment in candidates:
        apartment_code = _normalize_schedule_code(apartment["code"])
        if (
            normalized == apartment_code
            or normalized.startswith(apartment_code)
            or normalized_without_index.startswith(apartment_code)
        ):
            return apartment
    return None


async def restore_cleaning_schedule_from_codes(
    db: aiosqlite.Connection,
    timezone: str,
    date_value: str,
    raw_codes: list[str],
    user_id: int,
) -> dict:
    apartments = await apartment_repo.list_active(db)
    requested = []
    requested_ids = set()
    unknown_codes = []
    excluded_codes = []

    for raw_code in raw_codes:
        apartment = _match_schedule_apartment(raw_code, apartments)
        if not apartment:
            unknown_codes.append(raw_code)
            continue
        if is_housekeeping_excluded(apartment["code"]):
            excluded_codes.append(apartment["code"])
            continue
        if apartment["id"] in requested_ids:
            continue
        requested.append(apartment)
        requested_ids.add(apartment["id"])

    tasks_before = await task_repo.list_for_date(db, date_value)
    turnover_tasks = [
        task
        for task in tasks_before
        if task["cleaning_type"] != CleaningType.DAILY.value
        and not is_housekeeping_excluded(task["apartment_code"])
    ]
    tasks_by_apartment = {}
    for task in turnover_tasks:
        tasks_by_apartment.setdefault(task["apartment_id"], []).append(task)

    created = []
    existing = []
    duplicate_tasks = []
    for apartment in requested:
        apartment_tasks = tasks_by_apartment.get(apartment["id"], [])
        if apartment_tasks:
            existing.append(apartment_tasks[0])
            duplicate_tasks.extend(apartment_tasks[1:])
            continue

        next_booking = await booking_repo.find_next_checkin_same_day(
            db,
            apartment["id"],
            date_value,
        )
        next_checkin_time = (
            (next_booking["checkin_time"] or DEFAULT_REALTY_NEXT_CHECKIN_TIME)
            if next_booking
            else None
        )
        deadline_at = deadline_from_next_checkin(
            timezone,
            date_value,
            next_checkin_time,
        )
        comment_parts = [
            "Аварийно восстановлена по фактическому списку RealtyCalendar.",
            f"Плановый выезд: {DEFAULT_REALTY_CHECKOUT_TIME}",
        ]
        if next_checkin_time:
            comment_parts.append(f"Следующий заезд: {next_checkin_label(next_checkin_time)}.")
        else:
            comment_parts.append("Следующей брони в локальной базе нет.")

        task = await cleaning_service.create_task(
            db,
            timezone,
            apartment_id=apartment["id"],
            cleaning_type=CleaningType.STANDARD.value,
            planned_date=date_value,
            deadline_at=deadline_at,
            maid_id=None,
            supervisor_id=user_id,
            comment="\n".join(comment_parts),
            created_by=user_id,
        )
        created.append(task)

    extra_tasks = [
        task
        for task in turnover_tasks
        if task["apartment_id"] not in requested_ids
    ]

    return {
        "date": date_value,
        "requested": requested,
        "requested_count": len(requested),
        "created": created,
        "existing": existing,
        "unknown_codes": unknown_codes,
        "excluded_codes": excluded_codes,
        "extra_tasks": extra_tasks,
        "duplicate_tasks": duplicate_tasks,
    }


async def update_checkout_plan_and_create_cleaning(
    db: aiosqlite.Connection,
    timezone: str,
    booking_id: int,
    checkout_time: str,
    next_checkin_time: Optional[str],
    no_next_booking: bool,
    user_id: int,
):
    await booking_repo.update_checkout_plan(
        db,
        booking_id=booking_id,
        checkout_time=checkout_time,
        next_checkin_time=next_checkin_time,
        no_next_booking=no_next_booking,
        updated_at=cleaning_service.now_iso(timezone),
    )
    return await ensure_cleaning_task(
        db,
        timezone,
        booking_id,
        user_id,
        checked_out=False,
    )


async def mark_booking_checked_out(
    db: aiosqlite.Connection,
    timezone: str,
    booking_id: int,
    user_id: int,
):
    actual_checkout_at = cleaning_service.now_iso(timezone)
    await booking_repo.mark_checked_out(db, booking_id, actual_checkout_at)
    return await ensure_cleaning_task(
        db,
        timezone,
        booking_id,
        user_id,
        checked_out=True,
    )


async def create_ad_hoc_checkout(
    db: aiosqlite.Connection,
    timezone: str,
    apartment_id: int,
    user_id: int,
):
    now = datetime.now(ZoneInfo(timezone)).replace(microsecond=0)
    booking = await booking_repo.create_checkout_only_booking(
        db,
        apartment_id=apartment_id,
        checkout_date=now.date().isoformat(),
        checkout_time=now.strftime("%H:%M"),
        created_by=user_id,
    )
    return await mark_booking_checked_out(db, timezone, booking["id"], user_id)
