from datetime import datetime
import re
from typing import Optional

from app.i18n import cleaning_type_text, problem_type_text, status_text, tr
from app.models import CleaningType, CLEANING_TYPE_LABELS, PROBLEM_TYPE_LABELS, STATUS_LABELS, VERIFICATION_METHOD_LABELS, label


APARTMENT_FLOORS = {}

DEFAULT_CHECKOUT_TIME = "12:00"
DEFAULT_CHECKIN_TIME = "15:00"


def format_time(value: Optional[str]) -> str:
    if not value:
        return "-"
    try:
        return datetime.fromisoformat(value).strftime("%H:%M")
    except ValueError:
        return value


def format_date(value: Optional[str]) -> str:
    if not value:
        return "-"
    try:
        return datetime.fromisoformat(value).strftime("%d.%m.%Y")
    except ValueError:
        return value


def format_datetime(value: Optional[str]) -> str:
    if not value:
        return "-"
    try:
        return datetime.fromisoformat(value).strftime("%d.%m.%Y %H:%M")
    except ValueError:
        return value


def duration_label(start_value: Optional[str], end_value: Optional[str]) -> str:
    if not start_value or not end_value:
        return "-"
    try:
        start = datetime.fromisoformat(start_value)
        end = datetime.fromisoformat(end_value)
    except ValueError:
        return "-"
    minutes = max(0, round((end - start).total_seconds() / 60))
    hours, rest = divmod(minutes, 60)
    if hours:
        return f"{hours} ч {rest} мин"
    return f"{rest} мин"


def _row_value(row, key: str):
    try:
        return row[key]
    except (KeyError, IndexError, TypeError):
        return None


def _normalize_apartment_code(code: str) -> str:
    return re.sub(r"[^A-Z0-9]+", "-", code.upper()).strip("-")


def infer_floor_from_code(code: Optional[str]) -> Optional[int]:
    if not code:
        return None

    return APARTMENT_FLOORS.get(_normalize_apartment_code(code))


def floor_label(row) -> Optional[str]:
    floor = _row_value(row, "floor")
    if floor in (None, "", 0):
        floor = infer_floor_from_code(_row_value(row, "apartment_code") or _row_value(row, "code"))
    if not floor:
        return None
    return f"{floor} этаж"


def apartment_label(row, code_key: str = "apartment_code") -> str:
    code = _row_value(row, code_key) or _row_value(row, "code") or "-"
    floor = floor_label(row)
    display_code = compact_apartment_code(code)
    if not floor:
        return display_code
    return f"{display_code} ({floor})"


def compact_apartment_code(value: Optional[str]) -> str:
    return str(value or "-").strip()


def compact_apartment_label(row, code_key: str = "apartment_code") -> str:
    code = _row_value(row, code_key) or _row_value(row, "code") or "-"
    floor = floor_label(row)
    compact_code = compact_apartment_code(code)
    if not floor:
        return compact_code
    return f"{compact_code} ({floor})"


def checkout_time_label(row) -> str:
    return _row_value(row, "booking_checkout_time") or DEFAULT_CHECKOUT_TIME


def next_checkin_time_label(row) -> str:
    no_next_booking = bool(_row_value(row, "booking_no_next_booking"))
    if no_next_booking:
        return "нет"

    value = _row_value(row, "booking_next_checkin_time") or DEFAULT_CHECKIN_TIME
    if value == "after_18":
        return "после 18:00"
    return value


def _problem_comment(comment: Optional[str]) -> Optional[str]:
    if not comment or "Проблема:" not in comment:
        return None
    return comment.rsplit("Проблема:", 1)[1].strip() or None


def task_title(task, compact: bool = False) -> str:
    apartment = compact_apartment_label(task) if compact else apartment_label(task)
    if (
        _row_value(task, "cleaning_type") == CleaningType.DAILY.value
        and not _row_value(task, "booking_source")
    ):
        return f"{apartment} · ежедневная · с {format_time(_row_value(task, 'deadline_at'))}"
    checkout = checkout_time_label(task)
    if bool(_row_value(task, "booking_no_next_booking")):
        return f"{apartment} · выезд {checkout} · заезда нет"
    checkin = next_checkin_time_label(task)
    return f"{apartment} · выезд {checkout} · заезд {checkin}"


def maid_floor_label(row, language: str) -> Optional[str]:
    floor = _row_value(row, "floor")
    if floor in (None, "", 0):
        floor = infer_floor_from_code(_row_value(row, "apartment_code") or _row_value(row, "code"))
    if not floor:
        return None
    return tr(language, "floor", floor=floor)


def maid_apartment_label(row, language: str, code_key: str = "apartment_code") -> str:
    code = _row_value(row, code_key) or _row_value(row, "code") or "-"
    floor = maid_floor_label(row, language)
    display_code = compact_apartment_code(code)
    return f"{display_code} ({floor})" if floor else display_code


def compact_maid_apartment_label(
    row,
    language: str,
    code_key: str = "apartment_code",
) -> str:
    code = _row_value(row, code_key) or _row_value(row, "code") or "-"
    floor = maid_floor_label(row, language)
    compact_code = compact_apartment_code(code)
    return f"{compact_code} ({floor})" if floor else compact_code


def maid_next_checkin_time_label(row, language: str) -> str:
    if bool(_row_value(row, "booking_no_next_booking")):
        return tr(language, "no_checkin")
    value = _row_value(row, "booking_next_checkin_time") or DEFAULT_CHECKIN_TIME
    return tr(language, "after_18") if value == "after_18" else value


def maid_task_title(task, language: str = "ru", compact: bool = False) -> str:
    apartment = (
        compact_maid_apartment_label(task, language)
        if compact
        else maid_apartment_label(task, language)
    )
    if (
        _row_value(task, "cleaning_type") == CleaningType.DAILY.value
        and not _row_value(task, "booking_source")
    ):
        return tr(
            language,
            "daily_title",
            apartment=apartment,
            time=format_time(_row_value(task, "deadline_at")),
        )
    checkout = checkout_time_label(task)
    if bool(_row_value(task, "booking_no_next_booking")):
        return tr(
            language,
            "checkout_no_checkin",
            apartment=apartment,
            checkout=checkout,
        )
    return tr(
        language,
        "checkout_checkin",
        apartment=apartment,
        checkout=checkout,
        checkin=maid_next_checkin_time_label(task, language),
    )


def maid_task_card(task, language: str = "ru") -> str:
    floor = maid_floor_label(task, language) or "-"
    is_daily_cleaning = (
        _row_value(task, "cleaning_type") == CleaningType.DAILY.value
        and not _row_value(task, "booking_source")
    )
    lines = [
        f"{tr(language, 'card_object')}: {maid_apartment_label(task, language)}",
        f"{tr(language, 'card_building')}: {task['building'] or '-'}",
        f"{tr(language, 'card_address_floor')}: {task['address'] or '-'}, {floor}",
        f"{tr(language, 'card_type')}: {cleaning_type_text(language, task['cleaning_type'])}",
        f"{tr(language, 'card_status')}: {status_text(language, task['status'])}",
        f"{tr(language, 'card_maid')}: {task['maid_name'] or tr(language, 'not_assigned')}",
        f"{tr(language, 'card_supervisor')}: {task['supervisor_name'] or '-'}",
        f"{tr(language, 'card_start')}: {format_time(task['started_at'])}",
        f"{tr(language, 'card_finish')}: {format_time(task['finished_at'])}",
        f"{tr(language, 'card_access_time' if is_daily_cleaning else 'card_deadline')}: {format_time(task['deadline_at'])}",
    ]
    if not is_daily_cleaning:
        lines.insert(3, f"{tr(language, 'card_checkout')}: {checkout_time_label(task)}")
        lines.insert(4, f"{tr(language, 'card_next_checkin')}: {maid_next_checkin_time_label(task, language)}")
    if task["actual_duration_min"] is not None:
        lines.append(
            f"{tr(language, 'card_duration')}: "
            f"{task['actual_duration_min']} {tr(language, 'minutes_short')}"
        )
    if task["quality_score"] is not None:
        lines.append(f"{tr(language, 'card_score')}: {task['quality_score']}/10")
    if task["rework_reason"]:
        lines.append(f"{tr(language, 'card_rework')}: {task['rework_reason']}")
    problem_resolved_at = _row_value(task, "problem_resolved_at")
    if task["problem_type"] and not problem_resolved_at:
        lines.append(
            f"{tr(language, 'card_problem')}: {problem_type_text(language, task['problem_type'])}"
        )
    elif task["problem_type"] and problem_resolved_at:
        lines.append(
            f"{tr(language, 'card_resolved_problem')}: {problem_type_text(language, task['problem_type'])}"
        )
    if _row_value(task, "apartment_keys_missing") or (
        _row_value(task, "keys_missing_reported_at") and not _row_value(task, "keys_missing_resolved_at")
    ):
        lines.append(tr(language, "card_keys_missing"))
    if task["comment"]:
        lines.append(f"{tr(language, 'card_comment')}: {task['comment']}")
    return "\n".join(lines)


def task_card(task) -> str:
    floor = floor_label(task) or "-"
    is_extra_cleaning = (
        _row_value(task, "cleaning_type") == CleaningType.DAILY.value
        and not _row_value(task, "booking_source")
    )
    lines = [
        f"Объект: {apartment_label(task)}",
        f"ЖК: {task['building'] or '-'}",
        f"Адрес/этаж: {task['address'] or '-'}, {floor}",
        f"Тип уборки: {label(CLEANING_TYPE_LABELS, task['cleaning_type'])}",
        f"Статус: {label(STATUS_LABELS, task['status'])}",
        f"Горничная: {task['maid_name'] or 'не назначена'}",
        f"Супервизор: {task['supervisor_name'] or '-'}",
        f"Старт: {format_time(task['started_at'])}",
        f"Финиш: {format_time(task['finished_at'])}",
        f"{'Можно прийти' if is_extra_cleaning else 'Дедлайн'}: {format_time(task['deadline_at'])}",
    ]
    if not is_extra_cleaning:
        lines.insert(3, f"Выезд гостя: {checkout_time_label(task)}")
        lines.insert(4, f"Следующий заезд: {next_checkin_time_label(task)}")
    if task["actual_duration_min"] is not None:
        lines.append(f"Время уборки: {task['actual_duration_min']} мин")
    if task["quality_score"] is not None:
        lines.append(f"Оценка: {task['quality_score']}/10")
    if _row_value(task, "verification_method"):
        lines.append(f"Способ проверки: {label(VERIFICATION_METHOD_LABELS, task['verification_method'])}")
    elif task["status"] == "verified" or _row_value(task, "verified_at"):
        lines.append("Способ проверки: не указан")
    if _row_value(task, "verified_by_name"):
        lines.append(f"Фактически принял: {task['verified_by_name']}")
    if task["rework_reason"]:
        lines.append(f"Переделка: {task['rework_reason']}")
    problem_resolved_at = _row_value(task, "problem_resolved_at")
    if task["problem_type"] and not problem_resolved_at:
        lines.append(f"Проблема: {label(PROBLEM_TYPE_LABELS, task['problem_type'])}")
    elif task["problem_type"] and problem_resolved_at:
        lines.append(f"Решенная проблема: {label(PROBLEM_TYPE_LABELS, task['problem_type'])}")
    if _row_value(task, "apartment_keys_missing") or (
        _row_value(task, "keys_missing_reported_at") and not _row_value(task, "keys_missing_resolved_at")
    ):
        lines.append("⚠️ Проблема: нет ключей — квартира не готова к заезду")
    if task["comment"]:
        lines.append(f"Комментарий: {task['comment']}")
    return "\n".join(lines)


def problem_card(task) -> str:
    keys_reported_at = _row_value(task, "keys_missing_reported_at")
    keys_resolved_at = _row_value(task, "keys_missing_resolved_at")
    keys_open = bool(keys_reported_at and not keys_resolved_at)
    problem_reported_at = _row_value(task, "problem_reported_at") or _row_value(task, "updated_at")
    problem_resolved_at = _row_value(task, "problem_resolved_at")
    generic_open = bool(task["problem_type"] and not problem_resolved_at)
    comment = _problem_comment(_row_value(task, "comment"))

    lines = [
        f"Проблема: {apartment_label(task)}",
        f"ЖК: {task['building'] or '-'}",
        f"Статус квартиры: {'⚠️ есть открытая проблема' if keys_open or generic_open else 'проблемы решены'}",
        f"Горничная: {task['maid_name'] or 'не назначена'}",
        f"Супервизор: {task['supervisor_name'] or '-'}",
    ]
    if task["problem_type"]:
        status = "открыта" if generic_open else "решена"
        problem_heading = "Другая проблема" if keys_reported_at else "Тип"
        lines.append(f"{problem_heading}: {label(PROBLEM_TYPE_LABELS, task['problem_type'])} — {status}")
        lines.append(f"Подана: {format_datetime(problem_reported_at)}")
        if problem_resolved_at:
            lines.append(f"Решена: {format_datetime(problem_resolved_at)}")
            lines.append(f"Время решения: {duration_label(problem_reported_at, problem_resolved_at)}")
        if comment:
            lines.append(f"Комментарий: {comment}")
    if keys_reported_at:
        if keys_open:
            lines.append("⚠️ Нет ключей: нельзя принять уборку и передать квартиру к заезду.")
        else:
            lines.append("Ключи положены — проблема решена.")
        lines.append(f"Об отсутствии ключей сообщено: {format_datetime(keys_reported_at)}")
        if keys_resolved_at:
            lines.append(f"Ключи положены: {format_datetime(keys_resolved_at)}")
    return "\n".join(lines)
