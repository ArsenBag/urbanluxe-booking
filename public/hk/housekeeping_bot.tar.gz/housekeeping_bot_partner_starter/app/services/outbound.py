"""Urban Luxe (01.10.2026): исходящие события уборок в систему urbanluxe.cc.

Каждое изменение статуса уборки (log_event) уходит POST-ом на URBANLUXE_EVENTS_URL
с заголовком X-Webhook-Token = URBANLUXE_EVENTS_TOKEN. Там Netlify-функция hk-events
пишет статус в cleaning_tasks (Supabase) — лист заездов бронеров и staff.html видят «убрано».
Отправка fire-and-forget, ошибки только логируются; без URL — ничего не делает.
"""
from __future__ import annotations

import asyncio
import logging
import os
from typing import Any, Optional

import aiosqlite
from aiohttp import ClientError, ClientSession, ClientTimeout

from app.repositories import cleaning_tasks as task_repo

logger = logging.getLogger(__name__)

EVENTS_URL = os.getenv("URBANLUXE_EVENTS_URL", "").strip()
EVENTS_TOKEN = os.getenv("URBANLUXE_EVENTS_TOKEN", "").strip()

TASK_KEYS = (
    "id", "external_booking_id", "apartment_code", "building", "floor", "cleaning_type", "status",
    "planned_date", "planned_start_at", "deadline_at", "started_at", "finished_at", "verified_at",
    "actual_duration_min", "quality_score", "rework_required", "rework_reason", "problem_type",
    "comment", "maid_name", "supervisor_name", "verified_by_name",
)


def _task_dict(row) -> dict:
    if row is None:
        return {}
    keys = row.keys() if hasattr(row, "keys") else []
    return {k: row[k] for k in TASK_KEYS if k in keys}


async def _post(payload: dict) -> None:
    headers = {"X-Webhook-Token": EVENTS_TOKEN} if EVENTS_TOKEN else {}
    try:
        async with ClientSession(timeout=ClientTimeout(total=8)) as session:
            async with session.post(EVENTS_URL, json=payload, headers=headers) as response:
                if response.status >= 400:
                    logger.warning("urbanluxe events webhook %s: %s", response.status, (await response.text())[:300])
    except (ClientError, TimeoutError, asyncio.TimeoutError):
        logger.exception("urbanluxe events webhook failed")


async def emit_task_event(
    db: aiosqlite.Connection,
    task_id: int,
    user_id: Optional[int],
    event_type: str,
    old_status: Optional[str],
    new_status: Optional[str],
    payload: Optional[dict[str, Any]] = None,
) -> None:
    if not EVENTS_URL:
        return
    try:
        task = await task_repo.get_by_id(db, task_id)
        body = {
            "type": "cleaning_event",
            "event_type": event_type,
            "old_status": old_status,
            "new_status": new_status,
            "user_id": user_id,
            "task": _task_dict(task),
            "payload": payload or {},
        }
        asyncio.create_task(_post(body))
    except Exception:  # never break the bot because of the bridge
        logger.exception("urbanluxe events: emit failed")
