import json
from datetime import datetime, timedelta
from typing import Iterable, Optional
from zoneinfo import ZoneInfo

import aiosqlite

from app.apartment_catalog import minimum_cleaning_minutes
from app.models import CleaningType, TaskStatus, VERIFICATION_METHOD_LABELS, normalize_cleaning_type
from app.repositories import apartments as apartment_repo
from app.repositories import cleaning_tasks as task_repo
from app.services import outbound


BLOCKING_PROBLEM_TYPES = {"guest_not_left", "no_access"}


def problem_blocks_cleaning(problem_type: str) -> bool:
    return problem_type in BLOCKING_PROBLEM_TYPES


def keys_missing_open(task) -> bool:
    return bool(task["keys_missing_reported_at"] and not task["keys_missing_resolved_at"])


def now_iso(timezone: str) -> str:
    return datetime.now(ZoneInfo(timezone)).replace(microsecond=0).isoformat()


def today_iso(timezone: str) -> str:
    return datetime.now(ZoneInfo(timezone)).date().isoformat()


def deadline_iso(timezone: str, date_value: str, time_value: str) -> str:
    date_part = datetime.fromisoformat(date_value).date()
    hour, minute = [int(part) for part in time_value.split(":", 1)]
    return datetime(
        date_part.year,
        date_part.month,
        date_part.day,
        hour,
        minute,
        tzinfo=ZoneInfo(timezone),
    ).isoformat()


def display_time(value: Optional[str]) -> str:
    if not value:
        return "-"
    if value == "after_18":
        return "после 18:00"
    return value


def estimate_duration(apartment, cleaning_type: str) -> int:
    cleaning_type = normalize_cleaning_type(cleaning_type)
    bathrooms = apartment["bathrooms_count"] or 1
    beds = apartment["beds_count"] or 1
    sofas = apartment["sofa_beds_count"] or 0
    area = apartment["area_m2"] or 0

    minutes = bathrooms * 20 + 15 + beds * 10 + sofas * 5
    if 45 < area <= 70:
        minutes += 10
    elif 70 < area <= 100:
        minutes += 25
    elif area > 100:
        minutes += 40

    multiplier = {
        CleaningType.STANDARD.value: 1,
        CleaningType.GENERAL.value: 1.7,
        CleaningType.DAILY.value: 0.4,
    }[cleaning_type]
    estimate = max(20, round(minutes * multiplier))
    if cleaning_type != CleaningType.DAILY.value:
        estimate = max(
            estimate,
            minimum_cleaning_minutes(apartment["apartment_type"]),
        )
    return estimate


async def log_event(
    db: aiosqlite.Connection,
    task_id: int,
    user_id: Optional[int],
    event_type: str,
    old_status: Optional[str],
    new_status: Optional[str],
    payload: Optional[dict] = None,
) -> None:
    await db.execute(
        """
        INSERT INTO cleaning_events (
            task_id, user_id, event_type, old_status, new_status, payload_json
        )
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            task_id,
            user_id,
            event_type,
            old_status,
            new_status,
            json.dumps(payload or {}, ensure_ascii=False),
        ),
    )
    # Urban Luxe: продублировать событие в urbanluxe.cc (лист заездов / staff.html)
    await outbound.emit_task_event(db, task_id, user_id, event_type, old_status, new_status, payload)


async def create_task(
    db: aiosqlite.Connection,
    timezone: str,
    apartment_id: int,
    cleaning_type: str,
    planned_date: str,
    deadline_at: Optional[str],
    maid_id: Optional[int],
    supervisor_id: Optional[int],
    comment: Optional[str],
    created_by: Optional[int],
    external_booking_id: Optional[str] = None,
):
    cleaning_type = normalize_cleaning_type(cleaning_type)
    apartment = await apartment_repo.get_by_id(db, apartment_id)
    if not apartment:
        raise ValueError("Apartment not found")

    status = TaskStatus.ASSIGNED.value if maid_id else TaskStatus.PLAN.value
    estimated = estimate_duration(apartment, cleaning_type)
    current_time = now_iso(timezone)

    cursor = await db.execute(
        """
        INSERT INTO cleaning_tasks (
            external_booking_id, apartment_id, cleaning_type, status, assigned_maid_id, supervisor_id,
            planned_date, deadline_at, estimated_duration_min, comment, created_by,
            created_at, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            external_booking_id,
            apartment_id,
            cleaning_type,
            status,
            maid_id,
            supervisor_id,
            planned_date,
            deadline_at,
            estimated,
            comment,
            created_by,
            current_time,
            current_time,
        ),
    )
    task_id = cursor.lastrowid
    await log_event(
        db,
        task_id,
        created_by,
        "created",
        None,
        status,
        {"maid_id": maid_id, "deadline_at": deadline_at},
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def cancel_scheduled_task(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    user_id: int,
    reason: str,
):
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        raise ValueError("Уборка не найдена")
    if task["started_at"] or task["status"] not in (
        TaskStatus.PLAN.value,
        TaskStatus.GUEST_CHECKED_OUT.value,
        TaskStatus.ASSIGNED.value,
    ):
        raise ValueError("Можно отменить только еще не начатую уборку")

    updated_at = now_iso(timezone)
    await db.execute(
        """
        UPDATE cleaning_tasks
        SET status = 'canceled',
            updated_at = ?
        WHERE id = ?
        """,
        (updated_at, task_id),
    )
    if task["local_booking_id"]:
        await db.execute(
            """
            UPDATE bookings
            SET status = 'canceled',
                updated_at = ?
            WHERE id = ?
            """,
            (updated_at, task["local_booking_id"]),
        )
    await log_event(
        db,
        task_id,
        user_id,
        "schedule_canceled_manually",
        task["status"],
        TaskStatus.CANCELED.value,
        {"reason": reason, "local_booking_id": task["local_booking_id"]},
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def change_cleaning_type(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    user_id: int,
    cleaning_type: str,
):
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        raise ValueError("Уборка не найдена")
    if task["started_at"] or task["status"] in (
        TaskStatus.IN_PROGRESS.value,
        TaskStatus.COMPLETED.value,
        TaskStatus.WAITING_CHECK.value,
        TaskStatus.VERIFIED.value,
        TaskStatus.REWORK.value,
        TaskStatus.CANCELED.value,
    ):
        raise ValueError("Тип можно изменить только до начала уборки")

    new_type = normalize_cleaning_type(cleaning_type)
    old_type = normalize_cleaning_type(task["cleaning_type"])
    if new_type == old_type:
        return task

    apartment = await apartment_repo.get_by_id(db, task["apartment_id"])
    estimated = estimate_duration(apartment, new_type)
    current_time = now_iso(timezone)
    await db.execute(
        """
        UPDATE cleaning_tasks
        SET cleaning_type = ?,
            estimated_duration_min = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (new_type, estimated, current_time, task_id),
    )
    await log_event(
        db,
        task_id,
        user_id,
        "cleaning_type_changed",
        task["status"],
        task["status"],
        {"old_cleaning_type": old_type, "new_cleaning_type": new_type},
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def mark_guest_checked_out(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    user_id: int,
    comment: Optional[str] = None,
):
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        raise ValueError("Cleaning task not found")
    if task["status"] not in (TaskStatus.PLAN.value, TaskStatus.GUEST_CHECKED_OUT.value):
        return task

    current_time = now_iso(timezone)
    merged_comment = task["comment"] or ""
    if comment:
        merged_comment = f"{merged_comment}\n{comment}".strip()

    await db.execute(
        """
        UPDATE cleaning_tasks
        SET status = 'guest_checked_out',
            comment = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (merged_comment or None, current_time, task_id),
    )
    await log_event(
        db,
        task_id,
        user_id,
        "guest_checked_out",
        task["status"],
        TaskStatus.GUEST_CHECKED_OUT.value,
        {"comment": comment},
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def assign_task(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    maid_id: int,
    supervisor_id: int,
):
    task = await task_repo.get_by_id(db, task_id)
    old_status = task["status"]
    await db.execute(
        """
        UPDATE cleaning_tasks
        SET assigned_maid_id = ?,
            supervisor_id = ?,
            status = 'assigned',
            updated_at = ?
        WHERE id = ?
        """,
        (maid_id, supervisor_id, now_iso(timezone), task_id),
    )
    await log_event(
        db,
        task_id,
        supervisor_id,
        "assigned",
        old_status,
        TaskStatus.ASSIGNED.value,
        {"maid_id": maid_id},
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def reassign_task(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    maid_id: int,
    supervisor_id: int,
):
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        raise ValueError("Cleaning task not found")
    if task["status"] not in (
        TaskStatus.PLAN.value,
        TaskStatus.GUEST_CHECKED_OUT.value,
        TaskStatus.ASSIGNED.value,
        TaskStatus.REWORK.value,
    ):
        raise ValueError("Эту уборку нельзя переназначить из текущего статуса")

    old_status = task["status"]
    new_status = (
        TaskStatus.ASSIGNED.value
        if old_status in (TaskStatus.PLAN.value, TaskStatus.GUEST_CHECKED_OUT.value)
        else old_status
    )
    await db.execute(
        """
        UPDATE cleaning_tasks
        SET assigned_maid_id = ?,
            supervisor_id = ?,
            status = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (maid_id, supervisor_id, new_status, now_iso(timezone), task_id),
    )
    await log_event(
        db,
        task_id,
        supervisor_id,
        "reassigned",
        old_status,
        new_status,
        {"old_maid_id": task["assigned_maid_id"], "maid_id": maid_id},
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def start_task(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    user_id: int,
    before_video_ids: Optional[Iterable[str]] = None,
    before_photo_ids: Optional[Iterable[str]] = None,
    keys_photo_id: Optional[str] = None,
    tv_photo_id: Optional[str] = None,
):
    before_video_ids = list(before_video_ids or [])
    before_photo_ids = list(before_photo_ids or [])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        raise ValueError("Уборка не найдена")
    if task["status"] != TaskStatus.ASSIGNED.value:
        raise ValueError("Эту уборку нельзя начать из текущего статуса")
    apartment_keys_missing = await task_repo.has_open_missing_keys_for_apartment(
        db, task["apartment_id"]
    )
    if not keys_photo_id and not apartment_keys_missing:
        raise ValueError("Перед стартом нужно отправить фото ключей")
    if not tv_photo_id:
        raise ValueError("Перед стартом нужно отправить фото включённого телевизора")
    if not before_video_ids:
        raise ValueError("Перед стартом нужно отправить видео квартиры ДО уборки")

    current_time = now_iso(timezone)
    await add_photos(db, task_id, user_id, before_video_ids, "before_video")
    if keys_photo_id:
        await add_photos(db, task_id, user_id, [keys_photo_id], "before_keys")
    await add_photos(db, task_id, user_id, [tv_photo_id], "before_tv")
    await add_photos(db, task_id, user_id, before_photo_ids, "before_extra")
    await db.execute(
        """
        UPDATE cleaning_tasks
        SET status = 'in_progress',
            started_at = COALESCE(started_at, ?),
            updated_at = ?
        WHERE id = ?
        """,
        (current_time, current_time, task_id),
    )
    await log_event(
        db,
        task_id,
        user_id,
        "started",
        task["status"],
        TaskStatus.IN_PROGRESS.value,
        {
            "before_videos_count": len(before_video_ids),
            "before_photos_count": len(before_photo_ids),
            "keys_photo_count": int(bool(keys_photo_id)),
            "keys_missing": apartment_keys_missing,
            "tv_photo_count": 1,
        },
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def add_photos(
    db: aiosqlite.Connection,
    task_id: int,
    user_id: int,
    file_ids: Iterable[str],
    photo_type: str,
):
    for file_id in file_ids:
        await db.execute(
            """
            INSERT INTO cleaning_photos (task_id, telegram_file_id, photo_type, uploaded_by)
            VALUES (?, ?, ?, ?)
            """,
            (task_id, file_id, photo_type, user_id),
        )


async def finish_task(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    user_id: int,
    photo_file_ids: Iterable[str],
    video_file_ids: Optional[Iterable[str]] = None,
    comment: Optional[str] = None,
    drain_photo_id: Optional[str] = None,
    vacuum_photo_id: Optional[str] = None,
):
    photo_file_ids = list(photo_file_ids)
    video_file_ids = list(video_file_ids or [])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        raise ValueError("Уборка не найдена")
    if task["status"] != TaskStatus.IN_PROGRESS.value:
        raise ValueError("Сначала нужно начать уборку")
    if not drain_photo_id:
        raise ValueError("Перед завершением нужно отправить фото чистого слива")
    if not vacuum_photo_id:
        raise ValueError("Перед завершением нужно отправить фото чистого пылесоса")
    if not video_file_ids:
        raise ValueError("Перед завершением нужно отправить видео ПОСЛЕ уборки")

    current_time = now_iso(timezone)
    duration = None
    if task["started_at"]:
        started_at = datetime.fromisoformat(task["started_at"])
        finished_at = datetime.fromisoformat(current_time)
        duration = max(0, int((finished_at - started_at).total_seconds() // 60))

    merged_comment = task["comment"] or ""
    if comment:
        merged_comment = f"{merged_comment}\n{comment}".strip()

    await add_photos(db, task_id, user_id, photo_file_ids, "after_photo")
    await add_photos(db, task_id, user_id, video_file_ids, "after_video")
    await add_photos(db, task_id, user_id, [drain_photo_id], "after_drain")
    await add_photos(db, task_id, user_id, [vacuum_photo_id], "after_vacuum")
    await db.execute(
        """
        UPDATE cleaning_tasks
        SET status = 'waiting_check',
            finished_at = ?,
            actual_duration_min = ?,
            comment = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (current_time, duration, merged_comment or None, current_time, task_id),
    )
    await log_event(
        db,
        task_id,
        user_id,
        "finished",
        task["status"],
        TaskStatus.WAITING_CHECK.value,
        {
            "after_photos_count": len(photo_file_ids),
            "after_videos_count": len(video_file_ids),
            "drain_photo_count": 1,
            "vacuum_photo_count": 1,
        },
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def verify_task(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    supervisor_id: int,
    quality_score: int,
    verification_method: str,
):
    if verification_method not in VERIFICATION_METHOD_LABELS:
        raise ValueError("Укажите способ проверки: лично или по видео")
    if not isinstance(quality_score, int) or not 0 <= quality_score <= 10:
        raise ValueError("Оценка качества должна быть от 0 до 10")
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        raise ValueError("Уборка не найдена")
    if await task_repo.has_open_missing_keys_for_apartment(db, task["apartment_id"]):
        raise ValueError("Нельзя принять уборку: в квартире нет ключей. Сначала положите ключи и закройте проблему.")
    if task["status"] != TaskStatus.WAITING_CHECK.value:
        raise ValueError("Эта уборка сейчас не ожидает проверки")
    current_time = now_iso(timezone)
    cursor = await db.execute(
        """
        UPDATE cleaning_tasks
        SET status = 'verified',
            verified_at = ?,
            quality_score = ?,
            verification_method = ?,
            verified_by_user_id = ?,
            updated_at = ?
        WHERE id = ?
          AND status = 'waiting_check'
          AND NOT EXISTS (
              SELECT 1
              FROM cleaning_tasks key_issue
              WHERE key_issue.apartment_id = cleaning_tasks.apartment_id
                AND key_issue.keys_missing_reported_at IS NOT NULL
                AND key_issue.keys_missing_resolved_at IS NULL
          )
        """,
        (current_time, quality_score, verification_method, supervisor_id, current_time, task_id),
    )
    if not cursor.rowcount:
        if await task_repo.has_open_missing_keys_for_apartment(db, task["apartment_id"]):
            raise ValueError("Нельзя принять уборку: в квартире нет ключей. Сначала положите ключи и закройте проблему.")
        raise ValueError("Эта уборка сейчас не ожидает проверки")
    await log_event(
        db,
        task_id,
        supervisor_id,
        "verified",
        task["status"],
        TaskStatus.VERIFIED.value,
        {"quality_score": quality_score, "verification_method": verification_method},
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def send_to_rework(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    supervisor_id: int,
    reason: str,
    comment: Optional[str] = None,
    photo_file_ids: Optional[Iterable[str]] = None,
):
    photo_file_ids = list(photo_file_ids or [])
    task = await task_repo.get_by_id(db, task_id)
    current_time = now_iso(timezone)
    merged_comment = task["comment"] or ""
    if comment:
        merged_comment = f"{merged_comment}\nПеределка: {comment}".strip()
    if photo_file_ids:
        await add_photos(db, task_id, supervisor_id, photo_file_ids, "rework")
    await db.execute(
        """
        UPDATE cleaning_tasks
        SET status = 'rework',
            rework_required = 1,
            rework_reason = ?,
            comment = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (reason, merged_comment or None, current_time, task_id),
    )
    await log_event(
        db,
        task_id,
        supervisor_id,
        "rework",
        task["status"],
        TaskStatus.REWORK.value,
        {
            "reason": reason,
            "comment": comment,
            "photos_count": len(photo_file_ids),
        },
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def complete_rework(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    user_id: int,
    photo_file_ids: Iterable[str],
    comment: Optional[str] = None,
):
    photo_file_ids = list(photo_file_ids or [])
    task = await task_repo.get_by_id(db, task_id)
    if task["status"] != TaskStatus.REWORK.value:
        raise ValueError("Эта задача сейчас не в статусе переделки")

    current_time = now_iso(timezone)
    merged_comment = task["comment"] or ""
    if comment:
        merged_comment = f"{merged_comment}\nПеределка исправлена: {comment}".strip()

    await add_photos(db, task_id, user_id, photo_file_ids, "rework_done")
    await db.execute(
        """
        UPDATE cleaning_tasks
        SET status = 'waiting_check',
            finished_at = ?,
            comment = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (current_time, merged_comment or None, current_time, task_id),
    )
    await log_event(
        db,
        task_id,
        user_id,
        "rework_done",
        task["status"],
        TaskStatus.WAITING_CHECK.value,
        {
            "photos_count": len(photo_file_ids),
            "comment": comment,
        },
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def mark_keys_missing(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    maid_id: int,
):
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["assigned_maid_id"] != maid_id:
        raise ValueError("Уборка не найдена или не назначена вам")
    if task["status"] != TaskStatus.ASSIGNED.value:
        raise ValueError("Сообщить об отсутствии ключей можно до начала уборки")
    if await task_repo.has_open_missing_keys_for_apartment(db, task["apartment_id"]):
        return task, False

    current_time = now_iso(timezone)
    cursor = await db.execute(
        """
        UPDATE cleaning_tasks
        SET keys_missing_reported_at = ?,
            keys_missing_resolved_at = NULL,
            updated_at = ?
        WHERE id = ?
          AND assigned_maid_id = ?
          AND status = 'assigned'
          AND NOT EXISTS (
              SELECT 1
              FROM cleaning_tasks key_issue
              WHERE key_issue.apartment_id = cleaning_tasks.apartment_id
                AND key_issue.keys_missing_reported_at IS NOT NULL
                AND key_issue.keys_missing_resolved_at IS NULL
          )
        """,
        (current_time, current_time, task_id, maid_id),
    )
    if not cursor.rowcount:
        current_task = await task_repo.get_by_id(db, task_id)
        if current_task["status"] != TaskStatus.ASSIGNED.value:
            raise ValueError("Сообщить об отсутствии ключей можно до начала уборки")
        return current_task, False
    await log_event(
        db,
        task_id,
        maid_id,
        "keys_missing",
        task["status"],
        task["status"],
        {"apartment_code": task["apartment_code"]},
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id), True


async def resolve_keys_missing(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    supervisor_id: int,
):
    task = await task_repo.get_by_id(db, task_id)
    if not task or not keys_missing_open(task):
        raise ValueError("Проблема с ключами уже закрыта или не найдена")
    current_time = now_iso(timezone)
    cursor = await db.execute(
        """
        UPDATE cleaning_tasks
        SET keys_missing_resolved_at = ?,
            updated_at = ?
        WHERE id = ?
          AND keys_missing_reported_at IS NOT NULL
          AND keys_missing_resolved_at IS NULL
        """,
        (current_time, current_time, task_id),
    )
    if not cursor.rowcount:
        raise ValueError("Проблема с ключами уже закрыта или не найдена")
    await log_event(
        db,
        task_id,
        supervisor_id,
        "keys_missing_resolved",
        task["status"],
        task["status"],
        {"keys_missing_reported_at": task["keys_missing_reported_at"]},
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def mark_problem(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    user_id: int,
    problem_type: str,
    comment: Optional[str] = None,
    photo_file_ids: Optional[Iterable[str]] = None,
    video_file_ids: Optional[Iterable[str]] = None,
):
    photo_file_ids = list(photo_file_ids or [])
    video_file_ids = list(video_file_ids or [])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        raise ValueError("Cleaning task not found")
    current_time = now_iso(timezone)
    next_status = (
        TaskStatus.PROBLEM.value
        if problem_blocks_cleaning(problem_type)
        else task["status"]
    )
    merged_comment = task["comment"] or ""
    if comment:
        merged_comment = f"{merged_comment}\nПроблема: {comment}".strip()

    await add_photos(db, task_id, user_id, photo_file_ids, "problem")
    await add_photos(db, task_id, user_id, video_file_ids, "problem_video")

    await db.execute(
        """
        UPDATE cleaning_tasks
        SET status = ?,
            problem_type = ?,
            comment = ?,
            problem_reported_at = COALESCE(problem_reported_at, ?),
            problem_resolved_at = NULL,
            updated_at = ?
        WHERE id = ?
        """,
        (
            next_status,
            problem_type,
            merged_comment or None,
            current_time,
            current_time,
            task_id,
        ),
    )
    await log_event(
        db,
        task_id,
        user_id,
        "problem",
        task["status"],
        next_status,
        {
            "problem_type": problem_type,
            "blocks_cleaning": problem_blocks_cleaning(problem_type),
            "comment": comment,
            "photos_count": len(photo_file_ids),
            "videos_count": len(video_file_ids),
        },
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


async def report_forgotten_items(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    user_id: int,
    comment: Optional[str] = None,
    photo_file_ids: Optional[Iterable[str]] = None,
    video_file_ids: Optional[Iterable[str]] = None,
):
    photo_file_ids = list(photo_file_ids or [])
    video_file_ids = list(video_file_ids or [])
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        raise ValueError("Cleaning task not found")

    current_time = now_iso(timezone)
    merged_comment = task["comment"] or ""
    if comment:
        merged_comment = f"{merged_comment}\nЗабытые вещи: {comment}".strip()

    await add_photos(db, task_id, user_id, photo_file_ids, "forgotten_items")
    await add_photos(db, task_id, user_id, video_file_ids, "forgotten_items_video")
    await db.execute(
        """
        UPDATE cleaning_tasks
        SET comment = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (merged_comment or None, current_time, task_id),
    )
    await log_event(
        db,
        task_id,
        user_id,
        "forgotten_items",
        task["status"],
        task["status"],
        {
            "comment": comment,
            "photos_count": len(photo_file_ids),
            "videos_count": len(video_file_ids),
        },
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


def _status_after_problem_resolved(task) -> str:
    if task["finished_at"]:
        return TaskStatus.WAITING_CHECK.value
    if task["started_at"]:
        return TaskStatus.IN_PROGRESS.value
    if task["assigned_maid_id"]:
        return TaskStatus.ASSIGNED.value
    return TaskStatus.PLAN.value


async def resolve_problem(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: int,
    user_id: int,
):
    task = await task_repo.get_by_id(db, task_id)
    if not task:
        raise ValueError("Task not found")
    if not task["problem_type"] or task["problem_resolved_at"]:
        return task

    current_time = now_iso(timezone)
    next_status = (
        _status_after_problem_resolved(task)
        if task["status"] == TaskStatus.PROBLEM.value
        else task["status"]
    )
    reported_at = task["problem_reported_at"] or task["updated_at"]
    await db.execute(
        """
        UPDATE cleaning_tasks
        SET status = ?,
            problem_resolved_at = ?,
            updated_at = ?
        WHERE id = ?
        """,
        (next_status, current_time, current_time, task_id),
    )
    await log_event(
        db,
        task_id,
        user_id,
        "problem_resolved",
        task["status"],
        next_status,
        {
            "problem_type": task["problem_type"],
            "problem_reported_at": reported_at,
            "problem_resolved_at": current_time,
        },
    )
    await db.commit()
    return await task_repo.get_by_id(db, task_id)


def default_deadline_options() -> list:
    now = datetime.now()
    base_hours = [11, 12, 14, 16, 18, 20]
    result = []
    for hour in base_hours:
        label = f"{hour:02d}:00"
        result.append((label, label))
    if now.hour < 22:
        next_hour = (now + timedelta(hours=2)).replace(minute=0)
        result.insert(0, (next_hour.strftime("%H:%M"), next_hour.strftime("%H:%M")))
    return result
