import json
import logging
import re
from datetime import datetime
from typing import Any, Dict, Optional

import aiosqlite

from app.config import Settings
from app.models import TaskStatus
from app.repositories import apartments as apartment_repo
from app.repositories import bookings as booking_repo
from app.repositories import cleaning_tasks as task_repo
from app.services import booking_service, cleaning_service


BOOKING_EVENTS = {
    "create_booking",
    "update_booking",
    "cancel_booking",
    "delete_booking",
}

CANCEL_EVENTS = {"cancel_booking", "delete_booking"}
DEFAULT_CHECKIN_TIME = "15:00"
DEFAULT_CHECKOUT_TIME = "12:00"
logger = logging.getLogger(__name__)

EXTERNAL_ID_KEYS = (
    "id",
    "booking_id",
    "bookingId",
    "external_booking_id",
    "reservation_id",
    "reservationId",
    "order_id",
    "orderId",
    "uid",
    "uuid",
)

CHECKIN_DATE_KEYS = (
    "begin_date",
    "beginDate",
    "checkin_date",
    "checkinDate",
    "check_in_date",
    "arrival_date",
    "arrivalDate",
    "date_begin",
    "dateBegin",
    "date_from",
    "dateFrom",
    "start_date",
    "startDate",
    "from",
    "start",
)

CHECKOUT_DATE_KEYS = (
    "end_date",
    "endDate",
    "checkout_date",
    "checkoutDate",
    "check_out_date",
    "departure_date",
    "departureDate",
    "date_end",
    "dateEnd",
    "date_to",
    "dateTo",
    "finish_date",
    "finishDate",
    "to",
    "end",
)

CHECKIN_TIME_KEYS = (
    "arrival_time",
    "arrivalTime",
    "checkin_time",
    "checkinTime",
    "check_in_time",
    "time_begin",
    "timeBegin",
    "time_from",
    "timeFrom",
    "start_time",
    "startTime",
    "arrival_at",
    "arrivalAt",
)

CHECKOUT_TIME_KEYS = (
    "departure_time",
    "departureTime",
    "checkout_time",
    "checkoutTime",
    "check_out_time",
    "time_end",
    "timeEnd",
    "time_to",
    "timeTo",
    "end_time",
    "endTime",
    "departure_at",
    "departureAt",
)

BOOKING_HINT_KEYS = (
    *EXTERNAL_ID_KEYS,
    *CHECKIN_DATE_KEYS,
    *CHECKOUT_DATE_KEYS,
    *CHECKIN_TIME_KEYS,
    *CHECKOUT_TIME_KEYS,
    "realty_id",
    "realtyId",
    "apartment_id",
    "apartmentId",
    "apartment",
    "object",
    "flat",
    "room",
    "status",
    "guest",
    "guests",
    "guest_count",
    "guests_count",
)

NON_BOOKING_PAYLOAD_KEYS = {
    "basket",
    "bitrix_lead_id",
    "crm_entity_id",
}


def _payload_keys(payload: Dict[str, Any]) -> list[str]:
    return sorted(str(key) for key in payload.keys())


def _ignored_result(reason: str, **details: Any) -> Dict[str, Any]:
    return {
        "ok": True,
        "ignored": True,
        "reason": reason,
        **details,
    }


def _has_booking_hint(payload: Dict[str, Any]) -> bool:
    return any(payload.get(key) not in (None, "") for key in BOOKING_HINT_KEYS)


def _is_non_booking_payload(payload: Dict[str, Any], booking_payload: Dict[str, Any]) -> bool:
    payload_keys = set(payload.keys()) | set(booking_payload.keys())
    return bool(payload_keys & NON_BOOKING_PAYLOAD_KEYS) and not _has_booking_hint(booking_payload)


def _get_booking_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    # RealtyCalendar installations and intermediary integrations do not all
    # use the same envelope.  Preserve scalar fields from every wrapper and
    # let the innermost booking object win.  This is especially important for
    # partial updates where the booking id is outside ``data.booking`` while
    # the changed checkout field is inside it (or vice versa).
    merged = {
        key: value
        for key, value in payload.items()
        if key not in {"data", "booking", "reservation", "order"}
    }

    data = payload.get("data")
    if isinstance(data, dict):
        merged.update(
            {
                key: value
                for key, value in data.items()
                if key not in {"booking", "reservation", "order"}
            }
        )

    nested_candidates = []
    for container in (payload, data if isinstance(data, dict) else {}):
        for key in ("order", "reservation", "booking"):
            value = container.get(key)
            if isinstance(value, dict):
                nested_candidates.append(value)
    for candidate in nested_candidates:
        merged.update(candidate)

    return merged


def _event_type(payload: Dict[str, Any]) -> str:
    for key in ("event", "event_type", "type", "action"):
        value = payload.get(key)
        if value:
            return _normalize_event_type(value)
    data = payload.get("data")
    if isinstance(data, dict):
        for key in ("event", "event_type", "type", "action"):
            value = data.get(key)
            if value:
                return _normalize_event_type(value)
    return "update_booking"


def _normalize_event_type(value: Any) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")
    aliases = {
        "booking_create": "create_booking",
        "booking_created": "create_booking",
        "reservation_create": "create_booking",
        "reservation_created": "create_booking",
        "booking_update": "update_booking",
        "booking_updated": "update_booking",
        "reservation_update": "update_booking",
        "reservation_updated": "update_booking",
        "booking_cancel": "cancel_booking",
        "booking_canceled": "cancel_booking",
        "booking_cancelled": "cancel_booking",
        "reservation_cancel": "cancel_booking",
        "reservation_canceled": "cancel_booking",
        "reservation_cancelled": "cancel_booking",
        "booking_delete": "delete_booking",
        "booking_deleted": "delete_booking",
        "reservation_delete": "delete_booking",
        "reservation_deleted": "delete_booking",
    }
    return aliases.get(normalized, normalized or "update_booking")


def _parse_date(value: Any) -> Optional[str]:
    if not value:
        return None
    value = str(value).strip()
    for fmt in (
        "%Y-%m-%d",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%d.%m.%Y",
        "%d.%m.%Y %H:%M:%S",
        "%d.%m.%y",
        "%d.%m.%y %H:%M:%S",
    ):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            continue
    match = re.search(r"\d{4}-\d{2}-\d{2}", value)
    if match:
        return match.group(0)
    match = re.search(r"\d{1,2}\.\d{1,2}\.\d{2,4}", value)
    if match:
        date_value = match.group(0)
        for fmt in ("%d.%m.%Y", "%d.%m.%y"):
            try:
                return datetime.strptime(date_value, fmt).date().isoformat()
            except ValueError:
                continue
    return None


def _parse_time(value: Any) -> Optional[str]:
    if not value:
        return None
    value = str(value).strip()
    try:
        return datetime.strptime(value, "%H:%M:%S").strftime("%H:%M")
    except ValueError:
        pass
    match = re.search(r"\b(\d{1,2}):(\d{2})\b", value)
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2))
        if 0 <= hour <= 23 and 0 <= minute <= 59:
            return f"{hour:02d}:{minute:02d}"
    return None


def _first_present(source: Dict[str, Any], keys: tuple[str, ...]) -> Any:
    for key in keys:
        if key in source and source[key] not in (None, ""):
            return source[key]
    return None


def _to_int(value: Any) -> Optional[int]:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


GUEST_TEXT_KEYS = (
    "comment",
    "comments",
    "note",
    "notes",
    "description",
    "memo",
    "guest_info",
    "client_comment",
    "remark",
    "remarks",
)


def _guest_count_from_text(value: Any) -> Optional[int]:
    if not value:
        return None

    text = str(value)
    total = 0
    found_category = False
    for pattern in (
        r"(\d+)\s*(?:взросл\w*|adult\w*)",
        r"(\d+)\s*(?:реб[её]н\w*|дет\w*|child\w*|children)",
        r"(\d+)\s*(?:младен\w*|infant\w*)",
    ):
        for match in re.finditer(pattern, text, flags=re.IGNORECASE):
            total += int(match.group(1))
            found_category = True
    if found_category:
        return total

    match = re.search(
        r"(?:гостей|гости|гость|guests?)\s*[:\-]?\s*(\d+)",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        return int(match.group(1))

    return None


def _guest_count_from_nested(value: Any) -> Optional[int]:
    if isinstance(value, dict):
        counts = [_guest_count_from_nested(item) for item in value.values()]
    elif isinstance(value, list):
        counts = [_guest_count_from_nested(item) for item in value]
    else:
        counts = [_guest_count_from_text(value)]

    counts = [count for count in counts if count]
    return max(counts) if counts else None


def _extract_guest_count(booking: Dict[str, Any]) -> Optional[int]:
    for key in ("guests_count", "guest_count", "guests"):
        direct = _to_int(booking.get(key))
        if direct is not None:
            return direct

    keyed_counts = [
        _guest_count_from_nested(booking.get(key))
        for key in GUEST_TEXT_KEYS
        if key in booking
    ]
    keyed_counts = [count for count in keyed_counts if count]
    if keyed_counts:
        return max(keyed_counts)

    return _guest_count_from_nested(booking)


def _is_checkout_extension(existing, checkout_date: str, checkout_time: str) -> bool:
    if not existing or not existing["checkout_date"]:
        return False
    old_date = existing["checkout_date"]
    old_time = existing["checkout_time"] or DEFAULT_CHECKOUT_TIME
    if checkout_date > old_date:
        return True
    return checkout_date == old_date and checkout_time > old_time


def _checkout_change_kind(existing, checkout_date: str, checkout_time: str) -> Optional[str]:
    if not _is_checkout_extension(existing, checkout_date, checkout_time):
        return None
    if checkout_date > existing["checkout_date"]:
        return "stay_extended"
    return "late_checkout"


def _has_apartment_reference(booking: Dict[str, Any]) -> bool:
    return bool(
        _realty_id(booking)
        or booking.get("apartment")
        or booking.get("object")
        or booking.get("flat")
        or booking.get("room")
        or booking.get("apartment_code")
        or booking.get("apartmentCode")
        or booking.get("object_name")
        or booking.get("objectName")
    )


def _external_id(booking: Dict[str, Any]) -> Optional[str]:
    value = _first_present(booking, EXTERNAL_ID_KEYS)
    if value not in (None, ""):
        return str(value)
    return None


def _realty_id(booking: Dict[str, Any]) -> Optional[int]:
    realty_id = _to_int(
        booking.get("realty_id")
        or booking.get("realtyId")
        or booking.get("apartment_id")
        or booking.get("apartmentId")
    )
    if realty_id:
        return realty_id
    for key in ("apartment", "object", "flat", "room"):
        apartment = booking.get(key)
        if isinstance(apartment, dict):
            nested_id = _to_int(
                apartment.get("realty_id")
                or apartment.get("realtyId")
                or apartment.get("apartment_id")
                or apartment.get("apartmentId")
                or apartment.get("id")
            )
            if nested_id:
                return nested_id
        elif isinstance(apartment, (int, float)):
            nested_id = _to_int(apartment)
            if nested_id:
                return nested_id
    return None


def _apartment_title(booking: Dict[str, Any], realty_id: Optional[int]) -> str:
    for key in (
        "apartment_code",
        "apartmentCode",
        "apartment_name",
        "apartmentName",
        "object_name",
        "objectName",
        "room_name",
        "roomName",
    ):
        if booking.get(key):
            return str(booking[key]).strip()
    for container_key in ("apartment", "object", "flat", "room"):
        apartment = booking.get(container_key)
        if isinstance(apartment, dict):
            for key in ("title", "name", "code", "number"):
                if apartment.get(key):
                    return str(apartment[key]).strip()
        if isinstance(apartment, str) and apartment.strip():
            return apartment.strip()
    return f"RC-{realty_id or booking.get('id', 'unknown')}"


def _apartment_address(booking: Dict[str, Any]) -> str:
    for container_key in ("apartment", "object", "flat", "room"):
        apartment = booking.get(container_key)
        if isinstance(apartment, dict) and apartment.get("address"):
            return str(apartment["address"]).strip()
    if booking.get("address"):
        return str(booking["address"]).strip()
    return ""


def _apartment_building(booking: Dict[str, Any]) -> str:
    for container_key in ("apartment", "object", "flat", "room"):
        apartment = booking.get(container_key)
        if not isinstance(apartment, dict):
            continue
        for key in ("building", "building_name", "buildingName", "complex"):
            value = apartment.get(key)
            if isinstance(value, dict):
                value = value.get("name") or value.get("title")
            if value:
                return str(value).strip()
    for key in ("building", "building_name", "buildingName", "complex"):
        value = booking.get(key)
        if isinstance(value, dict):
            value = value.get("name") or value.get("title")
        if value:
            return str(value).strip()
    return ""


async def _resolve_apartment(db: aiosqlite.Connection, booking: Dict[str, Any]):
    realty_id = _realty_id(booking)
    title = _apartment_title(booking, realty_id)
    address = _apartment_address(booking)
    building = _apartment_building(booking)

    if not title.upper().startswith("RC-"):
        apartment = await apartment_repo.get_any_by_code(db, title)
        if apartment:
            return await apartment_repo.refresh_from_realty(
                db, apartment["id"], realty_id, title, address, building
            )

    if realty_id:
        apartment = await apartment_repo.get_any_by_realty_id(db, realty_id)
        if apartment:
            return await apartment_repo.refresh_from_realty(
                db, apartment["id"], realty_id, title, address, building
            )

    apartment = await apartment_repo.get_any_by_code(db, title)
    if apartment:
        return await apartment_repo.refresh_from_realty(
            db, apartment["id"], realty_id, title, address, building
        )

    code = title[:80] if title else f"RC-{realty_id or booking.get('id', 'unknown')}"
    if realty_id:
        return await apartment_repo.create_from_realty(
            db, realty_id, code, address, building
        )

    existing = await apartment_repo.get_any_by_code(db, code)
    if existing:
        return await apartment_repo.refresh_from_realty(
            db, existing["id"], None, code, address, building
        )
    await apartment_repo.upsert_apartment(
        db,
        code=code,
        building=building,
        address=address,
        floor=0,
        apartment_type="unknown",
        area_m2=0,
        bathrooms_count=1,
        beds_count=1,
        sofa_beds_count=0,
    )
    return await apartment_repo.get_by_code(db, code)


async def _cancel_cleaning_if_possible(
    db: aiosqlite.Connection,
    timezone: str,
    task_id: Optional[int],
):
    if not task_id:
        return False
    task = await task_repo.get_by_id(db, task_id)
    if not task or task["status"] not in (
        TaskStatus.PLAN.value,
        TaskStatus.GUEST_CHECKED_OUT.value,
        TaskStatus.ASSIGNED.value,
    ):
        return False

    await db.execute(
        """
        UPDATE cleaning_tasks
        SET status = 'canceled',
            updated_at = ?
        WHERE id = ?
        """,
        (cleaning_service.now_iso(timezone), task_id),
    )
    await cleaning_service.log_event(
        db,
        task_id,
        None,
        "canceled",
        task["status"],
        TaskStatus.CANCELED.value,
        {"source": "realtycalendar"},
    )
    await db.commit()
    return True


async def _reconcile_related_dates(
    db: aiosqlite.Connection,
    settings: Settings,
    *date_values: Optional[str],
) -> list[dict]:
    results = []
    seen = set()
    for date_value in date_values:
        if not date_value or date_value in seen:
            continue
        seen.add(date_value)
        try:
            results.append(
                await booking_service.reconcile_cleaning_tasks_for_date(
                    db,
                    settings.timezone,
                    date_value,
                    user_id=None,
                )
            )
        except Exception:
            logger.exception("RealtyCalendar reconciliation failed for %s", date_value)
            results.append({"date": date_value, "error": "reconciliation failed"})
    return results


async def process_webhook(
    db: aiosqlite.Connection,
    settings: Settings,
    payload: Dict[str, Any],
) -> Dict[str, Any]:
    event_type = _event_type(payload)
    booking_payload = _get_booking_payload(payload)
    external_booking_id = _external_id(booking_payload)
    payload_json = json.dumps(payload, ensure_ascii=False)

    logger.info(
        "RealtyCalendar webhook received: event=%s booking_id=%s payload_keys=%s",
        event_type,
        external_booking_id,
        _payload_keys(booking_payload),
    )

    await booking_repo.log_realty_webhook_event(
        db,
        event_type,
        external_booking_id,
        payload_json,
    )

    apartment = None
    if _has_apartment_reference(booking_payload):
        apartment = await _resolve_apartment(db, booking_payload)

    if not external_booking_id:
        if _is_non_booking_payload(payload, booking_payload):
            return _ignored_result(
                "non-booking webhook event",
                payload_keys=_payload_keys(booking_payload),
            )
        return _ignored_result(
            "missing booking.id",
            payload_keys=_payload_keys(booking_payload),
        )

    existing = await booking_repo.get_by_external_booking_id(db, external_booking_id)
    incoming_status = str(booking_payload.get("status") or "").strip().lower()
    status_is_canceled = incoming_status in {
        "cancel",
        "canceled",
        "cancelled",
        "deleted",
    }
    if event_type in CANCEL_EVENTS or status_is_canceled:
        cancellation_changed = bool(existing and existing["status"] != "canceled")
        booking = await booking_repo.cancel_external_booking(db, external_booking_id)
        cleaning_canceled = False
        if booking:
            cleaning_canceled = await _cancel_cleaning_if_possible(
                db,
                settings.timezone,
                booking["cleaning_task_id"],
            )
        return {
            "ok": True,
            "event": event_type,
            "booking_id": external_booking_id,
            "canceled": True,
            "cancellation_changed": cancellation_changed,
            "booking_found": bool(booking),
            "cleaning_canceled": cleaning_canceled,
            "apartment_code": booking["apartment_code"] if booking else None,
            "housekeeping_excluded": bool(
                booking and not booking_service.housekeeping_cleaning_enabled(booking)
            ),
            "checkout_date": booking["checkout_date"] if booking else None,
            "checkout_time": (
                (booking["checkout_time"] or DEFAULT_CHECKOUT_TIME) if booking else None
            ),
        }

    incoming_checkin_date = _first_present(booking_payload, CHECKIN_DATE_KEYS)
    incoming_checkout_date = _first_present(booking_payload, CHECKOUT_DATE_KEYS)
    checkin_date = (
        _parse_date(incoming_checkin_date)
        if incoming_checkin_date is not None
        else (existing["checkin_date"] if existing else None)
    )
    checkout_date = (
        _parse_date(incoming_checkout_date)
        if incoming_checkout_date is not None
        else (existing["checkout_date"] if existing else None)
    )
    if not checkout_date:
        return _ignored_result(
            "missing checkout date",
            booking_id=external_booking_id,
            apartment_code=_apartment_title(booking_payload, _realty_id(booking_payload)),
            payload_keys=_payload_keys(booking_payload),
        )

    if existing and not _has_apartment_reference(booking_payload):
        apartment = await apartment_repo.get_by_id(db, existing["apartment_id"])
    if not apartment:
        apartment = await _resolve_apartment(db, booking_payload)

    incoming_checkin_time = _first_present(booking_payload, CHECKIN_TIME_KEYS)
    incoming_checkout_time = _first_present(booking_payload, CHECKOUT_TIME_KEYS)
    checkin_time = (
        _parse_time(incoming_checkin_time)
        or (existing["checkin_time"] if existing else None)
        or DEFAULT_CHECKIN_TIME
    )
    checkout_time = (
        _parse_time(incoming_checkout_time)
        or (existing["checkout_time"] if existing else None)
        or DEFAULT_CHECKOUT_TIME
    )
    checkout_change_kind = _checkout_change_kind(existing, checkout_date, checkout_time)
    extension_detected = checkout_change_kind is not None
    booking_created = existing is None
    checkin_changed = bool(
        existing
        and (
            checkin_date != existing["checkin_date"]
            or checkin_time != (existing["checkin_time"] or DEFAULT_CHECKIN_TIME)
        )
    )
    checkout_changed = bool(
        existing
        and (
            checkout_date != existing["checkout_date"]
            or checkout_time != (existing["checkout_time"] or DEFAULT_CHECKOUT_TIME)
        )
    )
    old_checkout_date = existing["checkout_date"] if existing else None
    old_checkout_time = existing["checkout_time"] if existing else None
    old_checkin_date = existing["checkin_date"] if existing else None
    old_checkin_time = existing["checkin_time"] if existing else None
    old_cleaning_task_id = existing["cleaning_task_id"] if existing else None
    old_cleaning_status = existing["cleaning_status"] if existing else None
    old_cleaning_planned_date = existing["cleaning_planned_date"] if existing else None
    had_active_task = bool(
        old_cleaning_task_id and old_cleaning_status != TaskStatus.CANCELED.value
    )
    guests_count = _extract_guest_count(booking_payload)
    if guests_count is None and existing:
        guests_count = existing["guests_count"]
    realty_id = _realty_id(booking_payload) or (existing["realty_id"] if existing else None)
    external_status = (
        booking_payload.get("status")
        or (existing["external_status"] if existing else None)
        or event_type
    )

    booking = await booking_repo.upsert_external_booking(
        db,
        external_booking_id=external_booking_id,
        realty_id=realty_id,
        apartment_id=apartment["id"],
        checkin_date=checkin_date,
        checkin_time=checkin_time,
        checkout_date=checkout_date,
        checkout_time=checkout_time,
        guests_count=guests_count,
        external_status=str(external_status),
        raw_payload_json=payload_json,
    )
    booking = await booking_service.refresh_turnover_links(
        db,
        settings.timezone,
        booking,
    )
    booking = await booking_service.ensure_cleaning_task(
        db,
        settings.timezone,
        booking["id"],
        None,
        checked_out=False,
    )
    current_task = (
        await task_repo.get_by_id(db, booking["cleaning_task_id"])
        if booking["cleaning_task_id"]
        else None
    )
    cleaning_created = bool(
        current_task
        and (
            not had_active_task
            or current_task["id"] != old_cleaning_task_id
        )
    )
    followup_cleaning_created = bool(
        checkout_changed
        and had_active_task
        and current_task
        and current_task["id"] != old_cleaning_task_id
    )
    task_rescheduled = bool(
        checkout_change_kind == "stay_extended"
        and current_task
        and current_task["id"] == old_cleaning_task_id
        and old_cleaning_planned_date != current_task["planned_date"]
        and current_task["planned_date"] == checkout_date
    )
    schedule_update_blocked = bool(
        checkout_change_kind == "stay_extended"
        and old_cleaning_task_id
        and current_task
        and current_task["id"] == old_cleaning_task_id
        and current_task["planned_date"] != checkout_date
    )
    schedule_updated = bool(
        checkout_changed
        and current_task
        and not schedule_update_blocked
    )
    reconciliation = await _reconcile_related_dates(
        db,
        settings,
        old_checkout_date if checkout_changed else None,
        old_checkin_date if checkin_changed else None,
        booking["checkout_date"],
        booking["checkin_date"],
    )
    previous_checkout = None
    if booking["checkin_date"]:
        previous_checkouts = await booking_repo.list_previous_checkouts_same_day(
            db,
            booking["apartment_id"],
            booking["checkin_date"],
            exclude_booking_id=booking["id"],
        )
        previous_checkout = previous_checkouts[0] if previous_checkouts else None

    return {
        "ok": True,
        "event": event_type,
        "booking_created": booking_created,
        "booking_id": external_booking_id,
        "local_booking_id": booking["id"],
        "cleaning_task_id": booking["cleaning_task_id"],
        "cleaning_created": cleaning_created,
        "followup_cleaning_created": followup_cleaning_created,
        "apartment_code": booking["apartment_code"],
        "housekeeping_excluded": not booking_service.housekeeping_cleaning_enabled(booking),
        "planned_date": booking["checkout_date"],
        "checkin_date": booking["checkin_date"],
        "checkin_time": booking["checkin_time"] or DEFAULT_CHECKIN_TIME,
        "checkout_date": booking["checkout_date"],
        "checkout_time": booking["checkout_time"] or DEFAULT_CHECKOUT_TIME,
        "next_checkin_time": booking["next_checkin_time"],
        "no_next_booking": bool(booking["no_next_booking"]),
        "previous_checkout_time": (
            (previous_checkout["checkout_time"] or DEFAULT_CHECKOUT_TIME)
            if previous_checkout
            else None
        ),
        "previous_cleaning_task_id": (
            previous_checkout["cleaning_task_id"] if previous_checkout else None
        ),
        "extension_detected": extension_detected,
        "checkin_changed": checkin_changed,
        "checkout_change_kind": checkout_change_kind,
        "checkout_changed": checkout_changed,
        "schedule_updated": schedule_updated,
        "task_rescheduled": task_rescheduled,
        "schedule_update_blocked": schedule_update_blocked,
        "old_checkout_date": old_checkout_date if checkout_changed else None,
        "old_checkout_time": old_checkout_time if checkout_changed else None,
        "old_checkin_date": old_checkin_date if checkin_changed else None,
        "old_checkin_time": old_checkin_time if checkin_changed else None,
        "new_checkin_date": checkin_date if checkin_changed else None,
        "new_checkin_time": checkin_time if checkin_changed else None,
        "new_checkout_date": checkout_date if extension_detected else None,
        "new_checkout_time": checkout_time if extension_detected else None,
        "maid_name": (
            (current_task["maid_name"] if current_task else None)
            or (existing["maid_name"] if existing else None)
        ) if extension_detected else None,
        "maid_telegram_id": (
            (
                (current_task["maid_telegram_id"] if current_task else None)
                or (existing["maid_telegram_id"] if existing else None)
            )
            if extension_detected
            else None
        ),
        "maid_language": (
            (
                (current_task["maid_language"] if current_task else None)
                or (existing["maid_language"] if existing else None)
            )
            if extension_detected
            else None
        ),
        "cleaning_status": old_cleaning_status if extension_detected else None,
        "current_cleaning_status": current_task["status"] if current_task else None,
        "old_cleaning_planned_date": old_cleaning_planned_date,
        "reconciliation": reconciliation,
    }
