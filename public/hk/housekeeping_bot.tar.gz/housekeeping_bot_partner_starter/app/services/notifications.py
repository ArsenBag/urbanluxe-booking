from __future__ import annotations

import logging

from aiogram import Bot

from app.config import Settings
from app.models import PROBLEM_TYPE_LABELS
from app.repositories import users as user_repo
from app.services.formatting import apartment_label, task_title
from app.services import shift_service


logger = logging.getLogger(__name__)


BOOKING_MANAGER_PROBLEM_TYPES = {
    "forgotten_items",
    "damage",
    "damaged_linen",
    "cigarette_smell",
    "supplies_missing",
    "guest_not_left",
    "no_access",
    "heavy_dirty",
    "property_damage",
    "other",
}


async def notify_telegram_id(bot: Bot, telegram_id, text: str) -> bool:
    if not telegram_id:
        logger.warning("Telegram notification skipped: recipient has no telegram_id")
        return False
    try:
        await bot.send_message(int(telegram_id), text)
    except Exception as exc:
        # A failed notification must not break the operational action.
        logger.warning(
            "Telegram notification failed: telegram_id=%s error=%s",
            telegram_id,
            type(exc).__name__,
        )
        return False
    logger.info("Telegram notification delivered: telegram_id=%s", telegram_id)
    return True


async def _notify_people(
    bot: Bot,
    users,
    text: str,
    photo_file_ids=None,
    video_file_ids=None,
    media_caption: str = "Материал",
) -> None:
    sent_to = set()
    photo_file_ids = list(photo_file_ids or [])
    video_file_ids = list(video_file_ids or [])
    for user in users:
        telegram_id = user["telegram_id"]
        if not telegram_id or telegram_id in sent_to:
            continue
        sent_to.add(telegram_id)
        await notify_telegram_id(bot, telegram_id, text)
        for photo_file_id in photo_file_ids:
            try:
                await bot.send_photo(int(telegram_id), photo_file_id, caption=media_caption)
            except Exception:
                continue
        for video_file_id in video_file_ids:
            try:
                await bot.send_video(int(telegram_id), video_file_id, caption=media_caption)
            except Exception:
                continue


async def notify_maid(bot: Bot, task, text: str) -> None:
    await notify_telegram_id(bot, task["maid_telegram_id"], text)


async def notify_supervisor(bot: Bot, task, text: str) -> None:
    await notify_telegram_id(bot, task["supervisor_telegram_id"], text)


async def notify_admins(bot: Bot, db, text: str) -> None:
    users = await user_repo.list_admins(db)
    for user in users:
        await notify_telegram_id(bot, user["telegram_id"], text)


async def notify_supervisors_on_shift(
    bot: Bot,
    db,
    settings: Settings,
    text: str,
    fallback_to_admins: bool = True,
) -> None:
    supervisors = await shift_service.supervisors_on_shift(db, settings.timezone)
    if supervisors:
        for supervisor in supervisors:
            await notify_telegram_id(bot, supervisor["telegram_id"], text)
        return

    if fallback_to_admins:
        await notify_admins(
            bot,
            db,
            "Нет супервайзера на смене. Уведомление для контроля:\n\n" + text,
        )


async def notify_supervisors_and_admins(bot: Bot, db, settings: Settings, text: str) -> None:
    await notify_supervisors_on_shift(bot, db, settings, text, fallback_to_admins=True)


async def notify_maid_shift_started(
    bot: Bot,
    db,
    settings: Settings,
    maid_name: str,
    started_at: str,
) -> None:
    admins = await user_repo.list_admins(db)
    supervisors = await shift_service.supervisors_on_shift(db, settings.timezone)
    started_time = shift_service.format_shift_time(started_at)
    await _notify_people(
        bot,
        [*admins, *supervisors],
        f"Горничная {maid_name} пришла на смену в {started_time}.",
    )


async def notify_maid_shift_ended(
    bot: Bot,
    db,
    settings: Settings,
    maid_name: str,
    ended_at: str,
    cart_photo_file_id: str,
) -> None:
    admins = await user_repo.list_admins(db)
    supervisors = await shift_service.supervisors_on_shift(db, settings.timezone)
    ended_time = shift_service.format_shift_time(ended_at)
    await _notify_people(
        bot,
        [*admins, *supervisors],
        f"Горничная {maid_name} завершила смену в {ended_time}.",
        photo_file_ids=[cart_photo_file_id],
        media_caption=f"Рабочая тележка · {maid_name}",
    )


async def notify_problem_stakeholders(
    bot: Bot,
    db,
    settings: Settings,
    task,
    maid_name: str,
    problem_type: str,
    comment: str | None = None,
    photo_file_ids=None,
    video_file_ids=None,
) -> None:
    problem_label = PROBLEM_TYPE_LABELS.get(problem_type, problem_type)
    text = (
        "Проблема от горничной\n"
        f"Объект: {apartment_label(task)}\n"
        f"Тип: {problem_label}\n"
        f"Горничная: {maid_name or '-'}"
    )
    if comment:
        text += f"\nКомментарий: {comment}"

    supervisors = await shift_service.supervisors_on_shift(db, settings.timezone)
    if supervisors:
        await _notify_people(bot, supervisors, text, photo_file_ids, video_file_ids, "Материал к проблеме")
    else:
        admins = await user_repo.list_admins(db)
        await _notify_people(
            bot,
            admins,
            "Нет супервайзера на смене. Уведомление для контроля:\n\n" + text,
            photo_file_ids,
            video_file_ids,
            "Материал к проблеме",
        )

    if problem_type not in BOOKING_MANAGER_PROBLEM_TYPES:
        return

    booking_managers = await user_repo.list_booking_managers(db)
    if booking_managers:
        await _notify_people(bot, booking_managers, text, photo_file_ids, video_file_ids, "Материал к проблеме")
        return

    await notify_admins(
        bot,
        db,
        "Нет менеджера бронирований в списке. Уведомление для контроля:\n\n" + text,
    )


async def notify_missing_keys_stakeholders(bot: Bot, db, task, maid_name: str) -> bool:
    text = (
        "Проблема в квартире: нет ключей\n"
        f"Объект: {apartment_label(task)}\n"
        f"Горничная: {maid_name or '-'}\n"
        "Уборку можно продолжать. До размещения ключей квартира не готова к заезду."
    )
    supervisors = [
        user for user in await user_repo.list_by_roles(db, ["supervisor"])
        if user["telegram_id"]
    ]
    booking_managers = [
        user for user in await user_repo.list_booking_managers(db)
        if user["telegram_id"]
    ]
    supervisor_delivered = any([
        await notify_telegram_id(bot, user["telegram_id"], text)
        for user in supervisors
    ])
    manager_delivered = any([
        await notify_telegram_id(bot, user["telegram_id"], text)
        for user in booking_managers
    ])

    missing_roles = []
    if not supervisor_delivered:
        missing_roles.append("супервайзеров")
    if not manager_delivered:
        missing_roles.append("менеджеров бронирований")
    if missing_roles:
        admins = await user_repo.list_admins(db)
        fallback_text = f"Не удалось уведомить {' и '.join(missing_roles)}. Уведомление для контроля:\n\n{text}"
        return any([
            await notify_telegram_id(bot, user["telegram_id"], fallback_text)
            for user in admins
        ])
    return True


async def notify_forgotten_items_stakeholders(
    bot: Bot,
    db,
    settings: Settings,
    task,
    maid_name: str,
    comment: str | None = None,
    photo_file_ids=None,
    video_file_ids=None,
) -> None:
    text = (
        "Забытые вещи\n"
        f"Объект: {apartment_label(task)}\n"
        f"Горничная: {maid_name or '-'}"
    )
    if comment:
        text += f"\nКомментарий: {comment}"

    supervisors = await shift_service.supervisors_on_shift(db, settings.timezone)
    if supervisors:
        await _notify_people(bot, supervisors, text, photo_file_ids, video_file_ids, "Забытые вещи")
    else:
        admins = await user_repo.list_admins(db)
        await _notify_people(
            bot,
            admins,
            "Нет супервайзера на смене. Уведомление для контроля:\n\n" + text,
            photo_file_ids,
            video_file_ids,
            "Забытые вещи",
        )

    booking_managers = await user_repo.list_booking_managers(db)
    if booking_managers:
        await _notify_people(bot, booking_managers, text, photo_file_ids, video_file_ids, "Забытые вещи")
        return

    await notify_admins(
        bot,
        db,
        "Нет менеджера бронирований в списке. Уведомление для контроля:\n\n" + text,
    )


def _task_value(task, key: str, default=None):
    try:
        value = task[key]
    except Exception:
        return default
    return default if value is None else value


def _ready_checkin_text(task) -> str:
    if bool(_task_value(task, "booking_no_next_booking", False)):
        return "заезда нет"
    value = _task_value(task, "booking_next_checkin_time")
    if value == "after_18":
        return "после 18:00"
    return value or "-"


async def notify_booking_managers(bot: Bot, db, text: str) -> None:
    booking_managers = await user_repo.list_booking_managers(db)
    if booking_managers:
        await _notify_people(bot, booking_managers, text)
        return

    await notify_admins(
        bot,
        db,
        "Нет менеджера бронирований в списке. Уведомление для контроля:\n\n" + text,
    )


async def notify_ready_for_checkin(bot: Bot, db, task) -> None:
    await notify_booking_managers(
        bot,
        db,
        "Готово к заезду:\n"
        f"Объект: {apartment_label(task)}\n"
        f"Следующий заезд: {_ready_checkin_text(task)}\n"
        f"Горничная: {_task_value(task, 'maid_name', '-')}",
    )


async def notify_task_assigned(bot: Bot, task) -> None:
    await notify_maid(bot, task, f"Вам назначена уборка: {task_title(task)}")


async def notify_task_started(bot: Bot, db, settings: Settings, task) -> None:
    maid = task["maid_name"] or "Горничная"
    await notify_supervisors_on_shift(
        bot,
        db,
        settings,
        f"{maid} начала уборку {apartment_label(task)}",
    )


async def notify_task_finished(bot: Bot, db, settings: Settings, task) -> None:
    maid = task["maid_name"] or "Горничная"
    await notify_supervisors_on_shift(
        bot,
        db,
        settings,
        f"{maid} завершила {apartment_label(task)}, ждет проверки",
    )
