import csv
from pathlib import Path
from typing import Tuple

import aiosqlite

from app.config import PROJECT_ROOT, Settings
from app.models import VERIFICATION_METHOD_LABELS
from app.repositories import cleaning_tasks as task_repo
from app.repositories import shifts as shift_repo
from app.services.formatting import compact_apartment_code, format_date, format_time


EXPORT_COLUMNS = [
    "task_id",
    "date",
    "apartment_code",
    "building",
    "apartment_type",
    "cleaning_type",
    "maid",
    "supervisor",
    "status",
    "planned_start",
    "deadline",
    "started_at",
    "finished_at",
    "duration_min",
    "quality_score",
    "verification_method",
    "verified_by",
    "rework_required",
    "rework_reason",
    "problem_type",
    "comment",
]


EXCEL_HEADERS = {
    "task_id": "ID",
    "date": "Дата",
    "apartment_code": "Объект",
    "building": "ЖК",
    "apartment_type": "Тип апартаментов",
    "cleaning_type": "Тип уборки",
    "maid": "Горничная",
    "supervisor": "Супервизор",
    "status": "Статус",
    "planned_start": "Плановый старт",
    "deadline": "Дедлайн",
    "started_at": "Начало",
    "finished_at": "Завершение",
    "duration_min": "Минут",
    "quality_score": "Оценка",
    "verification_method": "Способ проверки (со слов супервайзера)",
    "verified_by": "Кто принял",
    "rework_required": "Переделка",
    "rework_reason": "Причина переделки",
    "problem_type": "Проблема",
    "comment": "Комментарий",
}


SHIFT_EXPORT_COLUMNS = [
    "work_date",
    "maid_name",
    "started_at",
    "ended_at",
    "duration",
    "close_type",
    "assigned_count",
    "completed_count",
    "verified_count",
]


SHIFT_EXCEL_HEADERS = {
    "work_date": "Дата",
    "maid_name": "Горничная",
    "started_at": "Приход",
    "ended_at": "Уход",
    "duration": "Длительность",
    "close_type": "Закрытие смены",
    "assigned_count": "Всего назначено",
    "completed_count": "Завершено уборок",
    "verified_count": "Принято уборок",
}


def task_to_row(task) -> dict:
    was_verified = task["status"] == "verified" or bool(task["verified_at"])
    return {
        "task_id": task["id"],
        "date": task["planned_date"],
        "apartment_code": compact_apartment_code(task["apartment_code"]),
        "building": task["building"],
        "apartment_type": task["apartment_type"],
        "cleaning_type": task["cleaning_type"],
        "maid": task["maid_name"],
        "supervisor": task["supervisor_name"],
        "status": task["status"],
        "planned_start": format_time(task["planned_start_at"]),
        "deadline": format_time(task["deadline_at"]),
        "started_at": format_time(task["started_at"]),
        "finished_at": format_time(task["finished_at"]),
        "duration_min": task["actual_duration_min"],
        "quality_score": task["quality_score"],
        "verification_method": VERIFICATION_METHOD_LABELS.get(
            task["verification_method"],
            "Не указано" if was_verified else "",
        ),
        "verified_by": task["verified_by_name"] or (
            "Не указано" if was_verified else ""
        ),
        "rework_required": "yes" if task["rework_required"] else "no",
        "rework_reason": task["rework_reason"],
        "problem_type": task["problem_type"],
        "comment": task["comment"],
    }


async def export_csv(db: aiosqlite.Connection, planned_date: str) -> Path:
    export_dir = PROJECT_ROOT / "data" / "exports"
    export_dir.mkdir(parents=True, exist_ok=True)
    path = export_dir / f"cleaning_tasks_{planned_date}.csv"
    tasks = await task_repo.list_for_date(db, planned_date)

    with path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=EXPORT_COLUMNS)
        writer.writeheader()
        for task in tasks:
            writer.writerow(task_to_row(task))
    return path


def _export_path(start_date: str, end_date: str, suffix: str) -> Path:
    export_dir = PROJECT_ROOT / "data" / "exports"
    export_dir.mkdir(parents=True, exist_ok=True)
    if start_date == end_date:
        filename = f"cleaning_tasks_{start_date}.{suffix}"
    else:
        filename = f"cleaning_tasks_{start_date}_{end_date}.{suffix}"
    return export_dir / filename


def _shift_export_path(start_date: str, end_date: str) -> Path:
    export_dir = PROJECT_ROOT / "data" / "exports"
    export_dir.mkdir(parents=True, exist_ok=True)
    suffix = start_date if start_date == end_date else f"{start_date}_{end_date}"
    return export_dir / f"maid_shifts_{suffix}.xlsx"


def _style_sheet(sheet, columns, headers, alignment_type, font_type, fill_type, get_column_letter):
    header_fill = fill_type("solid", fgColor="D9EAD3")
    for cell in sheet[1]:
        cell.font = font_type(bold=True)
        cell.fill = header_fill
        cell.alignment = alignment_type(horizontal="center", vertical="center", wrap_text=True)

    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = alignment_type(vertical="top", wrap_text=True)

    for index, column in enumerate(columns, start=1):
        values = [headers[column]]
        for row_index in range(2, sheet.max_row + 1):
            value = sheet.cell(row_index, index).value
            values.append("" if value is None else str(value))
        width = min(max(len(value) for value in values) + 2, 42)
        sheet.column_dimensions[get_column_letter(index)].width = width

    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions


async def export_xlsx(db: aiosqlite.Connection, start_date: str, end_date: str) -> Path:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError as exc:
        raise RuntimeError("Для Excel-выгрузки нужно установить openpyxl.") from exc

    path = _export_path(start_date, end_date, "xlsx")
    tasks = (
        await task_repo.list_for_date(db, start_date)
        if start_date == end_date
        else await task_repo.list_for_date_range(db, start_date, end_date)
    )

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Уборки"
    sheet.append([EXCEL_HEADERS[column] for column in EXPORT_COLUMNS])

    for task in tasks:
        row = task_to_row(task)
        sheet.append([row.get(column, "") for column in EXPORT_COLUMNS])

    _style_sheet(
        sheet,
        EXPORT_COLUMNS,
        EXCEL_HEADERS,
        Alignment,
        Font,
        PatternFill,
        get_column_letter,
    )
    workbook.save(path)
    return path


def _shift_duration(started_at: str, ended_at: str) -> str:
    if not started_at or not ended_at:
        return "-"
    try:
        from datetime import datetime

        duration = datetime.fromisoformat(ended_at) - datetime.fromisoformat(started_at)
    except (TypeError, ValueError):
        return "-"
    total_minutes = max(0, round(duration.total_seconds() / 60))
    hours, minutes = divmod(total_minutes, 60)
    return f"{hours} ч {minutes:02d} мин"


async def export_shifts_xlsx(
    db: aiosqlite.Connection,
    start_date: str,
    end_date: str,
) -> Path:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError as exc:
        raise RuntimeError("Для Excel-выгрузки нужно установить openpyxl.") from exc

    path = _shift_export_path(start_date, end_date)
    shifts = await shift_repo.list_report_for_range(db, start_date, end_date)

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Смены"
    sheet.append([SHIFT_EXCEL_HEADERS[column] for column in SHIFT_EXPORT_COLUMNS])

    for shift in shifts:
        if not shift["ended_at"]:
            close_type = "Смена не закрыта"
        elif shift["auto_closed"]:
            close_type = "Автоматически"
        else:
            close_type = "Вручную"
        row = {
            "work_date": format_date(shift["work_date"]),
            "maid_name": shift["maid_name"],
            "started_at": format_time(shift["started_at"]),
            "ended_at": format_time(shift["ended_at"]),
            "duration": _shift_duration(shift["started_at"], shift["ended_at"]),
            "close_type": close_type,
            "assigned_count": shift["assigned_count"],
            "completed_count": shift["completed_count"],
            "verified_count": shift["verified_count"],
        }
        sheet.append([row[column] for column in SHIFT_EXPORT_COLUMNS])

    _style_sheet(
        sheet,
        SHIFT_EXPORT_COLUMNS,
        SHIFT_EXCEL_HEADERS,
        Alignment,
        Font,
        PatternFill,
        get_column_letter,
    )
    workbook.save(path)
    return path


async def sync_google_sheets(
    settings: Settings,
    db: aiosqlite.Connection,
    planned_date: str,
) -> Tuple[bool, str]:
    if not settings.google_sheet_id:
        return False, "Не задан GOOGLE_SHEET_ID."
    if not settings.google_credentials_file:
        return False, "Не задан GOOGLE_CREDENTIALS_FILE."

    try:
        from google.oauth2.service_account import Credentials
        from googleapiclient.discovery import build
    except ImportError:
        return False, "Не установлены google-api-python-client и google-auth."

    credentials_path = Path(settings.google_credentials_file)
    if not credentials_path.is_absolute():
        credentials_path = PROJECT_ROOT / credentials_path
    if not credentials_path.exists():
        return False, f"Файл credentials не найден: {credentials_path}"

    credentials = Credentials.from_service_account_file(
        str(credentials_path),
        scopes=["https://www.googleapis.com/auth/spreadsheets"],
    )
    service = build("sheets", "v4", credentials=credentials)

    tasks = await task_repo.list_for_date(db, planned_date)
    values = [EXPORT_COLUMNS] + [
        [task_to_row(task).get(column, "") for column in EXPORT_COLUMNS]
        for task in tasks
    ]

    range_name = "cleaning_tasks!A1"
    body = {"values": values}
    service.spreadsheets().values().clear(
        spreadsheetId=settings.google_sheet_id,
        range="cleaning_tasks!A:Z",
    ).execute()
    service.spreadsheets().values().update(
        spreadsheetId=settings.google_sheet_id,
        range=range_name,
        valueInputOption="RAW",
        body=body,
    ).execute()
    return True, f"Google Sheets обновлен: {len(tasks)} задач."
