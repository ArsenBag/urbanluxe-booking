#!/usr/bin/env sh
set -eu

python scripts/init_db.py
exec python -m app.main

